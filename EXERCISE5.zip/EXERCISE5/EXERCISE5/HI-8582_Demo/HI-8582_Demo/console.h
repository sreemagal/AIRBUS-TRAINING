/*---------------------------------------------------------------------------- 
 *            H O L T   I N T E G R A T E D   C I R C U I T S 
 *---------------------------------------------------------------------------- 
 * The software is delivered "AS IS" without warranty or condition of any
 * kind, either expressed, implied or statutory. This includes without
 * limitation any warranty or condition with respect to merchantability or
 * fitness for any particular purpose, or against the infringements of
 * intellectual property rights of others.
 *----------------------------------------------------------------------------
 
 File Name              : console.h
 Object                 : Function Protoypes for reference design,
                          HI-8582_83 Evaluation Board based on the Atmel Cortex M-3
                                                 
 ----------------------------------------------------------------------------*/



//------------------------------------------------------------------------------
//     function prototypes
//------------------------------------------------------------------------------

void ConfigureUsart1(void);
void chk_key_input(void);
void show_menu(void);

