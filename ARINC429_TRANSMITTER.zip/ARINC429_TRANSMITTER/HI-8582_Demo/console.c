/* ----------------------------------------------------------------------------
 *                            HOLT Integrated Circuits 
 * ----------------------------------------------------------------------------
 *
 *    file	console.c
 *    object    HyperTerminal-style console I/O for reference design, Holt
                HI-3582A_83A Evaluation Board based on the Atmel Cortex M-3
 
 *    brief     This file contains functions for UART initialization, console
 *              screen text display and keyboard input when using a program 
 *              like HyperTerminal. 
 *
 *              Settings: 115200 baud, 8 data bits, 1 stop bit, no parity, 
 *              hardware flow control OFF
 *
 *	   	HOLT DISCLAIMER
 *      	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
 *      	KIND, EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 *      	WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 *      	PURPOSE AND NONINFRINGEMENT. 
 *      	IN NO EVENT SHALL HOLT, INC BE LIABLE FOR ANY CLAIM, DAMAGES
 *      	OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 *      	OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 *      	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
 *
 *              Copyright (C) 2009-2011 by  HOLT, Inc.
 *              All Rights Reserved
 */

// standard Atmel/IAR headers
#include <usart/usart.h>
#include <stdio.h>
#include <pio/pio.h>
#include <pmc/pmc.h>

// Holt project headers
#include "boardSupport.h"

#include "console.h"
#include "3582A_83A_Driver.h"   
#include "board_EBI.h"
extern const H3582 pH3582;


//------------------------------------------------------------------------------
//         Global variables
//------------------------------------------------------------------------------
extern unsigned short EmptyOrFull;


//------------------------------------------------------------------------------
//         Functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// Configures USART: hardware flow control OFF, asynchronous, 8 bits, 1 stop
/// bit, no parity, 115200 baud, then enables USART transmitter and receiver.
//------------------------------------------------------------------------------
void ConfigureUsart1(void)
{
  const Pin pins[] = {PINS_USART};
  
  unsigned int mode = AT91C_US_USMODE_NORMAL // USMODE_HWHSH enables RTS/CTS handshaking
                        | AT91C_US_CLKS_CLOCK
                        | AT91C_US_CHRL_8_BITS
                        | AT91C_US_PAR_NONE
                        | AT91C_US_NBSTOP_1_BIT
                        | AT91C_US_CHMODE_NORMAL;

    // configure PIO pins used by USART1
    PIO_Configure(pins, PIO_LISTSIZE(pins));  
  
    // Enable the peripheral clock in the PMC
    PMC_EnablePeripheral(BOARD_ID_USART);

    // Configure the USART in the desired mode @ 115200 baud
    USART_Configure(BOARD_USART_BASE, mode, 115200, BOARD_MCK);

   // Enable USART receiver & transmitter
    USART_SetTransmitterEnabled(BOARD_USART_BASE, 1);
    USART_SetReceiverEnabled(BOARD_USART_BASE, 1);
}


//------------------------------------------------------------------------------
//     function sends ASCII text header to screen
//------------------------------------------------------------------------------
void show_menu(void) {
  
    // Console Output via USART to user HyperTerminal

    putchar(12); // clear screen, may not work on some terminals

    printf("\n\r*************************************************\n\r");
    printf("   Holt Integrated Circuits HI-8582/HI-8583\n\r");
    printf("        Compiled: %s %s        \n\r", __DATE__, __TIME__);
    printf("*************************************************\n\n\r");
    printf("Press-0 to Enter Hardware Test mode, Pulse 74VC138 decoder outputs\n\r");
    printf("Press-1 to Toggle Enable/Disable Receiver-1 label recognition\n\r");
    printf("Press-2 to Toggle Enable/Disable Receiver-2 label recognition\n\r");
    printf("Press-5 to Enable  Receiver-1 Encoder data9=0 and data10=0 bits\n\r");
    printf("Press-6 to Disable Receiver-1 Encoder data9=0 and data10=0 bits\n\r");
    printf("Press-7 to Enable  Receiver-2 Encoder data9=0 and data10=0 bits\n\r");
    printf("Press-8 to Disable Receiver-2 Encoder data9=0 and data10=0 bits\n\r"); 
    printf("Press f or F to Toggle between FIFO Empty and FIFO Full demonstration\n\r");
    printf("Press l or L to load and read back 16 labels on Rec-1 and Rec-2\n\r");
    printf("Press h or H to Display this Menu\n\r");
    printf("Press m or M to apply a MR pulse to the HI-8582/83\n\r");
    printf("Press p or P to Toggle Transmitter ARINC bit32 between data or Parity\n\r");
    printf("Press s or S to Toggle the HI-8582/83 between Scrample and Un-scramble mode\n\r");
    printf("Press r or R to Toggle between HIGH SPEED and LOW SPEED\n\r");
    printf("Press t or T to Toggle between Self-Test Mode and Normal Operation\n\r"); 
    printf("Press SPACE BAR to Pause\n\r");   

  
} // end of show_menu()



//---------------------------------------------------------------------------
//   brief	this function checks for keyboard input and
//		decodes it, acts on it, when it occurs
//---------------------------------------------------------------------------
void chk_key_input(void) {

    char key;
  
    // poll USART Channel Status Reg for Rx Ready 
    if(USART_IsRxReady(BOARD_USART_BASE)) {
        // got key press at computer keyboard,
        // read USART Receive Holding register
        key = USART_GetChar(BOARD_USART_BASE);
             
        printf("\n\r");      
        switch(key) {
          
         // simple Hardware Test - Press Reset to return to program. 
         case '0': 
                       {
                unsigned short statusRegister;

                while(1){
                    Delay_x100ms(1);                  
                    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  //   LED ON 
                    printf("Testing Chip Selects and toggling LED in endless loop....\n\r");
                    Delay_x100ms(1);
                    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  //   LED OFF
                    statusRegister = pH3582->EN1;       //   read en1
                    pH3582->EN2 =statusRegister ;       //   write en2   
                    statusRegister = pH3582->CWSTR;     //   read cwstr      
                    statusRegister = pH3582->RSR;       //   read rsr
                    statusRegister = pH3582->PL2;       //   read pl2
                    statusRegister = pH3582->PL1;       //   read pl1
                    }
                }         
          
        // Toggle Enable/Disable Receiver-1 labels recognition  
        case '1': 
          {
            unsigned short controlWordM;            

            controlWordM = readControlWord();     // read the CW 
            if(controlWordM & CR2)          // labels enabled?
            {
                enableRec1_Labels(DISABLE);    // disable them
                printf("Receiver 1 labels Disabled\n\r");                  
            }
            else
            {
                enableRec1_Labels(ENABLE);    // disable them  
                printf("Receiver 1 labels Enabled\n\r");          
            }  
            Delay_x100ms(10);               
          }
          break; 
          
        // Toggle Enable/Disable Receiver-2 labels recognition  
        case '2': 
          {
            unsigned short controlWordM;            

            controlWordM = readControlWord();     // read the CW 
            if(controlWordM & CR3)          // labels enabled?
            {
                enableRec2_Labels(DISABLE);    // disable them
                printf("Receiver 2 labels Disabled\n\r");                  
            }
            else
            {
                enableRec2_Labels(ENABLE);    // disable them  
                printf("Receiver 2 labels Enabled\n\r");          
            }  
            Delay_x100ms(10);               
          }
          break;  
 
        // Enable Rec-1 Encoder bits9/10
        case '5':           
            setRec_1Bit_9Bit10encoder(ENABLE, 0, 0);   //  
            printf("Receiver 1 Encoder bits9/10 enabled\n\r");                   
            Delay_x100ms(10);               
          break; 
          
        // Disable Rec-1 Encoder bits9/10
        case '6':           
            setRec_1Bit_9Bit10encoder(DISABLE, 0, 0);   //  
            printf("Receiver 1 Encoder bits9/10 disabled\n\r");                   
            Delay_x100ms(10);               
          break;           
 
        // Enable Rec-1 Encoder bits9/10
        case '7':           
            setRec_2Bit_9Bit10encoder(ENABLE, 0, 0);   //  
            printf("Receiver 2 Encoder bits9/10 enabled\n\r");                   
            Delay_x100ms(10);               
          break; 
        // Disable Rec-1 Encoder bits9/10
        case '8':           
            setRec_2Bit_9Bit10encoder(DISABLE, 0, 0);   //  
            printf("Receiver 2 Encoder bits9/10 disabled\n\r");                   
            Delay_x100ms(10);               
          break;         
          
   
          
        // Space bar will pause and print out the CR, any key will continue
        case ' ': 
          {
            printf("\n\rProgram Paused, press any key to continue\n\r");
            printf("Control Word: 0x%.4X\n\r",readControlWord());
            while(!(USART_IsRxReady(BOARD_USART_BASE)));
                    key = USART_GetChar(BOARD_USART_BASE);
          }
          break; 
          
        // Toggle between FIFO Empty or FIFO FULL demo  
        case 'f':
        case 'F':
          if(EmptyOrFull){
              EmptyOrFull=0;
              printf("FIFO EMPTY Demo\n\r");
          }
            else{
              EmptyOrFull=1;  
              printf("FIFO FULL Demo\n\r");              
            }
            Delay_x100ms(10);  
            break; 
          
          
        // Initialize Label memory for both Receivers  
        case 'l':
        case 'L':
                loadReceiver_1_Labels();
                readReceiver_1_Labels();  
                loadReceiver_2_Labels();
                readReceiver_2_Labels();  
            printf("\n\rProgram Paused, press any key to continue\n\r");
            while(!(USART_IsRxReady(BOARD_USART_BASE)));
                    key = USART_GetChar(BOARD_USART_BASE);                
                
            break; 
            
        // Show Help menu  
        case 'h':
        case 'H':
            show_menu();
            printf("\n\rProgram Paused, press any key to continue\n\r");
            while(!(USART_IsRxReady(BOARD_USART_BASE)));
                    key = USART_GetChar(BOARD_USART_BASE);            
            break;

        // Master Reset
        case 'M':
        case 'm':
          {
            unsigned short statusReg;
           
            statusReg=reset_3582();                  // reset the 3582                             
            if(statusReg==SR_VALID_FROM_RESET){
            AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON  RSR is good
            printf("Part Detected, Status Reg Valid =0x%.4X\n\n\r",statusReg);
            writeControlWord(DEFAULTCONFG);     // default config to enable ALL
            }
            else{
            AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF RSR is bad
            printf("*** Part Not Detected, Status Reg Invalid =0x%.4X ***\n\n\r",statusReg); 
            printf(" Should be 0x0040. ");       
            }
          }
            break;
            
        // Toggle transmitter bit32 between data and parity bit  
        case'p':
        case 'P':
        toggleParityBit32();                    
        Delay_x100ms(10);               
        break;
        
        // Scramble and Unscramble    
        case 's':
        case 'S':
          {
            unsigned short controlWordM;            

            controlWordM = readControlWord();     // read the CW 
            if(controlWordM & CR15)          // Scrambled?
            {
                controlWordM &= 0x7FFF; // Scramble
                printf("Scrambled \n\r");                  
            }
            else
            {
                controlWordM |= 0x8000; // UnScramble
                printf("Un-scrambled \n\r");     
            }  
            writeControlWord(controlWordM); // write modified CW            
            Delay_x100ms(10);               
          }
          break; 
          
         // Toggle between HI and LO speeds, Affects all channels 
        case 'r':
        case 'R':
                {
                unsigned short controlWordM;            

                controlWordM = readControlWord();     // read the CW 
                if(controlWordM & CR13) // check TX data rate slow?
                {
                 // Set fast speed
                  controlWordM &= ~(CR0 | CR13 | CR14);
                  printf("HIGH SPEED\n\r");                 
                }
                else{
                 // Set slow speed 
                  controlWordM |= (CR0 | CR13 | CR14);
                  printf("LOW SPEED\n\r");              
                }
                
                writeControlWord(controlWordM); // write modified CW                  
                Delay_x100ms(10);                            
           }
          break;      
          
        // Toggle between Self-Test and Normal Operation    
        case 't':
        case 'T':
                toggleSelfTestMode();
                 Delay_x100ms(10);              
          break;
          

        default:
          // Ignore any invalid keypress

        break;
                  
            } // end switch(key)
        
    }  // end if(USART_IsRxReady(BOARD_USART_BASE))
                    
} // end chk_key_input()
                                                         
                                       

