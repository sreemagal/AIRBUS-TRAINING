HI-8582/83 Demo Project

Version 1.0 Initial release. 6/21/17.

IDE IAR EWARM 7.1 or greater
Project is nearly identical to HI-3582A 



