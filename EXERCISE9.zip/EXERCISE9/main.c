/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 9 – UART-Controlled ARINC429 Transmitter
 *
 * This exercise turns the ADK8582 + HI-8582 into a simple ARINC429
 * transmitter whose behaviour is controlled at run-time over UART
 * (USART1) by a host (PC terminal or IMXRT1050).
 *
 * UART settings: 115200 baud, 8 data bits, 1 stop bit, no parity.
 *
 * UART command summary (single-character commands):
 *   'h' or 'H' : show help and current configuration
 *   'e' or 'E' : enable ARINC transmission
 *   'd' or 'D' : disable ARINC transmission
 *   '1'        : set TX label = 0x01
 *   '2'        : set TX label = 0x02
 *   '3'        : set TX label = 0x03
 *   '4'        : set TX label = 0x04
 *   'f' or 'F' : fast transmit rate  (~100 ms between words)
 *   's' or 'S' : slow transmit rate  (~500 ms between words)
 *
 * Transmit pattern:
 *   - Label = current label selected by the host (default 0x01).
 *   - Upper 16 bits of the word form an incrementing counter.
 *   - Lower data bits (bits 8..15 excluding label) are 0.
 *
 * Trainee observations:
 *   - On the ARINC analyzer:
 *       Observe the selected label (0x01..0x04) and incrementing data field.
 *       Changing UART commands changes what appears on the ARINC bus.
 *   - On the UART console (HyperTerminal / IMXRT debug console):
 *       See TX lines such as:
 *         TX : 0x01000001  Label: 0x01
 *       plus feedback messages when commands are received.
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
// standard Atmel/IAR headers
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>
#include <usart/usart.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables & macros
//------------------------------------------------------------------------------
#define VER "1.0"

// Required by console.c (FIFO handling flag, not used in this exercise)
unsigned short EmptyOrFull = 0;

// Holt driver base pointer (from 3582A_83A_Driver.h)
const H3582 pH3582 = HI3582_BASE;

// Transmission control state (modified by UART commands)
static unsigned char  g_txEnabled     = 0;    // 0 = disabled, 1 = enabled
static unsigned char  g_txLabel       = 0x01; // default label
static unsigned short g_txDelayTicks  = 1;    // Delay_x100ms() ticks between words

// From driver header (status after reset)
#ifndef SR_VALID_FROM_RESET
#define SR_VALID_FROM_RESET 0x0040
#endif

//------------------------------------------------------------------------------
//  Helper: brief status/control dump at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("TX FIFO Status bits:\r\n");
    printf("  SR6 (0x0040) TX FIFO empty      : %s\r\n",
           (statusReg & 0x0040) ? "YES (no words pending)" : "no");
    printf("  SR7 (0x0080) TX FIFO not full   : %s\r\n",
           (statusReg & 0x0080) ? "YES (space available)"  : "no (TX FIFO full)");
    printf("  SR8 (0x0100) TX FIFO half-full  : %s\r\n",
           (statusReg & 0x0100) ? "YES (>=16 words loaded)" : "no (<16 words)");

    printf("\r\nDefault TX config (from Control Reg):\r\n");
    printf("  CR4 (0x0010) bit 32 function    : %s\r\n",
           (controlReg & 0x0010) ? "Parity bit (ARINC 32nd bit is parity)"
                                 : "Data bit (no parity bit)");
    printf("  CR12(0x1000) TX parity mode     : %s\r\n",
           (controlReg & 0x1000) ? "Even parity on bit 32"
                                 : "Odd parity on bit 32");
    printf("  CR13(0x2000) TX data rate       : %s\r\n",
           (controlReg & 0x2000) ? "LOW speed (CLK/80 ≈ 12.5 kbps)"
                                 : "HIGH speed (CLK/10 ≈ 100 kbps)");
    printf("  CR15(0x8000) data format        : %s\r\n",
           (controlReg & 0x8000) ? "Unscrambled ARINC (standard label/data layout)"
                                 : "Scrambled data\r\n");

    printf("\r\n");
}

//------------------------------------------------------------------------------
//  Helper: print UART command help and current configuration
//------------------------------------------------------------------------------
static void PrintCommandHelp(void)
{
    printf("\r\nUART command interface (Exercise 9 – TX control):\r\n");
    printf("  h/H : show this help and current configuration\r\n");
    printf("  e/E : ENABLE ARINC transmission\r\n");
    printf("  d/D : DISABLE ARINC transmission\r\n");
    printf("  1   : set TX label = 0x01\r\n");
    printf("  2   : set TX label = 0x02\r\n");
    printf("  3   : set TX label = 0x03\r\n");
    printf("  4   : set TX label = 0x04\r\n");
    printf("  f/F : fast transmit rate  (~100 ms between words)\r\n");
    printf("  s/S : slow transmit rate  (~500 ms between words)\r\n\r\n");

    printf("Current TX state:\r\n");
    printf("  TX enabled   : %s\r\n", g_txEnabled ? "YES" : "NO");
    printf("  TX label     : 0x%02X\r\n", g_txLabel);
    printf("  TX interval  : %u x 100 ms\r\n\r\n", (unsigned int)g_txDelayTicks);
}

//------------------------------------------------------------------------------
//  Helper: process a single UART command character
//------------------------------------------------------------------------------
static void ProcessUartCommand(char c)
{
    if (c == '\r' || c == '\n') {
        return; // ignore line endings
    }

    switch (c) {
        case 'h':
        case 'H':
            PrintCommandHelp();
            break;

        case 'e':
        case 'E':
            g_txEnabled = 1;
            printf("CMD: ARINC transmission ENABLED.\r\n");
            break;

        case 'd':
        case 'D':
            g_txEnabled = 0;
            printf("CMD: ARINC transmission DISABLED.\r\n");
            break;

        case '1':
            g_txLabel = 0x01;
            printf("CMD: TX label set to 0x01.\r\n");
            break;

        case '2':
            g_txLabel = 0x02;
            printf("CMD: TX label set to 0x02.\r\n");
            break;

        case '3':
            g_txLabel = 0x03;
            printf("CMD: TX label set to 0x03.\r\n");
            break;

        case '4':
            g_txLabel = 0x04;
            printf("CMD: TX label set to 0x04.\r\n");
            break;

        case 'f':
        case 'F':
            g_txDelayTicks = 1;   // ~100 ms
            printf("CMD: TX rate set to FAST (~100 ms between words).\r\n");
            break;

        case 's':
        case 'S':
            g_txDelayTicks = 5;   // ~500 ms
            printf("CMD: TX rate set to SLOW (~500 ms between words).\r\n");
            break;

        default:
            printf("CMD: unknown key '%c' (press 'h' for help).\r\n", c);
            break;
    }
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // Simple ARINC word buffer (same layout as Holt demo):
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };

    union arincBuffer32 ArincBuffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings (unused)
    (void)pinNSW2;

    // Initial ARINC TX buffer contents
    ArincBuffer.arincTXWord  = 0x00000000;
    ArincBuffer.arincByte[0] = 0x0000;
    ArincBuffer.arincByte[1] = 0x0000;      // high 16-bit data counter
    ArincBuffer.arincLable   = g_txLabel;   // label in low 8 bits

    __disable_interrupt();                  // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (as in original Holt demo)
    // -------------------------------------------------------------------------

    // Assert nMR low to reset HI-8582, then configure that pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure ARM's other general purpose I/O pins and timer(s)
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure the message interrupt pin
#endif

    init_timer();

    // Enable the MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize processor for selected interface to HI-8582 device
    Configure_ARM_MCU_ExtBus();

    // Flash both green LEDs to signify initialization complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300 ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // Configure USART1 for console / UART control
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset the 8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LED ON  (status register good)
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%04X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LED OFF (status register bad)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%04X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%04X\r\n", controlReg);
        printf("Check for +10V and -10V connected on the board.\r\n");
        printf("+10V enables the 5V power supply for the 8582.\r\n");
        printf("Status should be 0x0040. Try again and press Reset.\r\n");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default configuration for transmitter under UART control
    // -------------------------------------------------------------------------
    // DEFAULTCONFG typically selects:
    //  - Unscrambled ARINC
    //  - 32nd bit = parity
    //  - High-speed ARINC (100 kbps)
    //  - Odd parity
    //  - Normal mode (CR5 = 1)
    writeControlWord(DEFAULTCONFG);

    enableTransmission();
    __enable_interrupt();

    printf("Exercise 9: UART-controlled ARINC429 transmitter.\r\n");
    printf("Use a UART terminal or IMXRT1050 to send commands (press 'h' for help).\r\n\r\n");

    // Show initial help
    PrintCommandHelp();

    // -------------------------------------------------------------------------
    // Main loop:
    //   - Poll UART for single-character commands.
    //   - If TX is enabled, periodically send ARINC words with the
    //     currently selected label and incrementing data field.
    // -------------------------------------------------------------------------
    while (1) {
        // 1) Check for incoming UART command characters (non-blocking)
        if (USART_IsRxReady(BOARD_USART_BASE)) {
            char c = USART_GetChar(BOARD_USART_BASE);
            ProcessUartCommand(c);
        }

        // 2) If transmission is enabled, send a word when TX FIFO not full
        if (g_txEnabled) {
            statusReg = readStatusRegister();

            if ((statusReg & TXNFULL) == 0) {
                disableTransmission();

                // Build next ARINC word:
                //  - Clear word
                //  - Set label in low 8 bits
                //  - Increment upper 16 bits as counter
                ArincBuffer.arincTXWord = 0x00000000;
                ArincBuffer.arincLable  = g_txLabel;
                ArincBuffer.arincByte[1]++;

                writeTransmitterFIFO(ArincBuffer.arincTXWord);

                printf("TX : 0x%.8X  Label: 0x%.2X\r\n",
                       ArincBuffer.arincTXWord,
                       (ArincBuffer.arincTXWord & 0xFF));

                enableTransmission();
            }
        }

        // 3) Pace the transmission according to selected rate.
        //    This also limits how often we poll for UART commands.
        Delay_x100ms(g_txDelayTicks);
    } // end while(1)
}
