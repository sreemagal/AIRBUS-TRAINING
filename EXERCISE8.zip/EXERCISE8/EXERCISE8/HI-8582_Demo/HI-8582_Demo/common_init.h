/* ----------------------------------------------------------------------------
 *                            HOLT Integrated Circuits 
 * ----------------------------------------------------------------------------
 *
 *    file	common_init.h
 *    brief     This file contains prototype functions and macro definitions
 * 		used by routines in 613x_initialization.c file, and elsewhere
 *
 *	   	HOLT DISCLAIMER
 *      	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
 *      	KIND,EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 *      	WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 *      	PURPOSE AND NONINFRINGEMENT. 
 *      	IN NO EVENT SHALL HOLT, INC BE LIABLE FOR ANY CLAIM, DAMAGES
 *      	OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 *      	OTHERWISE,ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 *      	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
 *
 *              Copyright (C) 2009-2011 by  HOLT, Inc.
 *              All Rights Reserved
 */

//------------------------------------------------------------------------------
//  Macro definitions 
//------------------------------------------------------------------------------
//    brief	Macro for enabling/disabling console i/o. 


#define YES 1
#define NO 0
#define TRUE 1
#define FALSE 0
//#define CONSOLE_IO  YES  	// YES = enable
#define INT YES                 // Enable the Interrupt but the ISR only includes a counter variable.


// End of File


