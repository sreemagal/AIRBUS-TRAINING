#include "clocks.h"

/* Generated clock config entry points */
#include "clock_config.h"

/* Board utility accessors */
#include "board.h"

uint32_t BSP_DebugConsoleUartSrcClockHz(void)
{
    /*
     * The board layer provides this accessor in EVKB examples.
     * It is commonly used as the srcClkHz parameter to LPUART_Init().
     */
    return BOARD_DebugConsoleSrcFreq();
}

void BSP_InitClocks(void)
{
    /*
     * BOARD_InitBootClocks() is the canonical generated entry point.
     * It usually selects PLLs/roots and configures SystemCoreClock.
     */
    BOARD_InitBootClocks();
}
