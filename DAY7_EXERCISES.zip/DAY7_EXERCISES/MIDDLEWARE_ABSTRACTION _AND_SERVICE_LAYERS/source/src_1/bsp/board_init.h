#pragma once

#ifdef __cplusplus
extern "C" {
#endif

/*
 * BSP entry points
 *
 * Contract:
 *  - BSP_InitHardware() must be called exactly once, early in main().
 *  - This function is allowed to touch pin mux, clocks, debug console, MPU.
 *  - No other layer should call BOARD_* init routines directly.
 */
void BSP_InitHardware(void);

#ifdef __cplusplus
}
#endif
