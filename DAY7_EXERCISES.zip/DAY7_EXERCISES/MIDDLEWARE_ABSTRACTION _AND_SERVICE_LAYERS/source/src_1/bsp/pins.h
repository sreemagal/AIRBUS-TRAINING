#pragma once

#ifdef __cplusplus
extern "C" {
#endif

/*
 * BSP Pins
 *
 * Contract:
 *  - Initializes all board pin muxing required by the application.
 *  - Pin mux selection MUST be generated/edited using MCUXpresso Config Tools.
 *  - BSP_InitHardware() calls this for you.
 */
void BSP_InitPins(void);

#ifdef __cplusplus
}
#endif
