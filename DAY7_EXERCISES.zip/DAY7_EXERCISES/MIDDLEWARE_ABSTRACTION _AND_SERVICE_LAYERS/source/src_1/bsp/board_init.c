#include "board_init.h"

/* Local BSP submodules */
#include "pins.h"
#include "clocks.h"

/* Board-provided init functions */
#include "board.h"

/* For trace clock enabling */
#include "fsl_clock.h"

void BSP_InitHardware(void)
{
    /*
     * Keep ordering consistent with the EVKB hello_world generated init:
     *   1) MPU config (M7)
     *   2) Pins
     *   3) Clocks
     *   4) Debug console
     *   5) SystemCoreClockUpdate + Trace clock
     */

    BOARD_ConfigMPU();

    BSP_InitPins();
    BSP_InitClocks();

    BOARD_InitDebugConsole();

    /*
     * Trace clock is optional but commonly enabled by NXP generated init.
     * Leave coresight init to the debugger.
     */
    SystemCoreClockUpdate();
    CLOCK_EnableClock(kCLOCK_Trace);
}


