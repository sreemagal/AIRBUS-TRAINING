#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * BSP Clocks
 *
 * Contract:
 *  - Initializes all clock roots/dividers required by the application.
 *  - BSP_InitHardware() calls this for you.
 */
void BSP_InitClocks(void);

/*
 * Debug console UART clock (useful later when initializing UART drivers).
 *
 * Contract:
 *  - Returns the UART source clock in Hz used by the debug console.
 *  - Does not modify hardware state.
 */
uint32_t BSP_DebugConsoleUartSrcClockHz(void);

#ifdef __cplusplus
}
#endif
