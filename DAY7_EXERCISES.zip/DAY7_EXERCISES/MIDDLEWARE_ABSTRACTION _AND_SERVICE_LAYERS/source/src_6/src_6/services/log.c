#include "services/log.h"

#include <stdarg.h>
#include <stdio.h>

#include "middleware/ringbuf.h"
#include "services/timebase.h"

#ifndef LOG_BUFFER_SIZE
#define LOG_BUFFER_SIZE 1024u
#endif

#ifndef LOG_MAX_LINE
#define LOG_MAX_LINE 256u
#endif

static serial_port_t *s_port = NULL;
static log_level_t s_level = LOG_LEVEL_INFO;

static uint8_t s_log_storage[LOG_BUFFER_SIZE];
static ringbuf_t s_rb;

static uint8_t s_inited = 0u;
static volatile uint32_t s_drop_bytes = 0u;

static const char *lvl_str(log_level_t lvl)
{
    switch (lvl)
    {
        case LOG_LEVEL_ERROR: return "E";
        case LOG_LEVEL_WARN:  return "W";
        case LOG_LEVEL_INFO:  return "I";
        case LOG_LEVEL_DEBUG: return "D";
        default:              return "?";
    }
}

void Log_Init(void)
{
    if (s_inited != 0u)
    {
        return;
    }

    (void)RingBuf_Init(&s_rb, s_log_storage, sizeof(s_log_storage));
    s_drop_bytes = 0u;
    s_inited = 1u;
}

void Log_Bind(serial_port_t *port)
{
    if (s_inited == 0u)
    {
        Log_Init();
    }

    s_port = port;
}

void Log_SetLevel(log_level_t lvl)
{
    s_level = lvl;
}

size_t Log_Write(const uint8_t *data, size_t len)
{
    if ((data == NULL) || (len == 0u))
    {
        return 0u;
    }

    if (s_inited == 0u)
    {
        Log_Init();
    }

    size_t pushed = RingBuf_Push(&s_rb, data, len);
    if (pushed < len)
    {
        s_drop_bytes += (uint32_t)(len - pushed);
    }

    return pushed;
}

void Log_Poll(void)
{
    if (s_inited == 0u)
    {
        return;
    }

    if (s_port == NULL)
    {
        return;
    }

    /* Flush in bounded chunks to avoid long stalls. */
    uint8_t tmp[64];

    for (uint32_t iter = 0u; iter < 8u; iter++)
    {
        size_t avail = RingBuf_Avail(&s_rb);
        if (avail == 0u)
        {
            break;
        }

        size_t chunk = (avail < sizeof(tmp)) ? avail : sizeof(tmp);
        (void)RingBuf_Peek(&s_rb, 0u, tmp, chunk);

        /* SerialPort_Write returns number of bytes accepted (0 if busy). */
        size_t sent = SerialPort_Write(s_port, tmp, chunk);
        if (sent == 0u)
        {
            break;
        }

        (void)RingBuf_Drop(&s_rb, sent);

        if (sent < chunk)
        {
            /* Partial write: stop this poll to avoid spinning. */
            break;
        }
    }
}


void Log_Printf(log_level_t lvl, const char *fmt, ...)
{
    if ((fmt == NULL) || (lvl > s_level))
    {
        return;
    }

    if (s_inited == 0u)
    {
        Log_Init();
    }

    char buf[LOG_MAX_LINE];

    uint32_t ms = Timebase_Millis();

    /* Prefix: [123456 ms] I: */
    int n0 = snprintf(buf, sizeof(buf), "[%lu ms] %s: ", (unsigned long)ms, lvl_str(lvl));
    if (n0 < 0)
    {
        return;
    }

    size_t used = (size_t)n0;
    if (used >= sizeof(buf))
    {
        used = sizeof(buf) - 1u;
    }

    va_list ap;
    va_start(ap, fmt);
    int n1 = vsnprintf(&buf[used], sizeof(buf) - used, fmt, ap);
    va_end(ap);

    if (n1 < 0)
    {
        return;
    }

    /* Ensure newline termination */
    size_t total = used + (size_t)n1;
    if (total >= (sizeof(buf) - 2u))
    {
        total = sizeof(buf) - 2u;
    }

    buf[total++] = '\r';
    buf[total++] = '\n';

    size_t pushed = RingBuf_Push(&s_rb, (const uint8_t *)buf, total);
    if (pushed < total)
    {
        s_drop_bytes += (uint32_t)(total - pushed);
    }

    /* Attempt immediate flush; if busy, data remains buffered. */
    Log_Poll();
}

uint8_t Log_RateLimitAllow(log_rate_limit_t *rl, uint32_t now_ms)
{
    if (rl == NULL)
    {
        return 0u;
    }

    if (rl->initialized == 0u)
    {
        rl->last_emit_ms = 0u;
        rl->initialized = 1u;
    }

    if (rl->min_interval_ms == 0u)
    {
        return 1u;
    }

    /* Handles wraparound correctly with signed subtraction. */
    if ((int32_t)(now_ms - rl->last_emit_ms) >= (int32_t)rl->min_interval_ms)
    {
        rl->last_emit_ms = now_ms;
        return 1u;
    }

    return 0u;
}

uint32_t Log_GetDroppedBytes(void)
{
    return s_drop_bytes;
}

uint32_t Log_GetBufferedBytes(void)
{
    if (s_inited == 0u)
    {
        return 0u;
    }
    return (uint32_t)RingBuf_Avail(&s_rb);
}

