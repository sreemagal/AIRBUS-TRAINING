#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * timebase.h — 1ms monotonic timebase service
 *
 * Contract:
 *  - Call Timebase_Init(cpu_hz) once after clocks are configured.
 *  - Provides a monotonic millisecond counter.
 *  - Does not block.
 *
 * ISR contract:
 *  - SysTick_Handler() increments the millisecond counter.
 *  - Do not call printf/logging from SysTick_Handler().
 */

/* Initialize SysTick for 1ms tick.
 *
 * @param cpu_hz CPU core clock frequency in Hz.
 * @return 0 on success, non-zero on error.
 */
int Timebase_Init(uint32_t cpu_hz);

/* Monotonic milliseconds since init. */
uint32_t Timebase_Millis(void);

/*
 * Optional: microseconds since init.
 *
 * Notes:
 *  - Provided for diagnostics/jitter measurements.
 *  - Resolution depends on SysTick clock and is bounded within the current 1ms tick.
 */
uint32_t Timebase_Micros(void);

#ifdef __cplusplus
}
#endif
