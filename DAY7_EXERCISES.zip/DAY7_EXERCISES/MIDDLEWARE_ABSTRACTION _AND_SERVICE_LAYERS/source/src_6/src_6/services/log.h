#pragma once

#include <stdint.h>
#include <stddef.h>

#include "middleware/serial_port.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * log.h — Timestamped, non-blocking logging service
 *
 * Design constraints:
 *  - No dynamic allocation
 *  - No blocking on UART
 *  - If TX is busy, logs are buffered (bounded) and older bytes may be dropped.
 *
 * Calling context:
 *  - Log_Printf() is for task/main context only. DO NOT call from ISR.
 *  - Log_Poll() should be called periodically (e.g., every 10..50ms) to flush.
 */

typedef enum log_level
{
    LOG_LEVEL_ERROR = 0,
    LOG_LEVEL_WARN  = 1,
    LOG_LEVEL_INFO  = 2,
    LOG_LEVEL_DEBUG = 3,
} log_level_t;

/* Optional per-message rate limiter helper. */
typedef struct log_rate_limit
{
    uint32_t min_interval_ms;
    uint32_t last_emit_ms;
    uint8_t  initialized;
} log_rate_limit_t;

/*
 * Initialize logging buffer.
 *
 * If you never call Log_Init(), defaults are used (static buffer).
 */
void Log_Init(void);

/* Bind logging sink to a serial port (e.g., debug UART). */
void Log_Bind(serial_port_t *port);

/* Set global minimum log level. */
void Log_SetLevel(log_level_t lvl);

/* Poll to flush buffered bytes to the bound port. Safe to call often. */
void Log_Poll(void);

/* Write raw bytes (no formatting). Returns bytes accepted into log buffer. */
size_t Log_Write(const uint8_t *data, size_t len);

/* Printf-style logging with timestamp prefix. */
void Log_Printf(log_level_t lvl, const char *fmt, ...);

/* Rate limiting helper: returns 1 if allowed to emit now. */
uint8_t Log_RateLimitAllow(log_rate_limit_t *rl, uint32_t now_ms);

/* Diagnostics/counters */
uint32_t Log_GetDroppedBytes(void);
uint32_t Log_GetBufferedBytes(void);

#ifdef __cplusplus
}
#endif
