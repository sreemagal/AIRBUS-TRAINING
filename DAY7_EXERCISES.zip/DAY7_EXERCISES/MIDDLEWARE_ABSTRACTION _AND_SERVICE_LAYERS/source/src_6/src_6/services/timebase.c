#include <stdint.h>

/* MUST come before core_cm7.h on i.MX RT1052 */
#include "MIMXRT1052_COMMON.h"   /* defines __FPU_PRESENT, IRQn_Type, __NVIC_PRIO_BITS */
#include "core_cm7.h"            /* SysTick_Config, SysTick registers */



#include "services/timebase.h"

/* CMSIS core header (not NXP SDK). In MCUXpresso projects this is available by default. */
#include "core_cm7.h"

static volatile uint32_t s_ms = 0u;
static uint32_t s_cpu_hz = 0u;

int Timebase_Init(uint32_t cpu_hz)
{
    if (cpu_hz == 0u)
    {
        return -1;
    }

    s_cpu_hz = cpu_hz;
    s_ms = 0u;

    /* Configure SysTick to interrupt every 1ms.
     * SysTick_Config returns 0 on success.
     */
    uint32_t reload = (cpu_hz / 1000u);
    if (reload == 0u)
    {
        return -2;
    }

    /* SysTick reload register is 24-bit. */
    if (reload > 0x00FFFFFFu)
    {
        return -3;
    }

    if (SysTick_Config(reload) != 0u)
    {
        return -4;
    }

    /* Ensure SysTick uses core clock. */
    SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk;

    return 0;
}

uint32_t Timebase_Millis(void)
{
    /* Atomic enough for 32-bit on Cortex-M; if you want strict atomicity:
     * disable IRQ around read.
     */
    return s_ms;
}

uint32_t Timebase_Micros(void)
{
    /*
     * Microseconds = ms*1000 + fraction.
     *
     * SysTick counts down from LOAD to 0.
     * We compute elapsed cycles in current tick: (LOAD - VAL).
     */
    uint32_t ms_1;
    uint32_t val;
    uint32_t ms_2;

    /* Guard against rollover during read: read ms, then VAL, then ms again.
     * If ms changed, retry once (bounded).
     */
    ms_1 = s_ms;
    val = SysTick->VAL;
    ms_2 = s_ms;

    if (ms_2 != ms_1)
    {
        ms_1 = ms_2;
        val = SysTick->VAL;
    }

    uint32_t load = SysTick->LOAD;
    uint32_t elapsed_cycles = load - val;

    /* Convert cycles within 1ms to microseconds.
     * elapsed_cycles / (cpu_hz/1e6)
     */
    uint32_t cycles_per_us = (s_cpu_hz / 1000000u);
    if (cycles_per_us == 0u)
    {
        return ms_1 * 1000u;
    }

    uint32_t us_in_tick = elapsed_cycles / cycles_per_us;
    if (us_in_tick > 999u)
    {
        us_in_tick = 999u;
    }

    return (ms_1 * 1000u) + us_in_tick;
}

/* CMSIS vector name. Ensure no other module defines SysTick_Handler. */
void SysTick_Handler(void)
{
    s_ms++;
}
