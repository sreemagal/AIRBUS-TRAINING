#include <stdio.h>

#include "bsp/board_init.h"
#include "board.h"                 /* optional: BOARD_DebugConsoleSrcFreq() */
#include "drivers/uart_hw.h"
#include "middleware/serial_port.h"
#include "services/timebase.h"
#include "services/log.h"

static uart_hw_t g_log_uart;
static uint8_t g_log_uart_ring[1024];
static serial_port_t g_log_port;

static uint32_t now_ms(void)
{
    return Timebase_Millis();
}

int main(void)
{
    BSP_InitHardware();

    /* Ensure SystemCoreClock is valid */
    SystemCoreClockUpdate();

    /* 1) Timebase */
    (void)Timebase_Init(SystemCoreClock);

    /* 2) UART for logging (Milestone 2) */
    /* Example patterns (choose the one matching your Milestone 2 API): */
    /*
       uart_hw_cfg_t cfg = { ... base=LPUART2, baud=115200, src_clk=..., irq=... };
       UART_HW_Init(&g_log_uart, &cfg);
    */
    /* or */
    /*
       UART_HW_Init(&g_log_uart, (void*)LPUART2, BOARD_DebugConsoleSrcFreq(), 115200u);
    */

    (void)UART_HW_AttachRing(&g_log_uart, g_log_uart_ring, sizeof(g_log_uart_ring));

    /* 3) Bind UART → serial_port facade (Milestone 3) */
    (void)SerialPort_fromUart(&g_log_port, &g_log_uart);

    /* 4) Logging service (Milestone 6) */
    Log_Init();
    Log_Bind(&g_log_port);
    Log_SetLevel(LOG_LEVEL_INFO);

    Log_Printf(LOG_LEVEL_INFO, "Boot OK");

    uint32_t last = now_ms();

    for (;;)
    {
        /* Flush any buffered log bytes */
        Log_Poll();

        /* Periodic heartbeat once per second */
        uint32_t t = now_ms();
        if ((t - last) >= 1000u)
        {
            last = t;
            Log_Printf(LOG_LEVEL_INFO, "Heartbeat. buffered=%lu dropped=%lu",
                       (unsigned long)Log_GetBufferedBytes(),
                       (unsigned long)Log_GetDroppedBytes());
        }

        /* other work */
    }
}
