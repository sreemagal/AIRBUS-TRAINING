/*
 * src/app/m7_arinc429_demo.c — Optional EVKB demo for Milestone 7
 *
 * This file is APPLICATION layer and may use SDK debug console.
 * Add it to your EVKB project and call Milestone7_Arinc429Demo() once from main()
 * after the board + debug console init is complete.
 */

#include <stdint.h>
#include "fsl_debug_console.h"
#include "services/arinc429.h"

void Milestone7_Arinc429Demo(void)
{
    a429_fields_t f = { .label = 0x74u, .sdi = 2u, .data = 0x12345u, .ssm = 1u };

    uint32_t w = a429_make_word(f);
    PRINTF("M7: packed word = 0x%08X\r\n", (unsigned)w);

    a429_fields_t out;
    int rc = a429_parse_word(w, &out);
    PRINTF("M7: parse rc=%d label=0x%02X sdi=%u data=0x%05X ssm=%u\r\n",
           rc, out.label, out.sdi, (unsigned)out.data, out.ssm);

    /* Acceptance test demo: parity flip must fail */
    uint32_t w_bad = w ^ (1u << 31);
    rc = a429_parse_word(w_bad, &out);
    PRINTF("M7: parity flip parse rc=%d (expect %d)\r\n", rc, A429_ERR_PARITY);

    /* BNR demo */
    float lsb = 0.25f;
    unsigned width = 19u;
    float v = 456.75f;
    uint32_t bnr = a429_bnr_from_float(v, lsb, width);
    float v2 = a429_bnr_to_float(bnr, lsb, width);
    PRINTF("M7: BNR v=%.2f -> raw=0x%05X -> v2=%.2f\r\n",
           (double)v, (unsigned)bnr, (double)v2);
}
