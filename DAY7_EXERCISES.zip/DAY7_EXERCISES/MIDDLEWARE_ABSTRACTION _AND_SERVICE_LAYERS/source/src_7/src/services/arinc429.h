#pragma once
/*
 * services/arinc429.h — ARINC 429 word utilities (pack/unpack + parity + BNR scaling)
 *
 * Service-layer contract:
 *  - Pure C99: no NXP SDK headers, no I/O, no globals, no dynamic allocation.
 *  - Host-testable.
 *
 * Bit numbering contract (this module):
 *  - uint32_t word, bit0 = LSB.
 *  - Maps to ARINC 429 bits 1..32 where ARINC bit1 is the LSB of the LABEL field.
 *
 * Canonical field layout (packed word):
 *  - bits  0.. 7 : Label  (ARINC bits 1..8)
 *  - bits  8.. 9 : SDI    (ARINC bits 9..10)
 *  - bits 10..28 : Data   (ARINC bits 11..29)  (19 bits)
 *  - bits 29..30 : SSM    (ARINC bits 30..31)
 *  - bit      31 : Parity (ARINC bit 32)
 *
 * Parity rule:
 *  - ODD parity over the FULL 32-bit word.
 *  - Practically: compute parity over bits 0..30; set bit31 so total # of '1' bits in bits[31:0] is odd.
 *
 * NOTE (ADK-8582 / HI-8582 RX FIFO quirk):
 *  - Some HI-8582 RX FIFO reads deliver a 32-bit value where bit31 is NOT the parity bit.
 *    Instead: bit31=0 means "parity OK", bit31=1 means "parity error".
 *  - For those raw FIFO words, use a429_parse_word_hi8582_rx_fifo().
 */

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    uint8_t  label; /* 8 bits  (bits 0..7)  */
    uint8_t  sdi;   /* 2 bits  (bits 8..9)  */
    uint32_t data;  /* 19 bits (bits 10..28) */
    uint8_t  ssm;   /* 2 bits  (bits 29..30) */
} a429_fields_t;

enum
{
    A429_OK         = 0,
    A429_ERR_PARITY = -1,
    A429_ERR_PARAM  = -2,
    A429_ERR_RANGE  = -3
};

/* Build a 32-bit ARINC word with correct odd parity (bit31). */
uint32_t a429_make_word(a429_fields_t f);

/* Parse a canonical ARINC word; validate odd parity; return A429_ERR_PARITY on mismatch. */
int a429_parse_word(uint32_t word, a429_fields_t *out);

/*
 * Parse HI-8582 RX FIFO word:
 *  - bit31 is "parity error" flag (1=bad, 0=good), not the parity bit itself.
 *  - Remaining field extraction matches canonical packing layout.
 */
int a429_parse_word_hi8582_rx_fifo(uint32_t fifo_word, a429_fields_t *out);

/*
 * BNR scaling helpers (Binary Number Representation) — signed two's complement
 *
 * Parameters:
 *  - width: number of bits used for the signed value (typical BNR in bits 11..29 => width=19)
 *  - lsb:   engineering units per 1 LSB
 *
 * Behavior:
 *  - a429_bnr_from_float() rounds to the nearest quantized integer and SATURATES to representable range.
 *  - a429_bnr_to_float() sign-extends the width-bit field then multiplies by lsb.
 */
uint32_t a429_bnr_from_float(float value, float lsb, unsigned width);
float    a429_bnr_to_float(uint32_t data,  float lsb, unsigned width);

#ifdef __cplusplus
}
#endif
