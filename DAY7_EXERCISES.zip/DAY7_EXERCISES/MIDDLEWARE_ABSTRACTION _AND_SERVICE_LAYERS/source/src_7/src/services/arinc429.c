#include "services/arinc429.h"

/* -------- internal helpers -------- */

static uint32_t mask_u32(unsigned width)
{
    if (width == 0u)
        return 0u;
    if (width >= 32u)
        return 0xFFFFFFFFu;
    return (1u << width) - 1u;
}

static uint8_t popcount32(uint32_t x)
{
    uint8_t c = 0u;
    while (x != 0u)
    {
        c = (uint8_t)(c + (uint8_t)(x & 1u));
        x >>= 1u;
    }
    return c;
}

/* Return 1 if 'word' has ODD parity over bits[31:0], else 0. */
static uint8_t has_odd_parity(uint32_t word)
{
    return (uint8_t)((popcount32(word) & 1u) ? 1u : 0u);
}

/* Given bits0..30 in 'v' (bit31 MUST be 0), compute parity bit31 to make full word ODD parity. */
static uint8_t odd_parity_bit_for_31(uint32_t v)
{
    /* If ones count in bits0..30 is EVEN -> parity bit must be 1 to make total odd. */
    uint8_t ones = popcount32(v & 0x7FFFFFFFu);
    return (uint8_t)(((ones & 1u) == 0u) ? 1u : 0u);
}

static int32_t sign_extend_u32(uint32_t v, unsigned width)
{
    if (width == 0u)
        return 0;

    if (width >= 32u)
        return (int32_t)v;

    uint32_t m = mask_u32(width);
    v &= m;

    uint32_t signbit = 1u << (width - 1u);
    if ((v & signbit) != 0u)
    {
        /* set all upper bits to 1 */
        v |= ~m;
    }
    return (int32_t)v;
}

static int32_t clamp_i32(int64_t v, int64_t lo, int64_t hi)
{
    if (v < lo) return (int32_t)lo;
    if (v > hi) return (int32_t)hi;
    return (int32_t)v;
}

/* -------- public API -------- */

uint32_t a429_make_word(a429_fields_t f)
{
    /* Pack (mask each field to its width) */
    uint32_t w = 0u;
    w |= ((uint32_t)(f.label & 0xFFu)) << 0;            /* bits 0..7   */
    w |= ((uint32_t)(f.sdi   & 0x03u)) << 8;            /* bits 8..9   */
    w |= ((uint32_t)(f.data  & 0x7FFFFu)) << 10;        /* bits 10..28 */
    w |= ((uint32_t)(f.ssm   & 0x03u)) << 29;           /* bits 29..30 */
    /* Compute odd parity for bit31 */
    uint8_t p = odd_parity_bit_for_31(w);
    w |= ((uint32_t)p) << 31;
    return w;
}

int a429_parse_word(uint32_t word, a429_fields_t *out)
{
    if (out == 0)
        return A429_ERR_PARAM;

    if (!has_odd_parity(word))
        return A429_ERR_PARITY;

    out->label = (uint8_t)((word >> 0) & 0xFFu);
    out->sdi   = (uint8_t)((word >> 8) & 0x03u);
    out->data  = (uint32_t)((word >> 10) & 0x7FFFFu);
    out->ssm   = (uint8_t)((word >> 29) & 0x03u);
    return A429_OK;
}

int a429_parse_word_hi8582_rx_fifo(uint32_t fifo_word, a429_fields_t *out)
{
    if (out == 0)
        return A429_ERR_PARAM;

    /* Bit31 is the parity-error flag: 0=valid, 1=parity error. */
    if (((fifo_word >> 31) & 1u) != 0u)
        return A429_ERR_PARITY;

    out->label = (uint8_t)((fifo_word >> 0) & 0xFFu);
    out->sdi   = (uint8_t)((fifo_word >> 8) & 0x03u);
    out->data  = (uint32_t)((fifo_word >> 10) & 0x7FFFFu);
    out->ssm   = (uint8_t)((fifo_word >> 29) & 0x03u);
    return A429_OK;
}

uint32_t a429_bnr_from_float(float value, float lsb, unsigned width)
{
    if ((lsb <= 0.0f) || (width == 0u) || (width > 32u))
        return 0u;

    float scaled = value / lsb;

    /* Round to nearest integer (ties go away from 0 due to +/-0.5). */
    int64_t qi;
    if (scaled >= 0.0f)
        qi = (int64_t)(scaled + 0.5f);
    else
        qi = (int64_t)(scaled - 0.5f);

    /* Representable range for signed two's complement width bits */
    int64_t lo, hi;
    if (width >= 32u)
    {
        lo = (int64_t)(-2147483648LL);
        hi = (int64_t)( 2147483647LL);
    }
    else
    {
        lo = -(1LL << (width - 1u));
        hi =  (1LL << (width - 1u)) - 1LL;
    }

    int32_t q = clamp_i32(qi, lo, hi);

    return ((uint32_t)q) & mask_u32(width);
}

float a429_bnr_to_float(uint32_t data, float lsb, unsigned width)
{
    if ((lsb <= 0.0f) || (width == 0u) || (width > 32u))
        return 0.0f;

    int32_t q = sign_extend_u32(data, width);
    return ((float)q) * lsb;
}
