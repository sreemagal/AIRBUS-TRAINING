/*
 * tests/test_arinc429.c — host unit tests for services/arinc429.*
 *
 * Build (from repo root example):
 *   gcc -std=c99 -Wall -Wextra -Isrc -o test_arinc429 tests/test_arinc429.c src/services/arinc429.c -lm
 */

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>

#include "services/arinc429.h"

static void test_parity_flip_fails(void)
{
    a429_fields_t f = { .label = 0x74u, .sdi = 2u, .data = 0x12345u, .ssm = 1u };

    uint32_t w = a429_make_word(f);

    a429_fields_t out;
    assert(a429_parse_word(w, &out) == A429_OK);

    /* flip parity bit (bit31) */
    uint32_t w_bad = w ^ (1u << 31);
    assert(a429_parse_word(w_bad, &out) == A429_ERR_PARITY);
}

static void test_bnr_roundtrip(void)
{
    const float lsb = 0.25f;
    const unsigned width = 19u;

    const float values[] = { 0.0f, 1.0f, 456.75f, -10.0f, -123.25f };
    const float tol = (0.5f * lsb) + 1e-6f;

    for (unsigned i = 0; i < (unsigned)(sizeof(values)/sizeof(values[0])); i++)
    {
        float v  = values[i];
        uint32_t raw = a429_bnr_from_float(v, lsb, width);
        float v2 = a429_bnr_to_float(raw, lsb, width);

        float err = fabsf(v2 - v);
        assert(err <= tol);
    }
}

int main(void)
{
    test_parity_flip_fails();
    test_bnr_roundtrip();

    printf("PASS: all arinc429 tests\n");
    return 0;
}
