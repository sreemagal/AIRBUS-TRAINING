#include "bsp/board_init.h"
#include "board.h"                 /* for BOARD_DebugConsoleSrcFreq() */
#include "drivers/uart_hw.h"

static uart_hw_t g_link;
static uint8_t g_rx_ring[512];

int main(void)
{
    BSP_InitHardware();

    /* NOTE: LPUART2 pins and clock must be configured in BSP/Config Tools. */
    (void)UART_HW_Init(&g_link, (void*)LPUART2, BOARD_DebugConsoleSrcFreq(), 115200u);
    (void)UART_HW_AttachRing(&g_link, g_rx_ring, sizeof(g_rx_ring));

    const uint8_t msg[] = "UART_HW OK\r\n";
    (void)UART_HW_Send(&g_link, msg, sizeof(msg) - 1u);

    for (;;)
    {
        uint8_t buf[64];
        size_t got = 0u;
        (void)UART_HW_Receive(&g_link, buf, sizeof(buf), &got);
        if (got != 0u)
        {
            /* Echo back */
            (void)UART_HW_Send(&g_link, buf, got);
        }
    }
}
