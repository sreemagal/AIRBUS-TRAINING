#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * uart_hw.h — Driver/HAL wrapper for MCUXpresso LPUART transactional driver
 *
 * Layering contract:
 *  - This header is allowed to be included by middleware because it contains NO NXP SDK types.
 *  - The implementation (uart_hw.c) is the only place that includes fsl_lpuart.h / fsl_clock.h.
 *
 * Threading/ISR contract:
 *  - All APIs are callable from task/main context.
 *  - UART_HW_IrqHandler() is callable from ISR.
 *  - No API blocks waiting for hardware.
 */

typedef enum uart_hw_status
{
    UART_HW_OK = 0,
    UART_HW_INVALID_ARG,
    UART_HW_NOT_READY,
    UART_HW_BUSY,
    UART_HW_NO_RESOURCES,
    UART_HW_IO_ERROR,
} uart_hw_status_t;

/* Opaque UART HW device (does not expose NXP types). */
typedef struct uart_hw
{
    /* Hardware base pointer (cast to LPUART_Type* in uart_hw.c) */
    void *base;

    /* Opaque handle pointer (points to lpuart_handle_t in a private pool). */
    void *handle;

    /* RX ring buffer tracking (storage owned by caller). */
    uint8_t *rx_ring;
    size_t rx_ring_size;

    /* TX busy flag (set when TX started, cleared when callback sees TxIdle). */
    volatile uint8_t tx_busy;

    /* Diagnostics (optional but useful for acceptance tests). */
    volatile uint32_t tx_started;
    volatile uint32_t tx_completed;
    volatile uint32_t rx_drains;
    volatile uint32_t rx_bytes;

    /* Last driver callback status (opaque integer; for debug only). */
    volatile int32_t last_driver_status;

} uart_hw_t;

/*
 * UART_HW_Init
 *
 * @pre  dev != NULL
 * @pre  base != NULL (example: (void*)LPUART2)
 * @pre  src_clk_hz != 0 and baud != 0
 * @post dev becomes initialized; dev->handle points to an internal transactional handle
 *
 * Notes:
 *  - Peripheral clock gating and pin mux are BSP responsibilities.
 *  - This function sets baud and enables RX/TX.
 */
uart_hw_status_t UART_HW_Init(uart_hw_t *dev, void *base, uint32_t src_clk_hz, uint32_t baud);

/*
 * UART_HW_AttachRing
 *
 * Enables background ring-buffer reception.
 *
 * @pre dev initialized
 * @param ring pointer to caller-owned storage; may be NULL to disable ring
 * @param ring_size size of storage in bytes
 */
uart_hw_status_t UART_HW_AttachRing(uart_hw_t *dev, uint8_t *ring, size_t ring_size);

/*
 * UART_HW_RxAvailable
 *
 * Returns number of bytes currently available in the SDK RX ring buffer.
 *
 * @return 0 if no data or ring not attached.
 */
size_t UART_HW_RxAvailable(uart_hw_t *dev);

/*
 * UART_HW_Receive
 *
 * Drain up to len bytes from ring buffer into dst without blocking.
 *
 * @pre dev initialized
 * @pre dst != NULL
 * @post *got contains number of bytes copied (0..len)
 *
 * Return values:
 *  - UART_HW_OK on success (including got==0)
 *  - UART_HW_NOT_READY if ring buffer not attached
 */
uart_hw_status_t UART_HW_Receive(uart_hw_t *dev, uint8_t *dst, size_t len, size_t *got);

/*
 * UART_HW_Send
 *
 * Non-blocking transmit. Only one TX in flight.
 *
 * @pre dev initialized
 * @pre data != NULL, len > 0
 * @note data must remain valid until TX completes.
 */
uart_hw_status_t UART_HW_Send(uart_hw_t *dev, const uint8_t *data, size_t len);

/*
 * UART_HW_IrqHandler
 *
 * Optional ISR entry point (thin wrapper). Use if you want to bind IRQ vector manually.
 * Many EVKB projects already have LPUARTx_IRQHandler() calling LPUARTx_DriverIRQHandler().
 */
void UART_HW_IrqHandler(uart_hw_t *dev);

/*
 * UART_HW_Deinit
 *
 * Stops ring buffer and deinitializes LPUART.
 */
uart_hw_status_t UART_HW_Deinit(uart_hw_t *dev);

#ifdef __cplusplus
}
#endif
