#include "uart_hw.h"

/* This is the ONLY file in the stack that includes NXP LPUART headers. */
#include "fsl_lpuart.h"

/* Optional: for NVIC priority and IRQ array. */
#include "fsl_device_registers.h"

/*
 * Internal handle pool
 *
 * We store lpuart_handle_t in a fixed pool so uart_hw.h remains SDK-type-free.
 */
#ifndef UART_HW_MAX_INSTANCES
#define UART_HW_MAX_INSTANCES 4u
#endif

typedef struct uart_hw_slot
{
    uart_hw_t *owner;
    lpuart_handle_t handle;
} uart_hw_slot_t;

static uart_hw_slot_t s_slots[UART_HW_MAX_INSTANCES];

static uart_hw_slot_t *alloc_slot(uart_hw_t *dev)
{
    for (uint32_t i = 0u; i < UART_HW_MAX_INSTANCES; i++)
    {
        if (s_slots[i].owner == NULL)
        {
            s_slots[i].owner = dev;
            return &s_slots[i];
        }
    }
    return NULL;
}

static uart_hw_slot_t *find_slot(uart_hw_t *dev)
{
    for (uint32_t i = 0u; i < UART_HW_MAX_INSTANCES; i++)
    {
        if (s_slots[i].owner == dev)
        {
            return &s_slots[i];
        }
    }
    return NULL;
}

static void free_slot(uart_hw_t *dev)
{
    uart_hw_slot_t *s = find_slot(dev);
    if (s != NULL)
    {
        s->owner = NULL;
        /* handle content can remain; it will be memset by CreateHandle on next use */
    }
}

static uart_hw_status_t map_status(status_t st)
{
    if (st == kStatus_Success)
    {
        return UART_HW_OK;
    }

    /* Busy states (common) */
    if ((st == kStatus_LPUART_TxBusy) || (st == kStatus_LPUART_RxBusy))
    {
        return UART_HW_BUSY;
    }

    return UART_HW_IO_ERROR;
}

static void lpuart_cb(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    (void)base;
    (void)handle;

    uart_hw_t *dev = (uart_hw_t *)userData;
    if (dev == NULL)
    {
        return;
    }

    dev->last_driver_status = (int32_t)status;

    /* Transactional TX completion reports kStatus_LPUART_TxIdle */
    if (status == kStatus_LPUART_TxIdle)
    {
        dev->tx_busy = 0u;
        dev->tx_completed++;
    }
}

uart_hw_status_t UART_HW_Init(uart_hw_t *dev, void *base, uint32_t src_clk_hz, uint32_t baud)
{
    if ((dev == NULL) || (base == NULL) || (src_clk_hz == 0u) || (baud == 0u))
    {
        return UART_HW_INVALID_ARG;
    }

    /* Allocate a transactional handle slot. */
    uart_hw_slot_t *slot = alloc_slot(dev);
    if (slot == NULL)
    {
        return UART_HW_NO_RESOURCES;
    }

    dev->base = base;
    dev->handle = (void *)&slot->handle;

    dev->rx_ring = NULL;
    dev->rx_ring_size = 0u;

    dev->tx_busy = 0u;
    dev->tx_started = 0u;
    dev->tx_completed = 0u;
    dev->rx_drains = 0u;
    dev->rx_bytes = 0u;
    dev->last_driver_status = 0;

    LPUART_Type *b = (LPUART_Type *)dev->base;
    lpuart_handle_t *h = (lpuart_handle_t *)dev->handle;

    /* Configure UART with default settings + desired baud. */
    lpuart_config_t cfg;
    LPUART_GetDefaultConfig(&cfg);
    cfg.baudRate_Bps = baud;
    cfg.enableTx = true;
    cfg.enableRx = true;

    status_t st = LPUART_Init(b, &cfg, src_clk_hz);
    if (st != kStatus_Success)
    {
        free_slot(dev);
        dev->handle = NULL;
        return map_status(st);
    }

    /* Create transactional handle (also registers it in SDK global table for IRQ). */
    LPUART_TransferCreateHandle(b, h, lpuart_cb, dev);

    /* Optionally set priority (CreateHandle enables IRQ but does not set priority).
     * We use the instance-based IRQ array exported by the driver.
     */
#if defined(LPUART_RX_TX_IRQS)
    uint32_t instance = LPUART_GetInstance(b);
    /* Choose a default mid priority; system-level policy can override by calling NVIC_SetPriority again. */
    NVIC_SetPriority(s_lpuartIRQ[instance], 5u);
#endif

    return UART_HW_OK;
}

uart_hw_status_t UART_HW_AttachRing(uart_hw_t *dev, uint8_t *ring, size_t ring_size)
{
    if ((dev == NULL) || (dev->base == NULL) || (dev->handle == NULL))
    {
        return UART_HW_INVALID_ARG;
    }

    /* Disabling ring reception is allowed by passing ring==NULL. */
    if (ring == NULL)
    {
        dev->rx_ring = NULL;
        dev->rx_ring_size = 0u;
        LPUART_TransferStopRingBuffer((LPUART_Type *)dev->base, (lpuart_handle_t *)dev->handle);
        return UART_HW_OK;
    }

    if (ring_size < 16u)
    {
        /* Too small is likely useless; keep requirement explicit. */
        return UART_HW_INVALID_ARG;
    }

    dev->rx_ring = ring;
    dev->rx_ring_size = ring_size;

    LPUART_TransferStartRingBuffer((LPUART_Type *)dev->base,
                                  (lpuart_handle_t *)dev->handle,
                                  ring,
                                  ring_size);
    return UART_HW_OK;
}

size_t UART_HW_RxAvailable(uart_hw_t *dev)
{
    if ((dev == NULL) || (dev->base == NULL) || (dev->handle == NULL))
    {
        return 0u;
    }

    if ((dev->rx_ring == NULL) || (dev->rx_ring_size == 0u))
    {
        return 0u;
    }

    return LPUART_TransferGetRxRingBufferLength((LPUART_Type *)dev->base, (lpuart_handle_t *)dev->handle);
}

uart_hw_status_t UART_HW_Receive(uart_hw_t *dev, uint8_t *dst, size_t len, size_t *got)
{
    if ((dev == NULL) || (dst == NULL) || (got == NULL))
    {
        return UART_HW_INVALID_ARG;
    }

    *got = 0u;

    if ((dev->base == NULL) || (dev->handle == NULL))
    {
        return UART_HW_NOT_READY;
    }

    if ((dev->rx_ring == NULL) || (dev->rx_ring_size == 0u))
    {
        /* The exercise model assumes ring buffer RX. */
        return UART_HW_NOT_READY;
    }

    if (len == 0u)
    {
        return UART_HW_OK;
    }

    size_t avail = UART_HW_RxAvailable(dev);
    if (avail == 0u)
    {
        return UART_HW_OK;
    }

    size_t to_read = (avail < len) ? avail : len;

    lpuart_transfer_t xfer;
    xfer.data = dst;      /* union: data == rxData */
    xfer.dataSize = to_read;

    size_t received = 0u;
    status_t st = LPUART_TransferReceiveNonBlocking((LPUART_Type *)dev->base,
                                                    (lpuart_handle_t *)dev->handle,
                                                    &xfer,
                                                    &received);

    if (st != kStatus_Success)
    {
        return map_status(st);
    }

    *got = received;
    dev->rx_drains++;
    dev->rx_bytes += (uint32_t)received;

    return UART_HW_OK;
}

uart_hw_status_t UART_HW_Send(uart_hw_t *dev, const uint8_t *data, size_t len)
{
    if ((dev == NULL) || (data == NULL) || (len == 0u))
    {
        return UART_HW_INVALID_ARG;
    }

    if ((dev->base == NULL) || (dev->handle == NULL))
    {
        return UART_HW_NOT_READY;
    }

    if (dev->tx_busy != 0u)
    {
        return UART_HW_BUSY;
    }

    lpuart_transfer_t xfer;
    xfer.txData = data;
    xfer.dataSize = len;

    status_t st = LPUART_TransferSendNonBlocking((LPUART_Type *)dev->base,
                                                 (lpuart_handle_t *)dev->handle,
                                                 &xfer);
    if (st == kStatus_Success)
    {
        dev->tx_busy = 1u;
        dev->tx_started++;
        return UART_HW_OK;
    }

    return map_status(st);
}

void UART_HW_IrqHandler(uart_hw_t *dev)
{
    if ((dev == NULL) || (dev->base == NULL) || (dev->handle == NULL))
    {
        return;
    }

    /*
     * If you bind IRQ manually, call this from your LPUARTx_IRQHandler.
     * In most EVKB projects, the startup file already routes IRQ to LPUARTx_DriverIRQHandler,
     * which in turn calls LPUART_TransferHandleIRQ using the global handle table.
     */
    LPUART_TransferHandleIRQ((LPUART_Type *)dev->base, dev->handle);

    SDK_ISR_EXIT_BARRIER;
}

uart_hw_status_t UART_HW_Deinit(uart_hw_t *dev)
{
    if (dev == NULL)
    {
        return UART_HW_INVALID_ARG;
    }

    if ((dev->base != NULL) && (dev->handle != NULL))
    {
        /* Stop ring buffer if enabled. */
        LPUART_TransferStopRingBuffer((LPUART_Type *)dev->base, (lpuart_handle_t *)dev->handle);

        /* Deinit peripheral. */
        LPUART_Deinit((LPUART_Type *)dev->base);
    }

    free_slot(dev);

    dev->base = NULL;
    dev->handle = NULL;
    dev->rx_ring = NULL;
    dev->rx_ring_size = 0u;
    dev->tx_busy = 0u;

    return UART_HW_OK;
}

