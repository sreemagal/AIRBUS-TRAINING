#include <assert.h>
#include <string.h>

#include "middleware/serial_port.h"
#include "middleware/serial_port_fake.h"
#include "middleware/frame_link.h"

static uint8_t always_can_write(void *ctx)
{
    (void)ctx;
    return 1u;
}

int main(void)
{
    /* Two fake endpoints with independent buffers */
    serial_port_fake_t a, b;
    uint8_t a_rx[2048], a_tx[2048];
    uint8_t b_rx[2048], b_tx[2048];

    SerialFake_Init(&a, a_rx, sizeof(a_rx), a_tx, sizeof(a_tx));
    SerialFake_Init(&b, b_rx, sizeof(b_rx), b_tx, sizeof(b_tx));

    serial_port_t pa, pb;
    SerialFake_Bind(&pa, &a);
    SerialFake_Bind(&pb, &b);

    frame_link_t fla, flb;
    uint8_t fla_ring[512];
    uint8_t flb_ring[512];

    assert(FrameLink_Init(&fla, &pa, fla_ring, sizeof(fla_ring), 256u, 256u) == FL_OK);
    assert(FrameLink_Init(&flb, &pb, flb_ring, sizeof(flb_ring), 256u, 256u) == FL_OK);

    FrameLink_SetCanWriteProbe(&fla, always_can_write, NULL);
    FrameLink_SetCanWriteProbe(&flb, always_can_write, NULL);

    /* A sends a payload */
    const uint8_t msg[] = { 'P','I','N','G' };
    assert(FrameLink_Tx(&fla, msg, (uint16_t)sizeof(msg)) == FL_OK);

    /* Move bytes from A TX to B RX (link) */
    uint8_t wire[2048];
    size_t n = SerialFake_DrainTx(&a, wire, sizeof(wire));
    assert(n != 0u);
    assert(SerialFake_InjectRx(&b, wire, n) == n);

    /* Poll receiver and fetch frame */
    FrameLink_Poll(&flb);

    uint8_t out[32];
    uint16_t outlen = 0u;
    assert(FrameLink_RxGet(&flb, out, sizeof(out), &outlen) == FL_OK);
    assert(outlen == sizeof(msg));
    assert(memcmp(out, msg, sizeof(msg)) == 0);

    /* Corrupt a byte and ensure CRC drop */
    assert(FrameLink_Tx(&fla, msg, (uint16_t)sizeof(msg)) == FL_OK);
    n = SerialFake_DrainTx(&a, wire, sizeof(wire));
    assert(n > 8u);
    wire[6] ^= 0xFFu; /* flip a payload byte */
    assert(SerialFake_InjectRx(&b, wire, n) == n);

    uint32_t crc_before = flb.crc_err;
    FrameLink_Poll(&flb);
    assert(flb.crc_err == (crc_before + 1u));

    outlen = 0u;
    assert(FrameLink_RxGet(&flb, out, sizeof(out), &outlen) == FL_NO_FRAME);

    return 0;
}
