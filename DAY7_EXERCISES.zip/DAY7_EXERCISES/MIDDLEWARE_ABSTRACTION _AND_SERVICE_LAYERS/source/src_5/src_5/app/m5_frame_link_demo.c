#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "bsp/board_init.h"          /* Milestone 1: BSP_InitHardware() */
#include "board.h"                  /* BOARD_DebugConsoleSrcFreq() */
#include "fsl_common.h"             /* SDK_DelayAtLeastUs */
#include "fsl_debug_console.h"      /* PRINTF */

#include "drivers/uart_hw.h"        /* Milestone 2 */
#include "middleware/serial_port.h" /* Milestone 3 */
#include "middleware/frame_link.h"  /* Milestone 5 */
#include "middleware/frame_link_canwrite_uart_hw.h" /* Milestone 5 helper */

/* ---------------- Link UART objects ---------------- */
static uart_hw_t    g_link_uart;
static uint8_t      g_link_uart_rx_ring[1024];
static serial_port_t g_link_port;

/* ---------------- FrameLink objects ---------------- */
static frame_link_t g_fl;
static uint8_t      g_fl_rx_ring[512]; /* MUST be power-of-two */

static void link_init(void)
{
    /* 1) BSP bring-up (pins/clocks/debug console) is done in BSP_InitHardware() */

    /* 2) Init link UART (Milestone 2)
     *    NOTE: If you mapped a different LPUART instance for the framed link, change LPUART2.
     */
    (void)UART_HW_Init(&g_link_uart, (void*)LPUART2, BOARD_DebugConsoleSrcFreq(), 115200u);

    /* 3) Start background RX ring (Milestone 2) */
    (void)UART_HW_AttachRing(&g_link_uart, g_link_uart_rx_ring, sizeof(g_link_uart_rx_ring));

    /* 4) Bind uart_hw -> serial_port facade (Milestone 3) */
    (void)SerialPort_fromUart(&g_link_port, &g_link_uart);

    /* 5) Init framed link (Milestone 5) */
    (void)FrameLink_Init(&g_fl,
                         &g_link_port,
                         g_fl_rx_ring,
                         sizeof(g_fl_rx_ring),
                         256u, /* max_drain_per_poll */
                         256u  /* max_parse_bytes_per_poll */);

    /* 6) Provide can_write probe (TX completion safety) */
    FrameLink_SetCanWriteProbe(&g_fl, FrameLink_CanWrite_UartHw, &g_link_uart);
}

static void dump_payload_ascii(const uint8_t *p, uint16_t len)
{
    /* Print as ASCII safely on debug console */
    PRINTF("RX payload (%u bytes): ", len);
    for (uint16_t i = 0; i < len; i++) {
        uint8_t c = p[i];
        if (c >= 32u && c <= 126u) PRINTF("%c", c);
        else PRINTF(".");
    }
    PRINTF("\r\n");
}

int main(void)
{
    BSP_InitHardware();

    PRINTF("\r\n=== Milestone 5 Demo: CRC16-CCITT + Framed Link ===\r\n");

    link_init();

    PRINTF("Link UART ready. Send framed packets to the link UART.\r\n");
    PRINTF("Frame format: A5 5A + LEN(LE) + PAYLOAD + CRC16(LE over LEN+PAYLOAD)\r\n\r\n");

    uint32_t last_stats_ms = 0u;
    uint32_t ms = 0u;

    for (;;)
    {
        /* Service the framed link state machine */
        FrameLink_Poll(&g_fl);

        /* Drain all received frames */
        for (;;)
        {
            uint8_t  payload[FRAME_LINK_MAX_PAYLOAD];
            uint16_t len = 0u;

            framelink_status_t rc = FrameLink_RxGet(&g_fl, payload, (uint16_t)sizeof(payload), &len);
            if (rc != FL_OK) {
                break; /* no more frames */
            }

            /* Show what arrived (debug console only) */
            dump_payload_ascii(payload, len);

            /* Reply with an ACK frame (over the framed link) */
            uint8_t ack[64];
            const char prefix[] = "ACK:";
            uint16_t n = 0u;

            /* Build: "ACK:" + up to 58 bytes of payload */
            (void)memcpy(ack, prefix, sizeof(prefix)-1u);
            n = (uint16_t)(sizeof(prefix)-1u);

            uint16_t copy = len;
            if (copy > (uint16_t)(sizeof(ack) - n)) {
                copy = (uint16_t)(sizeof(ack) - n);
            }
            (void)memcpy(&ack[n], payload, copy);
            n = (uint16_t)(n + copy);

            (void)FrameLink_Tx(&g_fl, ack, n);
        }

        /* Periodic stats print (approx 1000ms) */
        SDK_DelayAtLeastUs(1000u, SystemCoreClock); /* ~1ms */
        ms++;
        if ((ms - last_stats_ms) >= 1000u) {
            last_stats_ms = ms;
            PRINTF("STATS: rx=%lu tx=%lu crc_err=%lu len_err=%lu sync_loss=%lu rxq_ovf=%lu tx_busy=%lu\r\n",
                   (unsigned long)g_fl.frames_rx,
                   (unsigned long)g_fl.frames_tx,
                   (unsigned long)g_fl.crc_err,
                   (unsigned long)g_fl.len_err,
                   (unsigned long)g_fl.sync_loss,
                   (unsigned long)g_fl.rx_q_overflow,
                   (unsigned long)g_fl.tx_busy);
        }
    }
}
