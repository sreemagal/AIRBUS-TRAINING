#pragma once

#include <stddef.h>
#include <stdint.h>

#include "middleware/serial_port.h"
#include "middleware/ringbuf.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * frame_link.h — Robust framed transport over serial_port_t
 *
 * Frame format:
 *   0xA5 0x5A | LEN(u16 LE) | PAYLOAD | CRC16(u16 LE)
 *
 * CRC16-CCITT:
 *   init=0xFFFF, poly=0x1021, computed over LEN(2 bytes) + PAYLOAD
 *
 * Determinism:
 *  - FrameLink_Poll() processes at most:
 *      - max_drain_per_poll bytes read from the serial port
 *      - max_parse_bytes_per_poll bytes consumed from the RX ring
 *
 * RX queue policy:
 *  - If RX queue is full, the newest valid frame is dropped and counted.
 */

#define FRAME_LINK_SYNC1 (0xA5u)
#define FRAME_LINK_SYNC2 (0x5Au)

#ifndef FRAME_LINK_MAX_PAYLOAD
#define FRAME_LINK_MAX_PAYLOAD (256u)
#endif

#ifndef FRAME_LINK_RX_QUEUE_LEN
#define FRAME_LINK_RX_QUEUE_LEN (4u)
#endif

typedef enum framelink_status
{
    FL_OK = 0,
    FL_NO_FRAME,
    FL_INVALID_ARG,
    FL_NOT_INIT,
    FL_BUSY,
    FL_LEN_ERROR,
    FL_IO_ERROR,
} framelink_status_t;

typedef struct frame_link_frame
{
    uint16_t len;
    uint8_t payload[FRAME_LINK_MAX_PAYLOAD];
} frame_link_frame_t;

/* Optional capability: probe whether serial port can accept a new async write.
 *
 * Contract:
 *  - return 1 if the underlying port is idle (can accept a new write)
 *  - return 0 if busy
 */
typedef uint8_t (*frame_link_can_write_fn_t)(void *ctx);

typedef struct frame_link
{
    /* Boundaries */
    serial_port_t *port;

    /* Optional probe for TX completion/idle */
    frame_link_can_write_fn_t can_write;
    void *can_write_ctx;

    /* RX staging ring */
    ringbuf_t rx_rb;

    /* Parser state */
    enum {
        RX_WAIT_S1 = 0,
        RX_WAIT_S2,
        RX_WAIT_LEN0,
        RX_WAIT_LEN1,
        RX_WAIT_PAYLOAD,
        RX_WAIT_CRC0,
        RX_WAIT_CRC1,
    } rx_state;

    uint16_t rx_len;
    uint16_t rx_idx;
    uint16_t rx_crc_calc;
    uint16_t rx_crc_rx;

    uint8_t rx_payload[FRAME_LINK_MAX_PAYLOAD];

    /* Completed RX frames queue */
    frame_link_frame_t rx_q[FRAME_LINK_RX_QUEUE_LEN];
    uint8_t rx_q_head;
    uint8_t rx_q_tail;

    /* TX single in-flight frame */
    uint8_t tx_buf[2u + 2u + FRAME_LINK_MAX_PAYLOAD + 2u]; /* sync+len+payload+crc */
    uint16_t tx_total_len;
    uint8_t  tx_inflight;

    /* Determinism bounds */
    uint16_t max_drain_per_poll;
    uint16_t max_parse_bytes_per_poll;

    /* Diagnostics */
    uint32_t bytes_in;
    uint32_t bytes_dropped;
    uint32_t frames_rx;
    uint32_t frames_tx;
    uint32_t crc_err;
    uint32_t len_err;
    uint32_t sync_loss;
    uint32_t rx_q_overflow;
    uint32_t tx_busy;

    uint8_t initialized;
} frame_link_t;

/*
 * FrameLink_Init
 *
 * @param rx_ring_storage must be power-of-two sized (>= 2).
 */
framelink_status_t FrameLink_Init(frame_link_t *fl,
                                 serial_port_t *port,
                                 uint8_t *rx_ring_storage,
                                 size_t rx_ring_size,
                                 uint16_t max_drain_per_poll,
                                 uint16_t max_parse_bytes_per_poll);

/* Provide optional TX idle probe (strongly recommended for UART async drivers). */
void FrameLink_SetCanWriteProbe(frame_link_t *fl, frame_link_can_write_fn_t fn, void *ctx);

/*
 * FrameLink_Poll
 *
 * Performs bounded:
 *  - TX completion check (clears tx_inflight when port becomes idle)
 *  - RX drain from serial port into RX ring
 *  - RX parsing from ring into RX queue
 */
void FrameLink_Poll(frame_link_t *fl);

/*
 * FrameLink_Tx
 *
 * Builds a frame into fl->tx_buf and starts async write.
 * Returns FL_BUSY if a frame is already in-flight.
 */
framelink_status_t FrameLink_Tx(frame_link_t *fl, const uint8_t *payload, uint16_t len);

/*
 * FrameLink_RxGet
 *
 * Pops one complete frame from RX queue.
 */
framelink_status_t FrameLink_RxGet(frame_link_t *fl, uint8_t *out, uint16_t out_cap, uint16_t *out_len);

/*
 * Convenience function matching the milestone wording:
 *  - drains
 *  - parses
 *  - returns one frame if available
 */
framelink_status_t FrameLink_RxPollOne(frame_link_t *fl, uint8_t *out, uint16_t out_cap, uint16_t *out_len);

#ifdef __cplusplus
}
#endif
