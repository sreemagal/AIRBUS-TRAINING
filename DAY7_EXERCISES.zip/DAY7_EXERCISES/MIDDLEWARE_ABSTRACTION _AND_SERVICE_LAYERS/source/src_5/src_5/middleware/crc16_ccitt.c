#include "crc16_ccitt.h"

uint16_t Crc16Ccitt_Update(uint16_t crc, const uint8_t *data, size_t len)
{
    if ((data == NULL) || (len == 0u))
    {
        return crc;
    }

    for (size_t i = 0u; i < len; i++)
    {
        crc ^= (uint16_t)((uint16_t)data[i] << 8);
        for (uint8_t b = 0u; b < 8u; b++)
        {
            if ((crc & 0x8000u) != 0u)
            {
                crc = (uint16_t)((crc << 1) ^ 0x1021u);
            }
            else
            {
                crc = (uint16_t)(crc << 1);
            }
        }
    }

    return crc;
}
