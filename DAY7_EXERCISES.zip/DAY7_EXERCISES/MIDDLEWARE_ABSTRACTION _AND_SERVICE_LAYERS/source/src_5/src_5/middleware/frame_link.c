#include "frame_link.h"

#include "middleware/crc16_ccitt.h"

static uint8_t q_is_full(const frame_link_t *fl)
{
    uint8_t next = (uint8_t)((fl->rx_q_head + 1u) % FRAME_LINK_RX_QUEUE_LEN);
    return (next == fl->rx_q_tail) ? 1u : 0u;
}

static uint8_t q_is_empty(const frame_link_t *fl)
{
    return (fl->rx_q_head == fl->rx_q_tail) ? 1u : 0u;
}

static void q_push(frame_link_t *fl, const uint8_t *payload, uint16_t len)
{
    if (q_is_full(fl) != 0u)
    {
        fl->rx_q_overflow++;
        /* Policy: drop newest valid frame. */
        return;
    }

    frame_link_frame_t *slot = &fl->rx_q[fl->rx_q_head];
    slot->len = len;

    /* len is bounded by FRAME_LINK_MAX_PAYLOAD before calling q_push */
    for (uint16_t i = 0u; i < len; i++)
    {
        slot->payload[i] = payload[i];
    }

    fl->rx_q_head = (uint8_t)((fl->rx_q_head + 1u) % FRAME_LINK_RX_QUEUE_LEN);
    fl->frames_rx++;
}

static void parser_reset(frame_link_t *fl)
{
    fl->rx_state = RX_WAIT_S1;
    fl->rx_len = 0u;
    fl->rx_idx = 0u;
    fl->rx_crc_calc = CRC16_CCITT_INIT;
    fl->rx_crc_rx = 0u;
}

framelink_status_t FrameLink_Init(frame_link_t *fl,
                                 serial_port_t *port,
                                 uint8_t *rx_ring_storage,
                                 size_t rx_ring_size,
                                 uint16_t max_drain_per_poll,
                                 uint16_t max_parse_bytes_per_poll)
{
    if ((fl == NULL) || (port == NULL) || (rx_ring_storage == NULL))
    {
        return FL_INVALID_ARG;
    }

    if ((max_drain_per_poll == 0u) || (max_parse_bytes_per_poll == 0u))
    {
        return FL_INVALID_ARG;
    }

    ringbuf_status_t rst = RingBuf_Init(&fl->rx_rb, rx_ring_storage, rx_ring_size);
    if (rst != RINGBUF_OK)
    {
        return FL_INVALID_ARG;
    }

    fl->port = port;
    fl->can_write = NULL;
    fl->can_write_ctx = NULL;

    parser_reset(fl);

    fl->rx_q_head = 0u;
    fl->rx_q_tail = 0u;

    fl->tx_total_len = 0u;
    fl->tx_inflight = 0u;

    fl->max_drain_per_poll = max_drain_per_poll;
    fl->max_parse_bytes_per_poll = max_parse_bytes_per_poll;

    fl->bytes_in = 0u;
    fl->bytes_dropped = 0u;
    fl->frames_rx = 0u;
    fl->frames_tx = 0u;
    fl->crc_err = 0u;
    fl->len_err = 0u;
    fl->sync_loss = 0u;
    fl->rx_q_overflow = 0u;
    fl->tx_busy = 0u;

    fl->initialized = 1u;
    return FL_OK;
}

void FrameLink_SetCanWriteProbe(frame_link_t *fl, frame_link_can_write_fn_t fn, void *ctx)
{
    if (fl == NULL)
    {
        return;
    }
    fl->can_write = fn;
    fl->can_write_ctx = ctx;
}

/* Try to retire TX in-flight when underlying port becomes idle again. */
static void service_tx(frame_link_t *fl)
{
    if (fl->tx_inflight == 0u)
    {
        return;
    }

    /* If no probe is provided, we cannot safely know when it is done.
     * For EVKB UART builds, always provide a probe.
     */
    if (fl->can_write == NULL)
    {
        return;
    }

    if (fl->can_write(fl->can_write_ctx) != 0u)
    {
        /* Underlying port is idle, so the previous frame must have completed. */
        fl->tx_inflight = 0u;
        fl->tx_total_len = 0u;
    }
}

/* Drain bytes from serial port into rx ring (bounded). */
static void service_rx_drain(frame_link_t *fl)
{
    uint16_t remaining = fl->max_drain_per_poll;

    /* Use a small stack chunk to keep memory low and bounded. */
    uint8_t tmp[64];

    while (remaining != 0u)
    {
        uint16_t chunk = remaining;
        if (chunk > (uint16_t)sizeof(tmp))
        {
            chunk = (uint16_t)sizeof(tmp);
        }

        size_t got = SerialPort_Read(fl->port, tmp, (size_t)chunk);
        if (got == 0u)
        {
            break;
        }

        fl->bytes_in += (uint32_t)got;

        size_t pushed = RingBuf_Push(&fl->rx_rb, tmp, got);
        if (pushed < got)
        {
            fl->bytes_dropped += (uint32_t)(got - pushed);
        }

        remaining = (uint16_t)(remaining - (uint16_t)got);
        if ((uint16_t)got < chunk)
        {
            /* Port returned fewer than requested; stop early. */
            break;
        }
    }
}

/* Consume at most max_parse_bytes_per_poll bytes from ring and run the parser FSM. */
static void service_rx_parse(frame_link_t *fl)
{
    uint16_t budget = fl->max_parse_bytes_per_poll;

    while ((budget != 0u) && (RingBuf_Avail(&fl->rx_rb) != 0u))
    {
        uint8_t b = 0u;
        (void)RingBuf_Pop(&fl->rx_rb, &b, 1u);
        budget--;

        switch (fl->rx_state)
        {
            case RX_WAIT_S1:
                if (b == FRAME_LINK_SYNC1)
                {
                    fl->rx_state = RX_WAIT_S2;
                }
                else
                {
                    fl->sync_loss++;
                }
                break;

            case RX_WAIT_S2:
                if (b == FRAME_LINK_SYNC2)
                {
                    fl->rx_state = RX_WAIT_LEN0;
                    /* Reset CRC calculator for a new frame. */
                    fl->rx_crc_calc = CRC16_CCITT_INIT;
                }
                else
                {
                    /* Resync trick: if we got another SYNC1, stay in WAIT_S2 */
                    fl->sync_loss++;
                    fl->rx_state = (b == FRAME_LINK_SYNC1) ? RX_WAIT_S2 : RX_WAIT_S1;
                }
                break;

            case RX_WAIT_LEN0:
                fl->rx_len = (uint16_t)b;
                /* CRC covers LEN bytes too */
                fl->rx_crc_calc = Crc16Ccitt_Update(fl->rx_crc_calc, &b, 1u);
                fl->rx_state = RX_WAIT_LEN1;
                break;

            case RX_WAIT_LEN1:
            {
                fl->rx_len |= (uint16_t)((uint16_t)b << 8);
                fl->rx_crc_calc = Crc16Ccitt_Update(fl->rx_crc_calc, &b, 1u);

                if (fl->rx_len > (uint16_t)FRAME_LINK_MAX_PAYLOAD)
                {
                    fl->len_err++;
                    parser_reset(fl);
                    break;
                }

                fl->rx_idx = 0u;
                fl->rx_state = (fl->rx_len == 0u) ? RX_WAIT_CRC0 : RX_WAIT_PAYLOAD;
            }
            break;

            case RX_WAIT_PAYLOAD:
                fl->rx_payload[fl->rx_idx++] = b;
                fl->rx_crc_calc = Crc16Ccitt_Update(fl->rx_crc_calc, &b, 1u);

                if (fl->rx_idx >= fl->rx_len)
                {
                    fl->rx_state = RX_WAIT_CRC0;
                }
                break;

            case RX_WAIT_CRC0:
                fl->rx_crc_rx = (uint16_t)b;
                fl->rx_state = RX_WAIT_CRC1;
                break;

            case RX_WAIT_CRC1:
                fl->rx_crc_rx |= (uint16_t)((uint16_t)b << 8);

                if (fl->rx_crc_rx != fl->rx_crc_calc)
                {
                    fl->crc_err++;
                    parser_reset(fl);
                    break;
                }

                /* Valid frame complete */
                q_push(fl, fl->rx_payload, fl->rx_len);
                parser_reset(fl);
                break;

            default:
                parser_reset(fl);
                break;
        }
    }
}

void FrameLink_Poll(frame_link_t *fl)
{
    if ((fl == NULL) || (fl->initialized == 0u) || (fl->port == NULL))
    {
        return;
    }

    /* Allow underlying implementations to service themselves if needed. */
    SerialPort_Poll(fl->port);

    service_tx(fl);
    service_rx_drain(fl);
    service_rx_parse(fl);
}

framelink_status_t FrameLink_Tx(frame_link_t *fl, const uint8_t *payload, uint16_t len)
{
    if ((fl == NULL) || (fl->initialized == 0u) || (fl->port == NULL) || (payload == NULL))
    {
        return FL_INVALID_ARG;
    }

    if (len > (uint16_t)FRAME_LINK_MAX_PAYLOAD)
    {
        fl->len_err++;
        return FL_LEN_ERROR;
    }

    /* Only one frame in flight to keep determinism + buffer safety. */
    if (fl->tx_inflight != 0u)
    {
        fl->tx_busy++;
        return FL_BUSY;
    }

    /* Require can_write probe for UART async safety. */
    if ((fl->can_write != NULL) && (fl->can_write(fl->can_write_ctx) == 0u))
    {
        fl->tx_busy++;
        return FL_BUSY;
    }

    /* Build frame into internal TX buffer */
    uint16_t idx = 0u;
    fl->tx_buf[idx++] = FRAME_LINK_SYNC1;
    fl->tx_buf[idx++] = FRAME_LINK_SYNC2;

    /* LEN LE */
    fl->tx_buf[idx++] = (uint8_t)(len & 0xFFu);
    fl->tx_buf[idx++] = (uint8_t)((len >> 8) & 0xFFu);

    /* Payload */
    for (uint16_t i = 0u; i < len; i++)
    {
        fl->tx_buf[idx++] = payload[i];
    }

    /* CRC over LEN+PAYLOAD */
    uint16_t crc = CRC16_CCITT_INIT;
    crc = Crc16Ccitt_Update(crc, &fl->tx_buf[2], 2u);      /* LEN bytes */
    crc = Crc16Ccitt_Update(crc, &fl->tx_buf[4], (size_t)len);

    fl->tx_buf[idx++] = (uint8_t)(crc & 0xFFu);
    fl->tx_buf[idx++] = (uint8_t)((crc >> 8) & 0xFFu);

    fl->tx_total_len = idx;

    /* Attempt to start write (non-blocking). */
    size_t wrote = SerialPort_Write(fl->port, fl->tx_buf, (size_t)fl->tx_total_len);
    if (wrote != (size_t)fl->tx_total_len)
    {
        /* Underlying port is busy or failed. Keep tx_total_len but do not mark inflight.
         * Caller can retry later.
         */
        fl->tx_busy++;
        fl->tx_total_len = 0u;
        return FL_BUSY;
    }

    fl->tx_inflight = 1u;
    fl->frames_tx++;

    return FL_OK;
}

framelink_status_t FrameLink_RxGet(frame_link_t *fl, uint8_t *out, uint16_t out_cap, uint16_t *out_len)
{
    if ((fl == NULL) || (fl->initialized == 0u) || (out == NULL) || (out_len == NULL))
    {
        return FL_INVALID_ARG;
    }

    if (q_is_empty(fl) != 0u)
    {
        *out_len = 0u;
        return FL_NO_FRAME;
    }

    const frame_link_frame_t *slot = &fl->rx_q[fl->rx_q_tail];

    if (slot->len > out_cap)
    {
        /* Caller buffer too small: do not pop. */
        *out_len = 0u;
        return FL_LEN_ERROR;
    }

    for (uint16_t i = 0u; i < slot->len; i++)
    {
        out[i] = slot->payload[i];
    }

    *out_len = slot->len;
    fl->rx_q_tail = (uint8_t)((fl->rx_q_tail + 1u) % FRAME_LINK_RX_QUEUE_LEN);
    return FL_OK;
}

framelink_status_t FrameLink_RxPollOne(frame_link_t *fl, uint8_t *out, uint16_t out_cap, uint16_t *out_len)
{
    if ((fl == NULL) || (out == NULL) || (out_len == NULL))
    {
        return FL_INVALID_ARG;
    }

    FrameLink_Poll(fl);
    return FrameLink_RxGet(fl, out, out_cap, out_len);
}
