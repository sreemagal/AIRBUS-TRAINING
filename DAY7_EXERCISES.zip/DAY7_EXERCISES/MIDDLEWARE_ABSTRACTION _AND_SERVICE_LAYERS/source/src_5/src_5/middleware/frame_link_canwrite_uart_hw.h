#pragma once

#include <stdint.h>

#include "drivers/uart_hw.h"

#ifdef __cplusplus
extern "C" {
#endif

static inline uint8_t FrameLink_CanWrite_UartHw(void *ctx)
{
    uart_hw_t *u = (uart_hw_t *)ctx;
    if (u == NULL)
    {
        return 0u;
    }

    /* tx_busy is cleared by the UART driver callback when TX completes. */
    return (u->tx_busy == 0u) ? 1u : 0u;
}

#ifdef __cplusplus
}
#endif

