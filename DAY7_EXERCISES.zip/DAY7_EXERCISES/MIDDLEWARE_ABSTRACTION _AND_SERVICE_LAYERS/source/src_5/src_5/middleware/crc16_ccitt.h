#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * CRC16-CCITT
 *  - Polynomial: 0x1021
 *  - Init:       0xFFFF
 *  - No reflection
 *  - No final XOR
 */

#define CRC16_CCITT_INIT (0xFFFFu)

/* Update CRC with a block of bytes. */
uint16_t Crc16Ccitt_Update(uint16_t crc, const uint8_t *data, size_t len);

/* Convenience: compute CRC over a block using CRC16_CCITT_INIT. */
static inline uint16_t Crc16Ccitt_Compute(const uint8_t *data, size_t len)
{
    return Crc16Ccitt_Update(CRC16_CCITT_INIT, data, len);
}

#ifdef __cplusplus
}
#endif
