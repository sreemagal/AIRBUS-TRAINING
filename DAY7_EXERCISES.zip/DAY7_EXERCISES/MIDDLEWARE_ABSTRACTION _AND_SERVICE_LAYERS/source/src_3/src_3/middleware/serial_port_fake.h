#pragma once

#include <stddef.h>
#include <stdint.h>

#include "middleware/serial_port.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * serial_port_fake — deterministic in-memory fake serial port
 *
 * Purpose:
 *  - Enables PC/host unit testing of middleware and services.
 *  - Provides explicit, bounded buffering.
 *
 * Model:
 *  - RX buffer: data available for SerialPort_Read()
 *  - TX buffer: collects data written by SerialPort_Write()
 */

typedef struct serial_port_fake
{
    /* RX: producer writes into rx_buf; consumer reads via SerialPort_Read */
    uint8_t *rx_buf;
    size_t rx_cap;
    size_t rx_head;
    size_t rx_tail;

    /* TX: consumer writes via SerialPort_Write; producer can read out */
    uint8_t *tx_buf;
    size_t tx_cap;
    size_t tx_head;
    size_t tx_tail;

    /* Diagnostics */
    uint32_t rx_drops;
    uint32_t tx_drops;
} serial_port_fake_t;

/* Initialize fake using caller-provided storage. */
void SerialFake_Init(serial_port_fake_t *f,
                     uint8_t *rx_storage, size_t rx_size,
                     uint8_t *tx_storage, size_t tx_size);

/* Bind fake to a serial_port_t */
void SerialFake_Bind(serial_port_t *p, serial_port_fake_t *f);

/* Inject bytes into RX stream (returns bytes accepted, drops counted). */
size_t SerialFake_InjectRx(serial_port_fake_t *f, const uint8_t *src, size_t len);

/* Extract bytes written to TX stream (returns bytes copied). */
size_t SerialFake_DrainTx(serial_port_fake_t *f, uint8_t *dst, size_t maxlen);

#ifdef __cplusplus
}
#endif
