#include "serial_port.h"

/* Milestone-2 driver wrapper (SDK-type-free header) */
#include "drivers/uart_hw.h"

/* -------------------- NULL port implementation -------------------- */

static size_t null_read(void *ctx, uint8_t *dst, size_t maxlen)
{
    (void)ctx;
    (void)dst;
    (void)maxlen;
    return 0u;
}

static size_t null_write(void *ctx, const uint8_t *src, size_t len)
{
    (void)ctx;
    (void)src;
    (void)len;
    return 0u;
}

static void null_poll(void *ctx)
{
    (void)ctx;
}

static const serial_port_vtable_t g_null_vt = {
    .read = null_read,
    .write = null_write,
    .poll = null_poll,
};

void SerialPort_makeNull(serial_port_t *p)
{
    if (p == NULL)
    {
        return;
    }
    p->ctx = NULL;
    p->vt = &g_null_vt;
}

/* -------------------- UART-backed serial port implementation -------------------- */

static size_t uart_read(void *ctx, uint8_t *dst, size_t maxlen)
{
    uart_hw_t *u = (uart_hw_t *)ctx;
    if ((u == NULL) || (dst == NULL) || (maxlen == 0u))
    {
        return 0u;
    }

    size_t got = 0u;
    uart_hw_status_t st = UART_HW_Receive(u, dst, maxlen, &got);

    /* Non-blocking semantics: on NOT_READY or errors, return 0 bytes. */
    (void)st;
    return got;
}

static size_t uart_write(void *ctx, const uint8_t *src, size_t len)
{
    uart_hw_t *u = (uart_hw_t *)ctx;
    if ((u == NULL) || (src == NULL) || (len == 0u))
    {
        return 0u;
    }

    uart_hw_status_t st = UART_HW_Send(u, src, len);

    /*
     * Contract mapping:
     *  - If busy, accept 0 bytes.
     *  - If OK, accept all bytes (driver requires buffer valid until completion).
     */
    if (st == UART_HW_OK)
    {
        return len;
    }

    return 0u;
}

static void uart_poll(void *ctx)
{
    /*
     * For interrupt-driven + ring-buffer RX, nothing is required here.
     * This hook exists to support alternative implementations (bit-banged UART, DMA service, etc.).
     */
    (void)ctx;
}

static const serial_port_vtable_t g_uart_vt = {
    .read = uart_read,
    .write = uart_write,
    .poll = uart_poll,
};

int SerialPort_fromUart(serial_port_t *p, void *uart_hw_ptr)
{
    if ((p == NULL) || (uart_hw_ptr == NULL))
    {
        return -1;
    }

    p->ctx = uart_hw_ptr;
    p->vt = &g_uart_vt;
    return 0;
}
