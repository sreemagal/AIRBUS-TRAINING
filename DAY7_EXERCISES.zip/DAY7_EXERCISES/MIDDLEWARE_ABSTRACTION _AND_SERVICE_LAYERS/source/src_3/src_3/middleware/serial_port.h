#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * serial_port.h — Middleware abstraction for byte-stream I/O
 *
 * Design contract (matches the exercise spec):
 *  - No blocking calls.
 *  - No dynamic allocation.
 *  - No hardware/SDK types are exposed.
 *
 * Semantics:
 *  - read(dst, maxlen) returns the number of bytes copied (0..maxlen).
 *    It MUST return immediately.
 *  - write(src, len) returns the number of bytes accepted for transmit.
 *    Implementations may accept 0 if busy.
 *  - poll() is optional. If an implementation does not need servicing, it can be a no-op.
 */

typedef struct serial_port serial_port_t;

typedef size_t (*serial_read_fn_t)(void *ctx, uint8_t *dst, size_t maxlen);
typedef size_t (*serial_write_fn_t)(void *ctx, const uint8_t *src, size_t len);
typedef void   (*serial_poll_fn_t)(void *ctx);

typedef struct serial_port_vtable
{
    serial_read_fn_t  read;
    serial_write_fn_t write;
    serial_poll_fn_t  poll;
} serial_port_vtable_t;

struct serial_port
{
    void *ctx;                         /* implementation context */
    const serial_port_vtable_t *vt;    /* implementation vtable */
};

/* -------------------- Safe wrapper helpers -------------------- */

static inline size_t SerialPort_Read(serial_port_t *p, uint8_t *dst, size_t maxlen)
{
    if ((p == NULL) || (p->vt == NULL) || (p->vt->read == NULL) || (dst == NULL) || (maxlen == 0u))
    {
        return 0u;
    }
    return p->vt->read(p->ctx, dst, maxlen);
}

static inline size_t SerialPort_Write(serial_port_t *p, const uint8_t *src, size_t len)
{
    if ((p == NULL) || (p->vt == NULL) || (p->vt->write == NULL) || (src == NULL) || (len == 0u))
    {
        return 0u;
    }
    return p->vt->write(p->ctx, src, len);
}

static inline void SerialPort_Poll(serial_port_t *p)
{
    if ((p != NULL) && (p->vt != NULL) && (p->vt->poll != NULL))
    {
        p->vt->poll(p->ctx);
    }
}

/* -------------------- Binding factories -------------------- */

/*
 * SerialPort_fromUart
 *
 * Binds a Milestone-2 uart_hw_t instance (passed as void*) to a serial_port_t.
 *
 * @pre p != NULL
 * @pre uart_hw_ptr != NULL and points to a valid uart_hw_t
 *
 * Returns 0 on success, non-zero on invalid args.
 */
int SerialPort_fromUart(serial_port_t *p, void *uart_hw_ptr);

/* Utility: create a disabled/null port (reads/writes always return 0). */
void SerialPort_makeNull(serial_port_t *p);

#ifdef __cplusplus
}
#endif
