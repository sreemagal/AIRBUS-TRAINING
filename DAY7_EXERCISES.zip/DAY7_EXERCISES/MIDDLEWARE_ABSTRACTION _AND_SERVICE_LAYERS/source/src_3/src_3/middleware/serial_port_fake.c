#include "serial_port_fake.h"

static size_t rb_avail(size_t head, size_t tail, size_t cap)
{
    return (head >= tail) ? (head - tail) : (cap - (tail - head));
}

static size_t rb_space(size_t head, size_t tail, size_t cap)
{
    /* One slot left empty to distinguish full vs empty. */
    return (cap - 1u) - rb_avail(head, tail, cap);
}

static size_t rb_push(uint8_t *buf, size_t cap, size_t *head, size_t tail, const uint8_t *src, size_t len)
{
    size_t pushed = 0u;
    size_t h = *head;

    while (pushed < len)
    {
        size_t space = rb_space(h, tail, cap);
        if (space == 0u)
        {
            break;
        }
        buf[h] = src[pushed];
        h = (h + 1u) % cap;
        pushed++;
    }

    *head = h;
    return pushed;
}

static size_t rb_pop(uint8_t *buf, size_t cap, size_t head, size_t *tail, uint8_t *dst, size_t len)
{
    size_t popped = 0u;
    size_t t = *tail;

    while (popped < len)
    {
        size_t avail = rb_avail(head, t, cap);
        if (avail == 0u)
        {
            break;
        }
        dst[popped] = buf[t];
        t = (t + 1u) % cap;
        popped++;
    }

    *tail = t;
    return popped;
}

void SerialFake_Init(serial_port_fake_t *f,
                     uint8_t *rx_storage, size_t rx_size,
                     uint8_t *tx_storage, size_t tx_size)
{
    if ((f == NULL) || (rx_storage == NULL) || (tx_storage == NULL) || (rx_size < 2u) || (tx_size < 2u))
    {
        return;
    }

    f->rx_buf = rx_storage;
    f->rx_cap = rx_size;
    f->rx_head = 0u;
    f->rx_tail = 0u;

    f->tx_buf = tx_storage;
    f->tx_cap = tx_size;
    f->tx_head = 0u;
    f->tx_tail = 0u;

    f->rx_drops = 0u;
    f->tx_drops = 0u;
}

static size_t fake_read(void *ctx, uint8_t *dst, size_t maxlen)
{
    serial_port_fake_t *f = (serial_port_fake_t *)ctx;
    if ((f == NULL) || (dst == NULL) || (maxlen == 0u))
    {
        return 0u;
    }

    return rb_pop(f->rx_buf, f->rx_cap, f->rx_head, &f->rx_tail, dst, maxlen);
}

static size_t fake_write(void *ctx, const uint8_t *src, size_t len)
{
    serial_port_fake_t *f = (serial_port_fake_t *)ctx;
    if ((f == NULL) || (src == NULL) || (len == 0u))
    {
        return 0u;
    }

    size_t pushed = rb_push(f->tx_buf, f->tx_cap, &f->tx_head, f->tx_tail, src, len);
    if (pushed < len)
    {
        f->tx_drops += (uint32_t)(len - pushed);
    }

    return pushed;
}

static void fake_poll(void *ctx)
{
    (void)ctx;
}

static const serial_port_vtable_t g_fake_vt = {
    .read = fake_read,
    .write = fake_write,
    .poll = fake_poll,
};

void SerialFake_Bind(serial_port_t *p, serial_port_fake_t *f)
{
    if ((p == NULL) || (f == NULL))
    {
        return;
    }

    p->ctx = f;
    p->vt = &g_fake_vt;
}

size_t SerialFake_InjectRx(serial_port_fake_t *f, const uint8_t *src, size_t len)
{
    if ((f == NULL) || (src == NULL) || (len == 0u))
    {
        return 0u;
    }

    size_t pushed = rb_push(f->rx_buf, f->rx_cap, &f->rx_head, f->rx_tail, src, len);
    if (pushed < len)
    {
        f->rx_drops += (uint32_t)(len - pushed);
    }

    return pushed;
}

size_t SerialFake_DrainTx(serial_port_fake_t *f, uint8_t *dst, size_t maxlen)
{
    if ((f == NULL) || (dst == NULL) || (maxlen == 0u))
    {
        return 0u;
    }

    return rb_pop(f->tx_buf, f->tx_cap, f->tx_head, &f->tx_tail, dst, maxlen);
}

