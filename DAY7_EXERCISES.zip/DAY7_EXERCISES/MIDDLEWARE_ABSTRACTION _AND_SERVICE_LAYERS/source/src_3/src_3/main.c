#include "bsp/board_init.h"
#include "board.h" /* BOARD_DebugConsoleSrcFreq() */
#include "drivers/uart_hw.h"
#include "middleware/serial_port.h"


static uart_hw_t g_link_uart;
static uint8_t g_link_rx_ring[1024];
static serial_port_t g_link_port;


int main(void)
{
BSP_InitHardware();


(void)UART_HW_Init(&g_link_uart, (void*)LPUART2, BOARD_DebugConsoleSrcFreq(), 115200u);
(void)UART_HW_AttachRing(&g_link_uart, g_link_rx_ring, sizeof(g_link_rx_ring));


(void)SerialPort_fromUart(&g_link_port, &g_link_uart);


const uint8_t msg[] = "Hello over serial_port facade\r\n";
(void)SerialPort_Write(&g_link_port, msg, sizeof(msg) - 1u);


for (;;)
{
uint8_t buf[64];
size_t got = SerialPort_Read(&g_link_port, buf, sizeof(buf));
if (got)
{
/* Echo */
(void)SerialPort_Write(&g_link_port, buf, got);
}
}
}