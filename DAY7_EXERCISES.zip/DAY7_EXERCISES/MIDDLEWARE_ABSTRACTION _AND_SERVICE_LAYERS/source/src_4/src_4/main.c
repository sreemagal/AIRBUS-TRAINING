#include <stdio.h>
#include <string.h>

#include "bsp/board_init.h"      /* if you use Milestone 1 BSP boundary */
#include "middleware/ringbuf.h"

static void ringbuf_demo(void)
{
    uint8_t storage[8]; /* cap=8 => max storable = 7 */
    ringbuf_t rb;

    int rc = RingBuf_Init(&rb, storage, sizeof(storage));
    printf("M4: init rc=%d cap=%u max=%u\r\n", rc, (unsigned)sizeof(storage), (unsigned)(sizeof(storage)-1));

    /* Push 5 bytes */
    const uint8_t a[] = {1,2,3,4,5};
    size_t pushed = RingBuf_Push(&rb, a, sizeof(a));
    printf("M4: pushed=%u avail=%u space=%u\r\n", (unsigned)pushed, (unsigned)RingBuf_Avail(&rb), (unsigned)RingBuf_Space(&rb));

    /* Peek 3 bytes without consuming */
    uint8_t peek[3];
    size_t pk = RingBuf_Peek(&rb, 0, peek, sizeof(peek));
    printf("M4: peeked=%u first=%u\r\n", (unsigned)pk, (unsigned)peek[0]);

    /* Pop 2 bytes */
    uint8_t out[2];
    size_t popped = RingBuf_Pop(&rb, out, sizeof(out));
    printf("M4: popped=%u [%u,%u] avail=%u space=%u\r\n",
           (unsigned)popped, (unsigned)out[0], (unsigned)out[1],
           (unsigned)RingBuf_Avail(&rb), (unsigned)RingBuf_Space(&rb));

    /* Overflow behavior: try to push 6 bytes when only 4 space left (cap=8 => max=7) */
    const uint8_t b[] = {6,7,8,9,10,11};
    size_t before_space = RingBuf_Space(&rb);
    size_t pushed2 = RingBuf_Push(&rb, b, sizeof(b));
    size_t drops = sizeof(b) - pushed2;
    printf("M4: before_space=%u pushed2=%u drops=%u avail=%u space=%u\r\n",
           (unsigned)before_space, (unsigned)pushed2, (unsigned)drops,
           (unsigned)RingBuf_Avail(&rb), (unsigned)RingBuf_Space(&rb));

    /* Drain all */
    uint8_t all[16];
    size_t n = RingBuf_Pop(&rb, all, sizeof(all));
    printf("M4: drained=%u final_avail=%u\r\n", (unsigned)n, (unsigned)RingBuf_Avail(&rb));
}

int main(void)
{
    /* If you have Milestone 1 BSP boundary: */
    BSP_InitHardware();

    printf("Milestone 4: ringbuf demo\r\n");
    ringbuf_demo();

    for(;;) {}
}
