#include "ringbuf.h"

static uint8_t is_power_of_two_u32(uint32_t x)
{
    /* True for 1,2,4,... but we require >=2. */
    return (x != 0u) && ((x & (x - 1u)) == 0u);
}

static uint32_t min_u32(uint32_t a, uint32_t b)
{
    return (a < b) ? a : b;
}

ringbuf_status_t RingBuf_Init(ringbuf_t *rb, uint8_t *storage, size_t storage_size)
{
    if ((rb == NULL) || (storage == NULL))
    {
        return RINGBUF_INVALID_ARG;
    }

    if (storage_size < 2u)
    {
        return RINGBUF_INVALID_ARG;
    }

    if (storage_size > 0xFFFFFFFFu)
    {
        /* size_t can be 64-bit on host; we restrict to 32-bit counters. */
        return RINGBUF_INVALID_ARG;
    }

    uint32_t cap = (uint32_t)storage_size;
    if (is_power_of_two_u32(cap) == 0u)
    {
        return RINGBUF_INVALID_ARG;
    }

    rb->buf = storage;
    rb->cap = cap;
    rb->mask = cap - 1u;
    rb->head = 0u;
    rb->tail = 0u;
    rb->initialized = 1u;

    return RINGBUF_OK;
}

ringbuf_status_t RingBuf_Reset(ringbuf_t *rb)
{
    if ((rb == NULL) || (rb->initialized == 0u))
    {
        return RINGBUF_NOT_INIT;
    }

    rb->head = 0u;
    rb->tail = 0u;
    return RINGBUF_OK;
}

size_t RingBuf_Avail(const ringbuf_t *rb)
{
    if ((rb == NULL) || (rb->initialized == 0u))
    {
        return 0u;
    }

    /* Works across wrap as long as invariant holds (difference < cap). */
    uint32_t head = rb->head;
    uint32_t tail = rb->tail;

    return (size_t)(head - tail);
}

size_t RingBuf_Space(const ringbuf_t *rb)
{
    if ((rb == NULL) || (rb->initialized == 0u))
    {
        return 0u;
    }

    /* Usable max = cap-1. */
    uint32_t used = (uint32_t)RingBuf_Avail(rb);
    uint32_t usable = (rb->cap - 1u);

    if (used >= usable)
    {
        return 0u;
    }

    return (size_t)(usable - used);
}

size_t RingBuf_UsableCapacity(const ringbuf_t *rb)
{
    if ((rb == NULL) || (rb->initialized == 0u))
    {
        return 0u;
    }

    return (size_t)(rb->cap - 1u);
}

size_t RingBuf_Push(ringbuf_t *rb, const uint8_t *src, size_t len)
{
    if ((rb == NULL) || (rb->initialized == 0u) || (src == NULL) || (len == 0u))
    {
        return 0u;
    }

    /* Bound by available space. */
    uint32_t space = (uint32_t)RingBuf_Space(rb);
    uint32_t want = (len > 0xFFFFFFFFu) ? 0xFFFFFFFFu : (uint32_t)len;
    uint32_t to_write = min_u32(space, want);

    uint32_t head = rb->head;

    for (uint32_t i = 0u; i < to_write; i++)
    {
        rb->buf[head & rb->mask] = src[i];
        head++;
    }

    rb->head = head;
    return (size_t)to_write;
}

size_t RingBuf_Pop(ringbuf_t *rb, uint8_t *dst, size_t len)
{
    if ((rb == NULL) || (rb->initialized == 0u) || (dst == NULL) || (len == 0u))
    {
        return 0u;
    }

    uint32_t avail = (uint32_t)RingBuf_Avail(rb);
    uint32_t want = (len > 0xFFFFFFFFu) ? 0xFFFFFFFFu : (uint32_t)len;
    uint32_t to_read = min_u32(avail, want);

    uint32_t tail = rb->tail;

    for (uint32_t i = 0u; i < to_read; i++)
    {
        dst[i] = rb->buf[tail & rb->mask];
        tail++;
    }

    rb->tail = tail;
    return (size_t)to_read;
}

size_t RingBuf_Peek(const ringbuf_t *rb, size_t offset, uint8_t *dst, size_t len)
{
    if ((rb == NULL) || (rb->initialized == 0u) || (dst == NULL) || (len == 0u))
    {
        return 0u;
    }

    uint32_t avail = (uint32_t)RingBuf_Avail(rb);

    /* If offset beyond available, nothing to return. */
    if (offset >= (size_t)avail)
    {
        return 0u;
    }

    uint32_t off = (offset > 0xFFFFFFFFu) ? 0xFFFFFFFFu : (uint32_t)offset;
    uint32_t remaining = avail - off;

    uint32_t want = (len > 0xFFFFFFFFu) ? 0xFFFFFFFFu : (uint32_t)len;
    uint32_t to_copy = min_u32(remaining, want);

    uint32_t start = rb->tail + off;

    for (uint32_t i = 0u; i < to_copy; i++)
    {
        dst[i] = rb->buf[(start + i) & rb->mask];
    }

    return (size_t)to_copy;
}

size_t RingBuf_Drop(ringbuf_t *rb, size_t len)
{
    if ((rb == NULL) || (rb->initialized == 0u) || (len == 0u))
    {
        return 0u;
    }

    uint32_t avail = (uint32_t)RingBuf_Avail(rb);
    uint32_t want = (len > 0xFFFFFFFFu) ? 0xFFFFFFFFu : (uint32_t)len;
    uint32_t to_drop = min_u32(avail, want);

    rb->tail = rb->tail + to_drop;
    return (size_t)to_drop;
}
