#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * ringbuf.h — deterministic SPSC byte ring buffer
 *
 * Intended use:
 *  - Producer pushes bytes (e.g., drained from serial_port into parsing buffer)
 *  - Consumer pops/peeks bytes (e.g., frame parser state machine)
 *
 * Concurrency contract:
 *  - Single producer and single consumer.
 *  - Safe for typical bare-metal patterns:
 *      (A) both producer and consumer in the same thread/task context, OR
 *      (B) producer in ISR and consumer in main *if* head/tail updates are naturally atomic
 *          (32-bit aligned writes on Cortex-M) and you do not read-modify-write shared fields.
 *
 *  If you need MPMC or multi-ISR usage, use a different design.
 */

typedef enum ringbuf_status
{
    RINGBUF_OK = 0,
    RINGBUF_INVALID_ARG,
    RINGBUF_NOT_INIT,
} ringbuf_status_t;

typedef struct ringbuf
{
    uint8_t *buf;
    uint32_t cap;   /* power-of-two storage size */
    uint32_t mask;  /* cap - 1 */

    /*
     * Monotonic counters (mod 2^32). Indexing uses (counter & mask).
     * Invariant: (head - tail) <= cap-1
     */
    volatile uint32_t head;
    volatile uint32_t tail;

    uint8_t initialized;
} ringbuf_t;

/* Initialize ring buffer with caller-provided storage.
 *
 * @pre rb != NULL
 * @pre storage != NULL
 * @pre storage_size is a power of two and >= 2
 *
 * @note usable capacity is storage_size - 1.
 */
ringbuf_status_t RingBuf_Init(ringbuf_t *rb, uint8_t *storage, size_t storage_size);

/* Reset to empty (does not clear storage). */
ringbuf_status_t RingBuf_Reset(ringbuf_t *rb);

/* Total bytes currently stored (0..cap-1). */
size_t RingBuf_Avail(const ringbuf_t *rb);

/* Free space remaining for push (0..cap-1-avail). */
size_t RingBuf_Space(const ringbuf_t *rb);

/* Usable capacity (cap-1). */
size_t RingBuf_UsableCapacity(const ringbuf_t *rb);

/* Push up to len bytes into the ring.
 *
 * @return number of bytes actually stored (0..len). Caller can count drops.
 */
size_t RingBuf_Push(ringbuf_t *rb, const uint8_t *src, size_t len);

/* Pop up to len bytes from the ring.
 *
 * @return number of bytes copied into dst (0..len).
 */
size_t RingBuf_Pop(ringbuf_t *rb, uint8_t *dst, size_t len);

/* Peek up to len bytes starting at offset from tail, without removing.
 *
 * @param offset number of bytes from current tail to start peeking.
 * @return number of bytes copied (0..len).
 */
size_t RingBuf_Peek(const ringbuf_t *rb, size_t offset, uint8_t *dst, size_t len);

/* Drop (discard) up to len bytes from the buffer.
 *
 * @return number of bytes dropped.
 */
size_t RingBuf_Drop(ringbuf_t *rb, size_t len);

#ifdef __cplusplus
}
#endif
