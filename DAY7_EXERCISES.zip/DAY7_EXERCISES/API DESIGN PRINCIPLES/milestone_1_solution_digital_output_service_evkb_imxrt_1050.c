/******************************************************************************
 * Milestone 1 (Solution)
 * Digital Output Service (DIO) + LED toggle demo
 * Target: NXP i.MX RT1050 EVKB (EVKB-IMXRT1050) using MCUXpresso SDK
 *
 * How to use this code in MCUXpresso IDE (high-level):
 *  1) Import SDK example:
 *     boards/evkbimxrt1050/driver_examples/gpio/led_output
 *  2) Add the two new files below to the project:
 *        - dio.h
 *        - dio.c
 *  3) Replace the example's gpio_led_output.c content with the demo main() below
 *     (or create a new C file with the demo main and exclude the original one).
 *  4) Build + flash.
 *
 * NOTE: This milestone intentionally keeps the timing simple (delay-based).
 *       A deterministic 1ms tick is introduced in Milestone 2.
 ******************************************************************************/

/******************************************************************************
 * File: dio.h
 ******************************************************************************/
#ifndef DIO_H_
#define DIO_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h" /* status_t, kStatus_* */
#include "fsl_gpio.h"   /* GPIO_Type, gpio_pin_config_t, GPIO_* APIs */

/* Versioning (simple semantic version for the DIO module). */
#define DIO_VERSION_MAJOR (1u)
#define DIO_VERSION_MINOR (0u)
#define DIO_VERSION_PATCH (0u)

/*
 * Design intent for Milestone 1
 * ----------------------------
 * - A small, explicit API wrapper around SDK GPIO pin output.
 * - Idempotent init when called again with the same configuration.
 * - Clear ownership: the caller owns the handle memory; DIO only stores a copy
 *   of key configuration fields in the handle.
 * - Consistent error handling using MCUXpresso SDK status_t.
 */

typedef struct
{
    GPIO_Type *base;   /* GPIO instance base pointer, e.g., GPIO1 */
    uint32_t pin;      /* Pin index [0..31] */
    bool activeLow;    /* true: logical ON drives pin low (0). false: logical ON drives pin high (1). */
    bool initialOn;    /* logical initial state applied during DIO_Init() */
} dio_config_t;

typedef struct
{
    GPIO_Type *base;
    uint32_t pin;
    bool activeLow;
    bool isInitialized;
} dio_handle_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize a digital output pin.
 *
 * @param handle Pointer to caller-owned handle storage.
 * @param config Pointer to configuration.
 *
 * @pre  - handle != NULL
 * @pre  - config != NULL
 * @pre  - config->base != NULL
 * @pre  - Pin mux/IO configuration for the selected pad has been done by
 *         the board/pin_mux layer (MCUXpresso config files).
 * @pre  - config->pin is in [0..31] for the selected GPIO port.
 *
 * @post - The pin is configured as a digital output.
 * @post - The initial logical output state is applied.
 * @post - handle->isInitialized == true on success.
 *
 * Idempotence rule:
 *  - If DIO_Init() is called again on an already initialized handle *with the
 *    exact same base/pin/activeLow*, it returns kStatus_Success and does not
 *    reconfigure hardware.
 *  - If called with a different configuration, it returns kStatus_Fail.
 *
 * Concurrency / context:
 *  - Main context only for this milestone.
 */
status_t DIO_Init(dio_handle_t *handle, const dio_config_t *config);

/*
 * @brief Write a logical level to the output pin.
 *
 * @param handle Initialized handle.
 * @param on     true = logical ON, false = logical OFF.
 *
 * @pre  handle != NULL
 * @pre  handle->isInitialized == true
 *
 * @post The hardware output is updated.
 */
status_t DIO_Write(dio_handle_t *handle, bool on);

/*
 * @brief Toggle the output pin.
 *
 * @param handle Initialized handle.
 *
 * @pre  handle != NULL
 * @pre  handle->isInitialized == true
 *
 * @post The hardware output is toggled.
 */
status_t DIO_Toggle(dio_handle_t *handle);

/*
 * @brief Read the current logical state of the pin.
 *
 * @param handle Initialized handle.
 * @param on     Output parameter receiving logical state.
 *
 * @pre  handle != NULL
 * @pre  on != NULL
 * @pre  handle->isInitialized == true
 *
 * @note On some MCUs, reading an output pin may reflect the pad/input sense.
 *       For a user LED this is typically fine.
 */
status_t DIO_Read(dio_handle_t *handle, bool *on);

#ifdef __cplusplus
}
#endif

#endif /* DIO_H_ */

/******************************************************************************
 * File: dio.c
 ******************************************************************************/
#include "dio.h"

/* Internal helper: validate port pin range for typical 32-bit GPIO ports. */
static inline bool DIO_IsPinInRange(uint32_t pin)
{
    return (pin < 32u);
}

/* Internal helper: convert logical ON/OFF to physical 0/1 considering activeLow. */
static inline uint8_t DIO_LogicalToPhysical(bool activeLow, bool logicalOn)
{
    const uint8_t on_u8 = logicalOn ? 1u : 0u;
    return activeLow ? (uint8_t)(1u - on_u8) : on_u8;
}

status_t DIO_Init(dio_handle_t *handle, const dio_config_t *config)
{
    if ((handle == NULL) || (config == NULL) || (config->base == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (!DIO_IsPinInRange(config->pin))
    {
        return kStatus_OutOfRange;
    }

    /* If already initialized: enforce idempotence rule. */
    if (handle->isInitialized)
    {
        const bool sameInstance = (handle->base == config->base) &&
                                  (handle->pin == config->pin) &&
                                  (handle->activeLow == config->activeLow);

        return sameInstance ? kStatus_Success : kStatus_Fail;
    }

    /* Configure pin as a digital output with defined initial value. */
    const uint8_t initialPhysical = DIO_LogicalToPhysical(config->activeLow, config->initialOn);

    gpio_pin_config_t pinCfg;
    pinCfg.direction     = kGPIO_DigitalOutput;
    pinCfg.outputLogic   = initialPhysical;
    pinCfg.interruptMode = kGPIO_NoIntmode;

    GPIO_PinInit(config->base, config->pin, &pinCfg);

    /* Store configuration in handle (caller retains ownership of handle memory). */
    handle->base         = config->base;
    handle->pin          = config->pin;
    handle->activeLow    = config->activeLow;
    handle->isInitialized = true;

    return kStatus_Success;
}

status_t DIO_Write(dio_handle_t *handle, bool on)
{
    if (handle == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        /* The handle exists but is not in a valid state for use. */
        return kStatus_Fail;
    }

    const uint8_t physical = DIO_LogicalToPhysical(handle->activeLow, on);
    GPIO_PinWrite(handle->base, handle->pin, physical);

    return kStatus_Success;
}

status_t DIO_Toggle(dio_handle_t *handle)
{
    if (handle == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        return kStatus_Fail;
    }

    /*
     * Toggle at the hardware level.
     * This is deterministic and does not require reading the pin first.
     */
    GPIO_PortToggle(handle->base, (uint32_t)(1u << handle->pin));

    return kStatus_Success;
}

status_t DIO_Read(dio_handle_t *handle, bool *on)
{
    if ((handle == NULL) || (on == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        return kStatus_Fail;
    }

    const uint8_t physical = GPIO_PinRead(handle->base, handle->pin);
    const bool logicalOn = handle->activeLow ? (physical == 0u) : (physical != 0u);

    *on = logicalOn;
    return kStatus_Success;
}

/******************************************************************************
 * File: gpio_led_output.c  (replace the example's main file with this demo)
 ******************************************************************************/
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_clock.h"   /* CLOCK_GetCpuClkFreq() */
#include "app.h"         /* EXAMPLE_LED_GPIO / EXAMPLE_LED_GPIO_PIN, BOARD_InitHardware() */

#include "dio.h"

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 1: Digital Output Service (DIO) demo\r\n");
    PRINTF("DIO version %u.%u.%u\r\n", DIO_VERSION_MAJOR, DIO_VERSION_MINOR, DIO_VERSION_PATCH);

    /*
     * EVKB-IMXRT1050 USER LED is active-low in the SDK board macros
     * (USER_LED_ON clears the GPIO bit).
     * We therefore configure activeLow=true so that logical ON maps to physical 0.
     */
    dio_handle_t userLed = {0};
    const dio_config_t userLedCfg = {
        .base      = EXAMPLE_LED_GPIO,
        .pin       = EXAMPLE_LED_GPIO_PIN,
        .activeLow = true,
        .initialOn = false,
    };

    status_t st = DIO_Init(&userLed, &userLedCfg);
    if (st != kStatus_Success)
    {
        PRINTF("DIO_Init failed: %ld\r\n", (long)st);
        while (1)
        {
            /* Fail-safe: stop here */
        }
    }

    /* Demonstrate idempotent init: calling again with same config must succeed. */
    st = DIO_Init(&userLed, &userLedCfg);
    if (st != kStatus_Success)
    {
        PRINTF("DIO_Init (2nd call) unexpected failure: %ld\r\n", (long)st);
        while (1)
        {
        }
    }

    PRINTF("Toggling USER LED using DIO_Toggle()...\r\n");

    while (1)
    {
        /* Toggle at a human-visible rate. */
        (void)DIO_Toggle(&userLed);

        /* Delay ~500ms using SDK helper; timing determinism is addressed in Milestone 2. */
        SDK_DelayAtLeastUs(500000u, CLOCK_GetCpuClkFreq());
    }
}
