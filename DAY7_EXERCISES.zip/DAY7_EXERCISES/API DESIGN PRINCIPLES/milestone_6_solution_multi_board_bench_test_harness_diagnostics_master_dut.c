/******************************************************************************
 * Milestone 6 (Solution)
 * Multi-board Bench Test Harness + Diagnostics (Master/DUT) over UFS frames
 *
 * What this milestone adds:
 * - A simple command/response protocol riding on UFS framed UART (Milestone 3)
 * - DUT (Device Under Test) command handling:
 *     - PING/PONG
 *     - PAUSE_POLL (intentionally stop polling to force RX ring overflow)
 *     - STATS_REQ (returns consolidated stats from UFS + A429B + AirData + jitter monitor)
 *     - RESET_STATS
 * - MASTER automated test sequence:
 *     1) PING/PONG
 *     2) Checksum error injection (send corrupted frames)
 *     3) RX ring overflow test (pause DUT polling + burst)
 *     4) Jitter test (MASTER sends periodic A429B words; DUT measures receive period)
 *
 * Target: EVKB-IMXRT1050 (i.MX RT1050) using MCUXpresso SDK
 *
 * Dependencies (from previous milestones):
 *   - dio.h/.c                 (Milestone 1)
 *   - tick_1ms.h/.c            (Milestone 2)
 *   - uart_framed_service.h/.c (Milestone 3)
 *   - arinc429_bridge.h/.c     (Milestone 4)
 *   - air_data_app.h/.c        (Milestone 5)
 *
 * Recommended baseline project to import:
 *   boards/evkbimxrt1050/driver_examples/lpuart/interrupt_transfer
 * Then add the above milestone modules + the files in this milestone.
 *
 * Wiring (2 boards):
 *   MASTER TX -> DUT RX
 *   MASTER RX <- DUT TX
 *   GND <-> GND
 *   (115200 8N1)
 ******************************************************************************/

/******************************************************************************
 * File: m6_test_protocol.h
 ******************************************************************************/
#ifndef M6_TEST_PROTOCOL_H_
#define M6_TEST_PROTOCOL_H_

#include <stdbool.h>
#include <stdint.h>

/* Test protocol message types carried inside UFS payload[0] */
#define M6_MSG_PING        (0xF0u)
#define M6_MSG_PONG        (0xF1u)
#define M6_MSG_PAUSE_POLL  (0xF2u)
#define M6_MSG_PAUSE_ACK   (0xF3u)
#define M6_MSG_STATS_REQ   (0xF4u)
#define M6_MSG_STATS_RSP   (0xF5u)
#define M6_MSG_BURST       (0xF6u) /* intentionally spammed */
#define M6_MSG_RESET_STATS (0xF7u)
#define M6_MSG_RESET_ACK   (0xF8u)

/* Payload lengths (without UFS framing) */
#define M6_LEN_PING        (3u)  /* type + seq16 */
#define M6_LEN_PONG        (3u)
#define M6_LEN_PAUSE_POLL  (5u)  /* type + seq16 + pause_ms16 */
#define M6_LEN_PAUSE_ACK   (3u)
#define M6_LEN_STATS_REQ   (3u)
#define M6_LEN_RESET_REQ   (3u)
#define M6_LEN_RESET_ACK   (3u)

/* Helper: little-endian packing */
static inline void M6_PutU16LE(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
}

static inline uint16_t M6_GetU16LE(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static inline void M6_PutU32LE(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
    p[2] = (uint8_t)((v >> 16) & 0xFFu);
    p[3] = (uint8_t)((v >> 24) & 0xFFu);
}

static inline uint32_t M6_GetU32LE(const uint8_t *p)
{
    return ((uint32_t)p[0]) |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

#endif /* M6_TEST_PROTOCOL_H_ */

/******************************************************************************
 * File: jitter_monitor.h
 ******************************************************************************/
#ifndef JITTER_MONITOR_H_
#define JITTER_MONITOR_H_

#include <stdbool.h>
#include <stdint.h>

typedef struct
{
    bool hasPrev;
    uint32_t expectedPeriodMs;

    uint32_t prevEventMs;

    uint32_t count;     /* number of intervals measured (events-1) */
    uint32_t sumMs;     /* sum of measured intervals */
    uint32_t minMs;     /* min measured interval */
    uint32_t maxMs;     /* max measured interval */
} jitter_mon_t;

static inline void JITTER_Init(jitter_mon_t *jm, uint32_t expectedPeriodMs)
{
    jm->hasPrev = false;
    jm->expectedPeriodMs = expectedPeriodMs;
    jm->prevEventMs = 0u;
    jm->count = 0u;
    jm->sumMs = 0u;
    jm->minMs = 0xFFFFFFFFu;
    jm->maxMs = 0u;
}

static inline void JITTER_Reset(jitter_mon_t *jm)
{
    const uint32_t exp = jm->expectedPeriodMs;
    JITTER_Init(jm, exp);
}

static inline void JITTER_OnEvent(jitter_mon_t *jm, uint32_t nowMs)
{
    if (!jm->hasPrev)
    {
        jm->hasPrev = true;
        jm->prevEventMs = nowMs;
        return;
    }

    const uint32_t dt = (uint32_t)(nowMs - jm->prevEventMs);
    jm->prevEventMs = nowMs;

    jm->count++;
    jm->sumMs += dt;
    if (dt < jm->minMs) jm->minMs = dt;
    if (dt > jm->maxMs) jm->maxMs = dt;
}

static inline uint32_t JITTER_AvgMs(const jitter_mon_t *jm)
{
    return (jm->count == 0u) ? 0u : (jm->sumMs / jm->count);
}

#endif /* JITTER_MONITOR_H_ */

/******************************************************************************
 * File: m6_dut.h
 ******************************************************************************/
#ifndef M6_DUT_H_
#define M6_DUT_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"
#include "tick_1ms.h"
#include "jitter_monitor.h"

/* DUT command handler / reply queue */
typedef struct
{
    ufs_t *ufs;
    const tick_handle_t *tick;

    /* modules for stats */
    const a429b_t *bridge;
    const airdata_t *air;
    const jitter_mon_t *jitter;

    /* pause behavior */
    uint32_t pauseRemainingMs;

    /* one pending reply (sent from main when TX available) */
    bool replyPending;
    uint8_t replyBuf[64];
    uint8_t replyLen;
} m6_dut_t;

void M6_DUT_Init(m6_dut_t *dut,
                 ufs_t *ufs,
                 const tick_handle_t *tick,
                 const a429b_t *bridge,
                 const airdata_t *air,
                 const jitter_mon_t *jitter);

/* Called from UFS rx callback (main context via UFS_Poll) */
void M6_DUT_OnFrame(m6_dut_t *dut, const uint8_t *payload, uint8_t len);

/* Called periodically from main using dt ms (handles pause timers and replies) */
void M6_DUT_OnTickMs(m6_dut_t *dut, uint32_t dtMs);

bool M6_DUT_IsPaused(const m6_dut_t *dut);

#endif /* M6_DUT_H_ */

/******************************************************************************
 * File: m6_dut.c
 ******************************************************************************/
#include "m6_dut.h"
#include "m6_test_protocol.h"

static void M6_DUT_QueueReply(m6_dut_t *dut, const uint8_t *payload, uint8_t len)
{
    if ((len == 0u) || (len > (uint8_t)sizeof(dut->replyBuf)))
    {
        return;
    }

    for (uint32_t i = 0; i < len; i++)
    {
        dut->replyBuf[i] = payload[i];
    }

    dut->replyLen = len;
    dut->replyPending = true;
}

static uint8_t M6_DUT_BuildStatsRsp(m6_dut_t *dut, uint16_t seq)
{
    /*
     * Stats payload layout (little-endian u32), kept under 64 bytes:
     * [0] type
     * [1..2] seq
     * Then 15 x u32 = 60 bytes total payload size = 63 bytes
     *
     * u32 list:
     *  0 ufs.rxFramesOk
     *  1 ufs.rxChecksumErrors
     *  2 ufs.rxRingOverflows
     *  3 a429b.wordsRx
     *  4 a429b.rxParityErrors
     *  5 a429b.rxSsmErrors
     *  6 a429b.rxFormatErrors
     *  7 air.validWordsTotal
     *  8 air.invalidWordsTotal
     *  9 air.altUpdates
     * 10 air.iasUpdates
     * 11 jitter.count
     * 12 jitter.minMs
     * 13 jitter.maxMs
     * 14 jitter.avgMs
     */

    ufs_stats_t us = {0};
    a429b_stats_t bs = {0};
    airdata_snapshot_t as = {0};

    UFS_GetStats(dut->ufs, &us);
    A429B_GetStats(dut->bridge, &bs);
    AirData_GetSnapshot(dut->air, &as);

    const uint32_t jCount = dut->jitter->count;
    const uint32_t jMin   = (dut->jitter->count == 0u) ? 0u : dut->jitter->minMs;
    const uint32_t jMax   = (dut->jitter->count == 0u) ? 0u : dut->jitter->maxMs;
    const uint32_t jAvg   = JITTER_AvgMs(dut->jitter);

    uint8_t p[64];
    p[0] = M6_MSG_STATS_RSP;
    M6_PutU16LE(&p[1], seq);

    uint32_t idx = 3u;
    M6_PutU32LE(&p[idx], us.rxFramesOk);        idx += 4u;
    M6_PutU32LE(&p[idx], us.rxChecksumErrors);  idx += 4u;
    M6_PutU32LE(&p[idx], us.rxRingOverflows);   idx += 4u;

    M6_PutU32LE(&p[idx], bs.wordsRx);           idx += 4u;
    M6_PutU32LE(&p[idx], bs.rxParityErrors);    idx += 4u;
    M6_PutU32LE(&p[idx], bs.rxSsmErrors);       idx += 4u;
    M6_PutU32LE(&p[idx], bs.rxFormatErrors);    idx += 4u;

    M6_PutU32LE(&p[idx], as.stats.validWordsTotal);   idx += 4u;
    M6_PutU32LE(&p[idx], as.stats.invalidWordsTotal); idx += 4u;
    M6_PutU32LE(&p[idx], as.stats.altUpdates);        idx += 4u;
    M6_PutU32LE(&p[idx], as.stats.iasUpdates);        idx += 4u;

    M6_PutU32LE(&p[idx], jCount); idx += 4u;
    M6_PutU32LE(&p[idx], jMin);   idx += 4u;
    M6_PutU32LE(&p[idx], jMax);   idx += 4u;
    M6_PutU32LE(&p[idx], jAvg);   idx += 4u;

    M6_DUT_QueueReply(dut, p, (uint8_t)idx);
    return (uint8_t)idx;
}

void M6_DUT_Init(m6_dut_t *dut,
                 ufs_t *ufs,
                 const tick_handle_t *tick,
                 const a429b_t *bridge,
                 const airdata_t *air,
                 const jitter_mon_t *jitter)
{
    dut->ufs = ufs;
    dut->tick = tick;
    dut->bridge = bridge;
    dut->air = air;
    dut->jitter = jitter;
    dut->pauseRemainingMs = 0u;
    dut->replyPending = false;
    dut->replyLen = 0u;
}

bool M6_DUT_IsPaused(const m6_dut_t *dut)
{
    return (dut->pauseRemainingMs != 0u);
}

void M6_DUT_OnFrame(m6_dut_t *dut, const uint8_t *payload, uint8_t len)
{
    if ((dut == NULL) || (payload == NULL) || (len < 3u))
    {
        return;
    }

    const uint8_t type = payload[0];
    const uint16_t seq = M6_GetU16LE(&payload[1]);

    if (type == M6_MSG_PING)
    {
        uint8_t rsp[M6_LEN_PONG];
        rsp[0] = M6_MSG_PONG;
        M6_PutU16LE(&rsp[1], seq);
        M6_DUT_QueueReply(dut, rsp, sizeof(rsp));
    }
    else if (type == M6_MSG_PAUSE_POLL)
    {
        if (len == M6_LEN_PAUSE_POLL)
        {
            const uint16_t pauseMs = M6_GetU16LE(&payload[3]);
            dut->pauseRemainingMs = (uint32_t)pauseMs;
        }

        uint8_t rsp[M6_LEN_PAUSE_ACK];
        rsp[0] = M6_MSG_PAUSE_ACK;
        M6_PutU16LE(&rsp[1], seq);
        M6_DUT_QueueReply(dut, rsp, sizeof(rsp));
    }
    else if (type == M6_MSG_STATS_REQ)
    {
        (void)M6_DUT_BuildStatsRsp(dut, seq);
    }
    else if (type == M6_MSG_RESET_STATS)
    {
        /* Reset underlying module stats.
         * Note: this function does not own those modules, so reset must be done
         * by the main code (we just send ACK here). For simplicity, master uses
         * RESET only for jitter monitor (handled in main demo).
         */
        uint8_t rsp[M6_LEN_RESET_ACK];
        rsp[0] = M6_MSG_RESET_ACK;
        M6_PutU16LE(&rsp[1], seq);
        M6_DUT_QueueReply(dut, rsp, sizeof(rsp));
    }
    else
    {
        /* Ignore unknown types */
    }
}

void M6_DUT_OnTickMs(m6_dut_t *dut, uint32_t dtMs)
{
    if ((dut == NULL) || (dtMs == 0u))
    {
        return;
    }

    if (dut->pauseRemainingMs > dtMs)
    {
        dut->pauseRemainingMs -= dtMs;
    }
    else
    {
        dut->pauseRemainingMs = 0u;
    }

    /* Try to send pending reply if TX is free. */
    if (dut->replyPending)
    {
        if (!UFS_IsTxBusy(dut->ufs))
        {
            const status_t st = UFS_SendFrame(dut->ufs, dut->replyBuf, dut->replyLen);
            if (st == kStatus_Success)
            {
                dut->replyPending = false;
                dut->replyLen = 0u;
            }
            /* else: keep pending and retry next tick */
        }
    }
}

/******************************************************************************
 * File: m6_master.h
 ******************************************************************************/
#ifndef M6_MASTER_H_
#define M6_MASTER_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"
#include "fsl_lpuart.h" /* LPUART_WriteBlocking */

#include "tick_1ms.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h" /* for packing A429B words */
#include "m6_test_protocol.h"

/* MASTER mailbox for received responses */
typedef struct
{
    bool hasMsg;
    uint8_t type;
    uint16_t seq;
    uint8_t payload[64];
    uint8_t len;
} m6_mailbox_t;

typedef enum
{
    M6M_STATE_INIT = 0,
    M6M_STATE_SEND_PING,
    M6M_STATE_WAIT_PONG,

    M6M_STATE_BASELINE_STATS,
    M6M_STATE_WAIT_BASELINE_STATS,

    M6M_STATE_INJECT_BAD_CHECKSUM,
    M6M_STATE_STATS_AFTER_BAD_CHECKSUM,
    M6M_STATE_WAIT_STATS_AFTER_BAD_CHECKSUM,

    M6M_STATE_SEND_PAUSE,
    M6M_STATE_WAIT_PAUSE_ACK,
    M6M_STATE_SEND_BURST,
    M6M_STATE_STATS_AFTER_BURST,
    M6M_STATE_WAIT_STATS_AFTER_BURST,

    M6M_STATE_JITTER_SEND_STREAM,
    M6M_STATE_JITTER_WAIT,
    M6M_STATE_JITTER_STATS,
    M6M_STATE_JITTER_WAIT_STATS,

    M6M_STATE_DONE
} m6m_state_t;

/* Parsed stats from DUT */
typedef struct
{
    uint32_t ufs_rxOk;
    uint32_t ufs_csumErr;
    uint32_t ufs_ovf;

    uint32_t a429b_wordsRx;
    uint32_t a429b_parityErr;
    uint32_t a429b_ssmErr;
    uint32_t a429b_fmtErr;

    uint32_t air_valid;
    uint32_t air_invalid;
    uint32_t air_altUp;
    uint32_t air_iasUp;

    uint32_t jit_count;
    uint32_t jit_min;
    uint32_t jit_max;
    uint32_t jit_avg;
} m6_stats_snapshot_t;

/* MASTER test runner */
typedef struct
{
    LPUART_Type *uartBase;
    const tick_handle_t *tick;

    /* For receiving responses we still use UFS parsing */
    ufs_t *ufs;

    m6_mailbox_t mb;

    m6m_state_t state;
    uint16_t seq;

    uint32_t stateTimerMs;
    uint32_t streamTimerMs;
    uint32_t streamPeriodMs;
    uint32_t streamNextDueMs;

    m6_stats_snapshot_t baseline;
    m6_stats_snapshot_t afterBadChecksum;
    m6_stats_snapshot_t afterBurst;
    m6_stats_snapshot_t afterJitter;

    /* Pass/fail flags */
    bool pass_ping;
    bool pass_checksum;
    bool pass_overflow;
    bool pass_jitter;
} m6_master_t;

void M6_MASTER_Init(m6_master_t *m,
                    LPUART_Type *uartBase,
                    const tick_handle_t *tick,
                    ufs_t *ufs);

/* Called from UFS rx callback (main context via UFS_Poll) */
void M6_MASTER_OnFrame(m6_master_t *m, const uint8_t *payload, uint8_t len);

/* Called periodically from main using dt ms: advances test state machine */
void M6_MASTER_Run(m6_master_t *m, uint32_t dtMs);

#endif /* M6_MASTER_H_ */

/******************************************************************************
 * File: m6_master.c
 ******************************************************************************/
#include "m6_master.h"
#include "fsl_debug_console.h"

/* ---- UFS frame builder for blocking TX (MASTER only) ---- */

static uint8_t M6_ChecksumTwoComplement(uint8_t len, const uint8_t *payload)
{
    uint32_t sum = (uint32_t)len;
    for (uint32_t i = 0; i < len; i++)
    {
        sum += payload[i];
    }
    return (uint8_t)(0u - (uint8_t)sum);
}

static void M6_SendUfsFrameBlocking(LPUART_Type *base, const uint8_t *payload, uint8_t len, bool corruptChecksum)
{
    /* Build full frame: START | LEN | payload | checksum */
    uint8_t frame[1u + 1u + 64u + 1u];
    uint32_t idx = 0u;

    frame[idx++] = UFS_FRAME_START_BYTE;
    frame[idx++] = len;

    for (uint32_t i = 0; i < len; i++)
    {
        frame[idx++] = payload[i];
    }

    uint8_t cs = M6_ChecksumTwoComplement(len, payload);
    if (corruptChecksum)
    {
        cs ^= 0xFFu; /* intentional corruption */
    }
    frame[idx++] = cs;

    /* Blocking write: MASTER is allowed to block. */
    LPUART_WriteBlocking(base, frame, idx);
}

static void M6_Master_SendPing(m6_master_t *m)
{
    uint8_t p[M6_LEN_PING];
    p[0] = M6_MSG_PING;
    M6_PutU16LE(&p[1], m->seq);
    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static void M6_Master_SendStatsReq(m6_master_t *m)
{
    uint8_t p[M6_LEN_STATS_REQ];
    p[0] = M6_MSG_STATS_REQ;
    M6_PutU16LE(&p[1], m->seq);
    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static void M6_Master_SendPause(m6_master_t *m, uint16_t pauseMs)
{
    uint8_t p[M6_LEN_PAUSE_POLL];
    p[0] = M6_MSG_PAUSE_POLL;
    M6_PutU16LE(&p[1], m->seq);
    M6_PutU16LE(&p[3], pauseMs);
    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static void M6_Master_SendCorruptFrames(m6_master_t *m, uint16_t count)
{
    /* Send corrupted PING frames; DUT should count checksum errors. */
    for (uint16_t i = 0; i < count; i++)
    {
        uint8_t p[M6_LEN_PING];
        p[0] = M6_MSG_PING;
        M6_PutU16LE(&p[1], (uint16_t)(0x9000u + i));
        M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), true);
    }
}

static void M6_Master_SendBurst(m6_master_t *m, uint16_t frames)
{
    /* Burst is small but valid framed messages, sent back-to-back. */
    for (uint16_t i = 0; i < frames; i++)
    {
        uint8_t p[5];
        p[0] = M6_MSG_BURST;
        M6_PutU16LE(&p[1], (uint16_t)(0xB000u));
        M6_PutU16LE(&p[3], i);
        M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
    }
}

static void M6_Master_SendA429Word(m6_master_t *m, uint32_t rawWord)
{
    /* UFS payload for domain word: [0]=A429B_MSG_WORD, [1..4]=word LE */
    uint8_t p[5];
    p[0] = A429B_MSG_WORD;
    p[1] = (uint8_t)(rawWord & 0xFFu);
    p[2] = (uint8_t)((rawWord >> 8) & 0xFFu);
    p[3] = (uint8_t)((rawWord >> 16) & 0xFFu);
    p[4] = (uint8_t)((rawWord >> 24) & 0xFFu);

    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static bool M6_ParseStatsRsp(const uint8_t *payload, uint8_t len, m6_stats_snapshot_t *out)
{
    if ((payload == NULL) || (out == NULL))
    {
        return false;
    }

    /* Minimum expected: type + seq16 + 15*u32 = 63 bytes */
    if (len < 63u)
    {
        return false;
    }

    if (payload[0] != M6_MSG_STATS_RSP)
    {
        return false;
    }

    uint32_t idx = 3u;
    out->ufs_rxOk        = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->ufs_csumErr     = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->ufs_ovf         = M6_GetU32LE(&payload[idx]); idx += 4u;

    out->a429b_wordsRx   = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->a429b_parityErr = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->a429b_ssmErr    = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->a429b_fmtErr    = M6_GetU32LE(&payload[idx]); idx += 4u;

    out->air_valid       = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->air_invalid     = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->air_altUp       = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->air_iasUp       = M6_GetU32LE(&payload[idx]); idx += 4u;

    out->jit_count       = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->jit_min         = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->jit_max         = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->jit_avg         = M6_GetU32LE(&payload[idx]); idx += 4u;

    (void)idx;
    return true;
}

void M6_MASTER_Init(m6_master_t *m,
                    LPUART_Type *uartBase,
                    const tick_handle_t *tick,
                    ufs_t *ufs)
{
    m->uartBase = uartBase;
    m->tick = tick;
    m->ufs = ufs;

    m->mb.hasMsg = false;
    m->state = M6M_STATE_INIT;
    m->seq = 1u;

    m->stateTimerMs = 0u;
    m->streamTimerMs = 0u;
    m->streamPeriodMs = 50u;
    m->streamNextDueMs = 0u;

    m->pass_ping = false;
    m->pass_checksum = false;
    m->pass_overflow = false;
    m->pass_jitter = false;
}

void M6_MASTER_OnFrame(m6_master_t *m, const uint8_t *payload, uint8_t len)
{
    if ((m == NULL) || (payload == NULL) || (len == 0u))
    {
        return;
    }

    if (len > (uint8_t)sizeof(m->mb.payload))
    {
        return;
    }

    m->mb.type = payload[0];
    m->mb.seq = (len >= 3u) ? M6_GetU16LE(&payload[1]) : 0u;
    m->mb.len = len;

    for (uint32_t i = 0; i < len; i++)
    {
        m->mb.payload[i] = payload[i];
    }

    m->mb.hasMsg = true;
}

static bool M6_Master_TakeMsg(m6_master_t *m, uint8_t type, uint16_t seq)
{
    if (!m->mb.hasMsg)
    {
        return false;
    }

    if ((m->mb.type == type) && (m->mb.seq == seq))
    {
        m->mb.hasMsg = false;
        return true;
    }

    return false;
}

static bool M6_Master_TakeStats(m6_master_t *m, uint16_t seq, m6_stats_snapshot_t *out)
{
    if (!m->mb.hasMsg)
    {
        return false;
    }

    if ((m->mb.type == M6_MSG_STATS_RSP) && (m->mb.seq == seq))
    {
        const bool ok = M6_ParseStatsRsp(m->mb.payload, m->mb.len, out);
        m->mb.hasMsg = false;
        return ok;
    }

    return false;
}

void M6_MASTER_Run(m6_master_t *m, uint32_t dtMs)
{
    if (m == NULL)
    {
        return;
    }

    m->stateTimerMs += dtMs;

    switch (m->state)
    {
        case M6M_STATE_INIT:
        {
            PRINTF("M6 MASTER: starting tests...\r\n");
            m->state = M6M_STATE_SEND_PING;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_SEND_PING:
        {
            PRINTF("Test1: PING...\r\n");
            M6_Master_SendPing(m);
            m->state = M6M_STATE_WAIT_PONG;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_WAIT_PONG:
        {
            if (M6_Master_TakeMsg(m, M6_MSG_PONG, m->seq))
            {
                PRINTF("  PONG received.\r\n");
                m->pass_ping = true;
                m->seq++;
                m->state = M6M_STATE_BASELINE_STATS;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: PONG timeout.\r\n");
                m->seq++;
                m->state = M6M_STATE_BASELINE_STATS;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_BASELINE_STATS:
        {
            PRINTF("Baseline: requesting STATS...\r\n");
            M6_Master_SendStatsReq(m);
            m->state = M6M_STATE_WAIT_BASELINE_STATS;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_WAIT_BASELINE_STATS:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->baseline))
            {
                PRINTF("  Baseline: csumErr=%lu ovf=%lu rxOk=%lu\r\n",
                       (unsigned long)m->baseline.ufs_csumErr,
                       (unsigned long)m->baseline.ufs_ovf,
                       (unsigned long)m->baseline.ufs_rxOk);
                m->seq++;
                m->state = M6M_STATE_INJECT_BAD_CHECKSUM;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: baseline STATS timeout.\r\n");
                m->seq++;
                m->state = M6M_STATE_INJECT_BAD_CHECKSUM;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_INJECT_BAD_CHECKSUM:
        {
            PRINTF("Test2: injecting bad-checksum frames...\r\n");
            M6_Master_SendCorruptFrames(m, 10u);
            m->state = M6M_STATE_STATS_AFTER_BAD_CHECKSUM;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_STATS_AFTER_BAD_CHECKSUM:
        {
            /* give DUT a moment to process / count */
            if (m->stateTimerMs >= 100u)
            {
                M6_Master_SendStatsReq(m);
                m->state = M6M_STATE_WAIT_STATS_AFTER_BAD_CHECKSUM;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_WAIT_STATS_AFTER_BAD_CHECKSUM:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->afterBadChecksum))
            {
                const uint32_t diff = m->afterBadChecksum.ufs_csumErr - m->baseline.ufs_csumErr;
                PRINTF("  checksumErrors increased by %lu\r\n", (unsigned long)diff);
                m->pass_checksum = (diff > 0u);
                PRINTF("  %s\r\n", m->pass_checksum ? "PASS" : "FAIL");

                m->seq++;
                m->state = M6M_STATE_SEND_PAUSE;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: STATS timeout after checksum test.\r\n");
                m->seq++;
                m->state = M6M_STATE_SEND_PAUSE;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_SEND_PAUSE:
        {
            PRINTF("Test3: overflow test: PAUSE_POLL 250ms...\r\n");
            M6_Master_SendPause(m, 250u);
            m->state = M6M_STATE_WAIT_PAUSE_ACK;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_WAIT_PAUSE_ACK:
        {
            if (M6_Master_TakeMsg(m, M6_MSG_PAUSE_ACK, m->seq))
            {
                PRINTF("  Pause ACK received. Sending burst...\r\n");
                m->seq++;
                m->state = M6M_STATE_SEND_BURST;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: PAUSE_ACK timeout. Proceeding anyway.\r\n");
                m->seq++;
                m->state = M6M_STATE_SEND_BURST;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_SEND_BURST:
        {
            /* Send enough frames to overflow a 256-byte RX ring when DUT is not polling */
            M6_Master_SendBurst(m, 300u);
            m->state = M6M_STATE_STATS_AFTER_BURST;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_STATS_AFTER_BURST:
        {
            /* Wait for DUT to resume polling */
            if (m->stateTimerMs >= 400u)
            {
                M6_Master_SendStatsReq(m);
                m->state = M6M_STATE_WAIT_STATS_AFTER_BURST;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_WAIT_STATS_AFTER_BURST:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->afterBurst))
            {
                const uint32_t diff = m->afterBurst.ufs_ovf - m->afterBadChecksum.ufs_ovf;
                PRINTF("  RX overflow increased by %lu\r\n", (unsigned long)diff);
                m->pass_overflow = (diff > 0u);
                PRINTF("  %s\r\n", m->pass_overflow ? "PASS" : "FAIL");

                m->seq++;
                m->state = M6M_STATE_JITTER_SEND_STREAM;
                m->stateTimerMs = 0u;
                m->streamTimerMs = 0u;
                m->streamNextDueMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: STATS timeout after burst.\r\n");
                m->seq++;
                m->state = M6M_STATE_JITTER_SEND_STREAM;
                m->stateTimerMs = 0u;
                m->streamTimerMs = 0u;
                m->streamNextDueMs = 0u;
            }
            break;
        }

        case M6M_STATE_JITTER_SEND_STREAM:
        {
            /*
             * Test4: jitter measurement
             * MASTER acts as a sensor: sends label 203 (altitude) every 50ms for 5 seconds.
             * DUT measures reception intervals and reports min/max/avg.
             */
            PRINTF("Test4: jitter stream: sending A429B label203 every %lu ms for 5s...\r\n",
                   (unsigned long)m->streamPeriodMs);

            m->state = M6M_STATE_JITTER_WAIT;
            m->stateTimerMs = 0u;
            m->streamTimerMs = 0u;
            m->streamNextDueMs = 0u;
            break;
        }

        case M6M_STATE_JITTER_WAIT:
        {
            m->streamTimerMs += dtMs;
            m->streamNextDueMs += dtMs;

            if (m->streamNextDueMs >= m->streamPeriodMs)
            {
                m->streamNextDueMs -= m->streamPeriodMs;

                /* Build a valid word: label 203, data increments, NORMAL, even parity */
                static uint32_t alt = 1000u;
                a429b_word_fields_t f = {
                    .label = 203u,
                    .sdi = 0u,
                    .data = (alt & 0x7FFFFu),
                    .ssm = A429B_SSM_NORMAL_OPERATION,
                    .parity = false,
                };

                uint32_t w;
                (void)A429B_PackWord(&f, &w);
                w = A429B_SetEvenParity(w);
                M6_Master_SendA429Word(m, w);

                alt += 1u;
            }

            if (m->streamTimerMs >= 5000u)
            {
                m->state = M6M_STATE_JITTER_STATS;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_JITTER_STATS:
        {
            PRINTF("  Requesting jitter STATS...\r\n");
            M6_Master_SendStatsReq(m);
            m->state = M6M_STATE_JITTER_WAIT_STATS;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_JITTER_WAIT_STATS:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->afterJitter))
            {
                PRINTF("  Jitter intervals=%lu min=%lu max=%lu avg=%lu (expected=%lu)\r\n",
                       (unsigned long)m->afterJitter.jit_count,
                       (unsigned long)m->afterJitter.jit_min,
                       (unsigned long)m->afterJitter.jit_max,
                       (unsigned long)m->afterJitter.jit_avg,
                       (unsigned long)m->streamPeriodMs);

                /* Pass if we got enough samples and bounds are reasonable (example rule) */
                m->pass_jitter = (m->afterJitter.jit_count >= 20u);
                PRINTF("  %s\r\n", m->pass_jitter ? "PASS" : "FAIL");

                m->seq++;
                m->state = M6M_STATE_DONE;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: jitter STATS timeout.\r\n");
                m->seq++;
                m->state = M6M_STATE_DONE;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_DONE:
        {
            PRINTF("\r\n=== Milestone 6 Summary ===\r\n");
            PRINTF("PING:     %s\r\n", m->pass_ping ? "PASS" : "FAIL");
            PRINTF("CHECKSUM: %s\r\n", m->pass_checksum ? "PASS" : "FAIL");
            PRINTF("OVERFLOW: %s\r\n", m->pass_overflow ? "PASS" : "FAIL");
            PRINTF("JITTER:   %s\r\n", m->pass_jitter ? "PASS" : "FAIL");
            PRINTF("===========================\r\n");

            m->state = M6M_STATE_DONE;
            break;
        }

        default:
            m->state = M6M_STATE_DONE;
            break;
    }
}

/******************************************************************************
 * File: milestone6_demo_main.c
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, BOARD_USER_LED_* */
#include "fsl_debug_console.h"
#include "fsl_clock.h"

#include "dio.h"
#include "tick_1ms.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"

#include "m6_test_protocol.h"
#include "m6_dut.h"
#include "m6_master.h"
#include "jitter_monitor.h"

/*
 * Role selection:
 *  0 = MASTER (runs automated test suite)
 *  1 = DUT    (runs full stack + command handler)
 */
#ifndef M6_NODE_ROLE
#define M6_NODE_ROLE (1u)
#endif

/* PIT defaults (if not provided by your project headers) */
#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

/* Shared objects */
static airdata_t s_air;
static jitter_mon_t s_jitter;
static tick_handle_t s_tick;
static ufs_t s_ufs;
static a429b_t s_bridge;
static dio_handle_t s_led;

/* DUT harness and MASTER harness */
static m6_dut_t s_dut;
static m6_master_t s_master;

/*
 * UFS RX dispatcher:
 * - Called from UFS_Poll() (main context)
 * - Routes payloads to either:
 *     - A429B_UfsRxHook (domain word)
 *     - Milestone 6 test protocol handler (PING/REQ/...) for MASTER or DUT
 */
typedef struct
{
    uint8_t role;
    a429b_t *bridge;
    m6_dut_t *dut;
    m6_master_t *master;
} m6_ctx_t;

static m6_ctx_t s_ctx;

static void M6_UfsRxDispatcher(const uint8_t *payload, uint8_t len, void *userData)
{
    m6_ctx_t *ctx = (m6_ctx_t *)userData;
    if ((ctx == NULL) || (payload == NULL) || (len == 0u))
    {
        return;
    }

    const uint8_t type = payload[0];

    if ((type == A429B_MSG_WORD) && (ctx->bridge != NULL))
    {
        /* Deliver to domain layer decoder */
        A429B_UfsRxHook(payload, len, ctx->bridge);
        return;
    }

    /* Otherwise treat as Milestone 6 control message */
    if (ctx->role == 0u)
    {
        M6_MASTER_OnFrame(ctx->master, payload, len);
    }
    else
    {
        M6_DUT_OnFrame(ctx->dut, payload, len);
    }
}

/* Domain word callback for DUT: update AirData + jitter monitor */
static void Dut_OnWord(uint32_t rawWord,
                       const a429b_word_fields_t *fields,
                       a429b_word_validity_t validity,
                       void *userData)
{
    (void)userData;

    AirData_OnWord(&s_air, rawWord, fields, validity);

    /* Jitter measurement: track label 203 receptions when valid */
    if ((validity == A429B_WORD_VALID) && (fields != NULL) && (fields->label == AIRDATA_LABEL_PRESSURE_ALT_FT))
    {
        JITTER_OnEvent(&s_jitter, TICK_GetMs(&s_tick));
    }
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 6: Bench Test Harness (%s)\r\n", (M6_NODE_ROLE == 0u) ? "MASTER" : "DUT");

    /* LED via DIO */
    const dio_config_t ledCfg = {
        .base = BOARD_USER_LED_GPIO,
        .pin = BOARD_USER_LED_GPIO_PIN,
        .activeLow = true,
        .initialOn = false,
    };
    (void)DIO_Init(&s_led, &ledCfg);

    /* 1ms tick */
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };
    if (TICK_Init(&s_tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("TICK_Init failed\r\n");
        while (1) {}
    }

    /* AirData app (only meaningful on DUT, but harmless on MASTER) */
    const airdata_config_t airCfg = {
        .activityPulseMs = 50u,
        .altStaleTimeoutMs = 500u,
        .iasStaleTimeoutMs = 500u,
        .acceptFunctionalTest = false,
    };
    (void)AirData_Init(&s_air, &airCfg);

    /* Jitter monitor expects 50ms periodic label 203 messages in this test */
    JITTER_Init(&s_jitter, 50u);

    /* UFS init: rxCb is dispatcher (not A429B hook directly) */
    s_ctx.role = (uint8_t)M6_NODE_ROLE;
    s_ctx.bridge = &s_bridge;
    s_ctx.dut = &s_dut;
    s_ctx.master = &s_master;

    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 192u,
        .rxCb = M6_UfsRxDispatcher,
        .rxCbUserData = &s_ctx,
    };

    if (UFS_Init(&s_ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("UFS_Init failed\r\n");
        while (1) {}
    }

    /* Domain layer: decode A429B words, callback differs for role */
    if (M6_NODE_ROLE == 1u)
    {
        (void)A429B_Init(&s_bridge, &s_ufs, Dut_OnWord, NULL);
        M6_DUT_Init(&s_dut, &s_ufs, &s_tick, &s_bridge, &s_air, &s_jitter);
    }
    else
    {
        /* MASTER does not need domain decoding; still init for pack helpers if desired */
        (void)A429B_Init(&s_bridge, &s_ufs, NULL, NULL);
        M6_MASTER_Init(&s_master, DEMO_LPUART, &s_tick, &s_ufs);
    }

    uint32_t lastMs = TICK_GetMs(&s_tick);
    uint32_t printTimer = 0u;

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&s_tick, &lastMs);

        if (dt != 0u)
        {
            if (M6_NODE_ROLE == 1u)
            {
                /* DUT: update app and DUT harness timers */
                AirData_OnTickMs(&s_air, dt);
                A429B_OnTickMs(&s_bridge, dt);
                M6_DUT_OnTickMs(&s_dut, dt);

                /* Drive LED based on app suggestion */
                (void)DIO_Write(&s_led, s_air.activityLedOn);
            }
            else
            {
                /* MASTER: run test suite */
                M6_MASTER_Run(&s_master, dt);
            }

            printTimer += dt;
        }

        /* Polling policy:
         * - MASTER always polls to receive responses.
         * - DUT polls only when not paused (to intentionally cause overflow during test).
         */
        if (M6_NODE_ROLE == 0u)
        {
            (void)UFS_Poll(&s_ufs);
        }
        else
        {
            if (!M6_DUT_IsPaused(&s_dut))
            {
                (void)UFS_Poll(&s_ufs);
            }
        }

        /* Periodic DUT status print (non-critical) */
        if ((M6_NODE_ROLE == 1u) && (printTimer >= 1000u))
        {
            printTimer -= 1000u;
            airdata_snapshot_t snap;
            AirData_GetSnapshot(&s_air, &snap);

            PRINTF("DUT: ALT=%s %luft IAS=%s %lukt LED=%u Jit(cnt=%lu min=%lu max=%lu avg=%lu)\r\n",
                   snap.altValid ? "OK" : "--",
                   (unsigned long)snap.altitude_ft,
                   snap.iasValid ? "OK" : "--",
                   (unsigned long)snap.ias_kt,
                   snap.activityLedOn ? 1u : 0u,
                   (unsigned long)s_jitter.count,
                   (unsigned long)((s_jitter.count==0u)?0u:s_jitter.minMs),
                   (unsigned long)((s_jitter.count==0u)?0u:s_jitter.maxMs),
                   (unsigned long)JITTER_AvgMs(&s_jitter));
        }
    }
}
