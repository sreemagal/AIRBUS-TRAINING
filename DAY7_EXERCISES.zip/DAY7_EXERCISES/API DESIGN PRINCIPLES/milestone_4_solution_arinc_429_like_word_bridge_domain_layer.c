/******************************************************************************
 * Milestone 4 (Solution)
 * Domain Layer: ARINC-429-like Word Bridge (simulated)
 *
 * This module sits ABOVE the framed UART service (Milestone 3) and BELOW the
 * application logic (Milestone 5). It converts framed UART payloads into
 * 32-bit "ARINC-like" words, validates parity/SSM rules, and supports a
 * deterministic periodic scheduler driven by a 1ms tick (Milestone 2).
 *
 * Target: EVKB-IMXRT1050 (i.MX RT1050) using MCUXpresso SDK
 *
 * Dependencies:
 *   - uart_framed_service.h/.c (Milestone 3)
 *   - tick_1ms.h/.c (Milestone 2) for dt-ms scheduler drive (optional but recommended)
 *
 * Recommended baseline project:
 *   boards/evkbimxrt1050/driver_examples/lpuart/interrupt_transfer
 *   + add PIT tick_1ms module (from Milestone 2)
 *
 * Payload protocol used on top of UFS frames for this milestone:
 *   PAYLOAD[0] = MSG_TYPE
 *   If MSG_TYPE == A429B_MSG_WORD (0xA1):
 *       PAYLOAD[1..4] = 32-bit word, little-endian (LSB first)
 *       LEN must be 5
 *
 * Notes:
 * - This is a simulated ARINC-429 abstraction (no electrical-level bus timing).
 * - Parity used here is EVEN parity across bits [30:0] with parity bit at [31].
 ******************************************************************************/

/******************************************************************************
 * File: arinc429_bridge.h
 ******************************************************************************/
#ifndef ARINC429_BRIDGE_H_
#define ARINC429_BRIDGE_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"            /* status_t */
#include "uart_framed_service.h"  /* ufs_t */

/* Versioning */
#define A429B_VERSION_MAJOR (1u)
#define A429B_VERSION_MINOR (0u)
#define A429B_VERSION_PATCH (0u)

/* Message type carried inside UFS frame payload */
#define A429B_MSG_WORD (0xA1u)

#ifndef A429B_MAX_SCHEDULED
#define A429B_MAX_SCHEDULED (8u)
#endif

/*
 * Simplified ARINC-429-like word layout (as per the lab specification):
 *  Bits [7:0]   = Label
 *  Bits [9:8]   = SDI
 *  Bits [28:10] = Data (19 bits)
 *  Bits [30:29] = SSM (2 bits)
 *  Bit  [31]    = Parity (even parity across bits [30:0])
 */

typedef enum
{
    A429B_SSM_NORMAL_OPERATION = 0u, /* 00 */
    A429B_SSM_NO_COMPUTED_DATA = 1u, /* 01 */
    A429B_SSM_FUNCTIONAL_TEST  = 2u, /* 10 */
    A429B_SSM_FAILURE_WARNING  = 3u  /* 11 */
} a429b_ssm_t;

typedef struct
{
    uint8_t label;   /* [7:0] */
    uint8_t sdi;     /* [9:8]  (0..3) */
    uint32_t data;   /* [28:10] (0..2^19-1) */
    a429b_ssm_t ssm; /* [30:29] */
    bool parity;     /* [31] parity bit (even parity across bits 0..30) */
} a429b_word_fields_t;

typedef enum
{
    A429B_WORD_VALID = 0,
    A429B_WORD_INVALID_PARITY,
    A429B_WORD_INVALID_SSM,
    A429B_WORD_INVALID_FORMAT
} a429b_word_validity_t;

/* User callback: invoked from A429B_Poll() context (main), never from ISR. */
typedef void (*a429b_word_cb_t)(uint32_t rawWord,
                               const a429b_word_fields_t *fields,
                               a429b_word_validity_t validity,
                               void *userData);

/* Diagnostic counters */
typedef struct
{
    uint32_t wordsRx;
    uint32_t wordsTx;
    uint32_t rxParityErrors;
    uint32_t rxSsmErrors;
    uint32_t rxFormatErrors;

    uint32_t schedEntriesActive;
    uint32_t schedTxBusyDrops;
    uint32_t schedTxErrors;
} a429b_stats_t;

/* Scheduler entry */
typedef struct
{
    bool enabled;
    uint32_t periodMs; /* period > 0 */
    uint32_t dueMs;    /* countdown to next send */
    uint32_t word;     /* packed 32-bit raw word */
} a429b_sched_entry_t;

/* Bridge instance */
typedef struct
{
    ufs_t *ufs; /* Underlying framed UART service */

    /* Word delivery */
    a429b_word_cb_t onWord;
    void *onWordUserData;

    /* Scheduler */
    a429b_sched_entry_t sched[A429B_MAX_SCHEDULED];

    /* Diagnostics */
    a429b_stats_t stats;

    bool isInitialized;
} a429b_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize the ARINC-like bridge.
 *
 * @param bridge Bridge instance.
 * @param ufs    Pointer to already-initialized UFS service.
 * @param cb     Word callback (may be NULL if you only want scheduling/TX).
 * @param userData Cookie passed back in callback.
 *
 * @pre bridge != NULL
 * @pre ufs != NULL
 * @pre UFS has been initialized with rxCb set to A429B internal hook (see A429B_AttachToUfs()).
 *
 * @post bridge is ready for scheduling and for processing received frames.
 */
status_t A429B_Init(a429b_t *bridge, ufs_t *ufs, a429b_word_cb_t cb, void *userData);

/*
 * @brief Attach bridge as the RX callback target of UFS.
 *
 * Rationale:
 * - UFS invokes rxCb only from UFS_Poll() (main context), so the bridge will also
 *   run in main context.
 *
 * Usage:
 *   - Call UFS_Init(... rxCb = A429B_UfsRxHook, rxCbUserData = bridge ...)
 *   - Then call A429B_Init(bridge,...)
 */
void A429B_UfsRxHook(const uint8_t *payload, uint8_t len, void *userData);

/*
 * @brief Poll bridge: drives underlying UFS parsing and processes any delivered frames.
 *
 * @return number of valid word callbacks invoked during this call.
 */
uint32_t A429B_Poll(a429b_t *bridge);

/*
 * @brief Drive scheduler with elapsed time in milliseconds.
 *
 * Determinism policy:
 * - "Skip" catch-up: if dt is large, we send at most one instance per entry per call.
 * - If TX is busy, we retry shortly (dueMs set to 1).
 */
void A429B_OnTickMs(a429b_t *bridge, uint32_t dtMs);

/*
 * @brief Immediately transmit a raw 32-bit word.
 *
 * @param bridge Bridge instance.
 * @param rawWord Packed 32-bit word.
 * @param ensureEvenParity If true, parity bit [31] will be corrected before sending.
 */
status_t A429B_SendWord(a429b_t *bridge, uint32_t rawWord, bool ensureEvenParity);

/*
 * @brief Schedule a periodic word transmit.
 *
 * @param slot Index 0..A429B_MAX_SCHEDULED-1
 * @param rawWord Packed word
 * @param periodMs Period in ms (>0)
 */
status_t A429B_ScheduleWord(a429b_t *bridge, uint32_t slot, uint32_t rawWord, uint32_t periodMs);

/* Disable a scheduled entry. */
status_t A429B_UnscheduleWord(a429b_t *bridge, uint32_t slot);

/* Helpers: pack/unpack and validity checks */
status_t A429B_PackWord(const a429b_word_fields_t *fields, uint32_t *outRawWord);
status_t A429B_UnpackWord(uint32_t rawWord, a429b_word_fields_t *outFields);

bool A429B_IsEvenParityValid(uint32_t rawWord);
uint32_t A429B_SetEvenParity(uint32_t rawWord);

/* Stats */
void A429B_GetStats(const a429b_t *bridge, a429b_stats_t *outStats);
void A429B_ResetStats(a429b_t *bridge);

#ifdef __cplusplus
}
#endif

#endif /* ARINC429_BRIDGE_H_ */

/******************************************************************************
 * File: arinc429_bridge.c
 ******************************************************************************/
#include "arinc429_bridge.h"

/* ---------------- Parity utilities ---------------- */

static inline uint32_t A429B_Popcount32(uint32_t x)
{
    /* Portable popcount (fast enough for lab). */
    uint32_t c = 0u;
    while (x != 0u)
    {
        c += (x & 1u);
        x >>= 1u;
    }
    return c;
}

bool A429B_IsEvenParityValid(uint32_t rawWord)
{
    /* Even parity across full 32 bits means total ones count is even. */
    const uint32_t ones = A429B_Popcount32(rawWord);
    return ((ones % 2u) == 0u);
}

uint32_t A429B_SetEvenParity(uint32_t rawWord)
{
    /* Compute parity bit for bits[30:0] such that total ones across [31:0] is even. */
    const uint32_t lower = rawWord & 0x7FFFFFFFu; /* bits 0..30 */
    const uint32_t onesLower = A429B_Popcount32(lower);

    const uint32_t parityBit = (onesLower % 2u); /* if odd -> set 1 to make total even */

    rawWord &= 0x7FFFFFFFu;
    rawWord |= (parityBit << 31);
    return rawWord;
}

/* ---------------- Pack / Unpack ---------------- */

status_t A429B_PackWord(const a429b_word_fields_t *fields, uint32_t *outRawWord)
{
    if ((fields == NULL) || (outRawWord == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (fields->sdi > 3u)
    {
        return kStatus_OutOfRange;
    }

    if (fields->data > ((1u << 19) - 1u))
    {
        return kStatus_OutOfRange;
    }

    if ((uint32_t)fields->ssm > 3u)
    {
        return kStatus_OutOfRange;
    }

    uint32_t w = 0u;
    w |= (uint32_t)fields->label;
    w |= ((uint32_t)fields->sdi & 0x3u) << 8;
    w |= ((uint32_t)fields->data & 0x7FFFFu) << 10;
    w |= ((uint32_t)fields->ssm & 0x3u) << 29;

    /* parity bit is stored explicitly; caller may later choose to enforce even parity */
    if (fields->parity)
    {
        w |= (1u << 31);
    }

    *outRawWord = w;
    return kStatus_Success;
}

status_t A429B_UnpackWord(uint32_t rawWord, a429b_word_fields_t *outFields)
{
    if (outFields == NULL)
    {
        return kStatus_InvalidArgument;
    }

    outFields->label  = (uint8_t)(rawWord & 0xFFu);
    outFields->sdi    = (uint8_t)((rawWord >> 8) & 0x3u);
    outFields->data   = (uint32_t)((rawWord >> 10) & 0x7FFFFu);
    outFields->ssm    = (a429b_ssm_t)((rawWord >> 29) & 0x3u);
    outFields->parity = (((rawWord >> 31) & 0x1u) != 0u);

    return kStatus_Success;
}

/* ---------------- SSM policy (simplified) ---------------- */

static bool A429B_IsSsmValid(a429b_ssm_t ssm)
{
    /* For this lab, treat NORMAL and FUNCTIONAL_TEST as valid; others invalid. */
    return (ssm == A429B_SSM_NORMAL_OPERATION) || (ssm == A429B_SSM_FUNCTIONAL_TEST);
}

/* ---------------- Bridge core ---------------- */

static void A429B_InternalReset(a429b_t *bridge)
{
    for (uint32_t i = 0; i < A429B_MAX_SCHEDULED; i++)
    {
        bridge->sched[i].enabled = false;
        bridge->sched[i].periodMs = 0u;
        bridge->sched[i].dueMs = 0u;
        bridge->sched[i].word = 0u;
    }

    A429B_ResetStats(bridge);
}

status_t A429B_Init(a429b_t *bridge, ufs_t *ufs, a429b_word_cb_t cb, void *userData)
{
    if ((bridge == NULL) || (ufs == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (bridge->isInitialized)
    {
        /* Idempotence: same UFS pointer only */
        return (bridge->ufs == ufs) ? kStatus_Success : kStatus_Fail;
    }

    bridge->ufs = ufs;
    bridge->onWord = cb;
    bridge->onWordUserData = userData;

    A429B_InternalReset(bridge);

    bridge->isInitialized = true;
    return kStatus_Success;
}

/*
 * UFS RX hook:
 * - Called from UFS_Poll() context (main), NOT from ISR.
 * - Decodes payloads and delivers word callback.
 */
void A429B_UfsRxHook(const uint8_t *payload, uint8_t len, void *userData)
{
    a429b_t *bridge = (a429b_t *)userData;
    if ((bridge == NULL) || (!bridge->isInitialized) || (payload == NULL))
    {
        return;
    }

    if (len < 1u)
    {
        bridge->stats.rxFormatErrors++;
        return;
    }

    const uint8_t msgType = payload[0];
    if (msgType != A429B_MSG_WORD)
    {
        /* For this milestone, ignore unknown message types. */
        return;
    }

    /* Must be exactly 5 bytes: type + 4 bytes word */
    if (len != 5u)
    {
        bridge->stats.rxFormatErrors++;
        if (bridge->onWord != NULL)
        {
            a429b_word_fields_t dummy;
            (void)A429B_UnpackWord(0u, &dummy);
            bridge->onWord(0u, &dummy, A429B_WORD_INVALID_FORMAT, bridge->onWordUserData);
        }
        return;
    }

    /* Little-endian word assembly */
    const uint32_t rawWord = ((uint32_t)payload[1]) |
                             ((uint32_t)payload[2] << 8) |
                             ((uint32_t)payload[3] << 16) |
                             ((uint32_t)payload[4] << 24);

    bridge->stats.wordsRx++;

    a429b_word_fields_t f;
    (void)A429B_UnpackWord(rawWord, &f);

    a429b_word_validity_t validity = A429B_WORD_VALID;

    /* Validate parity */
    if (!A429B_IsEvenParityValid(rawWord))
    {
        validity = A429B_WORD_INVALID_PARITY;
        bridge->stats.rxParityErrors++;
    }

    /* Validate SSM (only if parity passed; you may choose to check regardless) */
    if ((validity == A429B_WORD_VALID) && (!A429B_IsSsmValid(f.ssm)))
    {
        validity = A429B_WORD_INVALID_SSM;
        bridge->stats.rxSsmErrors++;
    }

    if (bridge->onWord != NULL)
    {
        bridge->onWord(rawWord, &f, validity, bridge->onWordUserData);
    }
}

uint32_t A429B_Poll(a429b_t *bridge)
{
    if ((bridge == NULL) || (!bridge->isInitialized) || (bridge->ufs == NULL))
    {
        return 0u;
    }

    /*
     * We rely on UFS invoking our A429B_UfsRxHook for each received frame.
     * We return an approximate number: UFS_Poll returns frames dispatched; here we
     * count word callbacks indirectly is not tracked. For simplicity, return UFS frames.
     */
    return UFS_Poll(bridge->ufs);
}

status_t A429B_SendWord(a429b_t *bridge, uint32_t rawWord, bool ensureEvenParity)
{
    if ((bridge == NULL) || (!bridge->isInitialized) || (bridge->ufs == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (ensureEvenParity)
    {
        rawWord = A429B_SetEvenParity(rawWord);
    }

    uint8_t payload[5];
    payload[0] = A429B_MSG_WORD;
    payload[1] = (uint8_t)(rawWord & 0xFFu);
    payload[2] = (uint8_t)((rawWord >> 8) & 0xFFu);
    payload[3] = (uint8_t)((rawWord >> 16) & 0xFFu);
    payload[4] = (uint8_t)((rawWord >> 24) & 0xFFu);

    const status_t st = UFS_SendFrame(bridge->ufs, payload, (uint8_t)sizeof(payload));
    if (st == kStatus_Success)
    {
        bridge->stats.wordsTx++;
    }

    return st;
}

status_t A429B_ScheduleWord(a429b_t *bridge, uint32_t slot, uint32_t rawWord, uint32_t periodMs)
{
    if ((bridge == NULL) || (!bridge->isInitialized))
    {
        return kStatus_InvalidArgument;
    }

    if (slot >= A429B_MAX_SCHEDULED)
    {
        return kStatus_OutOfRange;
    }

    if (periodMs == 0u)
    {
        return kStatus_OutOfRange;
    }

    bridge->sched[slot].enabled = true;
    bridge->sched[slot].periodMs = periodMs;
    bridge->sched[slot].dueMs = periodMs; /* first send after one period */
    bridge->sched[slot].word = rawWord;

    return kStatus_Success;
}

status_t A429B_UnscheduleWord(a429b_t *bridge, uint32_t slot)
{
    if ((bridge == NULL) || (!bridge->isInitialized))
    {
        return kStatus_InvalidArgument;
    }

    if (slot >= A429B_MAX_SCHEDULED)
    {
        return kStatus_OutOfRange;
    }

    bridge->sched[slot].enabled = false;
    bridge->sched[slot].periodMs = 0u;
    bridge->sched[slot].dueMs = 0u;
    bridge->sched[slot].word = 0u;

    return kStatus_Success;
}

void A429B_OnTickMs(a429b_t *bridge, uint32_t dtMs)
{
    if ((bridge == NULL) || (!bridge->isInitialized) || (bridge->ufs == NULL))
    {
        return;
    }

    /* Skip policy: at most one send per entry per call. */
    for (uint32_t i = 0; i < A429B_MAX_SCHEDULED; i++)
    {
        if (!bridge->sched[i].enabled)
        {
            continue;
        }

        /* Update due timer */
        if (bridge->sched[i].dueMs > dtMs)
        {
            bridge->sched[i].dueMs -= dtMs;
            continue;
        }

        /* Due now */
        bridge->sched[i].dueMs = 0u;

        /* Attempt to send */
        const status_t st = A429B_SendWord(bridge, bridge->sched[i].word, true);
        if (st == kStatus_Success)
        {
            bridge->sched[i].dueMs = bridge->sched[i].periodMs;
        }
        else if (st == kStatus_LPUART_TxBusy)
        {
            /* Back-pressure: retry soon (1ms). */
            bridge->stats.schedTxBusyDrops++;
            bridge->sched[i].dueMs = 1u;
        }
        else
        {
            /* Other TX errors: retry after full period. */
            bridge->stats.schedTxErrors++;
            bridge->sched[i].dueMs = bridge->sched[i].periodMs;
        }
    }

    /* Update active count */
    uint32_t active = 0u;
    for (uint32_t i = 0; i < A429B_MAX_SCHEDULED; i++)
    {
        if (bridge->sched[i].enabled)
        {
            active++;
        }
    }
    bridge->stats.schedEntriesActive = active;
}

void A429B_GetStats(const a429b_t *bridge, a429b_stats_t *outStats)
{
    if ((bridge == NULL) || (outStats == NULL))
    {
        return;
    }

    *outStats = bridge->stats;
}

void A429B_ResetStats(a429b_t *bridge)
{
    if (bridge == NULL)
    {
        return;
    }

    bridge->stats.wordsRx = 0u;
    bridge->stats.wordsTx = 0u;
    bridge->stats.rxParityErrors = 0u;
    bridge->stats.rxSsmErrors = 0u;
    bridge->stats.rxFormatErrors = 0u;
    bridge->stats.schedEntriesActive = 0u;
    bridge->stats.schedTxBusyDrops = 0u;
    bridge->stats.schedTxErrors = 0u;
}

/******************************************************************************
 * File: milestone4_demo_main.c
 * Demo showing:
 *  - UFS framed UART service
 *  - A429B bridge decoding/validating words
 *  - Periodic scheduler driven by 1ms tick
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* from imported LPUART example: DEMO_LPUART, DEMO_LPUART_CLK_FREQ */
#include "fsl_debug_console.h"
#include "fsl_clock.h"          /* CLOCK_GetFreq */

#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "tick_1ms.h"

/* If you also imported PIT example, these macros are typically present in its app.h.
 * For a combined project, you may need to define them yourself or merge app.h files.
 */
#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

static void Demo_OnWord(uint32_t rawWord,
                        const a429b_word_fields_t *fields,
                        a429b_word_validity_t validity,
                        void *userData)
{
    (void)userData;

    /* Keep callback lightweight; it runs in main context but should still be bounded. */
    if (validity == A429B_WORD_VALID)
    {
        PRINTF("WORD OK: label=%u sdi=%u data=%lu ssm=%u raw=0x%08lX\r\n",
               fields->label,
               fields->sdi,
               (unsigned long)fields->data,
               (unsigned)fields->ssm,
               (unsigned long)rawWord);
    }
    else
    {
        PRINTF("WORD BAD(%u): raw=0x%08lX\r\n", (unsigned)validity, (unsigned long)rawWord);
    }
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 4: ARINC-like Word Bridge + Scheduler demo\r\n");

    /* 1) Start 1ms tick (PIT) */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };

    if (TICK_Init(&tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("TICK_Init failed\r\n");
        while (1) {}
    }

    /* 2) Initialize UFS (framed UART service)
     * IMPORTANT: set rxCb to A429B_UfsRxHook and userData to the bridge instance.
     */
    ufs_t ufs = {0};
    a429b_t bridge = {0};

    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 128u,
        .rxCb = A429B_UfsRxHook,
        .rxCbUserData = &bridge,
    };

    if (UFS_Init(&ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("UFS_Init failed\r\n");
        while (1) {}
    }

    /* 3) Initialize bridge */
    if (A429B_Init(&bridge, &ufs, Demo_OnWord, NULL) != kStatus_Success)
    {
        PRINTF("A429B_Init failed\r\n");
        while (1) {}
    }

    /* 4) Create two example words and schedule them periodically
     * Label 203 and 204 are arbitrary in this demo; interpret them in Milestone 5.
     */
    a429b_word_fields_t w1 = {
        .label = 203u,
        .sdi = 0u,
        .data = 1000u,
        .ssm = A429B_SSM_NORMAL_OPERATION,
        .parity = false,
    };

    a429b_word_fields_t w2 = {
        .label = 204u,
        .sdi = 0u,
        .data = 250u,
        .ssm = A429B_SSM_NORMAL_OPERATION,
        .parity = false,
    };

    uint32_t raw1 = 0u;
    uint32_t raw2 = 0u;
    (void)A429B_PackWord(&w1, &raw1);
    (void)A429B_PackWord(&w2, &raw2);

    /* Ensure parity is correct before scheduling */
    raw1 = A429B_SetEvenParity(raw1);
    raw2 = A429B_SetEvenParity(raw2);

    (void)A429B_ScheduleWord(&bridge, 0u, raw1, 100u); /* every 100ms */
    (void)A429B_ScheduleWord(&bridge, 1u, raw2, 200u); /* every 200ms */

    PRINTF("Connect two EVKB boards via UART (TX<->RX, GND). Flash same demo on both.\r\n");

    /* Main loop */
    uint32_t last = TICK_GetMs(&tick);
    uint32_t statsTimer = 0u;

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
        if (dt != 0u)
        {
            A429B_OnTickMs(&bridge, dt);
            statsTimer += dt;
        }

        /* Drive UART parsing and bridge RX decoding */
        (void)A429B_Poll(&bridge);

        /* Periodically print bridge + UFS stats */
        if (statsTimer >= 1000u)
        {
            statsTimer -= 1000u;

            a429b_stats_t bs;
            ufs_stats_t us;
            A429B_GetStats(&bridge, &bs);
            UFS_GetStats(&ufs, &us);

            PRINTF("A429B: rx=%lu tx=%lu pErr=%lu ssmErr=%lu fmtErr=%lu schedActive=%lu\r\n",
                   (unsigned long)bs.wordsRx,
                   (unsigned long)bs.wordsTx,
                   (unsigned long)bs.rxParityErrors,
                   (unsigned long)bs.rxSsmErrors,
                   (unsigned long)bs.rxFormatErrors,
                   (unsigned long)bs.schedEntriesActive);

            PRINTF("UFS: rxOk=%lu csumErr=%lu lenErr=%lu ovf=%lu txReq=%lu txDone=%lu\r\n",
                   (unsigned long)us.rxFramesOk,
                   (unsigned long)us.rxChecksumErrors,
                   (unsigned long)us.rxLengthErrors,
                   (unsigned long)us.rxRingOverflows,
                   (unsigned long)us.txFramesRequested,
                   (unsigned long)us.txFramesDone);
        }
    }
}
