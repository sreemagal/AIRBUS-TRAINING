/******************************************************************************
 * Milestone 3 (Solution)
 * Framed UART Transport Service (UFS) using LPUART interrupt transfer
 * Target: NXP i.MX RT1050 EVKB (EVKB-IMXRT1050) using MCUXpresso SDK
 *
 * Frame format (fixed for this milestone):
 *   START(0x55) | LEN(1 byte) | PAYLOAD(LEN bytes) | CHECKSUM(1 byte)
 *
 * Checksum (8-bit two's complement):
 *   checksum = (uint8_t)(0u - (LEN + sum(PAYLOAD bytes)))
 *   Valid if (LEN + sum(PAYLOAD) + CHECKSUM) == 0 (mod 256)
 *
 * Key design rules implemented:
 * - No application callbacks from ISR.
 * - ISR is constant-time: enqueue received byte, re-arm 1-byte receive.
 * - Main loop calls UFS_Poll() to parse frames and dispatch callbacks.
 * - Non-blocking TX with explicit busy/back-pressure.
 * - Explicit, readable diagnostics counters.
 *
 * Recommended project baseline (MCUXpresso import):
 *   boards/evkbimxrt1050/driver_examples/lpuart/interrupt_transfer
 *
 * Integration steps:
 *   1) Import the LPUART interrupt_transfer example.
 *   2) Add the new files below to the project:
 *        - uart_framed_service.h
 *        - uart_framed_service.c
 *   3) Replace the example's lpuart_interrupt_transfer.c with the demo main below
 *      (or create a new main file and exclude the original).
 *   4) Build + flash.
 ******************************************************************************/

/******************************************************************************
 * File: uart_framed_service.h
 ******************************************************************************/
#ifndef UART_FRAMED_SERVICE_H_
#define UART_FRAMED_SERVICE_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "fsl_common.h"  /* status_t */
#include "fsl_lpuart.h"  /* LPUART transfer APIs */

/* Versioning */
#define UFS_VERSION_MAJOR (1u)
#define UFS_VERSION_MINOR (0u)
#define UFS_VERSION_PATCH (0u)

/* Constants for framing */
#define UFS_FRAME_START_BYTE (0x55u)

/*
 * Configure budgets explicitly (avionics mindset: bounded memory and time).
 * These can be overridden per project.
 */
#ifndef UFS_MAX_PAYLOAD
#define UFS_MAX_PAYLOAD (64u) /* max LEN supported by this service */
#endif

#ifndef UFS_RX_RING_SIZE
#define UFS_RX_RING_SIZE (256u) /* must be > (UFS_MAX_PAYLOAD + 3) to tolerate bursts */
#endif

/* Diagnostics counters: deterministic, monotonic, resettable. */
typedef struct
{
    uint32_t rxBytesEnqueued;   /* bytes accepted into RX ring from ISR */
    uint32_t rxRingOverflows;   /* bytes dropped because RX ring was full */
    uint32_t rxFramesOk;        /* valid frames delivered to application */
    uint32_t rxChecksumErrors;  /* frames rejected due to checksum mismatch */
    uint32_t rxLengthErrors;    /* frames rejected due to LEN > UFS_MAX_PAYLOAD */
    uint32_t rxFramingResyncs;  /* times parser re-synchronized to START byte */

    uint32_t txFramesRequested; /* send requests accepted (queued to HW) */
    uint32_t txFramesDone;      /* TX completion events (from ISR) */

    status_t lastRxDriverStatus; /* last non-idle RX status from LPUART ISR callback */
    status_t lastTxDriverStatus; /* last non-idle TX status from LPUART ISR callback */
} ufs_stats_t;

/*
 * RX callback type
 * Called ONLY from UFS_Poll() in main context.
 *
 * @param payload Pointer to a UFS-owned buffer valid only during the callback.
 * @param len     Payload length in bytes (0..UFS_MAX_PAYLOAD).
 * @param userData User cookie.
 */
typedef void (*ufs_rx_frame_cb_t)(const uint8_t *payload, uint8_t len, void *userData);

/* Service configuration */
typedef struct
{
    LPUART_Type *base;      /* e.g., DEMO_LPUART */
    uint32_t srcClockHz;    /* LPUART source clock */
    uint32_t baudRate;      /* e.g., 115200 */

    /* Optional: if you want the service to initialize the peripheral.
     * If false, caller must have already called LPUART_Init() with matching settings.
     */
    bool initPeripheral;

    /* Parser work bound per poll: limits how many RX bytes are consumed each call.
     * This keeps the Poll() time bounded for deterministic applications.
     */
    uint32_t maxBytesPerPoll;

    /* RX frame callback delivered from Poll() */
    ufs_rx_frame_cb_t rxCb;
    void *rxCbUserData;
} ufs_config_t;

/* Service instance */
typedef struct
{
    /* Hardware */
    LPUART_Type *base;
    lpuart_handle_t drvHandle;

    /* Single-byte RX transfer reused continuously */
    uint8_t isrRxByte;
    lpuart_transfer_t isrRxXfer;

    /* TX buffer for an entire framed message (START + LEN + PAYLOAD + CHECKSUM) */
    uint8_t txFrameBuf[UFS_MAX_PAYLOAD + 3u];
    lpuart_transfer_t txXfer;
    volatile bool txBusy;

    /* RX ring buffer (SPSC: ISR producer, main consumer) */
    uint8_t rxRing[UFS_RX_RING_SIZE];
    volatile uint16_t rxHead; /* written by ISR */
    volatile uint16_t rxTail; /* written by main */

    /* Frame parser state (main context only) */
    enum
    {
        UFS_PARSER_WAIT_START = 0,
        UFS_PARSER_WAIT_LEN,
        UFS_PARSER_WAIT_PAYLOAD,
        UFS_PARSER_WAIT_CHECKSUM
    } parserState;

    uint8_t curLen;
    uint8_t curIdx;
    uint8_t curPayload[UFS_MAX_PAYLOAD];
    uint8_t checksumAccum; /* accumulates LEN + payload sum */

    /* Configuration */
    uint32_t maxBytesPerPoll;
    ufs_rx_frame_cb_t rxCb;
    void *rxCbUserData;

    /* Diagnostics */
    ufs_stats_t stats;

    bool isInitialized;
} ufs_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize framed UART service.
 *
 * @pre svc != NULL
 * @pre cfg != NULL
 * @pre cfg->base != NULL
 * @pre cfg->srcClockHz != 0
 * @pre cfg->baudRate != 0
 * @pre Pin mux and clocks already configured by BOARD_InitHardware().
 *
 * @post Service is ready, RX is armed for continuous receive.
 *
 * Idempotence:
 * - Calling again with the same base and baudRate returns kStatus_Success.
 * - Calling with different settings on an initialized instance returns kStatus_Fail.
 */
status_t UFS_Init(ufs_t *svc, const ufs_config_t *cfg);

/*
 * @brief Non-blocking send of a payload as a framed message.
 *
 * @param svc Service instance.
 * @param payload Payload bytes (may be NULL if len == 0).
 * @param len Payload length (0..UFS_MAX_PAYLOAD).
 *
 * @retval kStatus_Success        Frame accepted and queued to the UART driver.
 * @retval kStatus_LPUART_TxBusy  Service is currently transmitting a previous frame.
 * @retval kStatus_InvalidArgument Bad pointer/length.
 *
 * Ownership/lifetime:
 * - Payload is copied into an internal buffer immediately.
 * - Caller may reuse/modify payload after UFS_SendFrame returns.
 */
status_t UFS_SendFrame(ufs_t *svc, const uint8_t *payload, uint8_t len);

/*
 * @brief Poll function: drains RX bytes (bounded), parses frames, dispatches callbacks.
 *
 * @param svc Service instance.
 *
 * @return Number of valid frames dispatched to the rx callback during this poll.
 *
 * Determinism:
 * - Work is bounded by cfg->maxBytesPerPoll.
 * - No dynamic allocation.
 */
uint32_t UFS_Poll(ufs_t *svc);

/* @brief Get a snapshot of diagnostic counters. */
void UFS_GetStats(const ufs_t *svc, ufs_stats_t *outStats);

/* @brief Reset diagnostic counters (service remains running). */
void UFS_ResetStats(ufs_t *svc);

/* @brief Returns whether TX is currently busy. */
bool UFS_IsTxBusy(const ufs_t *svc);

#ifdef __cplusplus
}
#endif

#endif /* UART_FRAMED_SERVICE_H_ */

/******************************************************************************
 * File: uart_framed_service.c
 ******************************************************************************/
#include "uart_framed_service.h"

/*
 * Forward declaration for the LPUART callback.
 * This is invoked from ISR context by the driver.
 */
static void UFS_LpuartCallback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData);

/* ---- Small ring-buffer helpers (SPSC: ISR producer, main consumer) ---- */

static inline uint16_t UFS_RingNext(uint16_t idx)
{
    /* Modulo ring size (must fit into uint16_t). */
    return (uint16_t)((idx + 1u) % (uint16_t)UFS_RX_RING_SIZE);
}

static bool UFS_RingPushFromIsr(ufs_t *svc, uint8_t b)
{
    /* Producer (ISR) updates head only. */
    const uint16_t head = svc->rxHead;
    const uint16_t next = UFS_RingNext(head);

    if (next == svc->rxTail)
    {
        /* Full: drop newest (documented policy for this milestone). */
        svc->stats.rxRingOverflows++;
        return false;
    }

    svc->rxRing[head] = b;
    svc->rxHead = next;

    svc->stats.rxBytesEnqueued++;
    return true;
}

static bool UFS_RingPopFromMain(ufs_t *svc, uint8_t *outByte)
{
    /* Consumer (main) updates tail only. */
    const uint16_t tail = svc->rxTail;
    if (tail == svc->rxHead)
    {
        return false; /* empty */
    }

    *outByte = svc->rxRing[tail];
    svc->rxTail = UFS_RingNext(tail);
    return true;
}

/* ---- Checksum helpers ---- */

static inline uint8_t UFS_ChecksumTwoComplement(uint8_t len, const uint8_t *payload)
{
    uint32_t sum = (uint32_t)len;
    for (uint32_t i = 0; i < len; i++)
    {
        sum += payload[i];
    }
    /* two's complement: (-sum) mod 256 */
    return (uint8_t)(0u - (uint8_t)sum);
}

static inline bool UFS_ChecksumIsValid(uint8_t len, const uint8_t *payload, uint8_t checksum)
{
    uint32_t sum = (uint32_t)len + checksum;
    for (uint32_t i = 0; i < len; i++)
    {
        sum += payload[i];
    }
    return (((uint8_t)sum) == 0u);
}

/* ---- Parser ---- */

static void UFS_ParserReset(ufs_t *svc)
{
    svc->parserState = UFS_PARSER_WAIT_START;
    svc->curLen = 0u;
    svc->curIdx = 0u;
    svc->checksumAccum = 0u;
}

static void UFS_ParserFeedByte(ufs_t *svc, uint8_t b, uint32_t *framesDispatched)
{
    switch (svc->parserState)
    {
        case UFS_PARSER_WAIT_START:
        {
            if (b == UFS_FRAME_START_BYTE)
            {
                svc->parserState = UFS_PARSER_WAIT_LEN;
                svc->checksumAccum = 0u;
            }
            else
            {
                /* ignore until start; count as resync attempt for observability */
                svc->stats.rxFramingResyncs++;
            }
            break;
        }

        case UFS_PARSER_WAIT_LEN:
        {
            svc->curLen = b;
            svc->curIdx = 0u;
            svc->checksumAccum = b; /* accum starts with LEN */

            if (svc->curLen > (uint8_t)UFS_MAX_PAYLOAD)
            {
                /* Length out of supported bound -> reject and resync */
                svc->stats.rxLengthErrors++;
                UFS_ParserReset(svc);
            }
            else
            {
                svc->parserState = (svc->curLen == 0u) ? UFS_PARSER_WAIT_CHECKSUM : UFS_PARSER_WAIT_PAYLOAD;
            }
            break;
        }

        case UFS_PARSER_WAIT_PAYLOAD:
        {
            /* curLen is already validated <= UFS_MAX_PAYLOAD */
            svc->curPayload[svc->curIdx++] = b;
            svc->checksumAccum = (uint8_t)(svc->checksumAccum + b);

            if (svc->curIdx >= svc->curLen)
            {
                svc->parserState = UFS_PARSER_WAIT_CHECKSUM;
            }
            break;
        }

        case UFS_PARSER_WAIT_CHECKSUM:
        {
            const uint8_t rxChecksum = b;
            const bool ok = UFS_ChecksumIsValid(svc->curLen, svc->curPayload, rxChecksum);

            if (ok)
            {
                svc->stats.rxFramesOk++;

                /* Dispatch callback from MAIN CONTEXT only (we are in Poll()) */
                if (svc->rxCb != NULL)
                {
                    svc->rxCb(svc->curPayload, svc->curLen, svc->rxCbUserData);
                }

                (*framesDispatched)++;
            }
            else
            {
                svc->stats.rxChecksumErrors++;
            }

            /* Always reset after checksum */
            UFS_ParserReset(svc);
            break;
        }

        default:
            UFS_ParserReset(svc);
            break;
    }
}

/* ---- Public API ---- */

status_t UFS_Init(ufs_t *svc, const ufs_config_t *cfg)
{
    if ((svc == NULL) || (cfg == NULL) || (cfg->base == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if ((cfg->srcClockHz == 0u) || (cfg->baudRate == 0u))
    {
        return kStatus_InvalidArgument;
    }

    /* Default maxBytesPerPoll if caller passes 0. */
    const uint32_t maxBytes = (cfg->maxBytesPerPoll == 0u) ? 64u : cfg->maxBytesPerPoll;

    /* Enforce idempotence for the same instance. */
    if (svc->isInitialized)
    {
        const bool same = (svc->base == cfg->base);
        return same ? kStatus_Success : kStatus_Fail;
    }

    /* Initialize fields */
    svc->base = cfg->base;
    svc->rxHead = 0u;
    svc->rxTail = 0u;
    svc->txBusy = false;

    svc->maxBytesPerPoll = maxBytes;
    svc->rxCb = cfg->rxCb;
    svc->rxCbUserData = cfg->rxCbUserData;

    UFS_ResetStats(svc);
    UFS_ParserReset(svc);

    /* Optionally initialize the peripheral. Pin mux and clocks are assumed done by BOARD_InitHardware(). */
    if (cfg->initPeripheral)
    {
        lpuart_config_t lpuartCfg;
        LPUART_GetDefaultConfig(&lpuartCfg);
        lpuartCfg.baudRate_Bps = cfg->baudRate;
        lpuartCfg.enableTx = true;
        lpuartCfg.enableRx = true;

        status_t st = LPUART_Init(svc->base, &lpuartCfg, cfg->srcClockHz);
        if (st != kStatus_Success)
        {
            return st;
        }
    }

    /* Create transfer handle and register ISR callback */
    LPUART_TransferCreateHandle(svc->base, &svc->drvHandle, UFS_LpuartCallback, svc);

    /* Arm continuous 1-byte receive */
    svc->isrRxXfer.data = &svc->isrRxByte;
    svc->isrRxXfer.dataSize = 1u;

    (void)LPUART_TransferReceiveNonBlocking(svc->base, &svc->drvHandle, &svc->isrRxXfer, NULL);

    svc->isInitialized = true;
    return kStatus_Success;
}

status_t UFS_SendFrame(ufs_t *svc, const uint8_t *payload, uint8_t len)
{
    if (svc == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!svc->isInitialized)
    {
        return kStatus_Fail;
    }

    if (len > (uint8_t)UFS_MAX_PAYLOAD)
    {
        return kStatus_OutOfRange;
    }

    if ((len > 0u) && (payload == NULL))
    {
        return kStatus_InvalidArgument;
    }

    /* Back-pressure: one in-flight frame only */
    if (svc->txBusy)
    {
        return kStatus_LPUART_TxBusy;
    }

    /* Build frame into internal TX buffer */
    const uint8_t start = UFS_FRAME_START_BYTE;
    const uint8_t checksum = UFS_ChecksumTwoComplement(len, payload);

    uint32_t idx = 0u;
    svc->txFrameBuf[idx++] = start;
    svc->txFrameBuf[idx++] = len;
    for (uint32_t i = 0; i < len; i++)
    {
        svc->txFrameBuf[idx++] = payload[i];
    }
    svc->txFrameBuf[idx++] = checksum;

    svc->txXfer.data = svc->txFrameBuf;
    svc->txXfer.dataSize = idx;

    svc->txBusy = true;
    svc->stats.txFramesRequested++;

    /* Kick TX (non-blocking). Driver will invoke callback with kStatus_LPUART_TxIdle when done. */
    const status_t st = LPUART_TransferSendNonBlocking(svc->base, &svc->drvHandle, &svc->txXfer);
    if (st != kStatus_Success)
    {
        /* If driver rejects the send, clear busy and report status. */
        svc->txBusy = false;
        svc->stats.lastTxDriverStatus = st;
        return st;
    }

    return kStatus_Success;
}

uint32_t UFS_Poll(ufs_t *svc)
{
    if ((svc == NULL) || (!svc->isInitialized))
    {
        return 0u;
    }

    uint32_t framesDispatched = 0u;
    uint32_t bytesBudget = svc->maxBytesPerPoll;

    while (bytesBudget-- > 0u)
    {
        uint8_t b;
        if (!UFS_RingPopFromMain(svc, &b))
        {
            break; /* no more RX bytes */
        }

        UFS_ParserFeedByte(svc, b, &framesDispatched);
    }

    return framesDispatched;
}

void UFS_GetStats(const ufs_t *svc, ufs_stats_t *outStats)
{
    if ((svc == NULL) || (outStats == NULL))
    {
        return;
    }

    /* Snapshot copy; races are acceptable for diagnostics. */
    *outStats = svc->stats;
}

void UFS_ResetStats(ufs_t *svc)
{
    if (svc == NULL)
    {
        return;
    }

    /* Reset counters deterministically */
    svc->stats.rxBytesEnqueued = 0u;
    svc->stats.rxRingOverflows = 0u;
    svc->stats.rxFramesOk = 0u;
    svc->stats.rxChecksumErrors = 0u;
    svc->stats.rxLengthErrors = 0u;
    svc->stats.rxFramingResyncs = 0u;
    svc->stats.txFramesRequested = 0u;
    svc->stats.txFramesDone = 0u;
    svc->stats.lastRxDriverStatus = kStatus_Success;
    svc->stats.lastTxDriverStatus = kStatus_Success;
}

bool UFS_IsTxBusy(const ufs_t *svc)
{
    return (svc != NULL) ? svc->txBusy : false;
}

/* ---- LPUART ISR callback ---- */

static void UFS_LpuartCallback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    (void)base;
    (void)handle;

    ufs_t *svc = (ufs_t *)userData;
    if ((svc == NULL) || (!svc->isInitialized))
    {
        return;
    }

    /*
     * Driver sends status codes such as:
     *   kStatus_LPUART_RxIdle - our 1-byte RX transfer completed
     *   kStatus_LPUART_TxIdle - our TX transfer completed
     * and potentially error statuses.
     */

    if (status == kStatus_LPUART_RxIdle)
    {
        /* Enqueue the received byte into our RX ring (drop if overflow). */
        (void)UFS_RingPushFromIsr(svc, svc->isrRxByte);

        /* Re-arm next 1-byte receive immediately */
        (void)LPUART_TransferReceiveNonBlocking(svc->base, &svc->drvHandle, &svc->isrRxXfer, NULL);
    }
    else if (status == kStatus_LPUART_TxIdle)
    {
        svc->txBusy = false;
        svc->stats.txFramesDone++;
    }
    else
    {
        /* Record unexpected/driver error status for diagnostics (do not PRINTF from ISR). */
        if (status != kStatus_Success)
        {
            /* Heuristic: treat non-idle statuses as potentially meaningful. */
            svc->stats.lastRxDriverStatus = status;
            svc->stats.lastTxDriverStatus = status;
        }

        /* Attempt to keep RX alive even if errors occur. */
        (void)LPUART_TransferReceiveNonBlocking(svc->base, &svc->drvHandle, &svc->isrRxXfer, NULL);
    }
}

/******************************************************************************
 * File: lpuart_interrupt_transfer.c  (replace example main with this demo)
 ******************************************************************************/
#include "board.h"
#include "app.h"              /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, etc (from imported example) */
#include "fsl_debug_console.h"
#include "fsl_clock.h"        /* CLOCK_GetFreq */

#include "uart_framed_service.h"

/* Simple RX callback: prints received frame as hex, then echoes it back. */
static void Demo_OnFrame(const uint8_t *payload, uint8_t len, void *userData)
{
    (void)userData;

    PRINTF("RX frame len=%u payload=", len);
    for (uint32_t i = 0; i < len; i++)
    {
        PRINTF("%02X ", payload[i]);
    }
    PRINTF("\r\n");
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 3: Framed UART Service (UFS) demo\r\n");
    PRINTF("UFS version %u.%u.%u\r\n", UFS_VERSION_MAJOR, UFS_VERSION_MINOR, UFS_VERSION_PATCH);
    PRINTF("Frame: 0x55 | LEN | PAYLOAD | CHECKSUM(two's complement)\r\n");

    ufs_t svc = {0};
    const ufs_config_t cfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 128u,
        .rxCb = Demo_OnFrame,
        .rxCbUserData = NULL,
    };

    const status_t st = UFS_Init(&svc, &cfg);
    if (st != kStatus_Success)
    {
        PRINTF("UFS_Init failed: %ld\r\n", (long)st);
        while (1) { }
    }

    /* Transmit an initial frame */
    const uint8_t hello[] = { 'H','E','L','L','O' };
    (void)UFS_SendFrame(&svc, hello, (uint8_t)sizeof(hello));

    /* Main loop: poll parser + occasionally print stats */
    uint32_t lastPrint = 0u;
    while (1)
    {
        (void)UFS_Poll(&svc);

        /* Lightweight periodic stats (uses a crude loop counter; Milestone 2 tick is better) */
        lastPrint++;
        if (lastPrint >= 2000000u)
        {
            lastPrint = 0u;
            ufs_stats_t s;
            UFS_GetStats(&svc, &s);
            PRINTF("Stats: rxOk=%lu csumErr=%lu lenErr=%lu ovf=%lu txReq=%lu txDone=%lu\r\n",
                   (unsigned long)s.rxFramesOk,
                   (unsigned long)s.rxChecksumErrors,
                   (unsigned long)s.rxLengthErrors,
                   (unsigned long)s.rxRingOverflows,
                   (unsigned long)s.txFramesRequested,
                   (unsigned long)s.txFramesDone);
        }

        /*
         * In your multi-board setup:
         * - Connect TX/RX between two EVKB boards.
         * - Flash this demo on both.
         * - Each board will print received frames and send HELLO once.
         */
    }
}
