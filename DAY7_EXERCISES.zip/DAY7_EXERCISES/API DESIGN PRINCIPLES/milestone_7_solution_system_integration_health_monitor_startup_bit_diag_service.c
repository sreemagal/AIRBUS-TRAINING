/******************************************************************************
 * Milestone 7 (Solution)
 * System Integration Layer (SIL): Startup BIT + Health Monitor + Diagnostics Service
 *
 * Purpose of this milestone
 * -------------------------
 * 1) Integrate all layers into a single deterministic main-loop architecture:
 *      Tick (PIT 1ms) -> UFS (framed UART) -> A429B (domain) -> AirData (app)
 * 2) Provide a startup Built-In Test (BIT) and runtime health monitoring.
 * 3) Provide a simple diagnostic request/response protocol (maintenance-friendly):
 *      DIAG_REQ  -> DIAG_RSP  (includes build info + fault mask + key counters)
 * 4) Drive a fault LED pattern based on health state (OK/WARN/FAIL).
 *
 * Recommended baseline project (MCUXpresso import):
 *   boards/evkbimxrt1050/driver_examples/lpuart/interrupt_transfer
 * Then add milestone modules + this milestone modules.
 *
 * Wiring:
 *   For 2-board demo: wire UART TX<->RX and GND<->GND.
 *   Optionally, a third board can act as a maintenance console requesting DIAG.
 ******************************************************************************/

/******************************************************************************
 * File: m7_build_info.h
 ******************************************************************************/
#ifndef M7_BUILD_INFO_H_
#define M7_BUILD_INFO_H_

#include <stdint.h>

/* Firmware identity (edit to match your program naming) */
#define M7_FW_NAME "AIRBUS_BARE_METAL_LAB"

/* Semantic version (system-level) */
#define M7_FW_VERSION_MAJOR (0u)
#define M7_FW_VERSION_MINOR (7u)
#define M7_FW_VERSION_PATCH (0u)

/* Build metadata */
#define M7_BUILD_DATE __DATE__
#define M7_BUILD_TIME __TIME__

/* Toolchain string (best-effort) */
#if defined(__clang__)
#define M7_COMPILER_STR "clang"
#elif defined(__GNUC__)
#define M7_COMPILER_STR "gcc"
#elif defined(__ARMCC_VERSION)
#define M7_COMPILER_STR "armcc"
#else
#define M7_COMPILER_STR "unknown"
#endif

/* Returns a pointer to a static string (no allocation). */
const char *M7_GetBuildInfoString(void);

#endif /* M7_BUILD_INFO_H_ */

/******************************************************************************
 * File: m7_build_info.c
 ******************************************************************************/
#include "m7_build_info.h"

const char *M7_GetBuildInfoString(void)
{
    /* Keep it short for embedded logs; avoid sprintf at runtime. */
    return M7_FW_NAME " v" 
           /* stringify numbers via preprocessor */
           "0" "." "7" "." "0"
           " (" M7_COMPILER_STR ", " M7_BUILD_DATE " " M7_BUILD_TIME ")";
}

/******************************************************************************
 * File: m7_fault_manager.h
 ******************************************************************************/
#ifndef M7_FAULT_MANAGER_H_
#define M7_FAULT_MANAGER_H_

#include <stdbool.h>
#include <stdint.h>

#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"

/* Fault bit definitions (latched by default) */
#define M7_FAULT_UART_RX_OVERFLOW     (1u << 0)
#define M7_FAULT_UART_CHECKSUM_RATE   (1u << 1)
#define M7_FAULT_DOMAIN_PARITY_ERR    (1u << 2)
#define M7_FAULT_DOMAIN_SSM_ERR       (1u << 3)
#define M7_FAULT_APP_STALE_DATA       (1u << 4)

typedef enum
{
    M7_HEALTH_OK = 0,
    M7_HEALTH_WARN,
    M7_HEALTH_FAIL
} m7_health_state_t;

typedef struct
{
    /* Current latched faults (bitmask) */
    uint32_t latchedFaults;

    /* Health state derived from faults */
    m7_health_state_t health;

    /* Previous snapshots (for rate checks) */
    ufs_stats_t prevUfs;
    a429b_stats_t prevA429;
    airdata_snapshot_t prevAir;

    bool hasPrev;

    /* Tunable thresholds */
    uint32_t checksumErrPerSecWarn; /* if checksum errors increase by this per second -> warn */

    /* Internal timer for evaluation cadence */
    uint32_t evalAccumMs;
} m7_fault_manager_t;

void M7_FaultManager_Init(m7_fault_manager_t *fm);

/* Evaluate faults using module stats; call periodically with dtMs (recommended 1000ms cadence). */
void M7_FaultManager_OnTickMs(m7_fault_manager_t *fm,
                             uint32_t dtMs,
                             const ufs_t *ufs,
                             const a429b_t *a429,
                             const airdata_t *air);

/* Clear all latched faults (maintenance action). */
void M7_FaultManager_Clear(m7_fault_manager_t *fm);

#endif /* M7_FAULT_MANAGER_H_ */

/******************************************************************************
 * File: m7_fault_manager.c
 ******************************************************************************/
#include "m7_fault_manager.h"

static m7_health_state_t M7_ComputeHealth(uint32_t faults)
{
    /* Simple policy:
     * - Any fault present -> WARN
     * - Some faults can escalate to FAIL (customize as needed)
     */
    if (faults == 0u)
    {
        return M7_HEALTH_OK;
    }

    if (faults & (M7_FAULT_UART_RX_OVERFLOW | M7_FAULT_DOMAIN_PARITY_ERR))
    {
        /* Treat overflow and parity as higher severity */
        return M7_HEALTH_FAIL;
    }

    return M7_HEALTH_WARN;
}

void M7_FaultManager_Init(m7_fault_manager_t *fm)
{
    fm->latchedFaults = 0u;
    fm->health = M7_HEALTH_OK;

    /* Conservative defaults */
    fm->checksumErrPerSecWarn = 5u;

    fm->evalAccumMs = 0u;
    fm->hasPrev = false;
}

void M7_FaultManager_Clear(m7_fault_manager_t *fm)
{
    fm->latchedFaults = 0u;
    fm->health = M7_HEALTH_OK;
    fm->hasPrev = false;
    fm->evalAccumMs = 0u;
}

void M7_FaultManager_OnTickMs(m7_fault_manager_t *fm,
                             uint32_t dtMs,
                             const ufs_t *ufs,
                             const a429b_t *a429,
                             const airdata_t *air)
{
    if ((fm == NULL) || (ufs == NULL) || (a429 == NULL) || (air == NULL) || (dtMs == 0u))
    {
        return;
    }

    fm->evalAccumMs += dtMs;
    if (fm->evalAccumMs < 1000u)
    {
        return; /* evaluate at ~1 Hz */
    }

    fm->evalAccumMs -= 1000u;

    /* Snapshot current stats */
    ufs_stats_t us;
    a429b_stats_t as;
    airdata_snapshot_t airSnap;

    UFS_GetStats(ufs, &us);
    A429B_GetStats(a429, &as);
    AirData_GetSnapshot(air, &airSnap);

    if (!fm->hasPrev)
    {
        fm->prevUfs = us;
        fm->prevA429 = as;
        fm->prevAir = airSnap;
        fm->hasPrev = true;
        fm->health = M7_ComputeHealth(fm->latchedFaults);
        return;
    }

    /* Check RX ring overflow increments */
    if (us.rxRingOverflows != fm->prevUfs.rxRingOverflows)
    {
        fm->latchedFaults |= M7_FAULT_UART_RX_OVERFLOW;
    }

    /* Check checksum error rate (per second) */
    {
        const uint32_t diff = us.rxChecksumErrors - fm->prevUfs.rxChecksumErrors;
        if (diff >= fm->checksumErrPerSecWarn)
        {
            fm->latchedFaults |= M7_FAULT_UART_CHECKSUM_RATE;
        }
    }

    /* Domain errors */
    if (as.rxParityErrors != fm->prevA429.rxParityErrors)
    {
        fm->latchedFaults |= M7_FAULT_DOMAIN_PARITY_ERR;
    }
    if (as.rxSsmErrors != fm->prevA429.rxSsmErrors)
    {
        fm->latchedFaults |= M7_FAULT_DOMAIN_SSM_ERR;
    }

    /* Application stale events */
    if ((airSnap.stats.altStaleEvents != fm->prevAir.stats.altStaleEvents) ||
        (airSnap.stats.iasStaleEvents != fm->prevAir.stats.iasStaleEvents))
    {
        fm->latchedFaults |= M7_FAULT_APP_STALE_DATA;
    }

    /* Update prev snapshots */
    fm->prevUfs = us;
    fm->prevA429 = as;
    fm->prevAir = airSnap;

    /* Derive health */
    fm->health = M7_ComputeHealth(fm->latchedFaults);
}

/******************************************************************************
 * File: m7_led_pattern.h
 ******************************************************************************/
#ifndef M7_LED_PATTERN_H_
#define M7_LED_PATTERN_H_

#include <stdbool.h>
#include <stdint.h>

#include "dio.h"
#include "m7_fault_manager.h"

/*
 * LED patterns (deterministic)
 *  OK:   1 Hz blink (500ms on, 500ms off)
 *  WARN: double-blink every 2 seconds
 *  FAIL: 5 Hz blink (100ms on, 100ms off)
 */

typedef struct
{
    dio_handle_t *led;

    m7_health_state_t state;

    uint32_t phaseMs;
    bool ledOn;
} m7_led_pattern_t;

void M7_LedPattern_Init(m7_led_pattern_t *lp, dio_handle_t *led);
void M7_LedPattern_SetState(m7_led_pattern_t *lp, m7_health_state_t state);
void M7_LedPattern_OnTickMs(m7_led_pattern_t *lp, uint32_t dtMs);

#endif /* M7_LED_PATTERN_H_ */

/******************************************************************************
 * File: m7_led_pattern.c
 ******************************************************************************/
#include "m7_led_pattern.h"

void M7_LedPattern_Init(m7_led_pattern_t *lp, dio_handle_t *led)
{
    lp->led = led;
    lp->state = M7_HEALTH_OK;
    lp->phaseMs = 0u;
    lp->ledOn = false;

    (void)DIO_Write(lp->led, false);
}

void M7_LedPattern_SetState(m7_led_pattern_t *lp, m7_health_state_t state)
{
    lp->state = state;
    lp->phaseMs = 0u;
}

void M7_LedPattern_OnTickMs(m7_led_pattern_t *lp, uint32_t dtMs)
{
    if ((lp == NULL) || (lp->led == NULL) || (dtMs == 0u))
    {
        return;
    }

    lp->phaseMs += dtMs;

    switch (lp->state)
    {
        case M7_HEALTH_OK:
        {
            /* 1 Hz: 0-499 on, 500-999 off */
            const uint32_t p = lp->phaseMs % 1000u;
            lp->ledOn = (p < 500u);
            break;
        }

        case M7_HEALTH_WARN:
        {
            /* Double blink every 2000ms:
             * 0-99 on, 100-199 off, 200-299 on, else off
             */
            const uint32_t p = lp->phaseMs % 2000u;
            lp->ledOn = (p < 100u) || ((p >= 200u) && (p < 300u));
            break;
        }

        case M7_HEALTH_FAIL:
        default:
        {
            /* 5 Hz: 0-99 on, 100-199 off */
            const uint32_t p = lp->phaseMs % 200u;
            lp->ledOn = (p < 100u);
            break;
        }
    }

    (void)DIO_Write(lp->led, lp->ledOn);
}

/******************************************************************************
 * File: m7_diag_service.h
 ******************************************************************************/
#ifndef M7_DIAG_SERVICE_H_
#define M7_DIAG_SERVICE_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"
#include "uart_framed_service.h"
#include "m7_fault_manager.h"
#include "m7_build_info.h"

/* Diagnostic messages (inside UFS payload[0]) */
#define M7_MSG_DIAG_REQ (0xE0u)
#define M7_MSG_DIAG_RSP (0xE1u)
#define M7_MSG_CLEAR_FAULTS (0xE2u)
#define M7_MSG_CLEAR_ACK   (0xE3u)

/*
 * DIAG_REQ payload:
 *   [0]=M7_MSG_DIAG_REQ
 *   [1..2]=seq16
 *
 * DIAG_RSP payload (fixed format, <= 64 bytes):
 *   [0]=M7_MSG_DIAG_RSP
 *   [1..2]=seq16
 *   [3]=fw_major
 *   [4]=fw_minor
 *   [5]=fw_patch
 *   [6]=health_state
 *   [7..10]=fault_mask (u32 LE)
 *   [11..14]=ufs_rxOk (u32 LE)
 *   [15..18]=ufs_csumErr (u32 LE)
 *   [19..22]=ufs_ovf (u32 LE)
 *   [23..26]=a429_wordsRx (u32 LE)
 *   [27..30]=air_validWords (u32 LE)
 *   [31..34]=air_invalidWords (u32 LE)
 *   [35..38]=uptime_ms (u32 LE)  (low 32 bits)
 *   [39]=buildStrLen
 *   [40..]=build string bytes (truncated to fit)
 */

typedef struct
{
    ufs_t *ufs;
    const tick_handle_t *tick;
    m7_fault_manager_t *faults;

    /* Sources for counters */
    const ufs_t *ufsStatsSrc;
    const a429b_t *a429;
    const airdata_t *air;

    /* Reply buffer */
    bool replyPending;
    uint8_t replyBuf[64];
    uint8_t replyLen;
} m7_diag_service_t;

void M7_Diag_Init(m7_diag_service_t *ds,
                  ufs_t *ufs,
                  const tick_handle_t *tick,
                  m7_fault_manager_t *faults,
                  const ufs_t *ufsStatsSrc,
                  const a429b_t *a429,
                  const airdata_t *air);

/* Called from UFS rx callback (main context) */
void M7_Diag_OnFrame(m7_diag_service_t *ds, const uint8_t *payload, uint8_t len);

/* Called from main loop dt; sends pending reply when TX is free */
void M7_Diag_OnTickMs(m7_diag_service_t *ds, uint32_t dtMs);

#endif /* M7_DIAG_SERVICE_H_ */

/******************************************************************************
 * File: m7_diag_service.c
 ******************************************************************************/
#include "m7_diag_service.h"

static inline void M7_PutU16LE(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
}

static inline uint16_t M7_GetU16LE(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static inline void M7_PutU32LE(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
    p[2] = (uint8_t)((v >> 16) & 0xFFu);
    p[3] = (uint8_t)((v >> 24) & 0xFFu);
}

static void M7_Diag_Queue(m7_diag_service_t *ds, const uint8_t *p, uint8_t len)
{
    if ((len == 0u) || (len > (uint8_t)sizeof(ds->replyBuf)))
    {
        return;
    }

    for (uint32_t i = 0; i < len; i++)
    {
        ds->replyBuf[i] = p[i];
    }

    ds->replyLen = len;
    ds->replyPending = true;
}

static void M7_Diag_BuildRsp(m7_diag_service_t *ds, uint16_t seq)
{
    ufs_stats_t us = {0};
    a429b_stats_t as = {0};
    airdata_snapshot_t air = {0};

    UFS_GetStats(ds->ufsStatsSrc, &us);
    A429B_GetStats(ds->a429, &as);
    AirData_GetSnapshot(ds->air, &air);

    const uint32_t uptime = TICK_GetMs(ds->tick);

    uint8_t p[64];
    uint32_t idx = 0u;

    p[idx++] = M7_MSG_DIAG_RSP;
    M7_PutU16LE(&p[idx], seq); idx += 2u;

    p[idx++] = (uint8_t)M7_FW_VERSION_MAJOR;
    p[idx++] = (uint8_t)M7_FW_VERSION_MINOR;
    p[idx++] = (uint8_t)M7_FW_VERSION_PATCH;

    p[idx++] = (uint8_t)ds->faults->health;

    M7_PutU32LE(&p[idx], ds->faults->latchedFaults); idx += 4u;
    M7_PutU32LE(&p[idx], us.rxFramesOk); idx += 4u;
    M7_PutU32LE(&p[idx], us.rxChecksumErrors); idx += 4u;
    M7_PutU32LE(&p[idx], us.rxRingOverflows); idx += 4u;
    M7_PutU32LE(&p[idx], as.wordsRx); idx += 4u;
    M7_PutU32LE(&p[idx], air.stats.validWordsTotal); idx += 4u;
    M7_PutU32LE(&p[idx], air.stats.invalidWordsTotal); idx += 4u;
    M7_PutU32LE(&p[idx], uptime); idx += 4u;

    const char *bi = M7_GetBuildInfoString();

    /* Copy build info string with explicit length byte (truncate to fit) */
    uint32_t maxStr = (sizeof(p) - idx - 1u); /* reserve length byte */
    uint32_t n = 0u;
    while ((bi[n] != '\0') && (n < maxStr))
    {
        n++;
    }

    p[idx++] = (uint8_t)n;
    for (uint32_t i = 0; i < n; i++)
    {
        p[idx++] = (uint8_t)bi[i];
    }

    M7_Diag_Queue(ds, p, (uint8_t)idx);
}

void M7_Diag_Init(m7_diag_service_t *ds,
                  ufs_t *ufs,
                  const tick_handle_t *tick,
                  m7_fault_manager_t *faults,
                  const ufs_t *ufsStatsSrc,
                  const a429b_t *a429,
                  const airdata_t *air)
{
    ds->ufs = ufs;
    ds->tick = tick;
    ds->faults = faults;
    ds->ufsStatsSrc = ufsStatsSrc;
    ds->a429 = a429;
    ds->air = air;

    ds->replyPending = false;
    ds->replyLen = 0u;
}

void M7_Diag_OnFrame(m7_diag_service_t *ds, const uint8_t *payload, uint8_t len)
{
    if ((ds == NULL) || (payload == NULL) || (len < 3u))
    {
        return;
    }

    const uint8_t type = payload[0];
    const uint16_t seq = M7_GetU16LE(&payload[1]);

    if (type == M7_MSG_DIAG_REQ)
    {
        M7_Diag_BuildRsp(ds, seq);
    }
    else if (type == M7_MSG_CLEAR_FAULTS)
    {
        M7_FaultManager_Clear(ds->faults);
        uint8_t ack[3];
        ack[0] = M7_MSG_CLEAR_ACK;
        M7_PutU16LE(&ack[1], seq);
        M7_Diag_Queue(ds, ack, sizeof(ack));
    }
    else
    {
        /* ignore */
    }
}

void M7_Diag_OnTickMs(m7_diag_service_t *ds, uint32_t dtMs)
{
    (void)dtMs;

    if ((ds == NULL) || (!ds->replyPending))
    {
        return;
    }

    if (!UFS_IsTxBusy(ds->ufs))
    {
        if (UFS_SendFrame(ds->ufs, ds->replyBuf, ds->replyLen) == kStatus_Success)
        {
            ds->replyPending = false;
            ds->replyLen = 0u;
        }
    }
}

/******************************************************************************
 * File: milestone7_system_main.c
 *
 * Demonstrates:
 *  - Startup BIT (initialization checks)
 *  - Health evaluation once per second
 *  - Fault LED patterns
 *  - Diagnostic request/response
 *  - Optional sensor role that transmits labels 203/204 periodically
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, board LED macros */
#include "fsl_debug_console.h"
#include "fsl_clock.h"

#include "dio.h"
#include "tick_1ms.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"

#include "m7_build_info.h"
#include "m7_fault_manager.h"
#include "m7_led_pattern.h"
#include "m7_diag_service.h"

/* Role selection for demo:
 *  0 = Mission Computer (receiver)
 *  1 = Sensor Emulator (transmits 203/204)
 */
#ifndef M7_NODE_ROLE
#define M7_NODE_ROLE (0u)
#endif

/* PIT defaults if missing from your headers */
#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

/*
 * RX dispatching
 * - UFS delivers all frames here (main context via UFS_Poll)
 * - We route:
 *     - A429B words to domain decoder
 *     - M7 diag messages to diag service
 */
typedef struct
{
    a429b_t *bridge;
    m7_diag_service_t *diag;
} m7_rx_ctx_t;

static m7_rx_ctx_t s_rxCtx;

static void M7_UfsRxDispatcher(const uint8_t *payload, uint8_t len, void *userData)
{
    m7_rx_ctx_t *ctx = (m7_rx_ctx_t *)userData;
    if ((ctx == NULL) || (payload == NULL) || (len == 0u))
    {
        return;
    }

    const uint8_t type = payload[0];

    if (type == A429B_MSG_WORD)
    {
        A429B_UfsRxHook(payload, len, ctx->bridge);
    }
    else if ((type == M7_MSG_DIAG_REQ) || (type == M7_MSG_CLEAR_FAULTS))
    {
        M7_Diag_OnFrame(ctx->diag, payload, len);
    }
    else
    {
        /* Unknown message: ignore for this milestone */
    }
}

/* Domain -> application callback */
static airdata_t s_air;
static void M7_OnWord(uint32_t rawWord,
                      const a429b_word_fields_t *fields,
                      a429b_word_validity_t validity,
                      void *userData)
{
    (void)userData;
    AirData_OnWord(&s_air, rawWord, fields, validity);
}

/* Startup BIT: return true if init sequence passed */
static bool M7_StartupBit(void)
{
    /* Minimal BIT: verify that required modules initialized earlier succeeded.
     * In this demo, we rely on return-code checks in main().
     * If you want deeper BIT, add hardware self-checks here.
     */
    return true;
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 7: System Integration + Health + Diag\r\n");
    PRINTF("Build: %s\r\n", M7_GetBuildInfoString());
    PRINTF("Role: %s\r\n", (M7_NODE_ROLE == 0u) ? "MissionComputer" : "SensorEmulator");

    /* ---- LED via DIO ---- */
    dio_handle_t led = {0};

    /* Map these macros in your board layer.
     * If your project uses different names, change here to match.
     */
#ifndef BOARD_USER_LED_GPIO
#define BOARD_USER_LED_GPIO EXAMPLE_LED_GPIO
#endif
#ifndef BOARD_USER_LED_GPIO_PIN
#define BOARD_USER_LED_GPIO_PIN EXAMPLE_LED_GPIO_PIN
#endif

    const dio_config_t ledCfg = {
        .base = BOARD_USER_LED_GPIO,
        .pin  = BOARD_USER_LED_GPIO_PIN,
        .activeLow = true,
        .initialOn = false,
    };

    if (DIO_Init(&led, &ledCfg) != kStatus_Success)
    {
        PRINTF("FATAL: LED init failed\r\n");
        while (1) {}
    }

    /* ---- Tick 1ms (PIT) ---- */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };

    if (TICK_Init(&tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("FATAL: tick init failed\r\n");
        while (1) {}
    }

    /* ---- Application ---- */
    const airdata_config_t airCfg = {
        .activityPulseMs = 50u,
        .altStaleTimeoutMs = 500u,
        .iasStaleTimeoutMs = 500u,
        .acceptFunctionalTest = false,
    };

    if (AirData_Init(&s_air, &airCfg) != kStatus_Success)
    {
        PRINTF("FATAL: AirData init failed\r\n");
        while (1) {}
    }

    /* ---- UFS ---- */
    ufs_t ufs = {0};
    a429b_t bridge = {0};

    /* Fault management + LED pattern + diag service */
    m7_fault_manager_t faults;
    m7_led_pattern_t ledPat;
    m7_diag_service_t diag;

    M7_FaultManager_Init(&faults);
    M7_LedPattern_Init(&ledPat, &led);

    /* Set dispatcher context */
    s_rxCtx.bridge = &bridge;
    s_rxCtx.diag = &diag;

    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 192u,
        .rxCb = M7_UfsRxDispatcher,
        .rxCbUserData = &s_rxCtx,
    };

    if (UFS_Init(&ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("FATAL: UFS init failed\r\n");
        while (1) {}
    }

    /* ---- Domain bridge ---- */
    if (A429B_Init(&bridge, &ufs, M7_OnWord, NULL) != kStatus_Success)
    {
        PRINTF("FATAL: A429B init failed\r\n");
        while (1) {}
    }

    /* ---- Diag service (replies over UFS) ---- */
    M7_Diag_Init(&diag, &ufs, &tick, &faults, &ufs, &bridge, &s_air);

    /* ---- Startup BIT ---- */
    const bool bitOk = M7_StartupBit();
    if (!bitOk)
    {
        faults.latchedFaults |= M7_FAULT_DOMAIN_PARITY_ERR; /* example: flag a severe fault */
        faults.health = M7_HEALTH_FAIL;
        PRINTF("BIT FAILED: entering FAIL state\r\n");
    }

    /* ---- Optional sensor scheduling ---- */
    uint32_t simAlt = 1000u;
    uint32_t simIas = 250u;

    if (M7_NODE_ROLE == 1u)
    {
        /* Sensor sends words periodically using domain scheduler */
        a429b_word_fields_t fAlt = {
            .label = 203u, .sdi = 0u, .data = simAlt, .ssm = A429B_SSM_NORMAL_OPERATION, .parity = false,
        };
        a429b_word_fields_t fIas = {
            .label = 204u, .sdi = 0u, .data = simIas, .ssm = A429B_SSM_NORMAL_OPERATION, .parity = false,
        };
        uint32_t wAlt, wIas;
        (void)A429B_PackWord(&fAlt, &wAlt);
        (void)A429B_PackWord(&fIas, &wIas);
        wAlt = A429B_SetEvenParity(wAlt);
        wIas = A429B_SetEvenParity(wIas);

        (void)A429B_ScheduleWord(&bridge, 0u, wAlt, 50u);
        (void)A429B_ScheduleWord(&bridge, 1u, wIas, 50u);

        PRINTF("SensorEmulator: sending labels 203/204 at 20 Hz\r\n");
    }
    else
    {
        PRINTF("MissionComputer: send DIAG_REQ from another node to read status\r\n");
    }

    /* ---- Main loop (deterministic architecture) ---- */
    uint32_t lastMs = TICK_GetMs(&tick);
    uint32_t printTimerMs = 0u;

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &lastMs);

        if (dt != 0u)
        {
            /* Drive periodic components */
            AirData_OnTickMs(&s_air, dt);
            A429B_OnTickMs(&bridge, dt);
            M7_Diag_OnTickMs(&diag, dt);

            /* Health monitoring (evaluates at ~1Hz internally) */
            M7_FaultManager_OnTickMs(&faults, dt, &ufs, &bridge, &s_air);
            M7_LedPattern_SetState(&ledPat, faults.health);
            M7_LedPattern_OnTickMs(&ledPat, dt);

            printTimerMs += dt;
        }

        /* Poll RX parsing and frame dispatching */
        (void)UFS_Poll(&ufs);

        /* Non-time-critical periodic log */
        if (printTimerMs >= 1000u)
        {
            printTimerMs -= 1000u;

            airdata_snapshot_t snap;
            AirData_GetSnapshot(&s_air, &snap);

            PRINTF("Health=%u faults=0x%08lX ALT=%s%lu IAS=%s%lu\r\n",
                   (unsigned)faults.health,
                   (unsigned long)faults.latchedFaults,
                   snap.altValid ? "OK" : "--",
                   (unsigned long)snap.altitude_ft,
                   snap.iasValid ? "OK" : "--",
                   (unsigned long)snap.ias_kt);
        }
    }
}
