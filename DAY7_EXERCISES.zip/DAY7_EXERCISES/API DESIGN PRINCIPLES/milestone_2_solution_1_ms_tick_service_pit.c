/******************************************************************************
 * Milestone 2 (Solution)
 * Deterministic 1 ms tick service using PIT + delta-consumption API
 * Target: NXP i.MX RT1050 EVKB (EVKB-IMXRT1050) using MCUXpresso SDK
 *
 * Recommended project baseline (MCUXpresso import):
 *   boards/evkbimxrt1050/driver_examples/pit
 *
 * Integration steps:
 *   1) Import the PIT example.
 *   2) Add these new files to the project:
 *        - tick_1ms.h
 *        - tick_1ms.c
 *   3) Replace the example's pit.c with the demo main below
 *      (or create a new main file and exclude the original pit.c main).
 *   4) Build + flash.
 *
 * Notes:
 * - The PIT IRQ on i.MXRT is shared for PIT channels; this solution uses channel 0.
 * - The ISR is constant-time: clear flag, increment counter, barrier.
 * - The main loop consumes elapsed time using a delta pattern, avoiding busy delays.
 ******************************************************************************/

/******************************************************************************
 * File: tick_1ms.h
 ******************************************************************************/
#ifndef TICK_1MS_H_
#define TICK_1MS_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h" /* status_t, kStatus_* */
#include "fsl_pit.h"    /* PIT driver types */

/* Versioning for the tick module */
#define TICK_VERSION_MAJOR (1u)
#define TICK_VERSION_MINOR (0u)
#define TICK_VERSION_PATCH (0u)

/*
 * tick_1ms module intent
 * ----------------------
 * - Provide a monotonic timebase in milliseconds (wraps naturally at 2^32 ms).
 * - Provide a deterministic "consume delta" API for the main loop:
 *     delta_ms = now_ms - last_ms; last_ms = now_ms
 * - No callbacks from ISR.
 * - ISR work is bounded and minimal.
 * - Single-instance ownership for milestone simplicity.
 */

typedef struct
{
    PIT_Type *pitBase;      /* Typically PIT */
    pit_chnl_t pitChannel;  /* Typically kPIT_Chnl_0 */
    IRQn_Type pitIrq;       /* Typically PIT_IRQn */
    uint32_t sourceClockHz; /* PIT input clock in Hz (e.g., CLOCK_GetFreq(kCLOCK_OscClk)) */
    uint32_t tickPeriodUs;  /* Tick period in microseconds. For 1ms tick, set to 1000. */
} tick_config_t;

typedef struct
{
    PIT_Type *pitBase;
    pit_chnl_t pitChannel;
    IRQn_Type pitIrq;
    uint32_t tickPeriodUs;
    volatile uint32_t msCounter; /* incremented from PIT ISR */
    bool isInitialized;
} tick_handle_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize the PIT-based tick generator.
 *
 * @param handle Caller-owned storage for the handle.
 * @param config Configuration for PIT and tick period.
 *
 * @pre  handle != NULL
 * @pre  config != NULL
 * @pre  config->pitBase != NULL
 * @pre  config->sourceClockHz != 0
 * @pre  config->tickPeriodUs != 0
 * @pre  Board clocking for PIT is enabled (done by BOARD_InitHardware() in SDK examples).
 *
 * @post PIT is configured and started.
 * @post msCounter starts at 0.
 * @post handle->isInitialized == true on success.
 *
 * Idempotence rule:
 *  - If called again on an initialized handle with the same PIT base/channel/IRQ and tickPeriodUs,
 *    returns kStatus_Success without reconfiguring hardware.
 *  - If called with a different configuration, returns kStatus_Fail.
 *
 * Concurrency/context:
 *  - Call from main context only.
 */
status_t TICK_Init(tick_handle_t *handle, const tick_config_t *config);

/*
 * @brief Get current monotonic time in milliseconds.
 *
 * @param handle Initialized tick handle.
 * @return Current millisecond count (wraps at 2^32).
 *
 * @pre handle != NULL
 * @pre handle->isInitialized == true
 *
 * Concurrency:
 *  - Safe to call from main context.
 *  - Value can change asynchronously due to ISR.
 */
uint32_t TICK_GetMs(const tick_handle_t *handle);

/*
 * @brief Consume elapsed milliseconds since the last call (delta pattern).
 *
 * @param handle Initialized tick handle.
 * @param lastMs Pointer to a caller-owned "last observed" timestamp.
 *
 * @return delta_ms = now_ms - *lastMs  (unsigned wrap-safe arithmetic)
 *
 * Usage pattern:
 *   uint32_t last = TICK_GetMs(&tick);
 *   for(;;) {
 *     uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
 *     ... update state machines using dt ...
 *   }
 *
 * @pre handle != NULL
 * @pre lastMs != NULL
 * @pre handle->isInitialized == true
 *
 * Concurrency:
 *  - Uses a short critical section to update *lastMs consistently with now.
 */
uint32_t TICK_ConsumeDeltaMs(const tick_handle_t *handle, uint32_t *lastMs);

/*
 * @brief Optional deinit (stops PIT). Not required for the lab, but useful.
 */
status_t TICK_Deinit(tick_handle_t *handle);

#ifdef __cplusplus
}
#endif

#endif /* TICK_1MS_H_ */

/******************************************************************************
 * File: tick_1ms.c
 ******************************************************************************/
#include "tick_1ms.h"

#include "fsl_common.h" /* SDK_ISR_EXIT_BARRIER */

/*
 * Milestone simplification:
 * - Single active instance (one PIT interrupt vector).
 * - This is explicit and documented, so it remains verifiable.
 */
static tick_handle_t *s_tickInstance = NULL;

/* Forward declaration of the ISR installed via the vector table. */
void PIT_IRQHandler(void);

static bool TICK_IsSameConfig(const tick_handle_t *h, const tick_config_t *c)
{
    return (h->pitBase == c->pitBase) &&
           (h->pitChannel == c->pitChannel) &&
           (h->pitIrq == c->pitIrq) &&
           (h->tickPeriodUs == c->tickPeriodUs);
}

status_t TICK_Init(tick_handle_t *handle, const tick_config_t *config)
{
    if ((handle == NULL) || (config == NULL) || (config->pitBase == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if ((config->sourceClockHz == 0u) || (config->tickPeriodUs == 0u))
    {
        return kStatus_InvalidArgument;
    }

    /* If already initialized, enforce idempotence. */
    if (handle->isInitialized)
    {
        return TICK_IsSameConfig(handle, config) ? kStatus_Success : kStatus_Fail;
    }

    /* Enforce single-instance rule. */
    if ((s_tickInstance != NULL) && (s_tickInstance != handle))
    {
        return kStatus_Fail;
    }

    /* Store configuration in the handle first (so ISR can safely use it once enabled). */
    handle->pitBase       = config->pitBase;
    handle->pitChannel    = config->pitChannel;
    handle->pitIrq        = config->pitIrq;
    handle->tickPeriodUs  = config->tickPeriodUs;
    handle->msCounter     = 0u;

    /* Configure and start PIT */
    pit_config_t pitCfg;
    PIT_GetDefaultConfig(&pitCfg);

    /*
     * If you want PIT to halt while debugging, set:
     *   pitCfg.enableRunInDebug = false;
     *
     * For deterministic timing characterization, it can be useful to keep it
     * running in debug. Choose based on your lab workflow.
     */

    PIT_Init(handle->pitBase, &pitCfg);

    /*
     * PIT_SetTimerPeriod expects "count" in ticks. SDK provides USEC_TO_COUNT.
     * For a 1 ms tick: tickPeriodUs = 1000.
     */
    const uint32_t periodTicks = USEC_TO_COUNT(handle->tickPeriodUs, config->sourceClockHz);
    if (periodTicks == 0u)
    {
        /* Very low clock or too small period would underflow/invalid. */
        return kStatus_OutOfRange;
    }

    PIT_SetTimerPeriod(handle->pitBase, handle->pitChannel, periodTicks);

    /* Enable timer interrupt for the chosen channel */
    PIT_EnableInterrupts(handle->pitBase, handle->pitChannel, kPIT_TimerInterruptEnable);

    /* Enable NVIC for PIT */
    EnableIRQ(handle->pitIrq);

    /* Start PIT */
    PIT_StartTimer(handle->pitBase, handle->pitChannel);

    handle->isInitialized = true;
    s_tickInstance = handle;

    return kStatus_Success;
}

uint32_t TICK_GetMs(const tick_handle_t *handle)
{
    if ((handle == NULL) || (!handle->isInitialized))
    {
        return 0u;
    }

    /* 32-bit read is naturally atomic on Cortex-M for aligned word, but the counter
     * can change asynchronously due to ISR. For GetMs() that's fine.
     */
    return handle->msCounter;
}

uint32_t TICK_ConsumeDeltaMs(const tick_handle_t *handle, uint32_t *lastMs)
{
    if ((handle == NULL) || (lastMs == NULL) || (!handle->isInitialized))
    {
        return 0u;
    }

    /*
     * Critical section: keep it minimal.
     * We want consistency between now_ms and lastMs update even if the ISR fires.
     */
    uint32_t now;
    uint32_t prev;

    __disable_irq();
    now = handle->msCounter;
    prev = *lastMs;
    *lastMs = now;
    __enable_irq();

    return (uint32_t)(now - prev); /* wrap-safe unsigned arithmetic */
}

status_t TICK_Deinit(tick_handle_t *handle)
{
    if (handle == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        return kStatus_Success;
    }

    PIT_StopTimer(handle->pitBase, handle->pitChannel);
    PIT_DisableInterrupts(handle->pitBase, handle->pitChannel, kPIT_TimerInterruptEnable);
    DisableIRQ(handle->pitIrq);

    /* Leave PIT module init state as-is; other code may use it.
     * For a strict ownership model you could call PIT_Deinit(), but keep it simple here.
     */

    handle->isInitialized = false;
    if (s_tickInstance == handle)
    {
        s_tickInstance = NULL;
    }

    return kStatus_Success;
}

/*
 * PIT interrupt handler
 * ---------------------
 * MUST remain constant-time and minimal.
 * No logging, no heavy work, no callbacks.
 */
void PIT_IRQHandler(void)
{
    if ((s_tickInstance == NULL) || (!s_tickInstance->isInitialized))
    {
        /* Spurious interrupt or not yet initialized. Safely clear all flags. */
        PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);
        SDK_ISR_EXIT_BARRIER;
        return;
    }

    /* Clear interrupt flag for the configured channel. */
    PIT_ClearStatusFlags(s_tickInstance->pitBase, s_tickInstance->pitChannel, kPIT_TimerFlag);

    /* 1 tick == 1 ms (as configured) */
    s_tickInstance->msCounter++;

    /*
     * Important on i.MXRT: CPU can outrun the IP bus clock clearing the flag.
     * This barrier prevents immediate re-entry into the handler.
     */
    SDK_ISR_EXIT_BARRIER;
}

/******************************************************************************
 * File: pit.c  (replace the PIT example's main file with this demo)
 ******************************************************************************/
#include "fsl_debug_console.h"
#include "board.h"
#include "app.h"       /* From PIT example: DEMO_PIT_BASEADDR, DEMO_PIT_CHANNEL, PIT_IRQ_ID, LED macros */
#include "fsl_clock.h" /* CLOCK_GetFreq */

#include "tick_1ms.h"

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 2: 1ms Tick Service (PIT) + delta-consumption demo\r\n");
    PRINTF("Tick version %u.%u.%u\r\n", TICK_VERSION_MAJOR, TICK_VERSION_MINOR, TICK_VERSION_PATCH);

    /* Initialize LED via the imported PIT example macros */
    LED_INIT();

    /* Configure and start 1ms tick */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u, /* 1 ms */
    };

    const status_t st = TICK_Init(&tick, &tickCfg);
    if (st != kStatus_Success)
    {
        PRINTF("TICK_Init failed: %ld\r\n", (long)st);
        while (1)
        {
            /* Fail-safe */
        }
    }

    /*
     * Delta-consumption pattern:
     * - last tracks the last observed time.
     * - dt is elapsed time since last loop iteration.
     */
    uint32_t last = TICK_GetMs(&tick);
    uint32_t accumLedMs = 0u;
    uint32_t accumPrintMs = 0u;

    while (true)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
        if (dt == 0u)
        {
            /* No tick elapsed since last iteration; do other background work here. */
            continue;
        }

        /* Example 1: toggle LED every 500 ms */
        accumLedMs += dt;
        if (accumLedMs >= 500u)
        {
            accumLedMs -= 500u;
            LED_TOGGLE();
        }

        /* Example 2: print a heartbeat once per second (avoid printing too often) */
        accumPrintMs += dt;
        if (accumPrintMs >= 1000u)
        {
            accumPrintMs -= 1000u;
            PRINTF("Heartbeat: ms=%lu\r\n", (unsigned long)TICK_GetMs(&tick));
        }

        /*
         * In later milestones, this is where you call:
         *   - UART service Poll()
         *   - domain scheduler update(dt)
         *   - application state machines
         */
    }
}
