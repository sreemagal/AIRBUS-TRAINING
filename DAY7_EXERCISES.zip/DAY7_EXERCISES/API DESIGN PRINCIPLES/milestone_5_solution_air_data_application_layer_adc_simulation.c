/******************************************************************************
 * Milestone 5 (Solution)
 * Application Layer: Air Data Computer (ADC) label fan-out simulation
 *
 * Goal:
 * - Track two ARINC-like labels:
 *     Label 203: Pressure Altitude  (feet)  -> data field used as feet
 *     Label 204: Indicated Airspeed (knots) -> data field used as knots
 * - Update application state ONLY on valid domain words.
 * - Drive a visible activity LED pulse when fresh valid data is received.
 * - Export deterministic diagnostics (counters + current values).
 * - Periodically send a small "status" word back (optional demo behavior).
 *
 * Layering recap:
 *   LPUART HW (SDK)  -> UFS (Milestone 3) -> A429B Bridge (Milestone 4)
 *     -> AirData App (this milestone)
 *
 * Recommended baseline project:
 *   boards/evkbimxrt1050/driver_examples/lpuart/interrupt_transfer
 * Plus add:
 *   - tick_1ms (Milestone 2)
 *   - uart_framed_service (Milestone 3)
 *   - arinc429_bridge (Milestone 4)
 *   - dio (Milestone 1) for LED control
 ******************************************************************************/

/******************************************************************************
 * File: air_data_app.h
 ******************************************************************************/
#ifndef AIR_DATA_APP_H_
#define AIR_DATA_APP_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"        /* status_t */
#include "arinc429_bridge.h"   /* a429b_word_fields_t, a429b_word_validity_t */

/* Versioning */
#define AIRDATA_VERSION_MAJOR (1u)
#define AIRDATA_VERSION_MINOR (0u)
#define AIRDATA_VERSION_PATCH (0u)

/* Labels tracked by this application */
#define AIRDATA_LABEL_PRESSURE_ALT_FT (203u)
#define AIRDATA_LABEL_IAS_KT          (204u)

/* Outgoing (demo) status label (application-defined) */
#define AIRDATA_LABEL_STATUS          (210u)

/* Application statistics */
typedef struct
{
    uint32_t validWordsTotal;
    uint32_t invalidWordsTotal;

    uint32_t altUpdates;
    uint32_t iasUpdates;

    uint32_t altStaleEvents;
    uint32_t iasStaleEvents;
} airdata_stats_t;

/* Application state snapshot (pure data, printable/loggable) */
typedef struct
{
    bool altValid;
    bool iasValid;

    uint32_t altitude_ft; /* valid iff altValid */
    uint32_t ias_kt;      /* valid iff iasValid */

    uint32_t lastAltAgeMs; /* how old the last alt update is (ms) */
    uint32_t lastIasAgeMs; /* how old the last ias update is (ms) */

    bool activityLedOn; /* application suggests LED state */

    airdata_stats_t stats;
} airdata_snapshot_t;

/* Application configuration */
typedef struct
{
    /* How long to pulse the activity LED after a valid update */
    uint32_t activityPulseMs; /* e.g., 50ms */

    /* Stale thresholds: if no fresh data within this time, mark invalid */
    uint32_t altStaleTimeoutMs; /* e.g., 500ms */
    uint32_t iasStaleTimeoutMs; /* e.g., 500ms */

    /* Application policy: which SSM values are accepted for state update */
    bool acceptFunctionalTest; /* if true, accept A429B_SSM_FUNCTIONAL_TEST as valid */
} airdata_config_t;

/* Application instance */
typedef struct
{
    airdata_config_t cfg;

    /* Last values */
    uint32_t altitude_ft;
    uint32_t ias_kt;

    bool altValid;
    bool iasValid;

    /* Ages (ms since last update); updated by AirData_OnTickMs() */
    uint32_t altAgeMs;
    uint32_t iasAgeMs;

    /* LED pulse state */
    uint32_t activityPulseRemainingMs;
    bool activityLedOn;

    airdata_stats_t stats;

    bool isInitialized;
} airdata_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize the application.
 *
 * @pre app != NULL
 * @pre cfg != NULL
 * @post app is ready and all values are reset to known defaults.
 */
status_t AirData_Init(airdata_t *app, const airdata_config_t *cfg);

/*
 * @brief Application word ingestion.
 *
 * This is the ONLY place where the app interprets labels and updates state.
 *
 * @param app Application instance
 * @param rawWord Raw 32-bit word (for traceability)
 * @param fields Decoded fields (label/sdi/data/ssm/parity)
 * @param validity Domain validity from bridge
 *
 * @note This function is designed to be unit-testable:
 *       no direct hardware, no prints, no delays.
 */
void AirData_OnWord(airdata_t *app,
                    uint32_t rawWord,
                    const a429b_word_fields_t *fields,
                    a429b_word_validity_t validity);

/*
 * @brief Time update (called from main loop with dt in ms).
 *
 * Responsibilities:
 * - Age tracking for altitude and airspeed
 * - Stale invalidation when timeout expires
 * - Activity LED pulse timing
 */
void AirData_OnTickMs(airdata_t *app, uint32_t dtMs);

/* @brief Get a snapshot of current application state for logging/telemetry. */
void AirData_GetSnapshot(const airdata_t *app, airdata_snapshot_t *out);

/*
 * @brief Build an application-defined "status" word.
 *
 * The purpose is to demonstrate application-to-domain interaction.
 * This word packs a few health bits + recent values.
 *
 * Encoding (example, deterministic):
 *   label = AIRDATA_LABEL_STATUS
 *   sdi   = 0
 *   ssm   = NORMAL
 *   data  bits:
 *     [0]  altValid
 *     [1]  iasValid
 *     [2]  activityLedOn
 *     [18:3] low 16 bits of altitude_ft (for demo)
 */
status_t AirData_BuildStatusWord(const airdata_t *app, uint32_t *outRawWord);

#ifdef __cplusplus
}
#endif

#endif /* AIR_DATA_APP_H_ */

/******************************************************************************
 * File: air_data_app.c
 ******************************************************************************/
#include "air_data_app.h"

static bool AirData_IsSsmAccepted(const airdata_t *app, a429b_ssm_t ssm)
{
    if (ssm == A429B_SSM_NORMAL_OPERATION)
    {
        return true;
    }

    if (app->cfg.acceptFunctionalTest && (ssm == A429B_SSM_FUNCTIONAL_TEST))
    {
        return true;
    }

    return false;
}

static void AirData_PulseActivity(airdata_t *app)
{
    app->activityPulseRemainingMs = app->cfg.activityPulseMs;
    app->activityLedOn = (app->cfg.activityPulseMs != 0u);
}

status_t AirData_Init(airdata_t *app, const airdata_config_t *cfg)
{
    if ((app == NULL) || (cfg == NULL))
    {
        return kStatus_InvalidArgument;
    }

    /* Copy configuration */
    app->cfg = *cfg;

    /* Reset state */
    app->altitude_ft = 0u;
    app->ias_kt = 0u;
    app->altValid = false;
    app->iasValid = false;

    app->altAgeMs = 0u;
    app->iasAgeMs = 0u;

    app->activityPulseRemainingMs = 0u;
    app->activityLedOn = false;

    app->stats.validWordsTotal = 0u;
    app->stats.invalidWordsTotal = 0u;
    app->stats.altUpdates = 0u;
    app->stats.iasUpdates = 0u;
    app->stats.altStaleEvents = 0u;
    app->stats.iasStaleEvents = 0u;

    app->isInitialized = true;
    return kStatus_Success;
}

void AirData_OnWord(airdata_t *app,
                    uint32_t rawWord,
                    const a429b_word_fields_t *fields,
                    a429b_word_validity_t validity)
{
    (void)rawWord;

    if ((app == NULL) || (!app->isInitialized) || (fields == NULL))
    {
        return;
    }

    if (validity != A429B_WORD_VALID)
    {
        app->stats.invalidWordsTotal++;
        return;
    }

    /* Domain says "valid". Apply application-level SSM acceptance policy. */
    if (!AirData_IsSsmAccepted(app, fields->ssm))
    {
        app->stats.invalidWordsTotal++;
        return;
    }

    app->stats.validWordsTotal++;

    /* Update application state based on label */
    if (fields->label == AIRDATA_LABEL_PRESSURE_ALT_FT)
    {
        app->altitude_ft = fields->data; /* 1 LSB = 1 ft for this lab */
        app->altValid = true;
        app->altAgeMs = 0u;
        app->stats.altUpdates++;
        AirData_PulseActivity(app);
    }
    else if (fields->label == AIRDATA_LABEL_IAS_KT)
    {
        app->ias_kt = fields->data; /* 1 LSB = 1 knot for this lab */
        app->iasValid = true;
        app->iasAgeMs = 0u;
        app->stats.iasUpdates++;
        AirData_PulseActivity(app);
    }
    else
    {
        /* Not a label we care about; ignore (still counted as validWordsTotal). */
    }
}

void AirData_OnTickMs(airdata_t *app, uint32_t dtMs)
{
    if ((app == NULL) || (!app->isInitialized) || (dtMs == 0u))
    {
        return;
    }

    /* Age tracking (saturate at UINT32_MAX to avoid wrap surprises) */
    if (app->altAgeMs <= (UINT32_MAX - dtMs))
    {
        app->altAgeMs += dtMs;
    }
    else
    {
        app->altAgeMs = UINT32_MAX;
    }

    if (app->iasAgeMs <= (UINT32_MAX - dtMs))
    {
        app->iasAgeMs += dtMs;
    }
    else
    {
        app->iasAgeMs = UINT32_MAX;
    }

    /* Stale invalidation */
    if (app->altValid && (app->cfg.altStaleTimeoutMs != 0u) && (app->altAgeMs > app->cfg.altStaleTimeoutMs))
    {
        app->altValid = false;
        app->stats.altStaleEvents++;
    }

    if (app->iasValid && (app->cfg.iasStaleTimeoutMs != 0u) && (app->iasAgeMs > app->cfg.iasStaleTimeoutMs))
    {
        app->iasValid = false;
        app->stats.iasStaleEvents++;
    }

    /* Activity LED pulse management */
    if (app->activityPulseRemainingMs > dtMs)
    {
        app->activityPulseRemainingMs -= dtMs;
        app->activityLedOn = true;
    }
    else
    {
        app->activityPulseRemainingMs = 0u;
        app->activityLedOn = false;
    }
}

void AirData_GetSnapshot(const airdata_t *app, airdata_snapshot_t *out)
{
    if ((app == NULL) || (out == NULL) || (!app->isInitialized))
    {
        return;
    }

    out->altValid = app->altValid;
    out->iasValid = app->iasValid;
    out->altitude_ft = app->altitude_ft;
    out->ias_kt = app->ias_kt;
    out->lastAltAgeMs = app->altAgeMs;
    out->lastIasAgeMs = app->iasAgeMs;
    out->activityLedOn = app->activityLedOn;
    out->stats = app->stats;
}

status_t AirData_BuildStatusWord(const airdata_t *app, uint32_t *outRawWord)
{
    if ((app == NULL) || (outRawWord == NULL) || (!app->isInitialized))
    {
        return kStatus_InvalidArgument;
    }

    a429b_word_fields_t f;
    f.label = AIRDATA_LABEL_STATUS;
    f.sdi = 0u;
    f.ssm = A429B_SSM_NORMAL_OPERATION;

    /* Pack a few bits deterministically */
    uint32_t data = 0u;
    data |= (app->altValid ? 1u : 0u) << 0;
    data |= (app->iasValid ? 1u : 0u) << 1;
    data |= (app->activityLedOn ? 1u : 0u) << 2;

    /* Low 16 bits of altitude in bits [18:3] (demo only) */
    data |= ((app->altitude_ft & 0xFFFFu) << 3);
    f.data = (data & 0x7FFFFu); /* 19-bit constraint */

    f.parity = false; /* will be fixed by A429B_SendWord(...ensureEvenParity=true) */

    return A429B_PackWord(&f, outRawWord);
}

/******************************************************************************
 * File: milestone5_demo_main.c
 *
 * This demo is designed to run on two EVKB boards:
 * - One board configured as SENSOR node (transmits labels 203/204 periodically)
 * - One board configured as MISSION COMPUTER node (receives and updates AirData)
 *
 * Select role by setting AIRDATA_NODE_ROLE:
 *   0 = Mission Computer (receiver + status response)
 *   1 = Sensor Emulator (periodic transmitter)
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, BOARD_InitHardware() */
#include "fsl_debug_console.h"
#include "fsl_clock.h"          /* CLOCK_GetFreq */

#include "dio.h"                /* Milestone 1 */
#include "tick_1ms.h"           /* Milestone 2 */
#include "uart_framed_service.h"/* Milestone 3 */
#include "arinc429_bridge.h"    /* Milestone 4 */
#include "air_data_app.h"       /* Milestone 5 */

#ifndef AIRDATA_NODE_ROLE
#define AIRDATA_NODE_ROLE (0u)
#endif

#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

static airdata_t s_air;

/* Bridge callback: adapter into application */
static void Demo_BridgeOnWord(uint32_t rawWord,
                             const a429b_word_fields_t *fields,
                             a429b_word_validity_t validity,
                             void *userData)
{
    (void)userData;
    AirData_OnWord(&s_air, rawWord, fields, validity);
}

static void Demo_PrintSnapshot(uint32_t nowMs, const airdata_snapshot_t *snap)
{
    PRINTF("[%lu ms] ALT=%s %lu ft (age=%lu ms), IAS=%s %lu kt (age=%lu ms), led=%u\r\n",
           (unsigned long)nowMs,
           snap->altValid ? "OK" : "--",
           (unsigned long)snap->altitude_ft,
           (unsigned long)snap->lastAltAgeMs,
           snap->iasValid ? "OK" : "--",
           (unsigned long)snap->ias_kt,
           (unsigned long)snap->lastIasAgeMs,
           snap->activityLedOn ? 1u : 0u);

    PRINTF("  Stats: valid=%lu invalid=%lu altUp=%lu iasUp=%lu altStale=%lu iasStale=%lu\r\n",
           (unsigned long)snap->stats.validWordsTotal,
           (unsigned long)snap->stats.invalidWordsTotal,
           (unsigned long)snap->stats.altUpdates,
           (unsigned long)snap->stats.iasUpdates,
           (unsigned long)snap->stats.altStaleEvents,
           (unsigned long)snap->stats.iasStaleEvents);
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 5: Air Data Application demo\r\n");
    PRINTF("Role: %s\r\n", (AIRDATA_NODE_ROLE == 0u) ? "MissionComputer" : "SensorEmulator");

    /* ---- LED via DIO (Milestone 1) ---- */
    dio_handle_t led = {0};
    const dio_config_t ledCfg = {
        .base = BOARD_USER_LED_GPIO,
        .pin = BOARD_USER_LED_GPIO_PIN,
        .activeLow = true,    /* EVKB USER LED is active-low */
        .initialOn = false,
    };
    if (DIO_Init(&led, &ledCfg) != kStatus_Success)
    {
        PRINTF("LED DIO_Init failed\r\n");
        while (1) {}
    }

    /* ---- 1ms tick (Milestone 2) ---- */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };
    if (TICK_Init(&tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("TICK_Init failed\r\n");
        while (1) {}
    }

    /* ---- Application init (Milestone 5) ---- */
    const airdata_config_t airCfg = {
        .activityPulseMs = 50u,
        .altStaleTimeoutMs = 500u,
        .iasStaleTimeoutMs = 500u,
        .acceptFunctionalTest = false,
    };
    if (AirData_Init(&s_air, &airCfg) != kStatus_Success)
    {
        PRINTF("AirData_Init failed\r\n");
        while (1) {}
    }

    /* ---- UFS + A429B bridge (Milestone 3 + 4) ---- */
    ufs_t ufs = {0};
    a429b_t bridge = {0};

    /* Important: UFS RX callback is the bridge hook (runs from UFS_Poll()) */
    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 128u,
        .rxCb = A429B_UfsRxHook,
        .rxCbUserData = &bridge,
    };
    if (UFS_Init(&ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("UFS_Init failed\r\n");
        while (1) {}
    }

    if (A429B_Init(&bridge, &ufs, Demo_BridgeOnWord, NULL) != kStatus_Success)
    {
        PRINTF("A429B_Init failed\r\n");
        while (1) {}
    }

    PRINTF("Wire two EVKB boards: TX<->RX, GND<->GND. Flash this demo on both.\r\n");

    /* ---- Mission/sensor demo variables ---- */
    uint32_t last = TICK_GetMs(&tick);
    uint32_t printTimer = 0u;
    uint32_t statusTxTimer = 0u;

    /* Sensor-side simulated values */
    uint32_t simAlt = 1000u;
    uint32_t simIas = 250u;
    uint32_t simUpdateTimer = 0u;

    /* Pre-build initial words for sensor role */
    uint32_t altWord = 0u;
    uint32_t iasWord = 0u;

    if (AIRDATA_NODE_ROLE == 1u)
    {
        a429b_word_fields_t fAlt = {
            .label = AIRDATA_LABEL_PRESSURE_ALT_FT,
            .sdi = 0u,
            .data = simAlt,
            .ssm = A429B_SSM_NORMAL_OPERATION,
            .parity = false,
        };
        a429b_word_fields_t fIas = {
            .label = AIRDATA_LABEL_IAS_KT,
            .sdi = 0u,
            .data = simIas,
            .ssm = A429B_SSM_NORMAL_OPERATION,
            .parity = false,
        };

        (void)A429B_PackWord(&fAlt, &altWord);
        (void)A429B_PackWord(&fIas, &iasWord);
        altWord = A429B_SetEvenParity(altWord);
        iasWord = A429B_SetEvenParity(iasWord);

        /* Use the domain scheduler (Milestone 4) for periodic transmit */
        (void)A429B_ScheduleWord(&bridge, 0u, altWord, 50u);  /* 20 Hz */
        (void)A429B_ScheduleWord(&bridge, 1u, iasWord, 50u);  /* 20 Hz */

        PRINTF("SensorEmulator: sending labels 203/204 at 20 Hz\r\n");
    }
    else
    {
        PRINTF("MissionComputer: receiving labels 203/204, sending STATUS label 210 at 10 Hz\r\n");
    }

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
        if (dt == 0u)
        {
            /* Background work can go here */
            (void)A429B_Poll(&bridge);
            continue;
        }

        /* Drive application and scheduler */
        AirData_OnTickMs(&s_air, dt);
        A429B_OnTickMs(&bridge, dt);

        /* Always poll RX parsing */
        (void)A429B_Poll(&bridge);

        /* Apply LED suggestion (hardware action done outside app for testability) */
        (void)DIO_Write(&led, s_air.activityLedOn);

        /* Periodic logging (non time-critical) */
        printTimer += dt;
        if (printTimer >= 1000u)
        {
            printTimer -= 1000u;
            airdata_snapshot_t snap;
            AirData_GetSnapshot(&s_air, &snap);
            Demo_PrintSnapshot(TICK_GetMs(&tick), &snap);
        }

        if (AIRDATA_NODE_ROLE == 0u)
        {
            /* Mission computer: send a status word back every 100ms (10 Hz) */
            statusTxTimer += dt;
            if (statusTxTimer >= 100u)
            {
                statusTxTimer -= 100u;
                uint32_t statusWord;
                if (AirData_BuildStatusWord(&s_air, &statusWord) == kStatus_Success)
                {
                    (void)A429B_SendWord(&bridge, statusWord, true);
                }
            }
        }
        else
        {
            /* Sensor emulator: slowly vary simulated values and refresh scheduled words */
            simUpdateTimer += dt;
            if (simUpdateTimer >= 500u)
            {
                simUpdateTimer -= 500u;

                /* Deterministic ramp */
                simAlt += 10u;
                simIas += 1u;
                if (simAlt > 1200u) simAlt = 1000u;
                if (simIas > 270u)  simIas = 250u;

                a429b_word_fields_t fAlt = {
                    .label = AIRDATA_LABEL_PRESSURE_ALT_FT,
                    .sdi = 0u,
                    .data = simAlt,
                    .ssm = A429B_SSM_NORMAL_OPERATION,
                    .parity = false,
                };
                a429b_word_fields_t fIas = {
                    .label = AIRDATA_LABEL_IAS_KT,
                    .sdi = 0u,
                    .data = simIas,
                    .ssm = A429B_SSM_NORMAL_OPERATION,
                    .parity = false,
                };

                (void)A429B_PackWord(&fAlt, &altWord);
                (void)A429B_PackWord(&fIas, &iasWord);
                altWord = A429B_SetEvenParity(altWord);
                iasWord = A429B_SetEvenParity(iasWord);

                /* Refresh scheduler entries (keeps period but updates data payload deterministically) */
                (void)A429B_ScheduleWord(&bridge, 0u, altWord, 50u);
                (void)A429B_ScheduleWord(&bridge, 1u, iasWord, 50u);
            }
        }
    }
}
