/******************************************************************************
 * File: air_data_app.h
 ******************************************************************************/
#ifndef AIR_DATA_APP_H_
#define AIR_DATA_APP_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"        /* status_t */
#include "arinc429_bridge.h"   /* a429b_word_fields_t, a429b_word_validity_t */

/* Versioning */
#define AIRDATA_VERSION_MAJOR (1u)
#define AIRDATA_VERSION_MINOR (0u)
#define AIRDATA_VERSION_PATCH (0u)

/* Labels tracked by this application */
#define AIRDATA_LABEL_PRESSURE_ALT_FT (203u)
#define AIRDATA_LABEL_IAS_KT          (204u)

/* Outgoing (demo) status label (application-defined) */
#define AIRDATA_LABEL_STATUS          (210u)

/* Application statistics */
typedef struct
{
    uint32_t validWordsTotal;
    uint32_t invalidWordsTotal;

    uint32_t altUpdates;
    uint32_t iasUpdates;

    uint32_t altStaleEvents;
    uint32_t iasStaleEvents;
} airdata_stats_t;

/* Application state snapshot (pure data, printable/loggable) */
typedef struct
{
    bool altValid;
    bool iasValid;

    uint32_t altitude_ft; /* valid iff altValid */
    uint32_t ias_kt;      /* valid iff iasValid */

    uint32_t lastAltAgeMs; /* how old the last alt update is (ms) */
    uint32_t lastIasAgeMs; /* how old the last ias update is (ms) */

    bool activityLedOn; /* application suggests LED state */

    airdata_stats_t stats;
} airdata_snapshot_t;

/* Application configuration */
typedef struct
{
    /* How long to pulse the activity LED after a valid update */
    uint32_t activityPulseMs; /* e.g., 50ms */

    /* Stale thresholds: if no fresh data within this time, mark invalid */
    uint32_t altStaleTimeoutMs; /* e.g., 500ms */
    uint32_t iasStaleTimeoutMs; /* e.g., 500ms */

    /* Application policy: which SSM values are accepted for state update */
    bool acceptFunctionalTest; /* if true, accept A429B_SSM_FUNCTIONAL_TEST as valid */
} airdata_config_t;

/* Application instance */
typedef struct
{
    airdata_config_t cfg;

    /* Last values */
    uint32_t altitude_ft;
    uint32_t ias_kt;

    bool altValid;
    bool iasValid;

    /* Ages (ms since last update); updated by AirData_OnTickMs() */
    uint32_t altAgeMs;
    uint32_t iasAgeMs;

    /* LED pulse state */
    uint32_t activityPulseRemainingMs;
    bool activityLedOn;

    airdata_stats_t stats;

    bool isInitialized;
} airdata_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize the application.
 *
 * @pre app != NULL
 * @pre cfg != NULL
 * @post app is ready and all values are reset to known defaults.
 */
status_t AirData_Init(airdata_t *app, const airdata_config_t *cfg);

/*
 * @brief Application word ingestion.
 *
 * This is the ONLY place where the app interprets labels and updates state.
 *
 * @param app Application instance
 * @param rawWord Raw 32-bit word (for traceability)
 * @param fields Decoded fields (label/sdi/data/ssm/parity)
 * @param validity Domain validity from bridge
 *
 * @note This function is designed to be unit-testable:
 *       no direct hardware, no prints, no delays.
 */
void AirData_OnWord(airdata_t *app,
                    uint32_t rawWord,
                    const a429b_word_fields_t *fields,
                    a429b_word_validity_t validity);

/*
 * @brief Time update (called from main loop with dt in ms).
 *
 * Responsibilities:
 * - Age tracking for altitude and airspeed
 * - Stale invalidation when timeout expires
 * - Activity LED pulse timing
 */
void AirData_OnTickMs(airdata_t *app, uint32_t dtMs);

/* @brief Get a snapshot of current application state for logging/telemetry. */
void AirData_GetSnapshot(const airdata_t *app, airdata_snapshot_t *out);

/*
 * @brief Build an application-defined "status" word.
 *
 * The purpose is to demonstrate application-to-domain interaction.
 * This word packs a few health bits + recent values.
 *
 * Encoding (example, deterministic):
 *   label = AIRDATA_LABEL_STATUS
 *   sdi   = 0
 *   ssm   = NORMAL
 *   data  bits:
 *     [0]  altValid
 *     [1]  iasValid
 *     [2]  activityLedOn
 *     [18:3] low 16 bits of altitude_ft (for demo)
 */
status_t AirData_BuildStatusWord(const airdata_t *app, uint32_t *outRawWord);

#ifdef __cplusplus
}
#endif

#endif /* AIR_DATA_APP_H_ */

