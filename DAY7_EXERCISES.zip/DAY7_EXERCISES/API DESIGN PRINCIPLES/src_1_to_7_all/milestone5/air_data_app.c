/******************************************************************************
 * File: air_data_app.c
 ******************************************************************************/
#include "air_data_app.h"

static bool AirData_IsSsmAccepted(const airdata_t *app, a429b_ssm_t ssm)
{
    if (ssm == A429B_SSM_NORMAL_OPERATION)
    {
        return true;
    }

    if (app->cfg.acceptFunctionalTest && (ssm == A429B_SSM_FUNCTIONAL_TEST))
    {
        return true;
    }

    return false;
}

static void AirData_PulseActivity(airdata_t *app)
{
    app->activityPulseRemainingMs = app->cfg.activityPulseMs;
    app->activityLedOn = (app->cfg.activityPulseMs != 0u);
}

status_t AirData_Init(airdata_t *app, const airdata_config_t *cfg)
{
    if ((app == NULL) || (cfg == NULL))
    {
        return kStatus_InvalidArgument;
    }

    /* Copy configuration */
    app->cfg = *cfg;

    /* Reset state */
    app->altitude_ft = 0u;
    app->ias_kt = 0u;
    app->altValid = false;
    app->iasValid = false;

    app->altAgeMs = 0u;
    app->iasAgeMs = 0u;

    app->activityPulseRemainingMs = 0u;
    app->activityLedOn = false;

    app->stats.validWordsTotal = 0u;
    app->stats.invalidWordsTotal = 0u;
    app->stats.altUpdates = 0u;
    app->stats.iasUpdates = 0u;
    app->stats.altStaleEvents = 0u;
    app->stats.iasStaleEvents = 0u;

    app->isInitialized = true;
    return kStatus_Success;
}

void AirData_OnWord(airdata_t *app,
                    uint32_t rawWord,
                    const a429b_word_fields_t *fields,
                    a429b_word_validity_t validity)
{
    (void)rawWord;

    if ((app == NULL) || (!app->isInitialized) || (fields == NULL))
    {
        return;
    }

    if (validity != A429B_WORD_VALID)
    {
        app->stats.invalidWordsTotal++;
        return;
    }

    /* Domain says "valid". Apply application-level SSM acceptance policy. */
    if (!AirData_IsSsmAccepted(app, fields->ssm))
    {
        app->stats.invalidWordsTotal++;
        return;
    }

    app->stats.validWordsTotal++;

    /* Update application state based on label */
    if (fields->label == AIRDATA_LABEL_PRESSURE_ALT_FT)
    {
        app->altitude_ft = fields->data; /* 1 LSB = 1 ft for this lab */
        app->altValid = true;
        app->altAgeMs = 0u;
        app->stats.altUpdates++;
        AirData_PulseActivity(app);
    }
    else if (fields->label == AIRDATA_LABEL_IAS_KT)
    {
        app->ias_kt = fields->data; /* 1 LSB = 1 knot for this lab */
        app->iasValid = true;
        app->iasAgeMs = 0u;
        app->stats.iasUpdates++;
        AirData_PulseActivity(app);
    }
    else
    {
        /* Not a label we care about; ignore (still counted as validWordsTotal). */
    }
}

void AirData_OnTickMs(airdata_t *app, uint32_t dtMs)
{
    if ((app == NULL) || (!app->isInitialized) || (dtMs == 0u))
    {
        return;
    }

    /* Age tracking (saturate at UINT32_MAX to avoid wrap surprises) */
    if (app->altAgeMs <= (UINT32_MAX - dtMs))
    {
        app->altAgeMs += dtMs;
    }
    else
    {
        app->altAgeMs = UINT32_MAX;
    }

    if (app->iasAgeMs <= (UINT32_MAX - dtMs))
    {
        app->iasAgeMs += dtMs;
    }
    else
    {
        app->iasAgeMs = UINT32_MAX;
    }

    /* Stale invalidation */
    if (app->altValid && (app->cfg.altStaleTimeoutMs != 0u) && (app->altAgeMs > app->cfg.altStaleTimeoutMs))
    {
        app->altValid = false;
        app->stats.altStaleEvents++;
    }

    if (app->iasValid && (app->cfg.iasStaleTimeoutMs != 0u) && (app->iasAgeMs > app->cfg.iasStaleTimeoutMs))
    {
        app->iasValid = false;
        app->stats.iasStaleEvents++;
    }

    /* Activity LED pulse management */
    if (app->activityPulseRemainingMs > dtMs)
    {
        app->activityPulseRemainingMs -= dtMs;
        app->activityLedOn = true;
    }
    else
    {
        app->activityPulseRemainingMs = 0u;
        app->activityLedOn = false;
    }
}

void AirData_GetSnapshot(const airdata_t *app, airdata_snapshot_t *out)
{
    if ((app == NULL) || (out == NULL) || (!app->isInitialized))
    {
        return;
    }

    out->altValid = app->altValid;
    out->iasValid = app->iasValid;
    out->altitude_ft = app->altitude_ft;
    out->ias_kt = app->ias_kt;
    out->lastAltAgeMs = app->altAgeMs;
    out->lastIasAgeMs = app->iasAgeMs;
    out->activityLedOn = app->activityLedOn;
    out->stats = app->stats;
}

status_t AirData_BuildStatusWord(const airdata_t *app, uint32_t *outRawWord)
{
    if ((app == NULL) || (outRawWord == NULL) || (!app->isInitialized))
    {
        return kStatus_InvalidArgument;
    }

    a429b_word_fields_t f;
    f.label = AIRDATA_LABEL_STATUS;
    f.sdi = 0u;
    f.ssm = A429B_SSM_NORMAL_OPERATION;

    /* Pack a few bits deterministically */
    uint32_t data = 0u;
    data |= (app->altValid ? 1u : 0u) << 0;
    data |= (app->iasValid ? 1u : 0u) << 1;
    data |= (app->activityLedOn ? 1u : 0u) << 2;

    /* Low 16 bits of altitude in bits [18:3] (demo only) */
    data |= ((app->altitude_ft & 0xFFFFu) << 3);
    f.data = (data & 0x7FFFFu); /* 19-bit constraint */

    f.parity = false; /* will be fixed by A429B_SendWord(...ensureEvenParity=true) */

    return A429B_PackWord(&f, outRawWord);
}

