/******************************************************************************
 * File: milestone5_demo_main.c
 *
 * This demo is designed to run on two EVKB boards:
 * - One board configured as SENSOR node (transmits labels 203/204 periodically)
 * - One board configured as MISSION COMPUTER node (receives and updates AirData)
 *
 * Select role by setting AIRDATA_NODE_ROLE:
 *   0 = Mission Computer (receiver + status response)
 *   1 = Sensor Emulator (periodic transmitter)
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, BOARD_InitHardware() */
#include "fsl_debug_console.h"
#include "fsl_clock.h"          /* CLOCK_GetFreq */

#include "dio.h"                /* Milestone 1 */
#include "tick_1ms.h"           /* Milestone 2 */
#include "uart_framed_service.h"/* Milestone 3 */
#include "arinc429_bridge.h"    /* Milestone 4 */
#include "air_data_app.h"       /* Milestone 5 */

#ifndef AIRDATA_NODE_ROLE
#define AIRDATA_NODE_ROLE (0u)
#endif

#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

static airdata_t s_air;

/* Bridge callback: adapter into application */
static void Demo_BridgeOnWord(uint32_t rawWord,
                             const a429b_word_fields_t *fields,
                             a429b_word_validity_t validity,
                             void *userData)
{
    (void)userData;
    AirData_OnWord(&s_air, rawWord, fields, validity);
}

static void Demo_PrintSnapshot(uint32_t nowMs, const airdata_snapshot_t *snap)
{
    PRINTF("[%lu ms] ALT=%s %lu ft (age=%lu ms), IAS=%s %lu kt (age=%lu ms), led=%u\r\n",
           (unsigned long)nowMs,
           snap->altValid ? "OK" : "--",
           (unsigned long)snap->altitude_ft,
           (unsigned long)snap->lastAltAgeMs,
           snap->iasValid ? "OK" : "--",
           (unsigned long)snap->ias_kt,
           (unsigned long)snap->lastIasAgeMs,
           snap->activityLedOn ? 1u : 0u);

    PRINTF("  Stats: valid=%lu invalid=%lu altUp=%lu iasUp=%lu altStale=%lu iasStale=%lu\r\n",
           (unsigned long)snap->stats.validWordsTotal,
           (unsigned long)snap->stats.invalidWordsTotal,
           (unsigned long)snap->stats.altUpdates,
           (unsigned long)snap->stats.iasUpdates,
           (unsigned long)snap->stats.altStaleEvents,
           (unsigned long)snap->stats.iasStaleEvents);
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 5: Air Data Application demo\r\n");
    PRINTF("Role: %s\r\n", (AIRDATA_NODE_ROLE == 0u) ? "MissionComputer" : "SensorEmulator");

    /* ---- LED via DIO (Milestone 1) ---- */
    dio_handle_t led = {0};
    const dio_config_t ledCfg = {
        .base = BOARD_USER_LED_GPIO,
        .pin = BOARD_USER_LED_GPIO_PIN,
        .activeLow = true,    /* EVKB USER LED is active-low */
        .initialOn = false,
    };
    if (DIO_Init(&led, &ledCfg) != kStatus_Success)
    {
        PRINTF("LED DIO_Init failed\r\n");
        while (1) {}
    }

    /* ---- 1ms tick (Milestone 2) ---- */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };
    if (TICK_Init(&tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("TICK_Init failed\r\n");
        while (1) {}
    }

    /* ---- Application init (Milestone 5) ---- */
    const airdata_config_t airCfg = {
        .activityPulseMs = 50u,
        .altStaleTimeoutMs = 500u,
        .iasStaleTimeoutMs = 500u,
        .acceptFunctionalTest = false,
    };
    if (AirData_Init(&s_air, &airCfg) != kStatus_Success)
    {
        PRINTF("AirData_Init failed\r\n");
        while (1) {}
    }

    /* ---- UFS + A429B bridge (Milestone 3 + 4) ---- */
    ufs_t ufs = {0};
    a429b_t bridge = {0};

    /* Important: UFS RX callback is the bridge hook (runs from UFS_Poll()) */
    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 128u,
        .rxCb = A429B_UfsRxHook,
        .rxCbUserData = &bridge,
    };
    if (UFS_Init(&ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("UFS_Init failed\r\n");
        while (1) {}
    }

    if (A429B_Init(&bridge, &ufs, Demo_BridgeOnWord, NULL) != kStatus_Success)
    {
        PRINTF("A429B_Init failed\r\n");
        while (1) {}
    }

    PRINTF("Wire two EVKB boards: TX<->RX, GND<->GND. Flash this demo on both.\r\n");

    /* ---- Mission/sensor demo variables ---- */
    uint32_t last = TICK_GetMs(&tick);
    uint32_t printTimer = 0u;
    uint32_t statusTxTimer = 0u;

    /* Sensor-side simulated values */
    uint32_t simAlt = 1000u;
    uint32_t simIas = 250u;
    uint32_t simUpdateTimer = 0u;

    /* Pre-build initial words for sensor role */
    uint32_t altWord = 0u;
    uint32_t iasWord = 0u;

    if (AIRDATA_NODE_ROLE == 1u)
    {
        a429b_word_fields_t fAlt = {
            .label = AIRDATA_LABEL_PRESSURE_ALT_FT,
            .sdi = 0u,
            .data = simAlt,
            .ssm = A429B_SSM_NORMAL_OPERATION,
            .parity = false,
        };
        a429b_word_fields_t fIas = {
            .label = AIRDATA_LABEL_IAS_KT,
            .sdi = 0u,
            .data = simIas,
            .ssm = A429B_SSM_NORMAL_OPERATION,
            .parity = false,
        };

        (void)A429B_PackWord(&fAlt, &altWord);
        (void)A429B_PackWord(&fIas, &iasWord);
        altWord = A429B_SetEvenParity(altWord);
        iasWord = A429B_SetEvenParity(iasWord);

        /* Use the domain scheduler (Milestone 4) for periodic transmit */
        (void)A429B_ScheduleWord(&bridge, 0u, altWord, 50u);  /* 20 Hz */
        (void)A429B_ScheduleWord(&bridge, 1u, iasWord, 50u);  /* 20 Hz */

        PRINTF("SensorEmulator: sending labels 203/204 at 20 Hz\r\n");
    }
    else
    {
        PRINTF("MissionComputer: receiving labels 203/204, sending STATUS label 210 at 10 Hz\r\n");
    }

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
        if (dt == 0u)
        {
            /* Background work can go here */
            (void)A429B_Poll(&bridge);
            continue;
        }

        /* Drive application and scheduler */
        AirData_OnTickMs(&s_air, dt);
        A429B_OnTickMs(&bridge, dt);

        /* Always poll RX parsing */
        (void)A429B_Poll(&bridge);

        /* Apply LED suggestion (hardware action done outside app for testability) */
        (void)DIO_Write(&led, s_air.activityLedOn);

        /* Periodic logging (non time-critical) */
        printTimer += dt;
        if (printTimer >= 1000u)
        {
            printTimer -= 1000u;
            airdata_snapshot_t snap;
            AirData_GetSnapshot(&s_air, &snap);
            Demo_PrintSnapshot(TICK_GetMs(&tick), &snap);
        }

        if (AIRDATA_NODE_ROLE == 0u)
        {
            /* Mission computer: send a status word back every 100ms (10 Hz) */
            statusTxTimer += dt;
            if (statusTxTimer >= 100u)
            {
                statusTxTimer -= 100u;
                uint32_t statusWord;
                if (AirData_BuildStatusWord(&s_air, &statusWord) == kStatus_Success)
                {
                    (void)A429B_SendWord(&bridge, statusWord, true);
                }
            }
        }
        else
        {
            /* Sensor emulator: slowly vary simulated values and refresh scheduled words */
            simUpdateTimer += dt;
            if (simUpdateTimer >= 500u)
            {
                simUpdateTimer -= 500u;

                /* Deterministic ramp */
                simAlt += 10u;
                simIas += 1u;
                if (simAlt > 1200u) simAlt = 1000u;
                if (simIas > 270u)  simIas = 250u;

                a429b_word_fields_t fAlt = {
                    .label = AIRDATA_LABEL_PRESSURE_ALT_FT,
                    .sdi = 0u,
                    .data = simAlt,
                    .ssm = A429B_SSM_NORMAL_OPERATION,
                    .parity = false,
                };
                a429b_word_fields_t fIas = {
                    .label = AIRDATA_LABEL_IAS_KT,
                    .sdi = 0u,
                    .data = simIas,
                    .ssm = A429B_SSM_NORMAL_OPERATION,
                    .parity = false,
                };

                (void)A429B_PackWord(&fAlt, &altWord);
                (void)A429B_PackWord(&fIas, &iasWord);
                altWord = A429B_SetEvenParity(altWord);
                iasWord = A429B_SetEvenParity(iasWord);

                /* Refresh scheduler entries (keeps period but updates data payload deterministically) */
                (void)A429B_ScheduleWord(&bridge, 0u, altWord, 50u);
                (void)A429B_ScheduleWord(&bridge, 1u, iasWord, 50u);
            }
        }
    }
}
