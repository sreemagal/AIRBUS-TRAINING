/******************************************************************************
 * File: uart_framed_service.c
 ******************************************************************************/
#include "uart_framed_service.h"

/*
 * Forward declaration for the LPUART callback.
 * This is invoked from ISR context by the driver.
 */
static void UFS_LpuartCallback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData);

/* ---- Small ring-buffer helpers (SPSC: ISR producer, main consumer) ---- */

static inline uint16_t UFS_RingNext(uint16_t idx)
{
    /* Modulo ring size (must fit into uint16_t). */
    return (uint16_t)((idx + 1u) % (uint16_t)UFS_RX_RING_SIZE);
}

static bool UFS_RingPushFromIsr(ufs_t *svc, uint8_t b)
{
    /* Producer (ISR) updates head only. */
    const uint16_t head = svc->rxHead;
    const uint16_t next = UFS_RingNext(head);

    if (next == svc->rxTail)
    {
        /* Full: drop newest (documented policy for this milestone). */
        svc->stats.rxRingOverflows++;
        return false;
    }

    svc->rxRing[head] = b;
    svc->rxHead = next;

    svc->stats.rxBytesEnqueued++;
    return true;
}

static bool UFS_RingPopFromMain(ufs_t *svc, uint8_t *outByte)
{
    /* Consumer (main) updates tail only. */
    const uint16_t tail = svc->rxTail;
    if (tail == svc->rxHead)
    {
        return false; /* empty */
    }

    *outByte = svc->rxRing[tail];
    svc->rxTail = UFS_RingNext(tail);
    return true;
}

/* ---- Checksum helpers ---- */

static inline uint8_t UFS_ChecksumTwoComplement(uint8_t len, const uint8_t *payload)
{
    uint32_t sum = (uint32_t)len;
    for (uint32_t i = 0; i < len; i++)
    {
        sum += payload[i];
    }
    /* two's complement: (-sum) mod 256 */
    return (uint8_t)(0u - (uint8_t)sum);
}

static inline bool UFS_ChecksumIsValid(uint8_t len, const uint8_t *payload, uint8_t checksum)
{
    uint32_t sum = (uint32_t)len + checksum;
    for (uint32_t i = 0; i < len; i++)
    {
        sum += payload[i];
    }
    return (((uint8_t)sum) == 0u);
}

/* ---- Parser ---- */

static void UFS_ParserReset(ufs_t *svc)
{
    svc->parserState = UFS_PARSER_WAIT_START;
    svc->curLen = 0u;
    svc->curIdx = 0u;
    svc->checksumAccum = 0u;
}

static void UFS_ParserFeedByte(ufs_t *svc, uint8_t b, uint32_t *framesDispatched)
{
    switch (svc->parserState)
    {
        case UFS_PARSER_WAIT_START:
        {
            if (b == UFS_FRAME_START_BYTE)
            {
                svc->parserState = UFS_PARSER_WAIT_LEN;
                svc->checksumAccum = 0u;
            }
            else
            {
                /* ignore until start; count as resync attempt for observability */
                svc->stats.rxFramingResyncs++;
            }
            break;
        }

        case UFS_PARSER_WAIT_LEN:
        {
            svc->curLen = b;
            svc->curIdx = 0u;
            svc->checksumAccum = b; /* accum starts with LEN */

            if (svc->curLen > (uint8_t)UFS_MAX_PAYLOAD)
            {
                /* Length out of supported bound -> reject and resync */
                svc->stats.rxLengthErrors++;
                UFS_ParserReset(svc);
            }
            else
            {
                svc->parserState = (svc->curLen == 0u) ? UFS_PARSER_WAIT_CHECKSUM : UFS_PARSER_WAIT_PAYLOAD;
            }
            break;
        }

        case UFS_PARSER_WAIT_PAYLOAD:
        {
            /* curLen is already validated <= UFS_MAX_PAYLOAD */
            svc->curPayload[svc->curIdx++] = b;
            svc->checksumAccum = (uint8_t)(svc->checksumAccum + b);

            if (svc->curIdx >= svc->curLen)
            {
                svc->parserState = UFS_PARSER_WAIT_CHECKSUM;
            }
            break;
        }

        case UFS_PARSER_WAIT_CHECKSUM:
        {
            const uint8_t rxChecksum = b;
            const bool ok = UFS_ChecksumIsValid(svc->curLen, svc->curPayload, rxChecksum);

            if (ok)
            {
                svc->stats.rxFramesOk++;

                /* Dispatch callback from MAIN CONTEXT only (we are in Poll()) */
                if (svc->rxCb != NULL)
                {
                    svc->rxCb(svc->curPayload, svc->curLen, svc->rxCbUserData);
                }

                (*framesDispatched)++;
            }
            else
            {
                svc->stats.rxChecksumErrors++;
            }

            /* Always reset after checksum */
            UFS_ParserReset(svc);
            break;
        }

        default:
            UFS_ParserReset(svc);
            break;
    }
}

/* ---- Public API ---- */

status_t UFS_Init(ufs_t *svc, const ufs_config_t *cfg)
{
    if ((svc == NULL) || (cfg == NULL) || (cfg->base == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if ((cfg->srcClockHz == 0u) || (cfg->baudRate == 0u))
    {
        return kStatus_InvalidArgument;
    }

    /* Default maxBytesPerPoll if caller passes 0. */
    const uint32_t maxBytes = (cfg->maxBytesPerPoll == 0u) ? 64u : cfg->maxBytesPerPoll;

    /* Enforce idempotence for the same instance. */
    if (svc->isInitialized)
    {
        const bool same = (svc->base == cfg->base);
        return same ? kStatus_Success : kStatus_Fail;
    }

    /* Initialize fields */
    svc->base = cfg->base;
    svc->rxHead = 0u;
    svc->rxTail = 0u;
    svc->txBusy = false;

    svc->maxBytesPerPoll = maxBytes;
    svc->rxCb = cfg->rxCb;
    svc->rxCbUserData = cfg->rxCbUserData;

    UFS_ResetStats(svc);
    UFS_ParserReset(svc);

    /* Optionally initialize the peripheral. Pin mux and clocks are assumed done by BOARD_InitHardware(). */
    if (cfg->initPeripheral)
    {
        lpuart_config_t lpuartCfg;
        LPUART_GetDefaultConfig(&lpuartCfg);
        lpuartCfg.baudRate_Bps = cfg->baudRate;
        lpuartCfg.enableTx = true;
        lpuartCfg.enableRx = true;

        status_t st = LPUART_Init(svc->base, &lpuartCfg, cfg->srcClockHz);
        if (st != kStatus_Success)
        {
            return st;
        }
    }

    /* Create transfer handle and register ISR callback */
    LPUART_TransferCreateHandle(svc->base, &svc->drvHandle, UFS_LpuartCallback, svc);

    /* Arm continuous 1-byte receive */
    svc->isrRxXfer.data = &svc->isrRxByte;
    svc->isrRxXfer.dataSize = 1u;

    (void)LPUART_TransferReceiveNonBlocking(svc->base, &svc->drvHandle, &svc->isrRxXfer, NULL);

    svc->isInitialized = true;
    return kStatus_Success;
}

status_t UFS_SendFrame(ufs_t *svc, const uint8_t *payload, uint8_t len)
{
    if (svc == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!svc->isInitialized)
    {
        return kStatus_Fail;
    }

    if (len > (uint8_t)UFS_MAX_PAYLOAD)
    {
        return kStatus_OutOfRange;
    }

    if ((len > 0u) && (payload == NULL))
    {
        return kStatus_InvalidArgument;
    }

    /* Back-pressure: one in-flight frame only */
    if (svc->txBusy)
    {
        return kStatus_LPUART_TxBusy;
    }

    /* Build frame into internal TX buffer */
    const uint8_t start = UFS_FRAME_START_BYTE;
    const uint8_t checksum = UFS_ChecksumTwoComplement(len, payload);

    uint32_t idx = 0u;
    svc->txFrameBuf[idx++] = start;
    svc->txFrameBuf[idx++] = len;
    for (uint32_t i = 0; i < len; i++)
    {
        svc->txFrameBuf[idx++] = payload[i];
    }
    svc->txFrameBuf[idx++] = checksum;

    svc->txXfer.data = svc->txFrameBuf;
    svc->txXfer.dataSize = idx;

    svc->txBusy = true;
    svc->stats.txFramesRequested++;

    /* Kick TX (non-blocking). Driver will invoke callback with kStatus_LPUART_TxIdle when done. */
    const status_t st = LPUART_TransferSendNonBlocking(svc->base, &svc->drvHandle, &svc->txXfer);
    if (st != kStatus_Success)
    {
        /* If driver rejects the send, clear busy and report status. */
        svc->txBusy = false;
        svc->stats.lastTxDriverStatus = st;
        return st;
    }

    return kStatus_Success;
}

uint32_t UFS_Poll(ufs_t *svc)
{
    if ((svc == NULL) || (!svc->isInitialized))
    {
        return 0u;
    }

    uint32_t framesDispatched = 0u;
    uint32_t bytesBudget = svc->maxBytesPerPoll;

    while (bytesBudget-- > 0u)
    {
        uint8_t b;
        if (!UFS_RingPopFromMain(svc, &b))
        {
            break; /* no more RX bytes */
        }

        UFS_ParserFeedByte(svc, b, &framesDispatched);
    }

    return framesDispatched;
}

void UFS_GetStats(const ufs_t *svc, ufs_stats_t *outStats)
{
    if ((svc == NULL) || (outStats == NULL))
    {
        return;
    }

    /* Snapshot copy; races are acceptable for diagnostics. */
    *outStats = svc->stats;
}

void UFS_ResetStats(ufs_t *svc)
{
    if (svc == NULL)
    {
        return;
    }

    /* Reset counters deterministically */
    svc->stats.rxBytesEnqueued = 0u;
    svc->stats.rxRingOverflows = 0u;
    svc->stats.rxFramesOk = 0u;
    svc->stats.rxChecksumErrors = 0u;
    svc->stats.rxLengthErrors = 0u;
    svc->stats.rxFramingResyncs = 0u;
    svc->stats.txFramesRequested = 0u;
    svc->stats.txFramesDone = 0u;
    svc->stats.lastRxDriverStatus = kStatus_Success;
    svc->stats.lastTxDriverStatus = kStatus_Success;
}

bool UFS_IsTxBusy(const ufs_t *svc)
{
    return (svc != NULL) ? svc->txBusy : false;
}

/* ---- LPUART ISR callback ---- */

static void UFS_LpuartCallback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    (void)base;
    (void)handle;

    ufs_t *svc = (ufs_t *)userData;
    if ((svc == NULL) || (!svc->isInitialized))
    {
        return;
    }

    /*
     * Driver sends status codes such as:
     *   kStatus_LPUART_RxIdle - our 1-byte RX transfer completed
     *   kStatus_LPUART_TxIdle - our TX transfer completed
     * and potentially error statuses.
     */

    if (status == kStatus_LPUART_RxIdle)
    {
        /* Enqueue the received byte into our RX ring (drop if overflow). */
        (void)UFS_RingPushFromIsr(svc, svc->isrRxByte);

        /* Re-arm next 1-byte receive immediately */
        (void)LPUART_TransferReceiveNonBlocking(svc->base, &svc->drvHandle, &svc->isrRxXfer, NULL);
    }
    else if (status == kStatus_LPUART_TxIdle)
    {
        svc->txBusy = false;
        svc->stats.txFramesDone++;
    }
    else
    {
        /* Record unexpected/driver error status for diagnostics (do not PRINTF from ISR). */
        if (status != kStatus_Success)
        {
            /* Heuristic: treat non-idle statuses as potentially meaningful. */
            svc->stats.lastRxDriverStatus = status;
            svc->stats.lastTxDriverStatus = status;
        }

        /* Attempt to keep RX alive even if errors occur. */
        (void)LPUART_TransferReceiveNonBlocking(svc->base, &svc->drvHandle, &svc->isrRxXfer, NULL);
    }
}

