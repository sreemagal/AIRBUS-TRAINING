/******************************************************************************
 * File: uart_framed_service.h
 ******************************************************************************/
#ifndef UART_FRAMED_SERVICE_H_
#define UART_FRAMED_SERVICE_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "fsl_common.h"  /* status_t */
#include "fsl_lpuart.h"  /* LPUART transfer APIs */

/* Versioning */
#define UFS_VERSION_MAJOR (1u)
#define UFS_VERSION_MINOR (0u)
#define UFS_VERSION_PATCH (0u)

/* Constants for framing */
#define UFS_FRAME_START_BYTE (0x55u)

/*
 * Configure budgets explicitly (avionics mindset: bounded memory and time).
 * These can be overridden per project.
 */
#ifndef UFS_MAX_PAYLOAD
#define UFS_MAX_PAYLOAD (64u) /* max LEN supported by this service */
#endif

#ifndef UFS_RX_RING_SIZE
#define UFS_RX_RING_SIZE (256u) /* must be > (UFS_MAX_PAYLOAD + 3) to tolerate bursts */
#endif

/* Diagnostics counters: deterministic, monotonic, resettable. */
typedef struct
{
    uint32_t rxBytesEnqueued;   /* bytes accepted into RX ring from ISR */
    uint32_t rxRingOverflows;   /* bytes dropped because RX ring was full */
    uint32_t rxFramesOk;        /* valid frames delivered to application */
    uint32_t rxChecksumErrors;  /* frames rejected due to checksum mismatch */
    uint32_t rxLengthErrors;    /* frames rejected due to LEN > UFS_MAX_PAYLOAD */
    uint32_t rxFramingResyncs;  /* times parser re-synchronized to START byte */

    uint32_t txFramesRequested; /* send requests accepted (queued to HW) */
    uint32_t txFramesDone;      /* TX completion events (from ISR) */

    status_t lastRxDriverStatus; /* last non-idle RX status from LPUART ISR callback */
    status_t lastTxDriverStatus; /* last non-idle TX status from LPUART ISR callback */
} ufs_stats_t;

/*
 * RX callback type
 * Called ONLY from UFS_Poll() in main context.
 *
 * @param payload Pointer to a UFS-owned buffer valid only during the callback.
 * @param len     Payload length in bytes (0..UFS_MAX_PAYLOAD).
 * @param userData User cookie.
 */
typedef void (*ufs_rx_frame_cb_t)(const uint8_t *payload, uint8_t len, void *userData);

/* Service configuration */
typedef struct
{
    LPUART_Type *base;      /* e.g., DEMO_LPUART */
    uint32_t srcClockHz;    /* LPUART source clock */
    uint32_t baudRate;      /* e.g., 115200 */

    /* Optional: if you want the service to initialize the peripheral.
     * If false, caller must have already called LPUART_Init() with matching settings.
     */
    bool initPeripheral;

    /* Parser work bound per poll: limits how many RX bytes are consumed each call.
     * This keeps the Poll() time bounded for deterministic applications.
     */
    uint32_t maxBytesPerPoll;

    /* RX frame callback delivered from Poll() */
    ufs_rx_frame_cb_t rxCb;
    void *rxCbUserData;
} ufs_config_t;

/* Service instance */
typedef struct
{
    /* Hardware */
    LPUART_Type *base;
    lpuart_handle_t drvHandle;

    /* Single-byte RX transfer reused continuously */
    uint8_t isrRxByte;
    lpuart_transfer_t isrRxXfer;

    /* TX buffer for an entire framed message (START + LEN + PAYLOAD + CHECKSUM) */
    uint8_t txFrameBuf[UFS_MAX_PAYLOAD + 3u];
    lpuart_transfer_t txXfer;
    volatile bool txBusy;

    /* RX ring buffer (SPSC: ISR producer, main consumer) */
    uint8_t rxRing[UFS_RX_RING_SIZE];
    volatile uint16_t rxHead; /* written by ISR */
    volatile uint16_t rxTail; /* written by main */

    /* Frame parser state (main context only) */
    enum
    {
        UFS_PARSER_WAIT_START = 0,
        UFS_PARSER_WAIT_LEN,
        UFS_PARSER_WAIT_PAYLOAD,
        UFS_PARSER_WAIT_CHECKSUM
    } parserState;

    uint8_t curLen;
    uint8_t curIdx;
    uint8_t curPayload[UFS_MAX_PAYLOAD];
    uint8_t checksumAccum; /* accumulates LEN + payload sum */

    /* Configuration */
    uint32_t maxBytesPerPoll;
    ufs_rx_frame_cb_t rxCb;
    void *rxCbUserData;

    /* Diagnostics */
    ufs_stats_t stats;

    bool isInitialized;
} ufs_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize framed UART service.
 *
 * @pre svc != NULL
 * @pre cfg != NULL
 * @pre cfg->base != NULL
 * @pre cfg->srcClockHz != 0
 * @pre cfg->baudRate != 0
 * @pre Pin mux and clocks already configured by BOARD_InitHardware().
 *
 * @post Service is ready, RX is armed for continuous receive.
 *
 * Idempotence:
 * - Calling again with the same base and baudRate returns kStatus_Success.
 * - Calling with different settings on an initialized instance returns kStatus_Fail.
 */
status_t UFS_Init(ufs_t *svc, const ufs_config_t *cfg);

/*
 * @brief Non-blocking send of a payload as a framed message.
 *
 * @param svc Service instance.
 * @param payload Payload bytes (may be NULL if len == 0).
 * @param len Payload length (0..UFS_MAX_PAYLOAD).
 *
 * @retval kStatus_Success        Frame accepted and queued to the UART driver.
 * @retval kStatus_LPUART_TxBusy  Service is currently transmitting a previous frame.
 * @retval kStatus_InvalidArgument Bad pointer/length.
 *
 * Ownership/lifetime:
 * - Payload is copied into an internal buffer immediately.
 * - Caller may reuse/modify payload after UFS_SendFrame returns.
 */
status_t UFS_SendFrame(ufs_t *svc, const uint8_t *payload, uint8_t len);

/*
 * @brief Poll function: drains RX bytes (bounded), parses frames, dispatches callbacks.
 *
 * @param svc Service instance.
 *
 * @return Number of valid frames dispatched to the rx callback during this poll.
 *
 * Determinism:
 * - Work is bounded by cfg->maxBytesPerPoll.
 * - No dynamic allocation.
 */
uint32_t UFS_Poll(ufs_t *svc);

/* @brief Get a snapshot of diagnostic counters. */
void UFS_GetStats(const ufs_t *svc, ufs_stats_t *outStats);

/* @brief Reset diagnostic counters (service remains running). */
void UFS_ResetStats(ufs_t *svc);

/* @brief Returns whether TX is currently busy. */
bool UFS_IsTxBusy(const ufs_t *svc);

#ifdef __cplusplus
}
#endif

#endif /* UART_FRAMED_SERVICE_H_ */

