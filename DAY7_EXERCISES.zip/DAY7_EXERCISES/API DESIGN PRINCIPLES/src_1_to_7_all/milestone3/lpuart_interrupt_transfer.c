/******************************************************************************
 * File: lpuart_interrupt_transfer.c  (replace example main with this demo)
 ******************************************************************************/
#include "board.h"
#include "app.h"              /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, etc (from imported example) */
#include "fsl_debug_console.h"
#include "fsl_clock.h"        /* CLOCK_GetFreq */

#include "uart_framed_service.h"

/* Simple RX callback: prints received frame as hex, then echoes it back. */
static void Demo_OnFrame(const uint8_t *payload, uint8_t len, void *userData)
{
    (void)userData;

    PRINTF("RX frame len=%u payload=", len);
    for (uint32_t i = 0; i < len; i++)
    {
        PRINTF("%02X ", payload[i]);
    }
    PRINTF("\r\n");
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 3: Framed UART Service (UFS) demo\r\n");
    PRINTF("UFS version %u.%u.%u\r\n", UFS_VERSION_MAJOR, UFS_VERSION_MINOR, UFS_VERSION_PATCH);
    PRINTF("Frame: 0x55 | LEN | PAYLOAD | CHECKSUM(two's complement)\r\n");

    ufs_t svc = {0};
    const ufs_config_t cfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 128u,
        .rxCb = Demo_OnFrame,
        .rxCbUserData = NULL,
    };

    const status_t st = UFS_Init(&svc, &cfg);
    if (st != kStatus_Success)
    {
        PRINTF("UFS_Init failed: %ld\r\n", (long)st);
        while (1) { }
    }

    /* Transmit an initial frame */
    const uint8_t hello[] = { 'H','E','L','L','O' };
    (void)UFS_SendFrame(&svc, hello, (uint8_t)sizeof(hello));

    /* Main loop: poll parser + occasionally print stats */
    uint32_t lastPrint = 0u;
    while (1)
    {
        (void)UFS_Poll(&svc);

        /* Lightweight periodic stats (uses a crude loop counter; Milestone 2 tick is better) */
        lastPrint++;
        if (lastPrint >= 2000000u)
        {
            lastPrint = 0u;
            ufs_stats_t s;
            UFS_GetStats(&svc, &s);
            PRINTF("Stats: rxOk=%lu csumErr=%lu lenErr=%lu ovf=%lu txReq=%lu txDone=%lu\r\n",
                   (unsigned long)s.rxFramesOk,
                   (unsigned long)s.rxChecksumErrors,
                   (unsigned long)s.rxLengthErrors,
                   (unsigned long)s.rxRingOverflows,
                   (unsigned long)s.txFramesRequested,
                   (unsigned long)s.txFramesDone);
        }

        /*
         * In your multi-board setup:
         * - Connect TX/RX between two EVKB boards.
         * - Flash this demo on both.
         * - Each board will print received frames and send HELLO once.
         */
    }
}
