/******************************************************************************
 * File: m6_test_protocol.h
 ******************************************************************************/
#ifndef M6_TEST_PROTOCOL_H_
#define M6_TEST_PROTOCOL_H_

#include <stdbool.h>
#include <stdint.h>

/* Test protocol message types carried inside UFS payload[0] */
#define M6_MSG_PING        (0xF0u)
#define M6_MSG_PONG        (0xF1u)
#define M6_MSG_PAUSE_POLL  (0xF2u)
#define M6_MSG_PAUSE_ACK   (0xF3u)
#define M6_MSG_STATS_REQ   (0xF4u)
#define M6_MSG_STATS_RSP   (0xF5u)
#define M6_MSG_BURST       (0xF6u) /* intentionally spammed */
#define M6_MSG_RESET_STATS (0xF7u)
#define M6_MSG_RESET_ACK   (0xF8u)

/* Payload lengths (without UFS framing) */
#define M6_LEN_PING        (3u)  /* type + seq16 */
#define M6_LEN_PONG        (3u)
#define M6_LEN_PAUSE_POLL  (5u)  /* type + seq16 + pause_ms16 */
#define M6_LEN_PAUSE_ACK   (3u)
#define M6_LEN_STATS_REQ   (3u)
#define M6_LEN_RESET_REQ   (3u)
#define M6_LEN_RESET_ACK   (3u)

/* Helper: little-endian packing */
static inline void M6_PutU16LE(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
}

static inline uint16_t M6_GetU16LE(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static inline void M6_PutU32LE(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
    p[2] = (uint8_t)((v >> 16) & 0xFFu);
    p[3] = (uint8_t)((v >> 24) & 0xFFu);
}

static inline uint32_t M6_GetU32LE(const uint8_t *p)
{
    return ((uint32_t)p[0]) |
           ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

#endif /* M6_TEST_PROTOCOL_H_ */

