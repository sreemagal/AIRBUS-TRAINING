/******************************************************************************
 * File: m6_dut.h
 ******************************************************************************/
#ifndef M6_DUT_H_
#define M6_DUT_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"
#include "tick_1ms.h"
#include "jitter_monitor.h"

/* DUT command handler / reply queue */
typedef struct
{
    ufs_t *ufs;
    const tick_handle_t *tick;

    /* modules for stats */
    const a429b_t *bridge;
    const airdata_t *air;
    const jitter_mon_t *jitter;

    /* pause behavior */
    uint32_t pauseRemainingMs;

    /* one pending reply (sent from main when TX available) */
    bool replyPending;
    uint8_t replyBuf[64];
    uint8_t replyLen;
} m6_dut_t;

void M6_DUT_Init(m6_dut_t *dut,
                 ufs_t *ufs,
                 const tick_handle_t *tick,
                 const a429b_t *bridge,
                 const airdata_t *air,
                 const jitter_mon_t *jitter);

/* Called from UFS rx callback (main context via UFS_Poll) */
void M6_DUT_OnFrame(m6_dut_t *dut, const uint8_t *payload, uint8_t len);

/* Called periodically from main using dt ms (handles pause timers and replies) */
void M6_DUT_OnTickMs(m6_dut_t *dut, uint32_t dtMs);

bool M6_DUT_IsPaused(const m6_dut_t *dut);

#endif /* M6_DUT_H_ */

