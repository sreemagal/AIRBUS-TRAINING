/******************************************************************************
 * File: m6_dut.c
 ******************************************************************************/
#include "m6_dut.h"
#include "m6_test_protocol.h"

static void M6_DUT_QueueReply(m6_dut_t *dut, const uint8_t *payload, uint8_t len)
{
    if ((len == 0u) || (len > (uint8_t)sizeof(dut->replyBuf)))
    {
        return;
    }

    for (uint32_t i = 0; i < len; i++)
    {
        dut->replyBuf[i] = payload[i];
    }

    dut->replyLen = len;
    dut->replyPending = true;
}

static uint8_t M6_DUT_BuildStatsRsp(m6_dut_t *dut, uint16_t seq)
{
    /*
     * Stats payload layout (little-endian u32), kept under 64 bytes:
     * [0] type
     * [1..2] seq
     * Then 15 x u32 = 60 bytes total payload size = 63 bytes
     *
     * u32 list:
     *  0 ufs.rxFramesOk
     *  1 ufs.rxChecksumErrors
     *  2 ufs.rxRingOverflows
     *  3 a429b.wordsRx
     *  4 a429b.rxParityErrors
     *  5 a429b.rxSsmErrors
     *  6 a429b.rxFormatErrors
     *  7 air.validWordsTotal
     *  8 air.invalidWordsTotal
     *  9 air.altUpdates
     * 10 air.iasUpdates
     * 11 jitter.count
     * 12 jitter.minMs
     * 13 jitter.maxMs
     * 14 jitter.avgMs
     */

    ufs_stats_t us = {0};
    a429b_stats_t bs = {0};
    airdata_snapshot_t as = {0};

    UFS_GetStats(dut->ufs, &us);
    A429B_GetStats(dut->bridge, &bs);
    AirData_GetSnapshot(dut->air, &as);

    const uint32_t jCount = dut->jitter->count;
    const uint32_t jMin   = (dut->jitter->count == 0u) ? 0u : dut->jitter->minMs;
    const uint32_t jMax   = (dut->jitter->count == 0u) ? 0u : dut->jitter->maxMs;
    const uint32_t jAvg   = JITTER_AvgMs(dut->jitter);

    uint8_t p[64];
    p[0] = M6_MSG_STATS_RSP;
    M6_PutU16LE(&p[1], seq);

    uint32_t idx = 3u;
    M6_PutU32LE(&p[idx], us.rxFramesOk);        idx += 4u;
    M6_PutU32LE(&p[idx], us.rxChecksumErrors);  idx += 4u;
    M6_PutU32LE(&p[idx], us.rxRingOverflows);   idx += 4u;

    M6_PutU32LE(&p[idx], bs.wordsRx);           idx += 4u;
    M6_PutU32LE(&p[idx], bs.rxParityErrors);    idx += 4u;
    M6_PutU32LE(&p[idx], bs.rxSsmErrors);       idx += 4u;
    M6_PutU32LE(&p[idx], bs.rxFormatErrors);    idx += 4u;

    M6_PutU32LE(&p[idx], as.stats.validWordsTotal);   idx += 4u;
    M6_PutU32LE(&p[idx], as.stats.invalidWordsTotal); idx += 4u;
    M6_PutU32LE(&p[idx], as.stats.altUpdates);        idx += 4u;
    M6_PutU32LE(&p[idx], as.stats.iasUpdates);        idx += 4u;

    M6_PutU32LE(&p[idx], jCount); idx += 4u;
    M6_PutU32LE(&p[idx], jMin);   idx += 4u;
    M6_PutU32LE(&p[idx], jMax);   idx += 4u;
    M6_PutU32LE(&p[idx], jAvg);   idx += 4u;

    M6_DUT_QueueReply(dut, p, (uint8_t)idx);
    return (uint8_t)idx;
}

void M6_DUT_Init(m6_dut_t *dut,
                 ufs_t *ufs,
                 const tick_handle_t *tick,
                 const a429b_t *bridge,
                 const airdata_t *air,
                 const jitter_mon_t *jitter)
{
    dut->ufs = ufs;
    dut->tick = tick;
    dut->bridge = bridge;
    dut->air = air;
    dut->jitter = jitter;
    dut->pauseRemainingMs = 0u;
    dut->replyPending = false;
    dut->replyLen = 0u;
}

bool M6_DUT_IsPaused(const m6_dut_t *dut)
{
    return (dut->pauseRemainingMs != 0u);
}

void M6_DUT_OnFrame(m6_dut_t *dut, const uint8_t *payload, uint8_t len)
{
    if ((dut == NULL) || (payload == NULL) || (len < 3u))
    {
        return;
    }

    const uint8_t type = payload[0];
    const uint16_t seq = M6_GetU16LE(&payload[1]);

    if (type == M6_MSG_PING)
    {
        uint8_t rsp[M6_LEN_PONG];
        rsp[0] = M6_MSG_PONG;
        M6_PutU16LE(&rsp[1], seq);
        M6_DUT_QueueReply(dut, rsp, sizeof(rsp));
    }
    else if (type == M6_MSG_PAUSE_POLL)
    {
        if (len == M6_LEN_PAUSE_POLL)
        {
            const uint16_t pauseMs = M6_GetU16LE(&payload[3]);
            dut->pauseRemainingMs = (uint32_t)pauseMs;
        }

        uint8_t rsp[M6_LEN_PAUSE_ACK];
        rsp[0] = M6_MSG_PAUSE_ACK;
        M6_PutU16LE(&rsp[1], seq);
        M6_DUT_QueueReply(dut, rsp, sizeof(rsp));
    }
    else if (type == M6_MSG_STATS_REQ)
    {
        (void)M6_DUT_BuildStatsRsp(dut, seq);
    }
    else if (type == M6_MSG_RESET_STATS)
    {
        /* Reset underlying module stats.
         * Note: this function does not own those modules, so reset must be done
         * by the main code (we just send ACK here). For simplicity, master uses
         * RESET only for jitter monitor (handled in main demo).
         */
        uint8_t rsp[M6_LEN_RESET_ACK];
        rsp[0] = M6_MSG_RESET_ACK;
        M6_PutU16LE(&rsp[1], seq);
        M6_DUT_QueueReply(dut, rsp, sizeof(rsp));
    }
    else
    {
        /* Ignore unknown types */
    }
}

void M6_DUT_OnTickMs(m6_dut_t *dut, uint32_t dtMs)
{
    if ((dut == NULL) || (dtMs == 0u))
    {
        return;
    }

    if (dut->pauseRemainingMs > dtMs)
    {
        dut->pauseRemainingMs -= dtMs;
    }
    else
    {
        dut->pauseRemainingMs = 0u;
    }

    /* Try to send pending reply if TX is free. */
    if (dut->replyPending)
    {
        if (!UFS_IsTxBusy(dut->ufs))
        {
            const status_t st = UFS_SendFrame(dut->ufs, dut->replyBuf, dut->replyLen);
            if (st == kStatus_Success)
            {
                dut->replyPending = false;
                dut->replyLen = 0u;
            }
            /* else: keep pending and retry next tick */
        }
    }
}

