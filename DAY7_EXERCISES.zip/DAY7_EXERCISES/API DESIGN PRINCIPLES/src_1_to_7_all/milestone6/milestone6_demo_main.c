/******************************************************************************
 * File: milestone6_demo_main.c
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, BOARD_USER_LED_* */
#include "fsl_debug_console.h"
#include "fsl_clock.h"

#include "dio.h"
#include "tick_1ms.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"

#include "m6_test_protocol.h"
#include "m6_dut.h"
#include "m6_master.h"
#include "jitter_monitor.h"

/*
 * Role selection:
 *  0 = MASTER (runs automated test suite)
 *  1 = DUT    (runs full stack + command handler)
 */
#ifndef M6_NODE_ROLE
#define M6_NODE_ROLE (1u)
#endif

/* PIT defaults (if not provided by your project headers) */
#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

/* Shared objects */
static airdata_t s_air;
static jitter_mon_t s_jitter;
static tick_handle_t s_tick;
static ufs_t s_ufs;
static a429b_t s_bridge;
static dio_handle_t s_led;

/* DUT harness and MASTER harness */
static m6_dut_t s_dut;
static m6_master_t s_master;

/*
 * UFS RX dispatcher:
 * - Called from UFS_Poll() (main context)
 * - Routes payloads to either:
 *     - A429B_UfsRxHook (domain word)
 *     - Milestone 6 test protocol handler (PING/REQ/...) for MASTER or DUT
 */
typedef struct
{
    uint8_t role;
    a429b_t *bridge;
    m6_dut_t *dut;
    m6_master_t *master;
} m6_ctx_t;

static m6_ctx_t s_ctx;

static void M6_UfsRxDispatcher(const uint8_t *payload, uint8_t len, void *userData)
{
    m6_ctx_t *ctx = (m6_ctx_t *)userData;
    if ((ctx == NULL) || (payload == NULL) || (len == 0u))
    {
        return;
    }

    const uint8_t type = payload[0];

    if ((type == A429B_MSG_WORD) && (ctx->bridge != NULL))
    {
        /* Deliver to domain layer decoder */
        A429B_UfsRxHook(payload, len, ctx->bridge);
        return;
    }

    /* Otherwise treat as Milestone 6 control message */
    if (ctx->role == 0u)
    {
        M6_MASTER_OnFrame(ctx->master, payload, len);
    }
    else
    {
        M6_DUT_OnFrame(ctx->dut, payload, len);
    }
}

/* Domain word callback for DUT: update AirData + jitter monitor */
static void Dut_OnWord(uint32_t rawWord,
                       const a429b_word_fields_t *fields,
                       a429b_word_validity_t validity,
                       void *userData)
{
    (void)userData;

    AirData_OnWord(&s_air, rawWord, fields, validity);

    /* Jitter measurement: track label 203 receptions when valid */
    if ((validity == A429B_WORD_VALID) && (fields != NULL) && (fields->label == AIRDATA_LABEL_PRESSURE_ALT_FT))
    {
        JITTER_OnEvent(&s_jitter, TICK_GetMs(&s_tick));
    }
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 6: Bench Test Harness (%s)\r\n", (M6_NODE_ROLE == 0u) ? "MASTER" : "DUT");

    /* LED via DIO */
    const dio_config_t ledCfg = {
        .base = BOARD_USER_LED_GPIO,
        .pin = BOARD_USER_LED_GPIO_PIN,
        .activeLow = true,
        .initialOn = false,
    };
    (void)DIO_Init(&s_led, &ledCfg);

    /* 1ms tick */
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };
    if (TICK_Init(&s_tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("TICK_Init failed\r\n");
        while (1) {}
    }

    /* AirData app (only meaningful on DUT, but harmless on MASTER) */
    const airdata_config_t airCfg = {
        .activityPulseMs = 50u,
        .altStaleTimeoutMs = 500u,
        .iasStaleTimeoutMs = 500u,
        .acceptFunctionalTest = false,
    };
    (void)AirData_Init(&s_air, &airCfg);

    /* Jitter monitor expects 50ms periodic label 203 messages in this test */
    JITTER_Init(&s_jitter, 50u);

    /* UFS init: rxCb is dispatcher (not A429B hook directly) */
    s_ctx.role = (uint8_t)M6_NODE_ROLE;
    s_ctx.bridge = &s_bridge;
    s_ctx.dut = &s_dut;
    s_ctx.master = &s_master;

    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 192u,
        .rxCb = M6_UfsRxDispatcher,
        .rxCbUserData = &s_ctx,
    };

    if (UFS_Init(&s_ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("UFS_Init failed\r\n");
        while (1) {}
    }

    /* Domain layer: decode A429B words, callback differs for role */
    if (M6_NODE_ROLE == 1u)
    {
        (void)A429B_Init(&s_bridge, &s_ufs, Dut_OnWord, NULL);
        M6_DUT_Init(&s_dut, &s_ufs, &s_tick, &s_bridge, &s_air, &s_jitter);
    }
    else
    {
        /* MASTER does not need domain decoding; still init for pack helpers if desired */
        (void)A429B_Init(&s_bridge, &s_ufs, NULL, NULL);
        M6_MASTER_Init(&s_master, DEMO_LPUART, &s_tick, &s_ufs);
    }

    uint32_t lastMs = TICK_GetMs(&s_tick);
    uint32_t printTimer = 0u;

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&s_tick, &lastMs);

        if (dt != 0u)
        {
            if (M6_NODE_ROLE == 1u)
            {
                /* DUT: update app and DUT harness timers */
                AirData_OnTickMs(&s_air, dt);
                A429B_OnTickMs(&s_bridge, dt);
                M6_DUT_OnTickMs(&s_dut, dt);

                /* Drive LED based on app suggestion */
                (void)DIO_Write(&s_led, s_air.activityLedOn);
            }
            else
            {
                /* MASTER: run test suite */
                M6_MASTER_Run(&s_master, dt);
            }

            printTimer += dt;
        }

        /* Polling policy:
         * - MASTER always polls to receive responses.
         * - DUT polls only when not paused (to intentionally cause overflow during test).
         */
        if (M6_NODE_ROLE == 0u)
        {
            (void)UFS_Poll(&s_ufs);
        }
        else
        {
            if (!M6_DUT_IsPaused(&s_dut))
            {
                (void)UFS_Poll(&s_ufs);
            }
        }

        /* Periodic DUT status print (non-critical) */
        if ((M6_NODE_ROLE == 1u) && (printTimer >= 1000u))
        {
            printTimer -= 1000u;
            airdata_snapshot_t snap;
            AirData_GetSnapshot(&s_air, &snap);

            PRINTF("DUT: ALT=%s %luft IAS=%s %lukt LED=%u Jit(cnt=%lu min=%lu max=%lu avg=%lu)\r\n",
                   snap.altValid ? "OK" : "--",
                   (unsigned long)snap.altitude_ft,
                   snap.iasValid ? "OK" : "--",
                   (unsigned long)snap.ias_kt,
                   snap.activityLedOn ? 1u : 0u,
                   (unsigned long)s_jitter.count,
                   (unsigned long)((s_jitter.count==0u)?0u:s_jitter.minMs),
                   (unsigned long)((s_jitter.count==0u)?0u:s_jitter.maxMs),
                   (unsigned long)JITTER_AvgMs(&s_jitter));
        }
    }
}
