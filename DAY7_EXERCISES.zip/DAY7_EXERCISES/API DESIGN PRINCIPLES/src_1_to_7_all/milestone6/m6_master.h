/******************************************************************************
 * File: m6_master.h
 ******************************************************************************/
#ifndef M6_MASTER_H_
#define M6_MASTER_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"
#include "fsl_lpuart.h" /* LPUART_WriteBlocking */

#include "tick_1ms.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h" /* for packing A429B words */
#include "m6_test_protocol.h"

/* MASTER mailbox for received responses */
typedef struct
{
    bool hasMsg;
    uint8_t type;
    uint16_t seq;
    uint8_t payload[64];
    uint8_t len;
} m6_mailbox_t;

typedef enum
{
    M6M_STATE_INIT = 0,
    M6M_STATE_SEND_PING,
    M6M_STATE_WAIT_PONG,

    M6M_STATE_BASELINE_STATS,
    M6M_STATE_WAIT_BASELINE_STATS,

    M6M_STATE_INJECT_BAD_CHECKSUM,
    M6M_STATE_STATS_AFTER_BAD_CHECKSUM,
    M6M_STATE_WAIT_STATS_AFTER_BAD_CHECKSUM,

    M6M_STATE_SEND_PAUSE,
    M6M_STATE_WAIT_PAUSE_ACK,
    M6M_STATE_SEND_BURST,
    M6M_STATE_STATS_AFTER_BURST,
    M6M_STATE_WAIT_STATS_AFTER_BURST,

    M6M_STATE_JITTER_SEND_STREAM,
    M6M_STATE_JITTER_WAIT,
    M6M_STATE_JITTER_STATS,
    M6M_STATE_JITTER_WAIT_STATS,

    M6M_STATE_DONE
} m6m_state_t;

/* Parsed stats from DUT */
typedef struct
{
    uint32_t ufs_rxOk;
    uint32_t ufs_csumErr;
    uint32_t ufs_ovf;

    uint32_t a429b_wordsRx;
    uint32_t a429b_parityErr;
    uint32_t a429b_ssmErr;
    uint32_t a429b_fmtErr;

    uint32_t air_valid;
    uint32_t air_invalid;
    uint32_t air_altUp;
    uint32_t air_iasUp;

    uint32_t jit_count;
    uint32_t jit_min;
    uint32_t jit_max;
    uint32_t jit_avg;
} m6_stats_snapshot_t;

/* MASTER test runner */
typedef struct
{
    LPUART_Type *uartBase;
    const tick_handle_t *tick;

    /* For receiving responses we still use UFS parsing */
    ufs_t *ufs;

    m6_mailbox_t mb;

    m6m_state_t state;
    uint16_t seq;

    uint32_t stateTimerMs;
    uint32_t streamTimerMs;
    uint32_t streamPeriodMs;
    uint32_t streamNextDueMs;

    m6_stats_snapshot_t baseline;
    m6_stats_snapshot_t afterBadChecksum;
    m6_stats_snapshot_t afterBurst;
    m6_stats_snapshot_t afterJitter;

    /* Pass/fail flags */
    bool pass_ping;
    bool pass_checksum;
    bool pass_overflow;
    bool pass_jitter;
} m6_master_t;

void M6_MASTER_Init(m6_master_t *m,
                    LPUART_Type *uartBase,
                    const tick_handle_t *tick,
                    ufs_t *ufs);

/* Called from UFS rx callback (main context via UFS_Poll) */
void M6_MASTER_OnFrame(m6_master_t *m, const uint8_t *payload, uint8_t len);

/* Called periodically from main using dt ms: advances test state machine */
void M6_MASTER_Run(m6_master_t *m, uint32_t dtMs);

#endif /* M6_MASTER_H_ */

