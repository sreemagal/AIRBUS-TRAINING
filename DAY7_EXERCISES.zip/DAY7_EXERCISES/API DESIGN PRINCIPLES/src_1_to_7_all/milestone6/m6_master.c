/******************************************************************************
 * File: m6_master.c
 ******************************************************************************/
#include "m6_master.h"
#include "fsl_debug_console.h"

/* ---- UFS frame builder for blocking TX (MASTER only) ---- */

static uint8_t M6_ChecksumTwoComplement(uint8_t len, const uint8_t *payload)
{
    uint32_t sum = (uint32_t)len;
    for (uint32_t i = 0; i < len; i++)
    {
        sum += payload[i];
    }
    return (uint8_t)(0u - (uint8_t)sum);
}

static void M6_SendUfsFrameBlocking(LPUART_Type *base, const uint8_t *payload, uint8_t len, bool corruptChecksum)
{
    /* Build full frame: START | LEN | payload | checksum */
    uint8_t frame[1u + 1u + 64u + 1u];
    uint32_t idx = 0u;

    frame[idx++] = UFS_FRAME_START_BYTE;
    frame[idx++] = len;

    for (uint32_t i = 0; i < len; i++)
    {
        frame[idx++] = payload[i];
    }

    uint8_t cs = M6_ChecksumTwoComplement(len, payload);
    if (corruptChecksum)
    {
        cs ^= 0xFFu; /* intentional corruption */
    }
    frame[idx++] = cs;

    /* Blocking write: MASTER is allowed to block. */
    LPUART_WriteBlocking(base, frame, idx);
}

static void M6_Master_SendPing(m6_master_t *m)
{
    uint8_t p[M6_LEN_PING];
    p[0] = M6_MSG_PING;
    M6_PutU16LE(&p[1], m->seq);
    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static void M6_Master_SendStatsReq(m6_master_t *m)
{
    uint8_t p[M6_LEN_STATS_REQ];
    p[0] = M6_MSG_STATS_REQ;
    M6_PutU16LE(&p[1], m->seq);
    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static void M6_Master_SendPause(m6_master_t *m, uint16_t pauseMs)
{
    uint8_t p[M6_LEN_PAUSE_POLL];
    p[0] = M6_MSG_PAUSE_POLL;
    M6_PutU16LE(&p[1], m->seq);
    M6_PutU16LE(&p[3], pauseMs);
    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static void M6_Master_SendCorruptFrames(m6_master_t *m, uint16_t count)
{
    /* Send corrupted PING frames; DUT should count checksum errors. */
    for (uint16_t i = 0; i < count; i++)
    {
        uint8_t p[M6_LEN_PING];
        p[0] = M6_MSG_PING;
        M6_PutU16LE(&p[1], (uint16_t)(0x9000u + i));
        M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), true);
    }
}

static void M6_Master_SendBurst(m6_master_t *m, uint16_t frames)
{
    /* Burst is small but valid framed messages, sent back-to-back. */
    for (uint16_t i = 0; i < frames; i++)
    {
        uint8_t p[5];
        p[0] = M6_MSG_BURST;
        M6_PutU16LE(&p[1], (uint16_t)(0xB000u));
        M6_PutU16LE(&p[3], i);
        M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
    }
}

static void M6_Master_SendA429Word(m6_master_t *m, uint32_t rawWord)
{
    /* UFS payload for domain word: [0]=A429B_MSG_WORD, [1..4]=word LE */
    uint8_t p[5];
    p[0] = A429B_MSG_WORD;
    p[1] = (uint8_t)(rawWord & 0xFFu);
    p[2] = (uint8_t)((rawWord >> 8) & 0xFFu);
    p[3] = (uint8_t)((rawWord >> 16) & 0xFFu);
    p[4] = (uint8_t)((rawWord >> 24) & 0xFFu);

    M6_SendUfsFrameBlocking(m->uartBase, p, sizeof(p), false);
}

static bool M6_ParseStatsRsp(const uint8_t *payload, uint8_t len, m6_stats_snapshot_t *out)
{
    if ((payload == NULL) || (out == NULL))
    {
        return false;
    }

    /* Minimum expected: type + seq16 + 15*u32 = 63 bytes */
    if (len < 63u)
    {
        return false;
    }

    if (payload[0] != M6_MSG_STATS_RSP)
    {
        return false;
    }

    uint32_t idx = 3u;
    out->ufs_rxOk        = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->ufs_csumErr     = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->ufs_ovf         = M6_GetU32LE(&payload[idx]); idx += 4u;

    out->a429b_wordsRx   = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->a429b_parityErr = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->a429b_ssmErr    = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->a429b_fmtErr    = M6_GetU32LE(&payload[idx]); idx += 4u;

    out->air_valid       = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->air_invalid     = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->air_altUp       = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->air_iasUp       = M6_GetU32LE(&payload[idx]); idx += 4u;

    out->jit_count       = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->jit_min         = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->jit_max         = M6_GetU32LE(&payload[idx]); idx += 4u;
    out->jit_avg         = M6_GetU32LE(&payload[idx]); idx += 4u;

    (void)idx;
    return true;
}

void M6_MASTER_Init(m6_master_t *m,
                    LPUART_Type *uartBase,
                    const tick_handle_t *tick,
                    ufs_t *ufs)
{
    m->uartBase = uartBase;
    m->tick = tick;
    m->ufs = ufs;

    m->mb.hasMsg = false;
    m->state = M6M_STATE_INIT;
    m->seq = 1u;

    m->stateTimerMs = 0u;
    m->streamTimerMs = 0u;
    m->streamPeriodMs = 50u;
    m->streamNextDueMs = 0u;

    m->pass_ping = false;
    m->pass_checksum = false;
    m->pass_overflow = false;
    m->pass_jitter = false;
}

void M6_MASTER_OnFrame(m6_master_t *m, const uint8_t *payload, uint8_t len)
{
    if ((m == NULL) || (payload == NULL) || (len == 0u))
    {
        return;
    }

    if (len > (uint8_t)sizeof(m->mb.payload))
    {
        return;
    }

    m->mb.type = payload[0];
    m->mb.seq = (len >= 3u) ? M6_GetU16LE(&payload[1]) : 0u;
    m->mb.len = len;

    for (uint32_t i = 0; i < len; i++)
    {
        m->mb.payload[i] = payload[i];
    }

    m->mb.hasMsg = true;
}

static bool M6_Master_TakeMsg(m6_master_t *m, uint8_t type, uint16_t seq)
{
    if (!m->mb.hasMsg)
    {
        return false;
    }

    if ((m->mb.type == type) && (m->mb.seq == seq))
    {
        m->mb.hasMsg = false;
        return true;
    }

    return false;
}

static bool M6_Master_TakeStats(m6_master_t *m, uint16_t seq, m6_stats_snapshot_t *out)
{
    if (!m->mb.hasMsg)
    {
        return false;
    }

    if ((m->mb.type == M6_MSG_STATS_RSP) && (m->mb.seq == seq))
    {
        const bool ok = M6_ParseStatsRsp(m->mb.payload, m->mb.len, out);
        m->mb.hasMsg = false;
        return ok;
    }

    return false;
}

void M6_MASTER_Run(m6_master_t *m, uint32_t dtMs)
{
    if (m == NULL)
    {
        return;
    }

    m->stateTimerMs += dtMs;

    switch (m->state)
    {
        case M6M_STATE_INIT:
        {
            PRINTF("M6 MASTER: starting tests...\r\n");
            m->state = M6M_STATE_SEND_PING;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_SEND_PING:
        {
            PRINTF("Test1: PING...\r\n");
            M6_Master_SendPing(m);
            m->state = M6M_STATE_WAIT_PONG;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_WAIT_PONG:
        {
            if (M6_Master_TakeMsg(m, M6_MSG_PONG, m->seq))
            {
                PRINTF("  PONG received.\r\n");
                m->pass_ping = true;
                m->seq++;
                m->state = M6M_STATE_BASELINE_STATS;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: PONG timeout.\r\n");
                m->seq++;
                m->state = M6M_STATE_BASELINE_STATS;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_BASELINE_STATS:
        {
            PRINTF("Baseline: requesting STATS...\r\n");
            M6_Master_SendStatsReq(m);
            m->state = M6M_STATE_WAIT_BASELINE_STATS;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_WAIT_BASELINE_STATS:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->baseline))
            {
                PRINTF("  Baseline: csumErr=%lu ovf=%lu rxOk=%lu\r\n",
                       (unsigned long)m->baseline.ufs_csumErr,
                       (unsigned long)m->baseline.ufs_ovf,
                       (unsigned long)m->baseline.ufs_rxOk);
                m->seq++;
                m->state = M6M_STATE_INJECT_BAD_CHECKSUM;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: baseline STATS timeout.\r\n");
                m->seq++;
                m->state = M6M_STATE_INJECT_BAD_CHECKSUM;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_INJECT_BAD_CHECKSUM:
        {
            PRINTF("Test2: injecting bad-checksum frames...\r\n");
            M6_Master_SendCorruptFrames(m, 10u);
            m->state = M6M_STATE_STATS_AFTER_BAD_CHECKSUM;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_STATS_AFTER_BAD_CHECKSUM:
        {
            /* give DUT a moment to process / count */
            if (m->stateTimerMs >= 100u)
            {
                M6_Master_SendStatsReq(m);
                m->state = M6M_STATE_WAIT_STATS_AFTER_BAD_CHECKSUM;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_WAIT_STATS_AFTER_BAD_CHECKSUM:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->afterBadChecksum))
            {
                const uint32_t diff = m->afterBadChecksum.ufs_csumErr - m->baseline.ufs_csumErr;
                PRINTF("  checksumErrors increased by %lu\r\n", (unsigned long)diff);
                m->pass_checksum = (diff > 0u);
                PRINTF("  %s\r\n", m->pass_checksum ? "PASS" : "FAIL");

                m->seq++;
                m->state = M6M_STATE_SEND_PAUSE;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: STATS timeout after checksum test.\r\n");
                m->seq++;
                m->state = M6M_STATE_SEND_PAUSE;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_SEND_PAUSE:
        {
            PRINTF("Test3: overflow test: PAUSE_POLL 250ms...\r\n");
            M6_Master_SendPause(m, 250u);
            m->state = M6M_STATE_WAIT_PAUSE_ACK;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_WAIT_PAUSE_ACK:
        {
            if (M6_Master_TakeMsg(m, M6_MSG_PAUSE_ACK, m->seq))
            {
                PRINTF("  Pause ACK received. Sending burst...\r\n");
                m->seq++;
                m->state = M6M_STATE_SEND_BURST;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: PAUSE_ACK timeout. Proceeding anyway.\r\n");
                m->seq++;
                m->state = M6M_STATE_SEND_BURST;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_SEND_BURST:
        {
            /* Send enough frames to overflow a 256-byte RX ring when DUT is not polling */
            M6_Master_SendBurst(m, 300u);
            m->state = M6M_STATE_STATS_AFTER_BURST;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_STATS_AFTER_BURST:
        {
            /* Wait for DUT to resume polling */
            if (m->stateTimerMs >= 400u)
            {
                M6_Master_SendStatsReq(m);
                m->state = M6M_STATE_WAIT_STATS_AFTER_BURST;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_WAIT_STATS_AFTER_BURST:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->afterBurst))
            {
                const uint32_t diff = m->afterBurst.ufs_ovf - m->afterBadChecksum.ufs_ovf;
                PRINTF("  RX overflow increased by %lu\r\n", (unsigned long)diff);
                m->pass_overflow = (diff > 0u);
                PRINTF("  %s\r\n", m->pass_overflow ? "PASS" : "FAIL");

                m->seq++;
                m->state = M6M_STATE_JITTER_SEND_STREAM;
                m->stateTimerMs = 0u;
                m->streamTimerMs = 0u;
                m->streamNextDueMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: STATS timeout after burst.\r\n");
                m->seq++;
                m->state = M6M_STATE_JITTER_SEND_STREAM;
                m->stateTimerMs = 0u;
                m->streamTimerMs = 0u;
                m->streamNextDueMs = 0u;
            }
            break;
        }

        case M6M_STATE_JITTER_SEND_STREAM:
        {
            /*
             * Test4: jitter measurement
             * MASTER acts as a sensor: sends label 203 (altitude) every 50ms for 5 seconds.
             * DUT measures reception intervals and reports min/max/avg.
             */
            PRINTF("Test4: jitter stream: sending A429B label203 every %lu ms for 5s...\r\n",
                   (unsigned long)m->streamPeriodMs);

            m->state = M6M_STATE_JITTER_WAIT;
            m->stateTimerMs = 0u;
            m->streamTimerMs = 0u;
            m->streamNextDueMs = 0u;
            break;
        }

        case M6M_STATE_JITTER_WAIT:
        {
            m->streamTimerMs += dtMs;
            m->streamNextDueMs += dtMs;

            if (m->streamNextDueMs >= m->streamPeriodMs)
            {
                m->streamNextDueMs -= m->streamPeriodMs;

                /* Build a valid word: label 203, data increments, NORMAL, even parity */
                static uint32_t alt = 1000u;
                a429b_word_fields_t f = {
                    .label = 203u,
                    .sdi = 0u,
                    .data = (alt & 0x7FFFFu),
                    .ssm = A429B_SSM_NORMAL_OPERATION,
                    .parity = false,
                };

                uint32_t w;
                (void)A429B_PackWord(&f, &w);
                w = A429B_SetEvenParity(w);
                M6_Master_SendA429Word(m, w);

                alt += 1u;
            }

            if (m->streamTimerMs >= 5000u)
            {
                m->state = M6M_STATE_JITTER_STATS;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_JITTER_STATS:
        {
            PRINTF("  Requesting jitter STATS...\r\n");
            M6_Master_SendStatsReq(m);
            m->state = M6M_STATE_JITTER_WAIT_STATS;
            m->stateTimerMs = 0u;
            break;
        }

        case M6M_STATE_JITTER_WAIT_STATS:
        {
            if (M6_Master_TakeStats(m, m->seq, &m->afterJitter))
            {
                PRINTF("  Jitter intervals=%lu min=%lu max=%lu avg=%lu (expected=%lu)\r\n",
                       (unsigned long)m->afterJitter.jit_count,
                       (unsigned long)m->afterJitter.jit_min,
                       (unsigned long)m->afterJitter.jit_max,
                       (unsigned long)m->afterJitter.jit_avg,
                       (unsigned long)m->streamPeriodMs);

                /* Pass if we got enough samples and bounds are reasonable (example rule) */
                m->pass_jitter = (m->afterJitter.jit_count >= 20u);
                PRINTF("  %s\r\n", m->pass_jitter ? "PASS" : "FAIL");

                m->seq++;
                m->state = M6M_STATE_DONE;
                m->stateTimerMs = 0u;
            }
            else if (m->stateTimerMs > 500u)
            {
                PRINTF("  FAIL: jitter STATS timeout.\r\n");
                m->seq++;
                m->state = M6M_STATE_DONE;
                m->stateTimerMs = 0u;
            }
            break;
        }

        case M6M_STATE_DONE:
        {
            PRINTF("\r\n=== Milestone 6 Summary ===\r\n");
            PRINTF("PING:     %s\r\n", m->pass_ping ? "PASS" : "FAIL");
            PRINTF("CHECKSUM: %s\r\n", m->pass_checksum ? "PASS" : "FAIL");
            PRINTF("OVERFLOW: %s\r\n", m->pass_overflow ? "PASS" : "FAIL");
            PRINTF("JITTER:   %s\r\n", m->pass_jitter ? "PASS" : "FAIL");
            PRINTF("===========================\r\n");

            m->state = M6M_STATE_DONE;
            break;
        }

        default:
            m->state = M6M_STATE_DONE;
            break;
    }
}

