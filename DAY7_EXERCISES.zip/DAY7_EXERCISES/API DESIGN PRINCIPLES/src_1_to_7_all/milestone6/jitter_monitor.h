/******************************************************************************
 * File: jitter_monitor.h
 ******************************************************************************/
#ifndef JITTER_MONITOR_H_
#define JITTER_MONITOR_H_

#include <stdbool.h>
#include <stdint.h>

typedef struct
{
    bool hasPrev;
    uint32_t expectedPeriodMs;

    uint32_t prevEventMs;

    uint32_t count;     /* number of intervals measured (events-1) */
    uint32_t sumMs;     /* sum of measured intervals */
    uint32_t minMs;     /* min measured interval */
    uint32_t maxMs;     /* max measured interval */
} jitter_mon_t;

static inline void JITTER_Init(jitter_mon_t *jm, uint32_t expectedPeriodMs)
{
    jm->hasPrev = false;
    jm->expectedPeriodMs = expectedPeriodMs;
    jm->prevEventMs = 0u;
    jm->count = 0u;
    jm->sumMs = 0u;
    jm->minMs = 0xFFFFFFFFu;
    jm->maxMs = 0u;
}

static inline void JITTER_Reset(jitter_mon_t *jm)
{
    const uint32_t exp = jm->expectedPeriodMs;
    JITTER_Init(jm, exp);
}

static inline void JITTER_OnEvent(jitter_mon_t *jm, uint32_t nowMs)
{
    if (!jm->hasPrev)
    {
        jm->hasPrev = true;
        jm->prevEventMs = nowMs;
        return;
    }

    const uint32_t dt = (uint32_t)(nowMs - jm->prevEventMs);
    jm->prevEventMs = nowMs;

    jm->count++;
    jm->sumMs += dt;
    if (dt < jm->minMs) jm->minMs = dt;
    if (dt > jm->maxMs) jm->maxMs = dt;
}

static inline uint32_t JITTER_AvgMs(const jitter_mon_t *jm)
{
    return (jm->count == 0u) ? 0u : (jm->sumMs / jm->count);
}

#endif /* JITTER_MONITOR_H_ */

