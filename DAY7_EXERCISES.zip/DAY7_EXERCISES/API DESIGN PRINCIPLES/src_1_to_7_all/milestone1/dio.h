/******************************************************************************
 * File: dio.h
 ******************************************************************************/
#ifndef DIO_H_
#define DIO_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h" /* status_t, kStatus_* */
#include "fsl_gpio.h"   /* GPIO_Type, gpio_pin_config_t, GPIO_* APIs */

/* Versioning (simple semantic version for the DIO module). */
#define DIO_VERSION_MAJOR (1u)
#define DIO_VERSION_MINOR (0u)
#define DIO_VERSION_PATCH (0u)

/*
 * Design intent for Milestone 1
 * ----------------------------
 * - A small, explicit API wrapper around SDK GPIO pin output.
 * - Idempotent init when called again with the same configuration.
 * - Clear ownership: the caller owns the handle memory; DIO only stores a copy
 *   of key configuration fields in the handle.
 * - Consistent error handling using MCUXpresso SDK status_t.
 */

typedef struct
{
    GPIO_Type *base;   /* GPIO instance base pointer, e.g., GPIO1 */
    uint32_t pin;      /* Pin index [0..31] */
    bool activeLow;    /* true: logical ON drives pin low (0). false: logical ON drives pin high (1). */
    bool initialOn;    /* logical initial state applied during DIO_Init() */
} dio_config_t;

typedef struct
{
    GPIO_Type *base;
    uint32_t pin;
    bool activeLow;
    bool isInitialized;
} dio_handle_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize a digital output pin.
 *
 * @param handle Pointer to caller-owned handle storage.
 * @param config Pointer to configuration.
 *
 * @pre  - handle != NULL
 * @pre  - config != NULL
 * @pre  - config->base != NULL
 * @pre  - Pin mux/IO configuration for the selected pad has been done by
 *         the board/pin_mux layer (MCUXpresso config files).
 * @pre  - config->pin is in [0..31] for the selected GPIO port.
 *
 * @post - The pin is configured as a digital output.
 * @post - The initial logical output state is applied.
 * @post - handle->isInitialized == true on success.
 *
 * Idempotence rule:
 *  - If DIO_Init() is called again on an already initialized handle *with the
 *    exact same base/pin/activeLow*, it returns kStatus_Success and does not
 *    reconfigure hardware.
 *  - If called with a different configuration, it returns kStatus_Fail.
 *
 * Concurrency / context:
 *  - Main context only for this milestone.
 */
status_t DIO_Init(dio_handle_t *handle, const dio_config_t *config);

/*
 * @brief Write a logical level to the output pin.
 *
 * @param handle Initialized handle.
 * @param on     true = logical ON, false = logical OFF.
 *
 * @pre  handle != NULL
 * @pre  handle->isInitialized == true
 *
 * @post The hardware output is updated.
 */
status_t DIO_Write(dio_handle_t *handle, bool on);

/*
 * @brief Toggle the output pin.
 *
 * @param handle Initialized handle.
 *
 * @pre  handle != NULL
 * @pre  handle->isInitialized == true
 *
 * @post The hardware output is toggled.
 */
status_t DIO_Toggle(dio_handle_t *handle);

/*
 * @brief Read the current logical state of the pin.
 *
 * @param handle Initialized handle.
 * @param on     Output parameter receiving logical state.
 *
 * @pre  handle != NULL
 * @pre  on != NULL
 * @pre  handle->isInitialized == true
 *
 * @note On some MCUs, reading an output pin may reflect the pad/input sense.
 *       For a user LED this is typically fine.
 */
status_t DIO_Read(dio_handle_t *handle, bool *on);

#ifdef __cplusplus
}
#endif

#endif /* DIO_H_ */

