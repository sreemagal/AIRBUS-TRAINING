/******************************************************************************
 * File: dio.c
 ******************************************************************************/
#include "dio.h"

/* Internal helper: validate port pin range for typical 32-bit GPIO ports. */
static inline bool DIO_IsPinInRange(uint32_t pin)
{
    return (pin < 32u);
}

/* Internal helper: convert logical ON/OFF to physical 0/1 considering activeLow. */
static inline uint8_t DIO_LogicalToPhysical(bool activeLow, bool logicalOn)
{
    const uint8_t on_u8 = logicalOn ? 1u : 0u;
    return activeLow ? (uint8_t)(1u - on_u8) : on_u8;
}

status_t DIO_Init(dio_handle_t *handle, const dio_config_t *config)
{
    if ((handle == NULL) || (config == NULL) || (config->base == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (!DIO_IsPinInRange(config->pin))
    {
        return kStatus_OutOfRange;
    }

    /* If already initialized: enforce idempotence rule. */
    if (handle->isInitialized)
    {
        const bool sameInstance = (handle->base == config->base) &&
                                  (handle->pin == config->pin) &&
                                  (handle->activeLow == config->activeLow);

        return sameInstance ? kStatus_Success : kStatus_Fail;
    }

    /* Configure pin as a digital output with defined initial value. */
    const uint8_t initialPhysical = DIO_LogicalToPhysical(config->activeLow, config->initialOn);

    gpio_pin_config_t pinCfg;
    pinCfg.direction     = kGPIO_DigitalOutput;
    pinCfg.outputLogic   = initialPhysical;
    pinCfg.interruptMode = kGPIO_NoIntmode;

    GPIO_PinInit(config->base, config->pin, &pinCfg);

    /* Store configuration in handle (caller retains ownership of handle memory). */
    handle->base         = config->base;
    handle->pin          = config->pin;
    handle->activeLow    = config->activeLow;
    handle->isInitialized = true;

    return kStatus_Success;
}

status_t DIO_Write(dio_handle_t *handle, bool on)
{
    if (handle == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        /* The handle exists but is not in a valid state for use. */
        return kStatus_Fail;
    }

    const uint8_t physical = DIO_LogicalToPhysical(handle->activeLow, on);
    GPIO_PinWrite(handle->base, handle->pin, physical);

    return kStatus_Success;
}

status_t DIO_Toggle(dio_handle_t *handle)
{
    if (handle == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        return kStatus_Fail;
    }

    /*
     * Toggle at the hardware level.
     * This is deterministic and does not require reading the pin first.
     */
    GPIO_PortToggle(handle->base, (uint32_t)(1u << handle->pin));

    return kStatus_Success;
}

status_t DIO_Read(dio_handle_t *handle, bool *on)
{
    if ((handle == NULL) || (on == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        return kStatus_Fail;
    }

    const uint8_t physical = GPIO_PinRead(handle->base, handle->pin);
    const bool logicalOn = handle->activeLow ? (physical == 0u) : (physical != 0u);

    *on = logicalOn;
    return kStatus_Success;
}

