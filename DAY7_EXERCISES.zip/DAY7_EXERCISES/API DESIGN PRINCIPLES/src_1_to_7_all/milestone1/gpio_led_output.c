/******************************************************************************
 * File: gpio_led_output.c  (replace the example's main file with this demo)
 ******************************************************************************/
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_clock.h"   /* CLOCK_GetCpuClkFreq() */
#include "app.h"         /* EXAMPLE_LED_GPIO / EXAMPLE_LED_GPIO_PIN, BOARD_InitHardware() */

#include "dio.h"

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 1: Digital Output Service (DIO) demo\r\n");
    PRINTF("DIO version %u.%u.%u\r\n", DIO_VERSION_MAJOR, DIO_VERSION_MINOR, DIO_VERSION_PATCH);

    /*
     * EVKB-IMXRT1050 USER LED is active-low in the SDK board macros
     * (USER_LED_ON clears the GPIO bit).
     * We therefore configure activeLow=true so that logical ON maps to physical 0.
     */
    dio_handle_t userLed = {0};
    const dio_config_t userLedCfg = {
        .base      = EXAMPLE_LED_GPIO,
        .pin       = EXAMPLE_LED_GPIO_PIN,
        .activeLow = true,
        .initialOn = false,
    };

    status_t st = DIO_Init(&userLed, &userLedCfg);
    if (st != kStatus_Success)
    {
        PRINTF("DIO_Init failed: %ld\r\n", (long)st);
        while (1)
        {
            /* Fail-safe: stop here */
        }
    }

    /* Demonstrate idempotent init: calling again with same config must succeed. */
    st = DIO_Init(&userLed, &userLedCfg);
    if (st != kStatus_Success)
    {
        PRINTF("DIO_Init (2nd call) unexpected failure: %ld\r\n", (long)st);
        while (1)
        {
        }
    }

    PRINTF("Toggling USER LED using DIO_Toggle()...\r\n");

    while (1)
    {
        /* Toggle at a human-visible rate. */
        (void)DIO_Toggle(&userLed);

        /* Delay ~500ms using SDK helper; timing determinism is addressed in Milestone 2. */
        SDK_DelayAtLeastUs(500000u, CLOCK_GetCpuClkFreq());
    }
}
