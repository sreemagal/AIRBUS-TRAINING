/******************************************************************************
 * File: milestone4_demo_main.c
 * Demo showing:
 *  - UFS framed UART service
 *  - A429B bridge decoding/validating words
 *  - Periodic scheduler driven by 1ms tick
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* from imported LPUART example: DEMO_LPUART, DEMO_LPUART_CLK_FREQ */
#include "fsl_debug_console.h"
#include "fsl_clock.h"          /* CLOCK_GetFreq */

#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "tick_1ms.h"

/* If you also imported PIT example, these macros are typically present in its app.h.
 * For a combined project, you may need to define them yourself or merge app.h files.
 */
#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

static void Demo_OnWord(uint32_t rawWord,
                        const a429b_word_fields_t *fields,
                        a429b_word_validity_t validity,
                        void *userData)
{
    (void)userData;

    /* Keep callback lightweight; it runs in main context but should still be bounded. */
    if (validity == A429B_WORD_VALID)
    {
        PRINTF("WORD OK: label=%u sdi=%u data=%lu ssm=%u raw=0x%08lX\r\n",
               fields->label,
               fields->sdi,
               (unsigned long)fields->data,
               (unsigned)fields->ssm,
               (unsigned long)rawWord);
    }
    else
    {
        PRINTF("WORD BAD(%u): raw=0x%08lX\r\n", (unsigned)validity, (unsigned long)rawWord);
    }
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 4: ARINC-like Word Bridge + Scheduler demo\r\n");

    /* 1) Start 1ms tick (PIT) */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };

    if (TICK_Init(&tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("TICK_Init failed\r\n");
        while (1) {}
    }

    /* 2) Initialize UFS (framed UART service)
     * IMPORTANT: set rxCb to A429B_UfsRxHook and userData to the bridge instance.
     */
    ufs_t ufs = {0};
    a429b_t bridge = {0};

    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 128u,
        .rxCb = A429B_UfsRxHook,
        .rxCbUserData = &bridge,
    };

    if (UFS_Init(&ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("UFS_Init failed\r\n");
        while (1) {}
    }

    /* 3) Initialize bridge */
    if (A429B_Init(&bridge, &ufs, Demo_OnWord, NULL) != kStatus_Success)
    {
        PRINTF("A429B_Init failed\r\n");
        while (1) {}
    }

    /* 4) Create two example words and schedule them periodically
     * Label 203 and 204 are arbitrary in this demo; interpret them in Milestone 5.
     */
    a429b_word_fields_t w1 = {
        .label = 203u,
        .sdi = 0u,
        .data = 1000u,
        .ssm = A429B_SSM_NORMAL_OPERATION,
        .parity = false,
    };

    a429b_word_fields_t w2 = {
        .label = 204u,
        .sdi = 0u,
        .data = 250u,
        .ssm = A429B_SSM_NORMAL_OPERATION,
        .parity = false,
    };

    uint32_t raw1 = 0u;
    uint32_t raw2 = 0u;
    (void)A429B_PackWord(&w1, &raw1);
    (void)A429B_PackWord(&w2, &raw2);

    /* Ensure parity is correct before scheduling */
    raw1 = A429B_SetEvenParity(raw1);
    raw2 = A429B_SetEvenParity(raw2);

    (void)A429B_ScheduleWord(&bridge, 0u, raw1, 100u); /* every 100ms */
    (void)A429B_ScheduleWord(&bridge, 1u, raw2, 200u); /* every 200ms */

    PRINTF("Connect two EVKB boards via UART (TX<->RX, GND). Flash same demo on both.\r\n");

    /* Main loop */
    uint32_t last = TICK_GetMs(&tick);
    uint32_t statsTimer = 0u;

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
        if (dt != 0u)
        {
            A429B_OnTickMs(&bridge, dt);
            statsTimer += dt;
        }

        /* Drive UART parsing and bridge RX decoding */
        (void)A429B_Poll(&bridge);

        /* Periodically print bridge + UFS stats */
        if (statsTimer >= 1000u)
        {
            statsTimer -= 1000u;

            a429b_stats_t bs;
            ufs_stats_t us;
            A429B_GetStats(&bridge, &bs);
            UFS_GetStats(&ufs, &us);

            PRINTF("A429B: rx=%lu tx=%lu pErr=%lu ssmErr=%lu fmtErr=%lu schedActive=%lu\r\n",
                   (unsigned long)bs.wordsRx,
                   (unsigned long)bs.wordsTx,
                   (unsigned long)bs.rxParityErrors,
                   (unsigned long)bs.rxSsmErrors,
                   (unsigned long)bs.rxFormatErrors,
                   (unsigned long)bs.schedEntriesActive);

            PRINTF("UFS: rxOk=%lu csumErr=%lu lenErr=%lu ovf=%lu txReq=%lu txDone=%lu\r\n",
                   (unsigned long)us.rxFramesOk,
                   (unsigned long)us.rxChecksumErrors,
                   (unsigned long)us.rxLengthErrors,
                   (unsigned long)us.rxRingOverflows,
                   (unsigned long)us.txFramesRequested,
                   (unsigned long)us.txFramesDone);
        }
    }
}
