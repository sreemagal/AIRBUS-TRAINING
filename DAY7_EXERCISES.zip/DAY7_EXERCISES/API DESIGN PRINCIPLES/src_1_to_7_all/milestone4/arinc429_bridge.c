/******************************************************************************
 * File: arinc429_bridge.c
 ******************************************************************************/
#include "arinc429_bridge.h"

/* ---------------- Parity utilities ---------------- */

static inline uint32_t A429B_Popcount32(uint32_t x)
{
    /* Portable popcount (fast enough for lab). */
    uint32_t c = 0u;
    while (x != 0u)
    {
        c += (x & 1u);
        x >>= 1u;
    }
    return c;
}

bool A429B_IsEvenParityValid(uint32_t rawWord)
{
    /* Even parity across full 32 bits means total ones count is even. */
    const uint32_t ones = A429B_Popcount32(rawWord);
    return ((ones % 2u) == 0u);
}

uint32_t A429B_SetEvenParity(uint32_t rawWord)
{
    /* Compute parity bit for bits[30:0] such that total ones across [31:0] is even. */
    const uint32_t lower = rawWord & 0x7FFFFFFFu; /* bits 0..30 */
    const uint32_t onesLower = A429B_Popcount32(lower);

    const uint32_t parityBit = (onesLower % 2u); /* if odd -> set 1 to make total even */

    rawWord &= 0x7FFFFFFFu;
    rawWord |= (parityBit << 31);
    return rawWord;
}

/* ---------------- Pack / Unpack ---------------- */

status_t A429B_PackWord(const a429b_word_fields_t *fields, uint32_t *outRawWord)
{
    if ((fields == NULL) || (outRawWord == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (fields->sdi > 3u)
    {
        return kStatus_OutOfRange;
    }

    if (fields->data > ((1u << 19) - 1u))
    {
        return kStatus_OutOfRange;
    }

    if ((uint32_t)fields->ssm > 3u)
    {
        return kStatus_OutOfRange;
    }

    uint32_t w = 0u;
    w |= (uint32_t)fields->label;
    w |= ((uint32_t)fields->sdi & 0x3u) << 8;
    w |= ((uint32_t)fields->data & 0x7FFFFu) << 10;
    w |= ((uint32_t)fields->ssm & 0x3u) << 29;

    /* parity bit is stored explicitly; caller may later choose to enforce even parity */
    if (fields->parity)
    {
        w |= (1u << 31);
    }

    *outRawWord = w;
    return kStatus_Success;
}

status_t A429B_UnpackWord(uint32_t rawWord, a429b_word_fields_t *outFields)
{
    if (outFields == NULL)
    {
        return kStatus_InvalidArgument;
    }

    outFields->label  = (uint8_t)(rawWord & 0xFFu);
    outFields->sdi    = (uint8_t)((rawWord >> 8) & 0x3u);
    outFields->data   = (uint32_t)((rawWord >> 10) & 0x7FFFFu);
    outFields->ssm    = (a429b_ssm_t)((rawWord >> 29) & 0x3u);
    outFields->parity = (((rawWord >> 31) & 0x1u) != 0u);

    return kStatus_Success;
}

/* ---------------- SSM policy (simplified) ---------------- */

static bool A429B_IsSsmValid(a429b_ssm_t ssm)
{
    /* For this lab, treat NORMAL and FUNCTIONAL_TEST as valid; others invalid. */
    return (ssm == A429B_SSM_NORMAL_OPERATION) || (ssm == A429B_SSM_FUNCTIONAL_TEST);
}

/* ---------------- Bridge core ---------------- */

static void A429B_InternalReset(a429b_t *bridge)
{
    for (uint32_t i = 0; i < A429B_MAX_SCHEDULED; i++)
    {
        bridge->sched[i].enabled = false;
        bridge->sched[i].periodMs = 0u;
        bridge->sched[i].dueMs = 0u;
        bridge->sched[i].word = 0u;
    }

    A429B_ResetStats(bridge);
}

status_t A429B_Init(a429b_t *bridge, ufs_t *ufs, a429b_word_cb_t cb, void *userData)
{
    if ((bridge == NULL) || (ufs == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (bridge->isInitialized)
    {
        /* Idempotence: same UFS pointer only */
        return (bridge->ufs == ufs) ? kStatus_Success : kStatus_Fail;
    }

    bridge->ufs = ufs;
    bridge->onWord = cb;
    bridge->onWordUserData = userData;

    A429B_InternalReset(bridge);

    bridge->isInitialized = true;
    return kStatus_Success;
}

/*
 * UFS RX hook:
 * - Called from UFS_Poll() context (main), NOT from ISR.
 * - Decodes payloads and delivers word callback.
 */
void A429B_UfsRxHook(const uint8_t *payload, uint8_t len, void *userData)
{
    a429b_t *bridge = (a429b_t *)userData;
    if ((bridge == NULL) || (!bridge->isInitialized) || (payload == NULL))
    {
        return;
    }

    if (len < 1u)
    {
        bridge->stats.rxFormatErrors++;
        return;
    }

    const uint8_t msgType = payload[0];
    if (msgType != A429B_MSG_WORD)
    {
        /* For this milestone, ignore unknown message types. */
        return;
    }

    /* Must be exactly 5 bytes: type + 4 bytes word */
    if (len != 5u)
    {
        bridge->stats.rxFormatErrors++;
        if (bridge->onWord != NULL)
        {
            a429b_word_fields_t dummy;
            (void)A429B_UnpackWord(0u, &dummy);
            bridge->onWord(0u, &dummy, A429B_WORD_INVALID_FORMAT, bridge->onWordUserData);
        }
        return;
    }

    /* Little-endian word assembly */
    const uint32_t rawWord = ((uint32_t)payload[1]) |
                             ((uint32_t)payload[2] << 8) |
                             ((uint32_t)payload[3] << 16) |
                             ((uint32_t)payload[4] << 24);

    bridge->stats.wordsRx++;

    a429b_word_fields_t f;
    (void)A429B_UnpackWord(rawWord, &f);

    a429b_word_validity_t validity = A429B_WORD_VALID;

    /* Validate parity */
    if (!A429B_IsEvenParityValid(rawWord))
    {
        validity = A429B_WORD_INVALID_PARITY;
        bridge->stats.rxParityErrors++;
    }

    /* Validate SSM (only if parity passed; you may choose to check regardless) */
    if ((validity == A429B_WORD_VALID) && (!A429B_IsSsmValid(f.ssm)))
    {
        validity = A429B_WORD_INVALID_SSM;
        bridge->stats.rxSsmErrors++;
    }

    if (bridge->onWord != NULL)
    {
        bridge->onWord(rawWord, &f, validity, bridge->onWordUserData);
    }
}

uint32_t A429B_Poll(a429b_t *bridge)
{
    if ((bridge == NULL) || (!bridge->isInitialized) || (bridge->ufs == NULL))
    {
        return 0u;
    }

    /*
     * We rely on UFS invoking our A429B_UfsRxHook for each received frame.
     * We return an approximate number: UFS_Poll returns frames dispatched; here we
     * count word callbacks indirectly is not tracked. For simplicity, return UFS frames.
     */
    return UFS_Poll(bridge->ufs);
}

status_t A429B_SendWord(a429b_t *bridge, uint32_t rawWord, bool ensureEvenParity)
{
    if ((bridge == NULL) || (!bridge->isInitialized) || (bridge->ufs == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (ensureEvenParity)
    {
        rawWord = A429B_SetEvenParity(rawWord);
    }

    uint8_t payload[5];
    payload[0] = A429B_MSG_WORD;
    payload[1] = (uint8_t)(rawWord & 0xFFu);
    payload[2] = (uint8_t)((rawWord >> 8) & 0xFFu);
    payload[3] = (uint8_t)((rawWord >> 16) & 0xFFu);
    payload[4] = (uint8_t)((rawWord >> 24) & 0xFFu);

    const status_t st = UFS_SendFrame(bridge->ufs, payload, (uint8_t)sizeof(payload));
    if (st == kStatus_Success)
    {
        bridge->stats.wordsTx++;
    }

    return st;
}

status_t A429B_ScheduleWord(a429b_t *bridge, uint32_t slot, uint32_t rawWord, uint32_t periodMs)
{
    if ((bridge == NULL) || (!bridge->isInitialized))
    {
        return kStatus_InvalidArgument;
    }

    if (slot >= A429B_MAX_SCHEDULED)
    {
        return kStatus_OutOfRange;
    }

    if (periodMs == 0u)
    {
        return kStatus_OutOfRange;
    }

    bridge->sched[slot].enabled = true;
    bridge->sched[slot].periodMs = periodMs;
    bridge->sched[slot].dueMs = periodMs; /* first send after one period */
    bridge->sched[slot].word = rawWord;

    return kStatus_Success;
}

status_t A429B_UnscheduleWord(a429b_t *bridge, uint32_t slot)
{
    if ((bridge == NULL) || (!bridge->isInitialized))
    {
        return kStatus_InvalidArgument;
    }

    if (slot >= A429B_MAX_SCHEDULED)
    {
        return kStatus_OutOfRange;
    }

    bridge->sched[slot].enabled = false;
    bridge->sched[slot].periodMs = 0u;
    bridge->sched[slot].dueMs = 0u;
    bridge->sched[slot].word = 0u;

    return kStatus_Success;
}

void A429B_OnTickMs(a429b_t *bridge, uint32_t dtMs)
{
    if ((bridge == NULL) || (!bridge->isInitialized) || (bridge->ufs == NULL))
    {
        return;
    }

    /* Skip policy: at most one send per entry per call. */
    for (uint32_t i = 0; i < A429B_MAX_SCHEDULED; i++)
    {
        if (!bridge->sched[i].enabled)
        {
            continue;
        }

        /* Update due timer */
        if (bridge->sched[i].dueMs > dtMs)
        {
            bridge->sched[i].dueMs -= dtMs;
            continue;
        }

        /* Due now */
        bridge->sched[i].dueMs = 0u;

        /* Attempt to send */
        const status_t st = A429B_SendWord(bridge, bridge->sched[i].word, true);
        if (st == kStatus_Success)
        {
            bridge->sched[i].dueMs = bridge->sched[i].periodMs;
        }
        else if (st == kStatus_LPUART_TxBusy)
        {
            /* Back-pressure: retry soon (1ms). */
            bridge->stats.schedTxBusyDrops++;
            bridge->sched[i].dueMs = 1u;
        }
        else
        {
            /* Other TX errors: retry after full period. */
            bridge->stats.schedTxErrors++;
            bridge->sched[i].dueMs = bridge->sched[i].periodMs;
        }
    }

    /* Update active count */
    uint32_t active = 0u;
    for (uint32_t i = 0; i < A429B_MAX_SCHEDULED; i++)
    {
        if (bridge->sched[i].enabled)
        {
            active++;
        }
    }
    bridge->stats.schedEntriesActive = active;
}

void A429B_GetStats(const a429b_t *bridge, a429b_stats_t *outStats)
{
    if ((bridge == NULL) || (outStats == NULL))
    {
        return;
    }

    *outStats = bridge->stats;
}

void A429B_ResetStats(a429b_t *bridge)
{
    if (bridge == NULL)
    {
        return;
    }

    bridge->stats.wordsRx = 0u;
    bridge->stats.wordsTx = 0u;
    bridge->stats.rxParityErrors = 0u;
    bridge->stats.rxSsmErrors = 0u;
    bridge->stats.rxFormatErrors = 0u;
    bridge->stats.schedEntriesActive = 0u;
    bridge->stats.schedTxBusyDrops = 0u;
    bridge->stats.schedTxErrors = 0u;
}

