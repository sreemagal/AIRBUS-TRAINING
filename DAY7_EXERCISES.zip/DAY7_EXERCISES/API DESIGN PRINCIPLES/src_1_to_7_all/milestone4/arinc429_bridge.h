/******************************************************************************
 * File: arinc429_bridge.h
 ******************************************************************************/
#ifndef ARINC429_BRIDGE_H_
#define ARINC429_BRIDGE_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"            /* status_t */
#include "uart_framed_service.h"  /* ufs_t */

/* Versioning */
#define A429B_VERSION_MAJOR (1u)
#define A429B_VERSION_MINOR (0u)
#define A429B_VERSION_PATCH (0u)

/* Message type carried inside UFS frame payload */
#define A429B_MSG_WORD (0xA1u)

#ifndef A429B_MAX_SCHEDULED
#define A429B_MAX_SCHEDULED (8u)
#endif

/*
 * Simplified ARINC-429-like word layout (as per the lab specification):
 *  Bits [7:0]   = Label
 *  Bits [9:8]   = SDI
 *  Bits [28:10] = Data (19 bits)
 *  Bits [30:29] = SSM (2 bits)
 *  Bit  [31]    = Parity (even parity across bits [30:0])
 */

typedef enum
{
    A429B_SSM_NORMAL_OPERATION = 0u, /* 00 */
    A429B_SSM_NO_COMPUTED_DATA = 1u, /* 01 */
    A429B_SSM_FUNCTIONAL_TEST  = 2u, /* 10 */
    A429B_SSM_FAILURE_WARNING  = 3u  /* 11 */
} a429b_ssm_t;

typedef struct
{
    uint8_t label;   /* [7:0] */
    uint8_t sdi;     /* [9:8]  (0..3) */
    uint32_t data;   /* [28:10] (0..2^19-1) */
    a429b_ssm_t ssm; /* [30:29] */
    bool parity;     /* [31] parity bit (even parity across bits 0..30) */
} a429b_word_fields_t;

typedef enum
{
    A429B_WORD_VALID = 0,
    A429B_WORD_INVALID_PARITY,
    A429B_WORD_INVALID_SSM,
    A429B_WORD_INVALID_FORMAT
} a429b_word_validity_t;

/* User callback: invoked from A429B_Poll() context (main), never from ISR. */
typedef void (*a429b_word_cb_t)(uint32_t rawWord,
                               const a429b_word_fields_t *fields,
                               a429b_word_validity_t validity,
                               void *userData);

/* Diagnostic counters */
typedef struct
{
    uint32_t wordsRx;
    uint32_t wordsTx;
    uint32_t rxParityErrors;
    uint32_t rxSsmErrors;
    uint32_t rxFormatErrors;

    uint32_t schedEntriesActive;
    uint32_t schedTxBusyDrops;
    uint32_t schedTxErrors;
} a429b_stats_t;

/* Scheduler entry */
typedef struct
{
    bool enabled;
    uint32_t periodMs; /* period > 0 */
    uint32_t dueMs;    /* countdown to next send */
    uint32_t word;     /* packed 32-bit raw word */
} a429b_sched_entry_t;

/* Bridge instance */
typedef struct
{
    ufs_t *ufs; /* Underlying framed UART service */

    /* Word delivery */
    a429b_word_cb_t onWord;
    void *onWordUserData;

    /* Scheduler */
    a429b_sched_entry_t sched[A429B_MAX_SCHEDULED];

    /* Diagnostics */
    a429b_stats_t stats;

    bool isInitialized;
} a429b_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize the ARINC-like bridge.
 *
 * @param bridge Bridge instance.
 * @param ufs    Pointer to already-initialized UFS service.
 * @param cb     Word callback (may be NULL if you only want scheduling/TX).
 * @param userData Cookie passed back in callback.
 *
 * @pre bridge != NULL
 * @pre ufs != NULL
 * @pre UFS has been initialized with rxCb set to A429B internal hook (see A429B_AttachToUfs()).
 *
 * @post bridge is ready for scheduling and for processing received frames.
 */
status_t A429B_Init(a429b_t *bridge, ufs_t *ufs, a429b_word_cb_t cb, void *userData);

/*
 * @brief Attach bridge as the RX callback target of UFS.
 *
 * Rationale:
 * - UFS invokes rxCb only from UFS_Poll() (main context), so the bridge will also
 *   run in main context.
 *
 * Usage:
 *   - Call UFS_Init(... rxCb = A429B_UfsRxHook, rxCbUserData = bridge ...)
 *   - Then call A429B_Init(bridge,...)
 */
void A429B_UfsRxHook(const uint8_t *payload, uint8_t len, void *userData);

/*
 * @brief Poll bridge: drives underlying UFS parsing and processes any delivered frames.
 *
 * @return number of valid word callbacks invoked during this call.
 */
uint32_t A429B_Poll(a429b_t *bridge);

/*
 * @brief Drive scheduler with elapsed time in milliseconds.
 *
 * Determinism policy:
 * - "Skip" catch-up: if dt is large, we send at most one instance per entry per call.
 * - If TX is busy, we retry shortly (dueMs set to 1).
 */
void A429B_OnTickMs(a429b_t *bridge, uint32_t dtMs);

/*
 * @brief Immediately transmit a raw 32-bit word.
 *
 * @param bridge Bridge instance.
 * @param rawWord Packed 32-bit word.
 * @param ensureEvenParity If true, parity bit [31] will be corrected before sending.
 */
status_t A429B_SendWord(a429b_t *bridge, uint32_t rawWord, bool ensureEvenParity);

/*
 * @brief Schedule a periodic word transmit.
 *
 * @param slot Index 0..A429B_MAX_SCHEDULED-1
 * @param rawWord Packed word
 * @param periodMs Period in ms (>0)
 */
status_t A429B_ScheduleWord(a429b_t *bridge, uint32_t slot, uint32_t rawWord, uint32_t periodMs);

/* Disable a scheduled entry. */
status_t A429B_UnscheduleWord(a429b_t *bridge, uint32_t slot);

/* Helpers: pack/unpack and validity checks */
status_t A429B_PackWord(const a429b_word_fields_t *fields, uint32_t *outRawWord);
status_t A429B_UnpackWord(uint32_t rawWord, a429b_word_fields_t *outFields);

bool A429B_IsEvenParityValid(uint32_t rawWord);
uint32_t A429B_SetEvenParity(uint32_t rawWord);

/* Stats */
void A429B_GetStats(const a429b_t *bridge, a429b_stats_t *outStats);
void A429B_ResetStats(a429b_t *bridge);

#ifdef __cplusplus
}
#endif

#endif /* ARINC429_BRIDGE_H_ */

