/******************************************************************************
 * File: tick_1ms.h
 ******************************************************************************/
#ifndef TICK_1MS_H_
#define TICK_1MS_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h" /* status_t, kStatus_* */
#include "fsl_pit.h"    /* PIT driver types */

/* Versioning for the tick module */
#define TICK_VERSION_MAJOR (1u)
#define TICK_VERSION_MINOR (0u)
#define TICK_VERSION_PATCH (0u)

/*
 * tick_1ms module intent
 * ----------------------
 * - Provide a monotonic timebase in milliseconds (wraps naturally at 2^32 ms).
 * - Provide a deterministic "consume delta" API for the main loop:
 *     delta_ms = now_ms - last_ms; last_ms = now_ms
 * - No callbacks from ISR.
 * - ISR work is bounded and minimal.
 * - Single-instance ownership for milestone simplicity.
 */

typedef struct
{
    PIT_Type *pitBase;      /* Typically PIT */
    pit_chnl_t pitChannel;  /* Typically kPIT_Chnl_0 */
    IRQn_Type pitIrq;       /* Typically PIT_IRQn */
    uint32_t sourceClockHz; /* PIT input clock in Hz (e.g., CLOCK_GetFreq(kCLOCK_OscClk)) */
    uint32_t tickPeriodUs;  /* Tick period in microseconds. For 1ms tick, set to 1000. */
} tick_config_t;

typedef struct
{
    PIT_Type *pitBase;
    pit_chnl_t pitChannel;
    IRQn_Type pitIrq;
    uint32_t tickPeriodUs;
    volatile uint32_t msCounter; /* incremented from PIT ISR */
    bool isInitialized;
} tick_handle_t;

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief Initialize the PIT-based tick generator.
 *
 * @param handle Caller-owned storage for the handle.
 * @param config Configuration for PIT and tick period.
 *
 * @pre  handle != NULL
 * @pre  config != NULL
 * @pre  config->pitBase != NULL
 * @pre  config->sourceClockHz != 0
 * @pre  config->tickPeriodUs != 0
 * @pre  Board clocking for PIT is enabled (done by BOARD_InitHardware() in SDK examples).
 *
 * @post PIT is configured and started.
 * @post msCounter starts at 0.
 * @post handle->isInitialized == true on success.
 *
 * Idempotence rule:
 *  - If called again on an initialized handle with the same PIT base/channel/IRQ and tickPeriodUs,
 *    returns kStatus_Success without reconfiguring hardware.
 *  - If called with a different configuration, returns kStatus_Fail.
 *
 * Concurrency/context:
 *  - Call from main context only.
 */
status_t TICK_Init(tick_handle_t *handle, const tick_config_t *config);

/*
 * @brief Get current monotonic time in milliseconds.
 *
 * @param handle Initialized tick handle.
 * @return Current millisecond count (wraps at 2^32).
 *
 * @pre handle != NULL
 * @pre handle->isInitialized == true
 *
 * Concurrency:
 *  - Safe to call from main context.
 *  - Value can change asynchronously due to ISR.
 */
uint32_t TICK_GetMs(const tick_handle_t *handle);

/*
 * @brief Consume elapsed milliseconds since the last call (delta pattern).
 *
 * @param handle Initialized tick handle.
 * @param lastMs Pointer to a caller-owned "last observed" timestamp.
 *
 * @return delta_ms = now_ms - *lastMs  (unsigned wrap-safe arithmetic)
 *
 * Usage pattern:
 *   uint32_t last = TICK_GetMs(&tick);
 *   for(;;) {
 *     uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
 *     ... update state machines using dt ...
 *   }
 *
 * @pre handle != NULL
 * @pre lastMs != NULL
 * @pre handle->isInitialized == true
 *
 * Concurrency:
 *  - Uses a short critical section to update *lastMs consistently with now.
 */
uint32_t TICK_ConsumeDeltaMs(const tick_handle_t *handle, uint32_t *lastMs);

/*
 * @brief Optional deinit (stops PIT). Not required for the lab, but useful.
 */
status_t TICK_Deinit(tick_handle_t *handle);

#ifdef __cplusplus
}
#endif

#endif /* TICK_1MS_H_ */

