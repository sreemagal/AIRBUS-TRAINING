/******************************************************************************
 * File: tick_1ms.c
 ******************************************************************************/
#include "tick_1ms.h"

#include "fsl_common.h" /* SDK_ISR_EXIT_BARRIER */

/*
 * Milestone simplification:
 * - Single active instance (one PIT interrupt vector).
 * - This is explicit and documented, so it remains verifiable.
 */
static tick_handle_t *s_tickInstance = NULL;

/* Forward declaration of the ISR installed via the vector table. */
void PIT_IRQHandler(void);

static bool TICK_IsSameConfig(const tick_handle_t *h, const tick_config_t *c)
{
    return (h->pitBase == c->pitBase) &&
           (h->pitChannel == c->pitChannel) &&
           (h->pitIrq == c->pitIrq) &&
           (h->tickPeriodUs == c->tickPeriodUs);
}

status_t TICK_Init(tick_handle_t *handle, const tick_config_t *config)
{
    if ((handle == NULL) || (config == NULL) || (config->pitBase == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if ((config->sourceClockHz == 0u) || (config->tickPeriodUs == 0u))
    {
        return kStatus_InvalidArgument;
    }

    /* If already initialized, enforce idempotence. */
    if (handle->isInitialized)
    {
        return TICK_IsSameConfig(handle, config) ? kStatus_Success : kStatus_Fail;
    }

    /* Enforce single-instance rule. */
    if ((s_tickInstance != NULL) && (s_tickInstance != handle))
    {
        return kStatus_Fail;
    }

    /* Store configuration in the handle first (so ISR can safely use it once enabled). */
    handle->pitBase       = config->pitBase;
    handle->pitChannel    = config->pitChannel;
    handle->pitIrq        = config->pitIrq;
    handle->tickPeriodUs  = config->tickPeriodUs;
    handle->msCounter     = 0u;

    /* Configure and start PIT */
    pit_config_t pitCfg;
    PIT_GetDefaultConfig(&pitCfg);

    /*
     * If you want PIT to halt while debugging, set:
     *   pitCfg.enableRunInDebug = false;
     *
     * For deterministic timing characterization, it can be useful to keep it
     * running in debug. Choose based on your lab workflow.
     */

    PIT_Init(handle->pitBase, &pitCfg);

    /*
     * PIT_SetTimerPeriod expects "count" in ticks. SDK provides USEC_TO_COUNT.
     * For a 1 ms tick: tickPeriodUs = 1000.
     */
    const uint32_t periodTicks = USEC_TO_COUNT(handle->tickPeriodUs, config->sourceClockHz);
    if (periodTicks == 0u)
    {
        /* Very low clock or too small period would underflow/invalid. */
        return kStatus_OutOfRange;
    }

    PIT_SetTimerPeriod(handle->pitBase, handle->pitChannel, periodTicks);

    /* Enable timer interrupt for the chosen channel */
    PIT_EnableInterrupts(handle->pitBase, handle->pitChannel, kPIT_TimerInterruptEnable);

    /* Enable NVIC for PIT */
    EnableIRQ(handle->pitIrq);

    /* Start PIT */
    PIT_StartTimer(handle->pitBase, handle->pitChannel);

    handle->isInitialized = true;
    s_tickInstance = handle;

    return kStatus_Success;
}

uint32_t TICK_GetMs(const tick_handle_t *handle)
{
    if ((handle == NULL) || (!handle->isInitialized))
    {
        return 0u;
    }

    /* 32-bit read is naturally atomic on Cortex-M for aligned word, but the counter
     * can change asynchronously due to ISR. For GetMs() that's fine.
     */
    return handle->msCounter;
}

uint32_t TICK_ConsumeDeltaMs(const tick_handle_t *handle, uint32_t *lastMs)
{
    if ((handle == NULL) || (lastMs == NULL) || (!handle->isInitialized))
    {
        return 0u;
    }

    /*
     * Critical section: keep it minimal.
     * We want consistency between now_ms and lastMs update even if the ISR fires.
     */
    uint32_t now;
    uint32_t prev;

    __disable_irq();
    now = handle->msCounter;
    prev = *lastMs;
    *lastMs = now;
    __enable_irq();

    return (uint32_t)(now - prev); /* wrap-safe unsigned arithmetic */
}

status_t TICK_Deinit(tick_handle_t *handle)
{
    if (handle == NULL)
    {
        return kStatus_InvalidArgument;
    }

    if (!handle->isInitialized)
    {
        return kStatus_Success;
    }

    PIT_StopTimer(handle->pitBase, handle->pitChannel);
    PIT_DisableInterrupts(handle->pitBase, handle->pitChannel, kPIT_TimerInterruptEnable);
    DisableIRQ(handle->pitIrq);

    /* Leave PIT module init state as-is; other code may use it.
     * For a strict ownership model you could call PIT_Deinit(), but keep it simple here.
     */

    handle->isInitialized = false;
    if (s_tickInstance == handle)
    {
        s_tickInstance = NULL;
    }

    return kStatus_Success;
}

/*
 * PIT interrupt handler
 * ---------------------
 * MUST remain constant-time and minimal.
 * No logging, no heavy work, no callbacks.
 */
void PIT_IRQHandler(void)
{
    if ((s_tickInstance == NULL) || (!s_tickInstance->isInitialized))
    {
        /* Spurious interrupt or not yet initialized. Safely clear all flags. */
        PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);
        SDK_ISR_EXIT_BARRIER;
        return;
    }

    /* Clear interrupt flag for the configured channel. */
    PIT_ClearStatusFlags(s_tickInstance->pitBase, s_tickInstance->pitChannel, kPIT_TimerFlag);

    /* 1 tick == 1 ms (as configured) */
    s_tickInstance->msCounter++;

    /*
     * Important on i.MXRT: CPU can outrun the IP bus clock clearing the flag.
     * This barrier prevents immediate re-entry into the handler.
     */
    SDK_ISR_EXIT_BARRIER;
}

