/******************************************************************************
 * File: pit.c  (replace the PIT example's main file with this demo)
 ******************************************************************************/
#include "fsl_debug_console.h"
#include "board.h"
#include "app.h"       /* From PIT example: DEMO_PIT_BASEADDR, DEMO_PIT_CHANNEL, PIT_IRQ_ID, LED macros */
#include "fsl_clock.h" /* CLOCK_GetFreq */

#include "tick_1ms.h"

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 2: 1ms Tick Service (PIT) + delta-consumption demo\r\n");
    PRINTF("Tick version %u.%u.%u\r\n", TICK_VERSION_MAJOR, TICK_VERSION_MINOR, TICK_VERSION_PATCH);

    /* Initialize LED via the imported PIT example macros */
    LED_INIT();

    /* Configure and start 1ms tick */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u, /* 1 ms */
    };

    const status_t st = TICK_Init(&tick, &tickCfg);
    if (st != kStatus_Success)
    {
        PRINTF("TICK_Init failed: %ld\r\n", (long)st);
        while (1)
        {
            /* Fail-safe */
        }
    }

    /*
     * Delta-consumption pattern:
     * - last tracks the last observed time.
     * - dt is elapsed time since last loop iteration.
     */
    uint32_t last = TICK_GetMs(&tick);
    uint32_t accumLedMs = 0u;
    uint32_t accumPrintMs = 0u;

    while (true)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &last);
        if (dt == 0u)
        {
            /* No tick elapsed since last iteration; do other background work here. */
            continue;
        }

        /* Example 1: toggle LED every 500 ms */
        accumLedMs += dt;
        if (accumLedMs >= 500u)
        {
            accumLedMs -= 500u;
            LED_TOGGLE();
        }

        /* Example 2: print a heartbeat once per second (avoid printing too often) */
        accumPrintMs += dt;
        if (accumPrintMs >= 1000u)
        {
            accumPrintMs -= 1000u;
            PRINTF("Heartbeat: ms=%lu\r\n", (unsigned long)TICK_GetMs(&tick));
        }

        /*
         * In later milestones, this is where you call:
         *   - UART service Poll()
         *   - domain scheduler update(dt)
         *   - application state machines
         */
    }
}
