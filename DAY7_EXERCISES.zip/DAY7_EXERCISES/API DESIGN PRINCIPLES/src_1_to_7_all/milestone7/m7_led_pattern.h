/******************************************************************************
 * File: m7_led_pattern.h
 ******************************************************************************/
#ifndef M7_LED_PATTERN_H_
#define M7_LED_PATTERN_H_

#include <stdbool.h>
#include <stdint.h>

#include "dio.h"
#include "m7_fault_manager.h"

/*
 * LED patterns (deterministic)
 *  OK:   1 Hz blink (500ms on, 500ms off)
 *  WARN: double-blink every 2 seconds
 *  FAIL: 5 Hz blink (100ms on, 100ms off)
 */

typedef struct
{
    dio_handle_t *led;

    m7_health_state_t state;

    uint32_t phaseMs;
    bool ledOn;
} m7_led_pattern_t;

void M7_LedPattern_Init(m7_led_pattern_t *lp, dio_handle_t *led);
void M7_LedPattern_SetState(m7_led_pattern_t *lp, m7_health_state_t state);
void M7_LedPattern_OnTickMs(m7_led_pattern_t *lp, uint32_t dtMs);

#endif /* M7_LED_PATTERN_H_ */

