/******************************************************************************
 * File: m7_diag_service.h
 ******************************************************************************/
#ifndef M7_DIAG_SERVICE_H_
#define M7_DIAG_SERVICE_H_

#include <stdbool.h>
#include <stdint.h>

#include "fsl_common.h"
#include "uart_framed_service.h"
#include "m7_fault_manager.h"
#include "m7_build_info.h"

/* Diagnostic messages (inside UFS payload[0]) */
#define M7_MSG_DIAG_REQ (0xE0u)
#define M7_MSG_DIAG_RSP (0xE1u)
#define M7_MSG_CLEAR_FAULTS (0xE2u)
#define M7_MSG_CLEAR_ACK   (0xE3u)

/*
 * DIAG_REQ payload:
 *   [0]=M7_MSG_DIAG_REQ
 *   [1..2]=seq16
 *
 * DIAG_RSP payload (fixed format, <= 64 bytes):
 *   [0]=M7_MSG_DIAG_RSP
 *   [1..2]=seq16
 *   [3]=fw_major
 *   [4]=fw_minor
 *   [5]=fw_patch
 *   [6]=health_state
 *   [7..10]=fault_mask (u32 LE)
 *   [11..14]=ufs_rxOk (u32 LE)
 *   [15..18]=ufs_csumErr (u32 LE)
 *   [19..22]=ufs_ovf (u32 LE)
 *   [23..26]=a429_wordsRx (u32 LE)
 *   [27..30]=air_validWords (u32 LE)
 *   [31..34]=air_invalidWords (u32 LE)
 *   [35..38]=uptime_ms (u32 LE)  (low 32 bits)
 *   [39]=buildStrLen
 *   [40..]=build string bytes (truncated to fit)
 */

typedef struct
{
    ufs_t *ufs;
    const tick_handle_t *tick;
    m7_fault_manager_t *faults;

    /* Sources for counters */
    const ufs_t *ufsStatsSrc;
    const a429b_t *a429;
    const airdata_t *air;

    /* Reply buffer */
    bool replyPending;
    uint8_t replyBuf[64];
    uint8_t replyLen;
} m7_diag_service_t;

void M7_Diag_Init(m7_diag_service_t *ds,
                  ufs_t *ufs,
                  const tick_handle_t *tick,
                  m7_fault_manager_t *faults,
                  const ufs_t *ufsStatsSrc,
                  const a429b_t *a429,
                  const airdata_t *air);

/* Called from UFS rx callback (main context) */
void M7_Diag_OnFrame(m7_diag_service_t *ds, const uint8_t *payload, uint8_t len);

/* Called from main loop dt; sends pending reply when TX is free */
void M7_Diag_OnTickMs(m7_diag_service_t *ds, uint32_t dtMs);

#endif /* M7_DIAG_SERVICE_H_ */

