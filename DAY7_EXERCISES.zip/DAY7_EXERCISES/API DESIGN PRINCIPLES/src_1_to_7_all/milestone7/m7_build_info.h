/******************************************************************************
 * File: m7_build_info.h
 ******************************************************************************/
#ifndef M7_BUILD_INFO_H_
#define M7_BUILD_INFO_H_

#include <stdint.h>

/* Firmware identity (edit to match your program naming) */
#define M7_FW_NAME "AIRBUS_BARE_METAL_LAB"

/* Semantic version (system-level) */
#define M7_FW_VERSION_MAJOR (0u)
#define M7_FW_VERSION_MINOR (7u)
#define M7_FW_VERSION_PATCH (0u)

/* Build metadata */
#define M7_BUILD_DATE __DATE__
#define M7_BUILD_TIME __TIME__

/* Toolchain string (best-effort) */
#if defined(__clang__)
#define M7_COMPILER_STR "clang"
#elif defined(__GNUC__)
#define M7_COMPILER_STR "gcc"
#elif defined(__ARMCC_VERSION)
#define M7_COMPILER_STR "armcc"
#else
#define M7_COMPILER_STR "unknown"
#endif

/* Returns a pointer to a static string (no allocation). */
const char *M7_GetBuildInfoString(void);

#endif /* M7_BUILD_INFO_H_ */

