/******************************************************************************
 * File: m7_fault_manager.c
 ******************************************************************************/
#include "m7_fault_manager.h"

static m7_health_state_t M7_ComputeHealth(uint32_t faults)
{
    /* Simple policy:
     * - Any fault present -> WARN
     * - Some faults can escalate to FAIL (customize as needed)
     */
    if (faults == 0u)
    {
        return M7_HEALTH_OK;
    }

    if (faults & (M7_FAULT_UART_RX_OVERFLOW | M7_FAULT_DOMAIN_PARITY_ERR))
    {
        /* Treat overflow and parity as higher severity */
        return M7_HEALTH_FAIL;
    }

    return M7_HEALTH_WARN;
}

void M7_FaultManager_Init(m7_fault_manager_t *fm)
{
    fm->latchedFaults = 0u;
    fm->health = M7_HEALTH_OK;

    /* Conservative defaults */
    fm->checksumErrPerSecWarn = 5u;

    fm->evalAccumMs = 0u;
    fm->hasPrev = false;
}

void M7_FaultManager_Clear(m7_fault_manager_t *fm)
{
    fm->latchedFaults = 0u;
    fm->health = M7_HEALTH_OK;
    fm->hasPrev = false;
    fm->evalAccumMs = 0u;
}

void M7_FaultManager_OnTickMs(m7_fault_manager_t *fm,
                             uint32_t dtMs,
                             const ufs_t *ufs,
                             const a429b_t *a429,
                             const airdata_t *air)
{
    if ((fm == NULL) || (ufs == NULL) || (a429 == NULL) || (air == NULL) || (dtMs == 0u))
    {
        return;
    }

    fm->evalAccumMs += dtMs;
    if (fm->evalAccumMs < 1000u)
    {
        return; /* evaluate at ~1 Hz */
    }

    fm->evalAccumMs -= 1000u;

    /* Snapshot current stats */
    ufs_stats_t us;
    a429b_stats_t as;
    airdata_snapshot_t airSnap;

    UFS_GetStats(ufs, &us);
    A429B_GetStats(a429, &as);
    AirData_GetSnapshot(air, &airSnap);

    if (!fm->hasPrev)
    {
        fm->prevUfs = us;
        fm->prevA429 = as;
        fm->prevAir = airSnap;
        fm->hasPrev = true;
        fm->health = M7_ComputeHealth(fm->latchedFaults);
        return;
    }

    /* Check RX ring overflow increments */
    if (us.rxRingOverflows != fm->prevUfs.rxRingOverflows)
    {
        fm->latchedFaults |= M7_FAULT_UART_RX_OVERFLOW;
    }

    /* Check checksum error rate (per second) */
    {
        const uint32_t diff = us.rxChecksumErrors - fm->prevUfs.rxChecksumErrors;
        if (diff >= fm->checksumErrPerSecWarn)
        {
            fm->latchedFaults |= M7_FAULT_UART_CHECKSUM_RATE;
        }
    }

    /* Domain errors */
    if (as.rxParityErrors != fm->prevA429.rxParityErrors)
    {
        fm->latchedFaults |= M7_FAULT_DOMAIN_PARITY_ERR;
    }
    if (as.rxSsmErrors != fm->prevA429.rxSsmErrors)
    {
        fm->latchedFaults |= M7_FAULT_DOMAIN_SSM_ERR;
    }

    /* Application stale events */
    if ((airSnap.stats.altStaleEvents != fm->prevAir.stats.altStaleEvents) ||
        (airSnap.stats.iasStaleEvents != fm->prevAir.stats.iasStaleEvents))
    {
        fm->latchedFaults |= M7_FAULT_APP_STALE_DATA;
    }

    /* Update prev snapshots */
    fm->prevUfs = us;
    fm->prevA429 = as;
    fm->prevAir = airSnap;

    /* Derive health */
    fm->health = M7_ComputeHealth(fm->latchedFaults);
}

