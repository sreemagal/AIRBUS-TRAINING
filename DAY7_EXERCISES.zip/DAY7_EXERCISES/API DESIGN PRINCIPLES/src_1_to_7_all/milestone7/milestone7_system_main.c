/******************************************************************************
 * File: milestone7_system_main.c
 *
 * Demonstrates:
 *  - Startup BIT (initialization checks)
 *  - Health evaluation once per second
 *  - Fault LED patterns
 *  - Diagnostic request/response
 *  - Optional sensor role that transmits labels 203/204 periodically
 ******************************************************************************/

#include "board.h"
#include "app.h"                /* DEMO_LPUART, DEMO_LPUART_CLK_FREQ, board LED macros */
#include "fsl_debug_console.h"
#include "fsl_clock.h"

#include "dio.h"
#include "tick_1ms.h"
#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"

#include "m7_build_info.h"
#include "m7_fault_manager.h"
#include "m7_led_pattern.h"
#include "m7_diag_service.h"

/* Role selection for demo:
 *  0 = Mission Computer (receiver)
 *  1 = Sensor Emulator (transmits 203/204)
 */
#ifndef M7_NODE_ROLE
#define M7_NODE_ROLE (0u)
#endif

/* PIT defaults if missing from your headers */
#ifndef DEMO_PIT_BASEADDR
#define DEMO_PIT_BASEADDR PIT
#endif
#ifndef DEMO_PIT_CHANNEL
#define DEMO_PIT_CHANNEL kPIT_Chnl_0
#endif
#ifndef PIT_IRQ_ID
#define PIT_IRQ_ID PIT_IRQn
#endif

/*
 * RX dispatching
 * - UFS delivers all frames here (main context via UFS_Poll)
 * - We route:
 *     - A429B words to domain decoder
 *     - M7 diag messages to diag service
 */
typedef struct
{
    a429b_t *bridge;
    m7_diag_service_t *diag;
} m7_rx_ctx_t;

static m7_rx_ctx_t s_rxCtx;

static void M7_UfsRxDispatcher(const uint8_t *payload, uint8_t len, void *userData)
{
    m7_rx_ctx_t *ctx = (m7_rx_ctx_t *)userData;
    if ((ctx == NULL) || (payload == NULL) || (len == 0u))
    {
        return;
    }

    const uint8_t type = payload[0];

    if (type == A429B_MSG_WORD)
    {
        A429B_UfsRxHook(payload, len, ctx->bridge);
    }
    else if ((type == M7_MSG_DIAG_REQ) || (type == M7_MSG_CLEAR_FAULTS))
    {
        M7_Diag_OnFrame(ctx->diag, payload, len);
    }
    else
    {
        /* Unknown message: ignore for this milestone */
    }
}

/* Domain -> application callback */
static airdata_t s_air;
static void M7_OnWord(uint32_t rawWord,
                      const a429b_word_fields_t *fields,
                      a429b_word_validity_t validity,
                      void *userData)
{
    (void)userData;
    AirData_OnWord(&s_air, rawWord, fields, validity);
}

/* Startup BIT: return true if init sequence passed */
static bool M7_StartupBit(void)
{
    /* Minimal BIT: verify that required modules initialized earlier succeeded.
     * In this demo, we rely on return-code checks in main().
     * If you want deeper BIT, add hardware self-checks here.
     */
    return true;
}

int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\nMilestone 7: System Integration + Health + Diag\r\n");
    PRINTF("Build: %s\r\n", M7_GetBuildInfoString());
    PRINTF("Role: %s\r\n", (M7_NODE_ROLE == 0u) ? "MissionComputer" : "SensorEmulator");

    /* ---- LED via DIO ---- */
    dio_handle_t led = {0};

    /* Map these macros in your board layer.
     * If your project uses different names, change here to match.
     */
#ifndef BOARD_USER_LED_GPIO
#define BOARD_USER_LED_GPIO EXAMPLE_LED_GPIO
#endif
#ifndef BOARD_USER_LED_GPIO_PIN
#define BOARD_USER_LED_GPIO_PIN EXAMPLE_LED_GPIO_PIN
#endif

    const dio_config_t ledCfg = {
        .base = BOARD_USER_LED_GPIO,
        .pin  = BOARD_USER_LED_GPIO_PIN,
        .activeLow = true,
        .initialOn = false,
    };

    if (DIO_Init(&led, &ledCfg) != kStatus_Success)
    {
        PRINTF("FATAL: LED init failed\r\n");
        while (1) {}
    }

    /* ---- Tick 1ms (PIT) ---- */
    tick_handle_t tick = {0};
    const tick_config_t tickCfg = {
        .pitBase       = DEMO_PIT_BASEADDR,
        .pitChannel    = DEMO_PIT_CHANNEL,
        .pitIrq        = PIT_IRQ_ID,
        .sourceClockHz = CLOCK_GetFreq(kCLOCK_OscClk),
        .tickPeriodUs  = 1000u,
    };

    if (TICK_Init(&tick, &tickCfg) != kStatus_Success)
    {
        PRINTF("FATAL: tick init failed\r\n");
        while (1) {}
    }

    /* ---- Application ---- */
    const airdata_config_t airCfg = {
        .activityPulseMs = 50u,
        .altStaleTimeoutMs = 500u,
        .iasStaleTimeoutMs = 500u,
        .acceptFunctionalTest = false,
    };

    if (AirData_Init(&s_air, &airCfg) != kStatus_Success)
    {
        PRINTF("FATAL: AirData init failed\r\n");
        while (1) {}
    }

    /* ---- UFS ---- */
    ufs_t ufs = {0};
    a429b_t bridge = {0};

    /* Fault management + LED pattern + diag service */
    m7_fault_manager_t faults;
    m7_led_pattern_t ledPat;
    m7_diag_service_t diag;

    M7_FaultManager_Init(&faults);
    M7_LedPattern_Init(&ledPat, &led);

    /* Set dispatcher context */
    s_rxCtx.bridge = &bridge;
    s_rxCtx.diag = &diag;

    const ufs_config_t ufsCfg = {
        .base = DEMO_LPUART,
        .srcClockHz = DEMO_LPUART_CLK_FREQ,
        .baudRate = 115200u,
        .initPeripheral = true,
        .maxBytesPerPoll = 192u,
        .rxCb = M7_UfsRxDispatcher,
        .rxCbUserData = &s_rxCtx,
    };

    if (UFS_Init(&ufs, &ufsCfg) != kStatus_Success)
    {
        PRINTF("FATAL: UFS init failed\r\n");
        while (1) {}
    }

    /* ---- Domain bridge ---- */
    if (A429B_Init(&bridge, &ufs, M7_OnWord, NULL) != kStatus_Success)
    {
        PRINTF("FATAL: A429B init failed\r\n");
        while (1) {}
    }

    /* ---- Diag service (replies over UFS) ---- */
    M7_Diag_Init(&diag, &ufs, &tick, &faults, &ufs, &bridge, &s_air);

    /* ---- Startup BIT ---- */
    const bool bitOk = M7_StartupBit();
    if (!bitOk)
    {
        faults.latchedFaults |= M7_FAULT_DOMAIN_PARITY_ERR; /* example: flag a severe fault */
        faults.health = M7_HEALTH_FAIL;
        PRINTF("BIT FAILED: entering FAIL state\r\n");
    }

    /* ---- Optional sensor scheduling ---- */
    uint32_t simAlt = 1000u;
    uint32_t simIas = 250u;

    if (M7_NODE_ROLE == 1u)
    {
        /* Sensor sends words periodically using domain scheduler */
        a429b_word_fields_t fAlt = {
            .label = 203u, .sdi = 0u, .data = simAlt, .ssm = A429B_SSM_NORMAL_OPERATION, .parity = false,
        };
        a429b_word_fields_t fIas = {
            .label = 204u, .sdi = 0u, .data = simIas, .ssm = A429B_SSM_NORMAL_OPERATION, .parity = false,
        };
        uint32_t wAlt, wIas;
        (void)A429B_PackWord(&fAlt, &wAlt);
        (void)A429B_PackWord(&fIas, &wIas);
        wAlt = A429B_SetEvenParity(wAlt);
        wIas = A429B_SetEvenParity(wIas);

        (void)A429B_ScheduleWord(&bridge, 0u, wAlt, 50u);
        (void)A429B_ScheduleWord(&bridge, 1u, wIas, 50u);

        PRINTF("SensorEmulator: sending labels 203/204 at 20 Hz\r\n");
    }
    else
    {
        PRINTF("MissionComputer: send DIAG_REQ from another node to read status\r\n");
    }

    /* ---- Main loop (deterministic architecture) ---- */
    uint32_t lastMs = TICK_GetMs(&tick);
    uint32_t printTimerMs = 0u;

    while (1)
    {
        const uint32_t dt = TICK_ConsumeDeltaMs(&tick, &lastMs);

        if (dt != 0u)
        {
            /* Drive periodic components */
            AirData_OnTickMs(&s_air, dt);
            A429B_OnTickMs(&bridge, dt);
            M7_Diag_OnTickMs(&diag, dt);

            /* Health monitoring (evaluates at ~1Hz internally) */
            M7_FaultManager_OnTickMs(&faults, dt, &ufs, &bridge, &s_air);
            M7_LedPattern_SetState(&ledPat, faults.health);
            M7_LedPattern_OnTickMs(&ledPat, dt);

            printTimerMs += dt;
        }

        /* Poll RX parsing and frame dispatching */
        (void)UFS_Poll(&ufs);

        /* Non-time-critical periodic log */
        if (printTimerMs >= 1000u)
        {
            printTimerMs -= 1000u;

            airdata_snapshot_t snap;
            AirData_GetSnapshot(&s_air, &snap);

            PRINTF("Health=%u faults=0x%08lX ALT=%s%lu IAS=%s%lu\r\n",
                   (unsigned)faults.health,
                   (unsigned long)faults.latchedFaults,
                   snap.altValid ? "OK" : "--",
                   (unsigned long)snap.altitude_ft,
                   snap.iasValid ? "OK" : "--",
                   (unsigned long)snap.ias_kt);
        }
    }
}
