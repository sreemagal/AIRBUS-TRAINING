/******************************************************************************
 * File: m7_fault_manager.h
 ******************************************************************************/
#ifndef M7_FAULT_MANAGER_H_
#define M7_FAULT_MANAGER_H_

#include <stdbool.h>
#include <stdint.h>

#include "uart_framed_service.h"
#include "arinc429_bridge.h"
#include "air_data_app.h"

/* Fault bit definitions (latched by default) */
#define M7_FAULT_UART_RX_OVERFLOW     (1u << 0)
#define M7_FAULT_UART_CHECKSUM_RATE   (1u << 1)
#define M7_FAULT_DOMAIN_PARITY_ERR    (1u << 2)
#define M7_FAULT_DOMAIN_SSM_ERR       (1u << 3)
#define M7_FAULT_APP_STALE_DATA       (1u << 4)

typedef enum
{
    M7_HEALTH_OK = 0,
    M7_HEALTH_WARN,
    M7_HEALTH_FAIL
} m7_health_state_t;

typedef struct
{
    /* Current latched faults (bitmask) */
    uint32_t latchedFaults;

    /* Health state derived from faults */
    m7_health_state_t health;

    /* Previous snapshots (for rate checks) */
    ufs_stats_t prevUfs;
    a429b_stats_t prevA429;
    airdata_snapshot_t prevAir;

    bool hasPrev;

    /* Tunable thresholds */
    uint32_t checksumErrPerSecWarn; /* if checksum errors increase by this per second -> warn */

    /* Internal timer for evaluation cadence */
    uint32_t evalAccumMs;
} m7_fault_manager_t;

void M7_FaultManager_Init(m7_fault_manager_t *fm);

/* Evaluate faults using module stats; call periodically with dtMs (recommended 1000ms cadence). */
void M7_FaultManager_OnTickMs(m7_fault_manager_t *fm,
                             uint32_t dtMs,
                             const ufs_t *ufs,
                             const a429b_t *a429,
                             const airdata_t *air);

/* Clear all latched faults (maintenance action). */
void M7_FaultManager_Clear(m7_fault_manager_t *fm);

#endif /* M7_FAULT_MANAGER_H_ */

