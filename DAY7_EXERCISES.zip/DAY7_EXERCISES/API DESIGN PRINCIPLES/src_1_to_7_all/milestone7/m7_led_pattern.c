/******************************************************************************
 * File: m7_led_pattern.c
 ******************************************************************************/
#include "m7_led_pattern.h"

void M7_LedPattern_Init(m7_led_pattern_t *lp, dio_handle_t *led)
{
    lp->led = led;
    lp->state = M7_HEALTH_OK;
    lp->phaseMs = 0u;
    lp->ledOn = false;

    (void)DIO_Write(lp->led, false);
}

void M7_LedPattern_SetState(m7_led_pattern_t *lp, m7_health_state_t state)
{
    lp->state = state;
    lp->phaseMs = 0u;
}

void M7_LedPattern_OnTickMs(m7_led_pattern_t *lp, uint32_t dtMs)
{
    if ((lp == NULL) || (lp->led == NULL) || (dtMs == 0u))
    {
        return;
    }

    lp->phaseMs += dtMs;

    switch (lp->state)
    {
        case M7_HEALTH_OK:
        {
            /* 1 Hz: 0-499 on, 500-999 off */
            const uint32_t p = lp->phaseMs % 1000u;
            lp->ledOn = (p < 500u);
            break;
        }

        case M7_HEALTH_WARN:
        {
            /* Double blink every 2000ms:
             * 0-99 on, 100-199 off, 200-299 on, else off
             */
            const uint32_t p = lp->phaseMs % 2000u;
            lp->ledOn = (p < 100u) || ((p >= 200u) && (p < 300u));
            break;
        }

        case M7_HEALTH_FAIL:
        default:
        {
            /* 5 Hz: 0-99 on, 100-199 off */
            const uint32_t p = lp->phaseMs % 200u;
            lp->ledOn = (p < 100u);
            break;
        }
    }

    (void)DIO_Write(lp->led, lp->ledOn);
}

