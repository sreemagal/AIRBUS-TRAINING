/******************************************************************************
 * File: m7_diag_service.c
 ******************************************************************************/
#include "m7_diag_service.h"

static inline void M7_PutU16LE(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
}

static inline uint16_t M7_GetU16LE(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static inline void M7_PutU32LE(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
    p[2] = (uint8_t)((v >> 16) & 0xFFu);
    p[3] = (uint8_t)((v >> 24) & 0xFFu);
}

static void M7_Diag_Queue(m7_diag_service_t *ds, const uint8_t *p, uint8_t len)
{
    if ((len == 0u) || (len > (uint8_t)sizeof(ds->replyBuf)))
    {
        return;
    }

    for (uint32_t i = 0; i < len; i++)
    {
        ds->replyBuf[i] = p[i];
    }

    ds->replyLen = len;
    ds->replyPending = true;
}

static void M7_Diag_BuildRsp(m7_diag_service_t *ds, uint16_t seq)
{
    ufs_stats_t us = {0};
    a429b_stats_t as = {0};
    airdata_snapshot_t air = {0};

    UFS_GetStats(ds->ufsStatsSrc, &us);
    A429B_GetStats(ds->a429, &as);
    AirData_GetSnapshot(ds->air, &air);

    const uint32_t uptime = TICK_GetMs(ds->tick);

    uint8_t p[64];
    uint32_t idx = 0u;

    p[idx++] = M7_MSG_DIAG_RSP;
    M7_PutU16LE(&p[idx], seq); idx += 2u;

    p[idx++] = (uint8_t)M7_FW_VERSION_MAJOR;
    p[idx++] = (uint8_t)M7_FW_VERSION_MINOR;
    p[idx++] = (uint8_t)M7_FW_VERSION_PATCH;

    p[idx++] = (uint8_t)ds->faults->health;

    M7_PutU32LE(&p[idx], ds->faults->latchedFaults); idx += 4u;
    M7_PutU32LE(&p[idx], us.rxFramesOk); idx += 4u;
    M7_PutU32LE(&p[idx], us.rxChecksumErrors); idx += 4u;
    M7_PutU32LE(&p[idx], us.rxRingOverflows); idx += 4u;
    M7_PutU32LE(&p[idx], as.wordsRx); idx += 4u;
    M7_PutU32LE(&p[idx], air.stats.validWordsTotal); idx += 4u;
    M7_PutU32LE(&p[idx], air.stats.invalidWordsTotal); idx += 4u;
    M7_PutU32LE(&p[idx], uptime); idx += 4u;

    const char *bi = M7_GetBuildInfoString();

    /* Copy build info string with explicit length byte (truncate to fit) */
    uint32_t maxStr = (sizeof(p) - idx - 1u); /* reserve length byte */
    uint32_t n = 0u;
    while ((bi[n] != '\0') && (n < maxStr))
    {
        n++;
    }

    p[idx++] = (uint8_t)n;
    for (uint32_t i = 0; i < n; i++)
    {
        p[idx++] = (uint8_t)bi[i];
    }

    M7_Diag_Queue(ds, p, (uint8_t)idx);
}

void M7_Diag_Init(m7_diag_service_t *ds,
                  ufs_t *ufs,
                  const tick_handle_t *tick,
                  m7_fault_manager_t *faults,
                  const ufs_t *ufsStatsSrc,
                  const a429b_t *a429,
                  const airdata_t *air)
{
    ds->ufs = ufs;
    ds->tick = tick;
    ds->faults = faults;
    ds->ufsStatsSrc = ufsStatsSrc;
    ds->a429 = a429;
    ds->air = air;

    ds->replyPending = false;
    ds->replyLen = 0u;
}

void M7_Diag_OnFrame(m7_diag_service_t *ds, const uint8_t *payload, uint8_t len)
{
    if ((ds == NULL) || (payload == NULL) || (len < 3u))
    {
        return;
    }

    const uint8_t type = payload[0];
    const uint16_t seq = M7_GetU16LE(&payload[1]);

    if (type == M7_MSG_DIAG_REQ)
    {
        M7_Diag_BuildRsp(ds, seq);
    }
    else if (type == M7_MSG_CLEAR_FAULTS)
    {
        M7_FaultManager_Clear(ds->faults);
        uint8_t ack[3];
        ack[0] = M7_MSG_CLEAR_ACK;
        M7_PutU16LE(&ack[1], seq);
        M7_Diag_Queue(ds, ack, sizeof(ack));
    }
    else
    {
        /* ignore */
    }
}

void M7_Diag_OnTickMs(m7_diag_service_t *ds, uint32_t dtMs)
{
    (void)dtMs;

    if ((ds == NULL) || (!ds->replyPending))
    {
        return;
    }

    if (!UFS_IsTxBusy(ds->ufs))
    {
        if (UFS_SendFrame(ds->ufs, ds->replyBuf, ds->replyLen) == kStatus_Success)
        {
            ds->replyPending = false;
            ds->replyLen = 0u;
        }
    }
}

