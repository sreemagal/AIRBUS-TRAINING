/******************************************************************************
 * File: m7_build_info.c
 ******************************************************************************/
#include "m7_build_info.h"

const char *M7_GetBuildInfoString(void)
{
    /* Keep it short for embedded logs; avoid sprintf at runtime. */
    return M7_FW_NAME " v" 
           /* stringify numbers via preprocessor */
           "0" "." "7" "." "0"
           " (" M7_COMPILER_STR ", " M7_BUILD_DATE " " M7_BUILD_TIME ")";
}

