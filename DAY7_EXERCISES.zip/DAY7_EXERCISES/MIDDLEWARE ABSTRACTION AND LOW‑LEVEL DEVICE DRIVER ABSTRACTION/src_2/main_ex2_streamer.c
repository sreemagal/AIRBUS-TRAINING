#include <intrinsics.h>
#include <stdio.h>

#include "boardSupport.h"
#include "console.h"
#include "uart_if.h"

#include "3582A_83A_Driver.h" /* for HI3582_BASE + types */

#include "hi8582_lldd.h"
#include "arinc_streamer.h"

/*
 * The original demo pattern: provide the mapped EBI base as a global constant.
 */
const H3582 pH3582 = HI3582_BASE;

/* Tune these for your UART/traffic */
#define POLL_MAX_READS_PER_TICK   64U
#define FLUSH_MAX_LINES_PER_TICK  10U

/* Optional: enable HW label recognition to reduce load */
#define USE_HW_LABEL_RECOGNITION  1

/* Optional: also enable SW filtering (useful during bring-up) */
#define USE_SW_LABEL_FILTER       0

static void app_banner(uint16_t sr)
{
    uart_if_write_str("\r\n--- EX2: HI-8582 ARINC Streamer (LLDD+Middleware) ---\r\n");
    {
        char buf[64];
        sprintf(buf, "Reset Status=0x%04X\r\n", (unsigned)sr);
        uart_if_write_str(buf);
    }
    uart_if_write_str("Protocol: R<rx>,<8HEX>\\r\\n\r\n");
}

void main(void)
{
    const Pin pinNMR = PIN_NMR;

    __disable_interrupt();

    /* Ensure nMR low then configure as output */
    AT91C_BASE_PIOC->PIO_CODR = nMR;
    PIO_Configure(&pinNMR, 1);

    /* Configure demo GPIO pins (includes SEL, LEDs, DR/HF/FF inputs, buttons) */
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();
#endif

    init_timer();

    /* Enable external reset */
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    /* UART transport */
    uart_if_init_115200();

    /* Reset HI-8582 and apply a basic configuration */
    uint16_t sr = hi8582_reset_pulse();

    /*
     * The demo’s DEFAULTCONFG selects:
     * - unscrambled
     * - high speed
     * - odd parity
     * - normal mode
     * - label recognition disabled
     */
    hi8582_write_control(DEFAULTCONFG);

#if USE_HW_LABEL_RECOGNITION
    /* Example label sets (16 labels each) */
    static const uint8_t rx1_labels[16] = {
        0x01,0x02,0x03,0x04, 0x10,0x11,0x12,0x13, 0x20,0x21,0x22,0x23, 0x30,0x31,0x32,0x33
    };
    static const uint8_t rx2_labels[16] = {
        0x40,0x41,0x42,0x43, 0x50,0x51,0x52,0x53, 0x60,0x61,0x62,0x63, 0x70,0x71,0x72,0x73
    };

    hi8582_program_label_table(HI8582_RX1, rx1_labels);
    hi8582_program_label_table(HI8582_RX2, rx2_labels);

    hi8582_set_label_recognition(HI8582_RX1, true);
    hi8582_set_label_recognition(HI8582_RX2, true);
#endif

    __enable_interrupt();

    app_banner(sr);

    /* Middleware ring buffer */
    static arinc_item_t rb_storage[512];
    arinc_streamer_t streamer;
    arinc_streamer_init(&streamer, rb_storage, (uint16_t)(sizeof(rb_storage) / sizeof(rb_storage[0])));

#if USE_SW_LABEL_FILTER
    {
        static const uint8_t labels[] = { 0x21, 0x22, 0x23 };
        arinc_streamer_set_sw_label_filter(&streamer, labels, (uint8_t)sizeof(labels));
        uart_if_write_str("SW label filter enabled\r\n");
    }
#endif

    uint32_t tick = 0U;

    while (1)
    {
        /* Pull as many words as we can without starving the CPU */
        arinc_streamer_poll(&streamer, POLL_MAX_READS_PER_TICK);

        /* Throttle UART output to stay within 115200 */
        (void)arinc_streamer_flush_uart(&streamer, FLUSH_MAX_LINES_PER_TICK);

        /* Periodic health output */
        tick++;
        if ((tick % 5000U) == 0U)
        {
            char buf[64];
            sprintf(buf, "Dropped=%lu\r\n", (unsigned long)streamer.dropped);
            uart_if_write_str(buf);
        }

        __NOP();
    }
}

R1,XXXXXXXX
R2,XXXXXXXX
