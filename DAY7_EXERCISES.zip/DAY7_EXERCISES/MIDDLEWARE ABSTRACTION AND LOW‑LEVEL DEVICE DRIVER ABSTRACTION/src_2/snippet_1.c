R<rx>,<8-hex>

Example:
R1,87654321
