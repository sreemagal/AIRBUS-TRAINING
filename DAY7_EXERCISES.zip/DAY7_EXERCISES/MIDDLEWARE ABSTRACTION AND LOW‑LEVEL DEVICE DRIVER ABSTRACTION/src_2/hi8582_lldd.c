#include "hi8582_lldd.h"

#include "boardSupport.h"        /* SEL, nMR, CR1/CR2/CR3, etc */
#include "3582A_83A_Driver.h"    /* H3582 register map type */

/* Provided by the application (same pattern as the original demo) */
extern const H3582 pH3582;

static inline void sel_set_high(void)
{
    AT91C_BASE_PIOC->PIO_SODR = SEL;
}

static inline void sel_set_low(void)
{
    AT91C_BASE_PIOC->PIO_CODR = SEL;
}

uint16_t hi8582_reset_pulse(void)
{
    /* Active-low pulse on nMR; matches demo behavior */
    unsigned int i = 1U;
    AT91C_BASE_PIOC->PIO_CODR = nMR;
    while (i--) { __NOP(); }
    AT91C_BASE_PIOC->PIO_SODR = nMR;

    return hi8582_read_status();
}

void hi8582_write_control(uint16_t cw)
{
    pH3582->CWSTR = cw;
}

uint16_t hi8582_read_control(void)
{
    /* Demo semantics: SEL=1 reads Control Word through RSR address */
    sel_set_high();
    return (uint16_t)pH3582->RSR;
}

uint16_t hi8582_read_status(void)
{
    /* SEL=0 reads Status Register through RSR address */
    sel_set_low();
    return (uint16_t)(pH3582->RSR & 0x01FFU);
}

bool hi8582_rx_data_available(hi8582_rx_t rx)
{
    uint16_t sr = hi8582_read_status();

    /* Based on the existing demo driver:
     * - RX1 data available bit: 0x0001
     * - RX2 data available bit: 0x0008
     */
    if (rx == HI8582_RX1)
        return ((sr & 0x0001U) != 0U);
    if (rx == HI8582_RX2)
        return ((sr & 0x0008U) != 0U);

    return false;
}

bool hi8582_read_rx_word(hi8582_rx_t rx, uint32_t *out_word)
{
    if (out_word == 0)
        return false;

    uint32_t w = 0U;
    uint32_t hi = 0U;

    sel_set_low();

    if (rx == HI8582_RX1)
        w = (uint32_t)pH3582->EN1;
    else if (rx == HI8582_RX2)
        w = (uint32_t)pH3582->EN2;
    else
        return false;

    w &= 0xFFFFU;

    sel_set_high();

    if (rx == HI8582_RX1)
        hi = (uint32_t)pH3582->EN1;
    else
        hi = (uint32_t)pH3582->EN2;

    w |= (hi << 16);

    *out_word = w;
    return true;
}

void hi8582_set_label_recognition(hi8582_rx_t rx, bool enable)
{
    uint16_t cw = hi8582_read_control();

    if (rx == HI8582_RX1)
    {
        if (enable) cw |= CR2;
        else        cw &= (uint16_t)~CR2;
    }
    else if (rx == HI8582_RX2)
    {
        if (enable) cw |= CR3;
        else        cw &= (uint16_t)~CR3;
    }

    hi8582_write_control(cw);
}

void hi8582_program_label_table(hi8582_rx_t rx, const uint8_t labels16[16])
{
    if (labels16 == 0)
        return;

    uint16_t cw = hi8582_read_control();

    /* CR1 high enables label table load */
    cw |= CR1;
    hi8582_write_control(cw);

    sel_set_high();

    for (unsigned i = 0U; i < 16U; i++)
    {
        if (rx == HI8582_RX1)
            pH3582->PL1 = (uint16_t)labels16[i];
        else
            pH3582->PL2 = (uint16_t)labels16[i];

        /* tiny delay helps meet label programming timing */
        for (volatile unsigned d = 0U; d < 2U; d++) { __NOP(); }
    }

    /* CR1 low ends label table load */
    cw &= (uint16_t)~CR1;
    hi8582_write_control(cw);

    sel_set_low();
}
