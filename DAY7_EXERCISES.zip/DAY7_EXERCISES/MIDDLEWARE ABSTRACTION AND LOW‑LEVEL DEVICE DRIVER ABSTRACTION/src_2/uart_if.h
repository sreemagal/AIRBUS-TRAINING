#ifndef UART_IF_H
#define UART_IF_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void uart_if_init_115200(void);
void uart_if_write(const uint8_t *data, size_t len);

/* convenience */
void uart_if_write_str(const char *s);

#ifdef __cplusplus
}
#endif

#endif /* UART_IF_H */
