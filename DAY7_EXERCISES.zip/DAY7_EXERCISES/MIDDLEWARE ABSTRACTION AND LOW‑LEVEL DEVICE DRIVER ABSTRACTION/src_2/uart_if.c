#include "uart_if.h"

#include <board.h>
#include <usart/usart.h>
#include <string.h>

#include "console.h" /* ConfigureUsart1() provided by the demo */

void uart_if_init_115200(void)
{
    /* Demo config: 115200 8N1, no HW flow */
    ConfigureUsart1();
}

void uart_if_write(const uint8_t *data, size_t len)
{
    if ((data == 0) || (len == 0U))
        return;

    for (size_t i = 0U; i < len; i++)
    {
        USART_Write(BOARD_USART_BASE, data[i], 0);
    }
}

void uart_if_write_str(const char *s)
{
    if (s == 0)
        return;

    uart_if_write((const uint8_t *)s, strlen(s));
}
