#include "arinc_streamer.h"
#include "uart_if.h"

static bool rb_is_full(arinc_streamer_t *s)
{
    uint16_t next = (uint16_t)((s->head + 1U) % s->cap);
    return (next == s->tail);
}

static bool rb_is_empty(arinc_streamer_t *s)
{
    return (s->head == s->tail);
}

static void rb_push(arinc_streamer_t *s, uint8_t rx, uint32_t word)
{
    if (rb_is_full(s))
    {
        s->dropped++;
        /* Drop oldest */
        s->tail = (uint16_t)((s->tail + 1U) % s->cap);
    }

    s->rb[s->head].rx   = rx;
    s->rb[s->head].word = word;
    s->head = (uint16_t)((s->head + 1U) % s->cap);
}

static bool rb_pop(arinc_streamer_t *s, arinc_item_t *out)
{
    if (rb_is_empty(s))
        return false;

    *out = s->rb[s->tail];
    s->tail = (uint16_t)((s->tail + 1U) % s->cap);
    return true;
}

static bool label_allowed(arinc_streamer_t *s, uint32_t word)
{
    if (!s->sw_label_filter_enable)
        return true;

    uint8_t label = (uint8_t)(word & 0xFFU);
    for (uint8_t i = 0U; i < s->sw_label_count; i++)
    {
        if (s->sw_labels[i] == label)
            return true;
    }
    return false;
}

void arinc_streamer_init(arinc_streamer_t *s, arinc_item_t *storage, uint16_t capacity)
{
    s->rb = storage;
    s->cap = capacity;
    s->head = 0U;
    s->tail = 0U;
    s->dropped = 0U;

    s->sw_label_filter_enable = false;
    s->sw_label_count = 0U;
}

void arinc_streamer_set_sw_label_filter(arinc_streamer_t *s, const uint8_t *labels, uint8_t label_count)
{
    s->sw_label_filter_enable = (labels != 0) && (label_count > 0U);
    s->sw_label_count = 0U;

    if (!s->sw_label_filter_enable)
        return;

    if (label_count > (uint8_t)sizeof(s->sw_labels))
        label_count = (uint8_t)sizeof(s->sw_labels);

    for (uint8_t i = 0U; i < label_count; i++)
        s->sw_labels[i] = labels[i];

    s->sw_label_count = label_count;
}

void arinc_streamer_poll(arinc_streamer_t *s, uint16_t max_reads_total)
{
    uint16_t reads = 0U;

    while (reads < max_reads_total)
    {
        bool did_one = false;
        uint32_t w;

        if (hi8582_rx_data_available(HI8582_RX1))
        {
            if (hi8582_read_rx_word(HI8582_RX1, &w))
            {
                if (label_allowed(s, w))
                    rb_push(s, 1U, w);
                did_one = true;
                reads++;
            }
        }

        if ((reads < max_reads_total) && hi8582_rx_data_available(HI8582_RX2))
        {
            if (hi8582_read_rx_word(HI8582_RX2, &w))
            {
                if (label_allowed(s, w))
                    rb_push(s, 2U, w);
                did_one = true;
                reads++;
            }
        }

        if (!did_one)
            break;
    }
}

static void hex8(uint32_t v, uint8_t out8[8])
{
    static const char h[] = "0123456789ABCDEF";
    for (int i = 7; i >= 0; i--)
    {
        out8[i] = (uint8_t)h[v & 0xFU];
        v >>= 4;
    }
}

uint16_t arinc_streamer_flush_uart(arinc_streamer_t *s, uint16_t max_lines)
{
    uint16_t sent = 0U;
    arinc_item_t it;

    while ((sent < max_lines) && rb_pop(s, &it))
    {
        /* Line: R<rx>,<8hex>\r\n */
        uint8_t line[1 + 1 + 1 + 8 + 2];
        /* 0:R, 1:rx digit, 2:comma, 3..10 hex, 11..12 CRLF */
        line[0] = (uint8_t)'R';
        line[1] = (uint8_t)('0' + (it.rx & 0x0FU));
        line[2] = (uint8_t)',';
        hex8(it.word, &line[3]);
        line[11] = (uint8_t)'\r';
        line[12] = (uint8_t)'\n';

        uart_if_write(line, sizeof(line));
        sent++;
    }

    return sent;
}
