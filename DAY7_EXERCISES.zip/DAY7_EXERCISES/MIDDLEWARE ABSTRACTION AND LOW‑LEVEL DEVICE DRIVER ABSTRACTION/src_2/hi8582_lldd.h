#ifndef HI8582_LLDD_H
#define HI8582_LLDD_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Receivers on HI-8582 */
typedef enum
{
    HI8582_RX1 = 1,
    HI8582_RX2 = 2,
} hi8582_rx_t;

/*
 * NOTE:
 * The Holt demo provides this constant in main.c:
 *   const H3582 pH3582 = HI3582_BASE;
 * and 3582A_83A_Driver.c references it as extern.
 *
 * This LLDD reuses that same pattern.
 */

uint16_t hi8582_reset_pulse(void);

void     hi8582_write_control(uint16_t cw);
uint16_t hi8582_read_control(void);
uint16_t hi8582_read_status(void);

bool     hi8582_rx_data_available(hi8582_rx_t rx);
bool     hi8582_read_rx_word(hi8582_rx_t rx, uint32_t *out_word);

/* Label recognition helpers (optional) */
void     hi8582_set_label_recognition(hi8582_rx_t rx, bool enable);
void     hi8582_program_label_table(hi8582_rx_t rx, const uint8_t labels16[16]);

#ifdef __cplusplus
}
#endif

#endif /* HI8582_LLDD_H */
