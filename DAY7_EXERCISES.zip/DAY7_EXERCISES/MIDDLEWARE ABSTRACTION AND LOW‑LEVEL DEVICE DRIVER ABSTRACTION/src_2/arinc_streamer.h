#ifndef ARINC_STREAMER_H
#define ARINC_STREAMER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "hi8582_lldd.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    uint32_t word;
    uint8_t  rx; /* 1 or 2 */
} arinc_item_t;

typedef struct
{
    arinc_item_t *rb;
    uint16_t cap;
    volatile uint16_t head;
    volatile uint16_t tail;
    volatile uint32_t dropped;

    /* Optional software label filter */
    bool     sw_label_filter_enable;
    uint8_t  sw_labels[32];
    uint8_t  sw_label_count;
} arinc_streamer_t;

void arinc_streamer_init(arinc_streamer_t *s, arinc_item_t *storage, uint16_t capacity);

/* Optional software label filter (independent of HW label recognition) */
void arinc_streamer_set_sw_label_filter(arinc_streamer_t *s, const uint8_t *labels, uint8_t label_count);

/* Pull from HI-8582 FIFOs into middleware ring buffer */
void arinc_streamer_poll(arinc_streamer_t *s, uint16_t max_reads_total);

/* Flush buffered words to UART using compact ASCII lines; throttled */
uint16_t arinc_streamer_flush_uart(arinc_streamer_t *s, uint16_t max_lines);

#ifdef __cplusplus
}
#endif

#endif /* ARINC_STREAMER_H */
