#include "line_codec.h"

static void emit_and_reset(line_codec_t *lc)
{
    if ((lc->on_line != 0) && (lc->len > 0U))
    {
        lc->on_line(lc->user, lc->buf, lc->len);
    }
    lc->len = 0U;
}

void line_codec_init(line_codec_t *lc,
                     uint8_t *buffer,
                     size_t buffer_capacity,
                     line_codec_on_line_t on_line,
                     void *user)
{
    lc->buf    = buffer;
    lc->cap    = buffer_capacity;
    lc->len    = 0U;
    lc->on_line = on_line;
    lc->user    = user;
}

void line_codec_feed(line_codec_t *lc, const uint8_t *data, size_t n)
{
    for (size_t i = 0U; i < n; i++)
    {
        uint8_t b = data[i];

        if (b == '\r')
            continue;

        if (b == '\n')
        {
            emit_and_reset(lc);
            continue;
        }

        if (lc->len < lc->cap)
        {
            lc->buf[lc->len++] = b;
        }
        else
        {
            /* Overflow: drop the line and reset */
            lc->len = 0U;
        }
    }
}
