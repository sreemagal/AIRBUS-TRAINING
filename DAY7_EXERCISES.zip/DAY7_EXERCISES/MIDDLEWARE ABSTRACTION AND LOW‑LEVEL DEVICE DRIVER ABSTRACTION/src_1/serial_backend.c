#include "serial_backend.h"
#include "serial_backend_select.h"

/* Backend-specific functions (implemented in the backend .c files) */
serial_status_t serial_backend_isr_init(const serial_config_t *cfg, void **out_ctx);
void serial_backend_isr_deinit(void *ctx);
size_t serial_backend_isr_read(void *ctx, uint8_t *dst, size_t max_len);
serial_status_t serial_backend_isr_write(void *ctx, const uint8_t *src, size_t len);
void serial_backend_isr_poll(void *ctx);

serial_status_t serial_backend_edma_init(const serial_config_t *cfg, void **out_ctx);
void serial_backend_edma_deinit(void *ctx);
size_t serial_backend_edma_read(void *ctx, uint8_t *dst, size_t max_len);
serial_status_t serial_backend_edma_write(void *ctx, const uint8_t *src, size_t len);
void serial_backend_edma_poll(void *ctx);

serial_status_t serial_backend_init(const serial_config_t *cfg, void **out_ctx)
{
#if SERIAL_BACKEND_USE_EDMA
    return serial_backend_edma_init(cfg, out_ctx);
#else
    return serial_backend_isr_init(cfg, out_ctx);
#endif
}

void serial_backend_deinit(void *ctx)
{
#if SERIAL_BACKEND_USE_EDMA
    serial_backend_edma_deinit(ctx);
#else
    serial_backend_isr_deinit(ctx);
#endif
}

size_t serial_backend_read(void *ctx, uint8_t *dst, size_t max_len)
{
#if SERIAL_BACKEND_USE_EDMA
    return serial_backend_edma_read(ctx, dst, max_len);
#else
    return serial_backend_isr_read(ctx, dst, max_len);
#endif
}

serial_status_t serial_backend_write(void *ctx, const uint8_t *src, size_t len)
{
#if SERIAL_BACKEND_USE_EDMA
    return serial_backend_edma_write(ctx, src, len);
#else
    return serial_backend_isr_write(ctx, src, len);
#endif
}

void serial_backend_poll(void *ctx)
{
#if SERIAL_BACKEND_USE_EDMA
    serial_backend_edma_poll(ctx);
#else
    serial_backend_isr_poll(ctx);
#endif
}
