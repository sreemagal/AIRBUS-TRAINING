#include "fsl_device_registers.h"   /* pulls in core_cm7.h + cmsis_gcc.h early */
#include "serial_backend.h"
#include "fsl_common_arm.h"   /* AT_NONCACHEABLE_SECTION_ALIGN */

#include "board.h"
#include "fsl_lpuart_edma.h"
#include "fsl_edma.h"
#if defined(FSL_FEATURE_SOC_DMAMUX_COUNT) && FSL_FEATURE_SOC_DMAMUX_COUNT
#include "fsl_dmamux.h"
#endif


#define SERIAL_LPUART          LPUART1
#define SERIAL_LPUART_CLK_HZ   BOARD_DebugConsoleSrcFreq()

/* Match the SDK EDMA example defaults */
#define SERIAL_TX_DMA_CHANNEL  0U
#define SERIAL_RX_DMA_CHANNEL  1U
#define SERIAL_TX_DMA_REQUEST  kDmaRequestMuxLPUART1Tx
#define SERIAL_RX_DMA_REQUEST  kDmaRequestMuxLPUART1Rx
#define SERIAL_DMAMUX_BASE     DMAMUX
#define SERIAL_EDMA_BASE       DMA0

/*
 * EDMA + cache note:
 * To keep this exercise robust without manual cache maintenance, we use
 * non-cacheable staging buffers for EDMA transfers.
 */
#define EDMA_TX_STAGING_SIZE   128U

typedef struct
{
    lpuart_edma_handle_t lpuart_edma;
    edma_handle_t tx_edma;
    edma_handle_t rx_edma;

    volatile bool tx_on_going;
    volatile bool rx_on_going;
    volatile bool rx_done;

    /* 1-byte RX chunk for low-latency line parsing */
    //AT_NONCACHEABLE_SECTION_ALIGN(uint8_t rx_byte[1], 4);

    /* TX staging to avoid cache issues */
   // AT_NONCACHEABLE_SECTION_ALIGN(uint8_t tx_stage[EDMA_TX_STAGING_SIZE], 4);
    uint8_t rx_byte[1] __attribute__((aligned(4)));
    uint8_t tx_stage[EDMA_TX_STAGING_SIZE] __attribute__((aligned(4)));

    /* Simple software RX ring buffer */
    uint8_t rb[256];
    volatile uint16_t rb_head;
    volatile uint16_t rb_tail;
} serial_edma_ctx_t;

//static serial_edma_ctx_t g_edma;
AT_NONCACHEABLE_SECTION_ALIGN(static serial_edma_ctx_t g_edma, 4);


static void rb_push(serial_edma_ctx_t *c, uint8_t b)
{
    uint16_t next = (uint16_t)((c->rb_head + 1U) % (uint16_t)sizeof(c->rb));
    if (next == c->rb_tail)
    {
        /* overflow: drop oldest */
        c->rb_tail = (uint16_t)((c->rb_tail + 1U) % (uint16_t)sizeof(c->rb));
    }
    c->rb[c->rb_head] = b;
    c->rb_head = next;
}

static size_t rb_pop(serial_edma_ctx_t *c, uint8_t *dst, size_t max_len)
{
    size_t n = 0U;
    while ((n < max_len) && (c->rb_tail != c->rb_head))
    {
        dst[n++] = c->rb[c->rb_tail];
        c->rb_tail = (uint16_t)((c->rb_tail + 1U) % (uint16_t)sizeof(c->rb));
    }
    return n;
}

static void lpuart_edma_user_callback(LPUART_Type *base, lpuart_edma_handle_t *handle, status_t status, void *userData)
{
    (void)base;
    (void)handle;
    (void)userData;

    if (status == kStatus_LPUART_TxIdle)
    {
        g_edma.tx_on_going = false;
    }
    else if (status == kStatus_LPUART_RxIdle)
    {
        g_edma.rx_on_going = false;
        g_edma.rx_done     = true;
    }
}

static void init_dmamux_and_edma(void)
{
    edma_config_t cfg;

#if defined(FSL_FEATURE_SOC_DMAMUX_COUNT) && FSL_FEATURE_SOC_DMAMUX_COUNT
    DMAMUX_Init(SERIAL_DMAMUX_BASE);
    DMAMUX_SetSource(SERIAL_DMAMUX_BASE, SERIAL_TX_DMA_CHANNEL, SERIAL_TX_DMA_REQUEST);
    DMAMUX_SetSource(SERIAL_DMAMUX_BASE, SERIAL_RX_DMA_CHANNEL, SERIAL_RX_DMA_REQUEST);
    DMAMUX_EnableChannel(SERIAL_DMAMUX_BASE, SERIAL_TX_DMA_CHANNEL);
    DMAMUX_EnableChannel(SERIAL_DMAMUX_BASE, SERIAL_RX_DMA_CHANNEL);
#endif

    EDMA_GetDefaultConfig(&cfg);
    EDMA_Init(SERIAL_EDMA_BASE, &cfg);

    EDMA_CreateHandle(&g_edma.tx_edma, SERIAL_EDMA_BASE, SERIAL_TX_DMA_CHANNEL);
    EDMA_CreateHandle(&g_edma.rx_edma, SERIAL_EDMA_BASE, SERIAL_RX_DMA_CHANNEL);

#if defined(FSL_FEATURE_EDMA_HAS_CHANNEL_MUX) && FSL_FEATURE_EDMA_HAS_CHANNEL_MUX
    EDMA_SetChannelMux(SERIAL_EDMA_BASE, SERIAL_TX_DMA_CHANNEL, SERIAL_TX_DMA_REQUEST);
    EDMA_SetChannelMux(SERIAL_EDMA_BASE, SERIAL_RX_DMA_CHANNEL, SERIAL_RX_DMA_REQUEST);
#endif
}

serial_status_t serial_backend_edma_init(const serial_config_t *cfg, void **out_ctx)
{
    if ((cfg == NULL) || (out_ctx == NULL))
        return SERIAL_ERR_BAD_PARAM;

    g_edma.rb_head = 0U;
    g_edma.rb_tail = 0U;

    g_edma.tx_on_going = false;
    g_edma.rx_on_going = false;
    g_edma.rx_done     = false;

    /* Init LPUART */
    lpuart_config_t lpuart_cfg;
    LPUART_GetDefaultConfig(&lpuart_cfg);
    lpuart_cfg.baudRate_Bps = cfg->baudrate;
    lpuart_cfg.enableTx     = cfg->enable_tx;
    lpuart_cfg.enableRx     = cfg->enable_rx;
    LPUART_Init(SERIAL_LPUART, &lpuart_cfg, SERIAL_LPUART_CLK_HZ);

    init_dmamux_and_edma();

    LPUART_TransferCreateHandleEDMA(SERIAL_LPUART, &g_edma.lpuart_edma, lpuart_edma_user_callback, NULL,
                                    &g_edma.tx_edma, &g_edma.rx_edma);

    *out_ctx = &g_edma;
    return SERIAL_OK;
}

void serial_backend_edma_deinit(void *ctx)
{
    (void)ctx;
    LPUART_Deinit(SERIAL_LPUART);
}

static void kick_rx_if_needed(serial_edma_ctx_t *c)
{
    if (!c->rx_on_going)
    {
        lpuart_transfer_t rx;
        rx.data     = c->rx_byte;
        rx.dataSize = 1U;

        c->rx_done     = false;
        c->rx_on_going = true;
        (void)LPUART_ReceiveEDMA(SERIAL_LPUART, &c->lpuart_edma, &rx);
    }
}

void serial_backend_edma_poll(void *ctx)
{
    serial_edma_ctx_t *c = (serial_edma_ctx_t *)ctx;

    kick_rx_if_needed(c);

    if (c->rx_done)
    {
        c->rx_done = false;
        rb_push(c, c->rx_byte[0]);
        /* Immediately arm next byte */
        kick_rx_if_needed(c);
    }
}

size_t serial_backend_edma_read(void *ctx, uint8_t *dst, size_t max_len)
{
    serial_edma_ctx_t *c = (serial_edma_ctx_t *)ctx;

    /* Make progress on RX */
    serial_backend_edma_poll(ctx);

    return rb_pop(c, dst, max_len);
}

serial_status_t serial_backend_edma_write(void *ctx, const uint8_t *src, size_t len)
{
    serial_edma_ctx_t *c = (serial_edma_ctx_t *)ctx;

    if ((src == NULL) || (len == 0U))
        return SERIAL_ERR_BAD_PARAM;

    size_t offset = 0U;

    while (offset < len)
    {
        size_t chunk = len - offset;
        if (chunk > EDMA_TX_STAGING_SIZE)
            chunk = EDMA_TX_STAGING_SIZE;

        for (size_t i = 0U; i < chunk; i++)
            c->tx_stage[i] = src[offset + i];

        lpuart_transfer_t tx;
        tx.data     = c->tx_stage;
        tx.dataSize = chunk;

        c->tx_on_going = true;
        status_t st = LPUART_SendEDMA(SERIAL_LPUART, &c->lpuart_edma, &tx);
        if (st != kStatus_Success)
            return SERIAL_ERR_IO;

        while (c->tx_on_going)
        {
            __NOP();
        }

        offset += chunk;
    }

    return SERIAL_OK;
}
