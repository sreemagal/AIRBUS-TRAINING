#ifndef SERIAL_BACKEND_SELECT_H
#define SERIAL_BACKEND_SELECT_H

/*
 * 0 = Interrupt backend (fsl_lpuart + NXP ring buffer)
 * 1 = EDMA backend      (fsl_lpuart_edma + DMAMUX + EDMA)
 */
#define SERIAL_BACKEND_USE_EDMA 0

#endif /* SERIAL_BACKEND_SELECT_H */
