#ifndef SERIAL_BACKEND_H
#define SERIAL_BACKEND_H

#include "serial_if.h"

#ifdef __cplusplus
extern "C" {
#endif

serial_status_t serial_backend_init(const serial_config_t *cfg, void **out_ctx);
void serial_backend_deinit(void *ctx);
size_t serial_backend_read(void *ctx, uint8_t *dst, size_t max_len);
serial_status_t serial_backend_write(void *ctx, const uint8_t *src, size_t len);
void serial_backend_poll(void *ctx);

#ifdef __cplusplus
}
#endif

#endif /* SERIAL_BACKEND_H */
