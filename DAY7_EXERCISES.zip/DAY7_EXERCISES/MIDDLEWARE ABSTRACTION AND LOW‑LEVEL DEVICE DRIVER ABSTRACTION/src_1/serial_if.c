#include "serial_if.h"
#include "serial_backend.h"

struct serial_handle
{
    void *ctx;
};

static serial_handle_t g_handle;
static bool g_is_open = false;

serial_status_t serial_open(serial_handle_t **out_handle, const serial_config_t *cfg)
{
    if ((out_handle == NULL) || (cfg == NULL))
        return SERIAL_ERR_BAD_PARAM;

    if (g_is_open)
        return SERIAL_ERR_BUSY;

    g_handle.ctx = NULL;
    serial_status_t st = serial_backend_init(cfg, &g_handle.ctx);
    if (st != SERIAL_OK)
        return st;

    g_is_open = true;
    *out_handle = &g_handle;
    return SERIAL_OK;
}

serial_status_t serial_close(serial_handle_t *handle)
{
    if ((handle == NULL) || (!g_is_open))
        return SERIAL_ERR_BAD_PARAM;

    serial_backend_deinit(handle->ctx);
    handle->ctx = NULL;
    g_is_open = false;
    return SERIAL_OK;
}

size_t serial_read(serial_handle_t *handle, uint8_t *dst, size_t max_len)
{
    if ((handle == NULL) || (dst == NULL) || (max_len == 0U) || (!g_is_open))
        return 0U;

    return serial_backend_read(handle->ctx, dst, max_len);
}

serial_status_t serial_write(serial_handle_t *handle, const uint8_t *src, size_t len)
{
    if ((handle == NULL) || (src == NULL) || (len == 0U) || (!g_is_open))
        return SERIAL_ERR_BAD_PARAM;

    return serial_backend_write(handle->ctx, src, len);
}

void serial_poll(serial_handle_t *handle)
{
    if ((handle == NULL) || (!g_is_open))
        return;

    serial_backend_poll(handle->ctx);
}
