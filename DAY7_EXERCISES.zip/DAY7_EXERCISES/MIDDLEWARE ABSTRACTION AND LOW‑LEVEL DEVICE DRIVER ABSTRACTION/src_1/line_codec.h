#ifndef LINE_CODEC_H
#define LINE_CODEC_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*line_codec_on_line_t)(void *user, const uint8_t *line, size_t len);

typedef struct
{
    uint8_t *buf;
    size_t cap;
    size_t len;

    line_codec_on_line_t on_line;
    void *user;
} line_codec_t;

void line_codec_init(line_codec_t *lc,
                     uint8_t *buffer,
                     size_t buffer_capacity,
                     line_codec_on_line_t on_line,
                     void *user);

void line_codec_feed(line_codec_t *lc, const uint8_t *data, size_t n);

#ifdef __cplusplus
}
#endif

#endif /* LINE_CODEC_H */
