#include "serial_backend.h"

#include "board.h"
#include "fsl_lpuart.h"

#define SERIAL_LPUART          LPUART1
#define SERIAL_LPUART_CLK_HZ   BOARD_DebugConsoleSrcFreq()

#define RX_RING_BUFFER_SIZE    256U

typedef struct
{
    lpuart_handle_t handle;
    uint8_t ring[RX_RING_BUFFER_SIZE];
    volatile bool tx_on_going;
} serial_isr_ctx_t;

static serial_isr_ctx_t g_isr;

static void lpuart_isr_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    (void)base;
    (void)handle;
    (void)userData;

    if (status == kStatus_LPUART_TxIdle)
    {
        g_isr.tx_on_going = false;
    }
}

serial_status_t serial_backend_isr_init(const serial_config_t *cfg, void **out_ctx)
{
    if ((cfg == NULL) || (out_ctx == NULL))
        return SERIAL_ERR_BAD_PARAM;

    lpuart_config_t config;
    LPUART_GetDefaultConfig(&config);
    config.baudRate_Bps = cfg->baudrate;
    config.enableTx     = cfg->enable_tx;
    config.enableRx     = cfg->enable_rx;

    LPUART_Init(SERIAL_LPUART, &config, SERIAL_LPUART_CLK_HZ);

    g_isr.tx_on_going = false;

    LPUART_TransferCreateHandle(SERIAL_LPUART, &g_isr.handle, lpuart_isr_callback, NULL);
    LPUART_TransferStartRingBuffer(SERIAL_LPUART, &g_isr.handle, g_isr.ring, RX_RING_BUFFER_SIZE);

    *out_ctx = &g_isr;
    return SERIAL_OK;
}

void serial_backend_isr_deinit(void *ctx)
{
    (void)ctx;
    LPUART_TransferStopRingBuffer(SERIAL_LPUART, &g_isr.handle);
    LPUART_Deinit(SERIAL_LPUART);
}

size_t serial_backend_isr_read(void *ctx, uint8_t *dst, size_t max_len)
{
    (void)ctx;

    lpuart_transfer_t xfer;
    xfer.data     = dst;
    xfer.dataSize = max_len;

    size_t received = 0U;
    (void)LPUART_TransferReceiveNonBlocking(SERIAL_LPUART, &g_isr.handle, &xfer, &received);
    return received;
}

serial_status_t serial_backend_isr_write(void *ctx, const uint8_t *src, size_t len)
{
    (void)ctx;

    if ((src == NULL) || (len == 0U))
        return SERIAL_ERR_BAD_PARAM;

    lpuart_transfer_t xfer;
    xfer.data     = (uint8_t *)(uintptr_t)src;
    xfer.dataSize = len;

    status_t st = LPUART_TransferSendNonBlocking(SERIAL_LPUART, &g_isr.handle, &xfer);
    if (st != kStatus_Success)
        return SERIAL_ERR_IO;

    g_isr.tx_on_going = true;
    while (g_isr.tx_on_going)
    {
        __NOP();
    }

    return SERIAL_OK;
}

void serial_backend_isr_poll(void *ctx)
{
    (void)ctx;
    /* No-op: RX ring buffer is maintained by the ISR-driven LLDD */
}
