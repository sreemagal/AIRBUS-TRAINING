#include "board.h"
#include "serial_if.h"
#include "line_codec.h"
#include "pin_mux.h"
#include "clock_config.h"

//#include "fsl_debug_console.h"
#include <string.h>

static serial_handle_t *g_serial = NULL;

static void serial_write_str(const char *s)
{
    (void)serial_write(g_serial, (const uint8_t *)s, strlen(s));
}

static bool line_equals(const uint8_t *line, size_t len, const char *lit)
{
    size_t n = strlen(lit);
    if (len != n)
        return false;
    return (memcmp(line, lit, n) == 0);
}

static void on_line(void *user, const uint8_t *line, size_t len)
{
    (void)user;

    if (line_equals(line, len, "LED ON"))
    {
        USER_LED_ON();
        serial_write_str("OK LED ON\r\n");
        return;
    }

    if (line_equals(line, len, "LED OFF"))
    {
        USER_LED_OFF();
        serial_write_str("OK LED OFF\r\n");
        return;
    }

    serial_write_str("ECHO: ");
    (void)serial_write(g_serial, line, len);
    serial_write_str("\r\n");
}

int main(void)
{
	    BOARD_ConfigMPU();
	    BOARD_InitBootPins();
	    BOARD_InitBootClocks();

	//    BOARD_InitDebugConsole();


    /* User LED setup */
    USER_LED_INIT(LOGIC_LED_OFF);

    serial_config_t cfg = {
        .baudrate  = 115200U,
        .enable_tx = true,
        .enable_rx = true,
    };

    if (serial_open(&g_serial, &cfg) != SERIAL_OK)
    {
        /* If serial cannot open, just spin */
        while (1)
        {
            __NOP();
        }
    }

    serial_write_str("Exercise1 ready. Type commands: LED ON / LED OFF / <text>\r\n");

    uint8_t line_buf[128];
    line_codec_t lc;
    line_codec_init(&lc, line_buf, sizeof(line_buf), on_line, NULL);

    uint8_t rx_tmp[32];

    while (1)
    {
        /* Make progress on EDMA backend (no-op on ISR backend) */
        serial_poll(g_serial);

        size_t n = serial_read(g_serial, rx_tmp, sizeof(rx_tmp));
        if (n > 0U)
        {
            line_codec_feed(&lc, rx_tmp, n);
        }

        __NOP();
    }
}
