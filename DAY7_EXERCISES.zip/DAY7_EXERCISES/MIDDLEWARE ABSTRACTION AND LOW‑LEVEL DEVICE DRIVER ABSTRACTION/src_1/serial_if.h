#ifndef SERIAL_IF_H
#define SERIAL_IF_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    SERIAL_OK = 0,
    SERIAL_ERR_BAD_PARAM,
    SERIAL_ERR_NOT_READY,
    SERIAL_ERR_BUSY,
    SERIAL_ERR_IO,
} serial_status_t;

typedef struct serial_handle serial_handle_t; /* Opaque */

typedef struct
{
    uint32_t baudrate;
    bool enable_tx;
    bool enable_rx;
} serial_config_t;

/**
 * Open the serial interface.
 *
 * Notes:
 * - This exercise assumes a single instance (one UART).
 * - Implementation selects the LLDD backend internally.
 */
serial_status_t serial_open(serial_handle_t **out_handle, const serial_config_t *cfg);

serial_status_t serial_close(serial_handle_t *handle);

/**
 * Non-blocking read.
 * @return number of bytes read (0..max_len)
 */
size_t serial_read(serial_handle_t *handle, uint8_t *dst, size_t max_len);

/**
 * Blocking write.
 */
serial_status_t serial_write(serial_handle_t *handle, const uint8_t *src, size_t len);

/**
 * Poll hook.
 * - ISR backend: no-op
 * - EDMA backend: kicks and harvests RX DMA
 */
void serial_poll(serial_handle_t *handle);

#ifdef __cplusplus
}
#endif

#endif /* SERIAL_IF_H */
