#pragma once

#include <stddef.h>
#include <stdint.h>
#include "fsl_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * bm_sched.h — Fixed-priority cooperative scheduler
 *
 * Model:
 *  - PIT ISR releases periodic tasks once per tick.
 *  - Main loop executes ready tasks to completion in priority order.
 *  - No dynamic memory.
 *  - Missed-release counting with "skip backlog" policy.
 *
 * Calling context:
 *  - BM_Sched_TickISR() must be called from PIT ISR.
 *  - BM_Sched_Run() must be called from main and never returns.
 */

typedef void (*bm_task_fn_t)(void);

typedef struct bm_task
{
    const char *name;
    bm_task_fn_t run;

    uint32_t period_ms; /* 0 => aperiodic */
    uint8_t  prio;      /* 0..255, higher = higher task priority */
    uint32_t wcet_us;   /* 0 disables WCET checks */

    /* Runtime fields */
    volatile uint8_t ready;
    uint32_t next_release_ms;
    uint32_t missed_releases;

    /* Instrumentation */
    uint32_t last_start_us;
    uint32_t last_finish_us;
    uint32_t wcet_violations;
} bm_task_t;

void     BM_Sched_CoreInit(void);
status_t BM_Sched_Register(bm_task_t *tasks, size_t count);
void     BM_Sched_TickISR(void);
void     BM_Sched_Run(void);

/* Safe to call from ISR or main to release an aperiodic task. */
static inline void BM_Sched_Release(bm_task_t *t)
{
    if (t != NULL)
    {
        t->ready = 1u;
    }
}

uint32_t BM_TimeMs(void);
uint32_t BM_TimeUs(void);

#ifdef __cplusplus
}
#endif
