#include "diag_proto.h"

static void wr_u32_le(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
    p[2] = (uint8_t)((v >> 16) & 0xFFu);
    p[3] = (uint8_t)((v >> 24) & 0xFFu);
}

static status_t diag_send(uart_framed_t *u, uint8_t id, uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    uint8_t payload[1u + 1u + 16u];
    payload[0] = BM_MSGTYPE_DIAG;
    payload[1] = id;

    wr_u32_le(&payload[2], a);
    wr_u32_le(&payload[6], b);
    wr_u32_le(&payload[10], c);
    wr_u32_le(&payload[14], d);

    return UartFramed_Send(u, payload, (uint8_t)sizeof(payload));
}

status_t Diag_SendLink(uart_framed_t *u, uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    return diag_send(u, (uint8_t)DIAG_ID_LINK, a, b, c, d);
}

status_t Diag_SendDomain(uart_framed_t *u, uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    return diag_send(u, (uint8_t)DIAG_ID_DOMAIN, a, b, c, d);
}

status_t Diag_SendApp(uart_framed_t *u, uint32_t a, uint32_t b, uint32_t c, uint32_t d)
{
    return diag_send(u, (uint8_t)DIAG_ID_APP, a, b, c, d);
}
