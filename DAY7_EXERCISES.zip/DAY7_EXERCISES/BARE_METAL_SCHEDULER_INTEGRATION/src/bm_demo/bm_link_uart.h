#pragma once

#include <stddef.h>
#include <stdint.h>

#include "fsl_common.h"
#include "fsl_clock.h"
#include "fsl_lpuart.h"

#include "project_config.h" /* for BM_LINK_UART_RX_RING_SIZE */

#ifdef __cplusplus
extern "C" {
#endif

/*
 * bm_link_uart.h — LINK UART physical layer wrapper
 *
 * Contract:
 *  - Transactional LPUART driver with background RX ring buffer.
 *  - No heavy processing in ISR; ISR fills ring.
 *  - Main/task context drains bytes using BM_LinkUart_Drain().
 *  - TX is single in-flight; busy returns kStatus_Busy.
 */

typedef struct bm_link_uart
{
    LPUART_Type *base;
    lpuart_handle_t handle;

    uint8_t rx_ring[BM_LINK_UART_RX_RING_SIZE];

    volatile uint8_t  tx_busy;
    volatile status_t last_tx_status;

    volatile uint32_t tx_started;
    volatile uint32_t tx_completed;
} bm_link_uart_t;

/*
 * Initialize LINK UART.
 *
 * @param src_clock_hz must be the actual UART root clock in Hz (board/clock-config dependent).
 *        Many EVKB examples use BOARD_DebugConsoleSrcFreq() as the UART root frequency.
 */
status_t BM_LinkUart_Init(bm_link_uart_t *u,
                          LPUART_Type *base,
                          IRQn_Type irqn,
                          clock_ip_name_t clock_ip,
                          uint32_t baud,
                          uint32_t src_clock_hz,
                          uint8_t nvic_priority);

size_t   BM_LinkUart_RxAvailable(bm_link_uart_t *u);
size_t   BM_LinkUart_Drain(bm_link_uart_t *u, uint8_t *dst, size_t maxlen);
status_t BM_LinkUart_SendNonBlocking(bm_link_uart_t *u, const uint8_t *data, size_t len);

#ifdef __cplusplus
}
#endif
