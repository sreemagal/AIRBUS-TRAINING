#pragma once

#include <stdint.h>
#include "fsl_common.h"
#include "uart_framed.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * arinc_bridge.h — Simulated ARINC-429 domain layer
 *
 * Word layout:
 *   bits [7:0]   label
 *   bits [9:8]   SDI
 *   bits [28:10] data (19 bits)
 *   bits [30:29] SSM (2 bits)
 *   bit  [31]    parity (even over bits [30:0])
 */

typedef enum arinc_validity
{
    ARINC_VALID_OK = 0,
    ARINC_VALID_BAD_PARITY,
    ARINC_VALID_BAD_SSM,
    ARINC_VALID_BAD_FORMAT,
} arinc_validity_t;

typedef struct arinc_word
{
    uint8_t  label;
    uint8_t  sdi;
    uint32_t data;  /* 19 bits */
    uint8_t  ssm;

    arinc_validity_t validity;
} arinc_word_t;

typedef void (*arinc_on_word_fn_t)(const arinc_word_t *w, void *user);

typedef struct arinc_tx_entry
{
    uint32_t raw_word;
    uint32_t period_ms;
    uint32_t next_release_ms;
} arinc_tx_entry_t;

typedef struct arinc_bridge
{
    uart_framed_t *link;

    arinc_on_word_fn_t on_word;
    void *on_word_user;

    arinc_tx_entry_t *tx_table;
    uint32_t tx_table_len;

    /* Diagnostics */
    uint32_t rx_words;
    uint32_t rx_bad_parity;
    uint32_t rx_bad_ssm;
    uint32_t rx_unknown_msg;
    uint32_t tx_words;
    uint32_t tx_busy;
} arinc_bridge_t;

/* Pack/unpack helpers */
uint32_t Arinc_PackRaw(uint8_t label, uint8_t sdi, uint32_t data19, uint8_t ssm, uint8_t set_even_parity);
void     Arinc_UnpackRaw(uint32_t raw, arinc_word_t *out);

status_t ArincBridge_Init(arinc_bridge_t *b, uart_framed_t *link);
void     ArincBridge_SetRxCallback(arinc_bridge_t *b, arinc_on_word_fn_t cb, void *user);
status_t ArincBridge_SetTxSchedule(arinc_bridge_t *b, arinc_tx_entry_t *table, uint32_t table_len, uint32_t now_ms);

/* Process RX frames + perform scheduled TX (task context). */
void ArincBridge_Poll(arinc_bridge_t *b, uint32_t now_ms);

#ifdef __cplusplus
}
#endif
