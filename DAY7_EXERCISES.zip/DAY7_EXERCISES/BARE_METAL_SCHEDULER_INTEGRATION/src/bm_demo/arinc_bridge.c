#include "arinc_bridge.h"
#include "project_config.h"

/* SSM policy for this exercise:
 *  - Accept only SSM=0b00 (Normal Operation)
 *  - Treat other SSM values as invalid (explicitly counted)
 */
static uint8_t ssm_is_acceptable(uint8_t ssm)
{
    return (ssm == 0u) ? 1u : 0u;
}

static uint8_t popcount32(uint32_t x)
{
    uint8_t c = 0u;
    while (x != 0u)
    {
        c = (uint8_t)(c + (uint8_t)(x & 1u));
        x >>= 1u;
    }
    return c;
}

static uint8_t parity_even_ok(uint32_t raw)
{
    /* Even parity across all 32 bits => popcount is even. */
    return ((popcount32(raw) & 1u) == 0u) ? 1u : 0u;
}

uint32_t Arinc_PackRaw(uint8_t label, uint8_t sdi, uint32_t data19, uint8_t ssm, uint8_t set_even_parity)
{
    uint32_t raw = 0u;

    raw |= ((uint32_t)label & 0xFFu);
    raw |= (((uint32_t)sdi & 0x3u) << 8);
    raw |= ((data19 & 0x7FFFFu) << 10);
    raw |= (((uint32_t)ssm & 0x3u) << 29);

    if (set_even_parity != 0u)
    {
        /* Make overall popcount even by selecting parity bit accordingly. */
        uint32_t raw_no_par = (raw & 0x7FFFFFFFu);
        uint8_t pc = popcount32(raw_no_par);
        uint8_t parity_bit = (pc & 1u) ? 1u : 0u;
        raw |= ((uint32_t)parity_bit << 31);
    }

    return raw;
}

void Arinc_UnpackRaw(uint32_t raw, arinc_word_t *out)
{
    if (out == NULL)
    {
        return;
    }

    out->label = (uint8_t)(raw & 0xFFu);
    out->sdi   = (uint8_t)((raw >> 8) & 0x3u);
    out->data  = (uint32_t)((raw >> 10) & 0x7FFFFu);
    out->ssm   = (uint8_t)((raw >> 29) & 0x3u);

    /* Validity computed by the bridge (parity+SSM). Default to OK here. */
    out->validity = ARINC_VALID_OK;
}

status_t ArincBridge_Init(arinc_bridge_t *b, uart_framed_t *link)
{
    if ((b == NULL) || (link == NULL))
    {
        return kStatus_InvalidArgument;
    }

    b->link = link;
    b->on_word = NULL;
    b->on_word_user = NULL;

    b->tx_table = NULL;
    b->tx_table_len = 0u;

    b->rx_words = 0u;
    b->rx_bad_parity = 0u;
    b->rx_bad_ssm = 0u;
    b->rx_unknown_msg = 0u;
    b->tx_words = 0u;
    b->tx_busy = 0u;

    return kStatus_Success;
}

void ArincBridge_SetRxCallback(arinc_bridge_t *b, arinc_on_word_fn_t cb, void *user)
{
    if (b == NULL)
    {
        return;
    }

    b->on_word = cb;
    b->on_word_user = user;
}

status_t ArincBridge_SetTxSchedule(arinc_bridge_t *b, arinc_tx_entry_t *table, uint32_t table_len, uint32_t now_ms)
{
    if ((b == NULL) || (table == NULL) || (table_len == 0u))
    {
        return kStatus_InvalidArgument;
    }

    b->tx_table = table;
    b->tx_table_len = table_len;

    for (uint32_t i = 0u; i < table_len; i++)
    {
        if (table[i].period_ms == 0u)
        {
            return kStatus_InvalidArgument;
        }
        table[i].next_release_ms = now_ms + table[i].period_ms;
    }

    return kStatus_Success;
}

static void try_send_raw_word(arinc_bridge_t *b, uint32_t raw)
{
    uint8_t payload[5];
    payload[0] = BM_MSGTYPE_ARINC_WORD;
    payload[1] = (uint8_t)(raw & 0xFFu);
    payload[2] = (uint8_t)((raw >> 8) & 0xFFu);
    payload[3] = (uint8_t)((raw >> 16) & 0xFFu);
    payload[4] = (uint8_t)((raw >> 24) & 0xFFu);

    status_t st = UartFramed_Send(b->link, payload, 5u);
    if (st == kStatus_Success)
    {
        b->tx_words++;
    }
    else if (st == kStatus_Busy)
    {
        b->tx_busy++;
    }
}

static void handle_one_frame(arinc_bridge_t *b, const uart_frame_t *f)
{
    if ((f == NULL) || (f->len < 1u))
    {
        return;
    }

    uint8_t type = f->payload[0];

    if (type == BM_MSGTYPE_ARINC_WORD)
    {
        /* Payload: [0]=type, [1..4]=raw word (little endian) */
        if (f->len != 5u)
        {
            b->rx_unknown_msg++;
            return;
        }

        uint32_t raw = ((uint32_t)f->payload[1]) |
                       ((uint32_t)f->payload[2] << 8) |
                       ((uint32_t)f->payload[3] << 16) |
                       ((uint32_t)f->payload[4] << 24);

        arinc_word_t w;
        Arinc_UnpackRaw(raw, &w);

        /* Compute validity */
        b->rx_words++;

        if (parity_even_ok(raw) == 0u)
        {
            w.validity = ARINC_VALID_BAD_PARITY;
            b->rx_bad_parity++;
        }
        else if (ssm_is_acceptable(w.ssm) == 0u)
        {
            w.validity = ARINC_VALID_BAD_SSM;
            b->rx_bad_ssm++;
        }
        else
        {
            w.validity = ARINC_VALID_OK;
        }

        if (b->on_word != NULL)
        {
            /* Always callback with explicit validity. */
            b->on_word(&w, b->on_word_user);
        }

        return;
    }

    if (type == BM_MSGTYPE_DIAG)
    {
        /* Optional: diagnostics frame handled by diag_proto in app; ignore here. */
        return;
    }

    b->rx_unknown_msg++;
}

void ArincBridge_Poll(arinc_bridge_t *b, uint32_t now_ms)
{
    if ((b == NULL) || (b->link == NULL))
    {
        return;
    }

    /* 1) RX: bounded by RX queue length. */
    for (;;)
    {
        uart_frame_t f;
        status_t st = UartFramed_Recv(b->link, &f);
        if (st != kStatus_Success)
        {
            break;
        }
        handle_one_frame(b, &f);
    }

    /* 2) TX: scheduled words. */
    if ((b->tx_table != NULL) && (b->tx_table_len != 0u))
    {
        for (uint32_t i = 0u; i < b->tx_table_len; i++)
        {
            arinc_tx_entry_t *e = &b->tx_table[i];
            if ((int32_t)(now_ms - e->next_release_ms) >= 0)
            {
                try_send_raw_word(b, e->raw_word);
                e->next_release_ms += e->period_ms;
            }
        }
    }
}
