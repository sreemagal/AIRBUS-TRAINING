#include "bm_link_uart.h"

static void BM_LinkUart_Callback(LPUART_Type *base,
                                 lpuart_handle_t *handle,
                                 status_t status,
                                 void *userData)
{
    (void)base;
    (void)handle;

    bm_link_uart_t *u = (bm_link_uart_t *)userData;
    if (u == NULL)
    {
        return;
    }

    if (status == kStatus_LPUART_TxIdle)
    {
        u->tx_busy = 0u;
        u->tx_completed++;
    }

    u->last_tx_status = status;
}

status_t BM_LinkUart_Init(bm_link_uart_t *u,
                          LPUART_Type *base,
                          IRQn_Type irqn,
                          clock_ip_name_t clock_ip,
                          uint32_t baud,
                          uint32_t src_clock_hz,
                          uint8_t nvic_priority)
{
    if ((u == NULL) || (base == NULL) || (baud == 0u) || (src_clock_hz == 0u))
    {
        return kStatus_InvalidArgument;
    }

    u->base = base;
    u->tx_busy = 0u;
    u->last_tx_status = kStatus_Success;
    u->tx_started = 0u;
    u->tx_completed = 0u;

    CLOCK_EnableClock(clock_ip);

    lpuart_config_t cfg;
    LPUART_GetDefaultConfig(&cfg);
    cfg.baudRate_Bps = baud;
    cfg.enableTx = true;
    cfg.enableRx = true;

    status_t st = LPUART_Init(base, &cfg, src_clock_hz);
    if (st != kStatus_Success)
    {
        return st;
    }

    LPUART_TransferCreateHandle(base, &u->handle, BM_LinkUart_Callback, u);

    /* Enable ring buffer background reception. */
    LPUART_TransferStartRingBuffer(base, &u->handle, u->rx_ring, sizeof(u->rx_ring));

    NVIC_SetPriority(irqn, nvic_priority);
    EnableIRQ(irqn);

    return kStatus_Success;
}

size_t BM_LinkUart_RxAvailable(bm_link_uart_t *u)
{
    if (u == NULL)
    {
        return 0u;
    }

    return LPUART_TransferGetRxRingBufferLength(u->base, &u->handle);
}

size_t BM_LinkUart_Drain(bm_link_uart_t *u, uint8_t *dst, size_t maxlen)
{
    if ((u == NULL) || (dst == NULL) || (maxlen == 0u))
    {
        return 0u;
    }

    size_t avail = BM_LinkUart_RxAvailable(u);
    if (avail == 0u)
    {
        return 0u;
    }

    size_t to_read = (avail < maxlen) ? avail : maxlen;

    lpuart_transfer_t xfer;
    xfer.data = dst;
    xfer.dataSize = to_read;

    size_t received = 0u;
    status_t st = LPUART_TransferReceiveNonBlocking(u->base, &u->handle, &xfer, &received);
    if (st != kStatus_Success)
    {
        return 0u;
    }

    return received;
}

status_t BM_LinkUart_SendNonBlocking(bm_link_uart_t *u, const uint8_t *data, size_t len)
{
    if ((u == NULL) || (data == NULL) || (len == 0u))
    {
        return kStatus_InvalidArgument;
    }

    if (u->tx_busy != 0u)
    {
        return kStatus_Busy;
    }

    lpuart_transfer_t xfer;
    xfer.txData = data;
    xfer.dataSize = len;

    status_t st = LPUART_TransferSendNonBlocking(u->base, &u->handle, &xfer);
    if (st == kStatus_Success)
    {
        u->tx_busy = 1u;
        u->tx_started++;
    }

    return st;
}
