#include "bm_tick_pit.h"
#include "bm_sched.h"
#include "project_config.h"

#include "fsl_pit.h"

status_t BM_TickPIT_Init_1kHz(void)
{
    pit_config_t pitCfg;

    CLOCK_EnableClock(kCLOCK_Pit);

    PIT_GetDefaultConfig(&pitCfg);
    PIT_Init(BM_TICK_PIT_BASE, &pitCfg);

    /* 1ms tick */
    PIT_SetTimerPeriod(BM_TICK_PIT_BASE,
                       BM_TICK_PIT_CHANNEL,
                       USEC_TO_COUNT(1000u, BM_PIT_SOURCE_CLOCK_HZ));

    PIT_EnableInterrupts(BM_TICK_PIT_BASE, BM_TICK_PIT_CHANNEL, kPIT_TimerInterruptEnable);

    NVIC_SetPriority(BM_TICK_PIT_IRQn, BM_NVIC_PRIO_PIT_TICK);
    EnableIRQ(BM_TICK_PIT_IRQn);

    PIT_StartTimer(BM_TICK_PIT_BASE, BM_TICK_PIT_CHANNEL);

    return kStatus_Success;
}

void PIT_IRQHandler(void)
{
    uint32_t flags = PIT_GetStatusFlags(BM_TICK_PIT_BASE, BM_TICK_PIT_CHANNEL);
    if ((flags & kPIT_TimerFlag) != 0u)
    {
        PIT_ClearStatusFlags(BM_TICK_PIT_BASE, BM_TICK_PIT_CHANNEL, kPIT_TimerFlag);
        BM_Sched_TickISR();
    }

    SDK_ISR_EXIT_BARRIER;
}
