#include "dio_service.h"
#include "board.h"
#include "fsl_gpio.h"

/*
 * NOTE:
 *  - Most EVKB examples provide BOARD_USER_LED_GPIO and BOARD_USER_LED_GPIO_PIN.
 *  - If your base project uses different names, adjust here or map them via macros.
 */

#ifndef BOARD_USER_LED_GPIO
/* Fall back to common alternative macro names if needed. */
#if defined(USER_LED_GPIO)
#define BOARD_USER_LED_GPIO USER_LED_GPIO
#endif
#endif

#ifndef BOARD_USER_LED_GPIO_PIN
#if defined(USER_LED_PIN)
#define BOARD_USER_LED_GPIO_PIN USER_LED_PIN
#endif
#endif

status_t DioUserLed_Init(dio_user_led_t *led, uint8_t initial_logic_level)
{
    if (led == NULL)
    {
        return kStatus_InvalidArgument;
    }

#if !defined(BOARD_USER_LED_GPIO) || !defined(BOARD_USER_LED_GPIO_PIN)
    /* Build-time error if LED macros are not available in the chosen base project. */
    return kStatus_Fail;
#else
    gpio_pin_config_t cfg = {
        .direction = kGPIO_DigitalOutput,
        .outputLogic = initial_logic_level,
        .interruptMode = kGPIO_NoIntmode,
    };

    GPIO_PinInit(BOARD_USER_LED_GPIO, BOARD_USER_LED_GPIO_PIN, &cfg);
    led->initialized = true;
    return kStatus_Success;
#endif
}

status_t DioUserLed_Write(dio_user_led_t *led, uint8_t logic_level)
{
    if ((led == NULL) || (!led->initialized))
    {
        return kStatus_InvalidArgument;
    }

#if !defined(BOARD_USER_LED_GPIO) || !defined(BOARD_USER_LED_GPIO_PIN)
    return kStatus_Fail;
#else
    GPIO_PinWrite(BOARD_USER_LED_GPIO, BOARD_USER_LED_GPIO_PIN, (uint32_t)logic_level);
    return kStatus_Success;
#endif
}

status_t DioUserLed_Toggle(dio_user_led_t *led)
{
    if ((led == NULL) || (!led->initialized))
    {
        return kStatus_InvalidArgument;
    }

#if !defined(BOARD_USER_LED_GPIO) || !defined(BOARD_USER_LED_GPIO_PIN)
    return kStatus_Fail;
#else
    GPIO_PortToggle(BOARD_USER_LED_GPIO, 1u << BOARD_USER_LED_GPIO_PIN);
    return kStatus_Success;
#endif
}
