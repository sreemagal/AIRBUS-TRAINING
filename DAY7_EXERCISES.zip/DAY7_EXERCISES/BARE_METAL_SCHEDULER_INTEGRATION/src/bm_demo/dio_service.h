#pragma once

#include <stdint.h>
#include "fsl_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Digital Output Service (generic example)
 *
 * Contract:
 *  - Init must be called once before other APIs.
 *  - All functions are main/task context only (not ISR-safe) to keep GPIO usage simple.
 *
 * Errors:
 *  - kStatus_InvalidArgument if led==NULL or not initialized.
 */

typedef struct dio_user_led
{
    bool initialized;
} dio_user_led_t;

status_t DioUserLed_Init(dio_user_led_t *led, uint8_t initial_logic_level);
status_t DioUserLed_Write(dio_user_led_t *led, uint8_t logic_level);
status_t DioUserLed_Toggle(dio_user_led_t *led);

#ifdef __cplusplus
}
#endif
