#pragma once

#include <stdint.h>
#include "fsl_common.h"
#include "uart_framed.h"
#include "project_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * diag_proto.h — Optional binary diagnostics message
 *
 * Payload format (LEN = 1 + 1 + 4*N):
 *   [0] = BM_MSGTYPE_DIAG
 *   [1] = diag_id
 *   [2..] = little-endian uint32 fields
 */

typedef enum diag_id
{
    DIAG_ID_LINK = 1,
    DIAG_ID_DOMAIN = 2,
    DIAG_ID_APP = 3,
    DIAG_ID_SCHED = 4,
} diag_id_t;

status_t Diag_SendLink(uart_framed_t *u, uint32_t a, uint32_t b, uint32_t c, uint32_t d);
status_t Diag_SendDomain(uart_framed_t *u, uint32_t a, uint32_t b, uint32_t c, uint32_t d);
status_t Diag_SendApp(uart_framed_t *u, uint32_t a, uint32_t b, uint32_t c, uint32_t d);

#ifdef __cplusplus
}
#endif
