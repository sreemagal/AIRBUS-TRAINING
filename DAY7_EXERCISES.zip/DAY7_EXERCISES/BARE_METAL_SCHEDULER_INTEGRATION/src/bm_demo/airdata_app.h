#pragma once

#include <stdint.h>
#include "fsl_common.h"
#include "arinc_bridge.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * airdata_app.h — Air Data application (simulated)
 *
 * Determinism:
 *  - Store values in fixed-point integers.
 *  - Convert to float only for printing.
 */

typedef struct airdata_state
{
    /* Fixed-point state */
    uint32_t ias_centi_kt;     /* 0.01 kt units */
    uint32_t pressure_alt_ft;  /* feet */

    uint32_t last_update_ms;

    uint32_t valid_words;
    uint32_t invalid_words;
    uint32_t ignored_words;
} airdata_state_t;

void AirData_Init(airdata_state_t *s);

/* Called by ARINC bridge in task context for each decoded word (validity explicit). */
void AirData_OnWord(const arinc_word_t *w, void *user);

#ifdef __cplusplus
}
#endif
