#pragma once

#include "fsl_common.h"

status_t BM_TickPIT_Init_1kHz(void);
