#include "uart_framed.h"

static uint8_t checksum_twos_complement(uint8_t len, const uint8_t *payload)
{
    uint32_t sum = (uint32_t)len;
    for (uint32_t i = 0u; i < (uint32_t)len; i++)
    {
        sum += payload[i];
    }
    return (uint8_t)(0u - (uint8_t)sum);
}

static uint8_t q_is_full(uart_framed_t *u)
{
    uint8_t next = (uint8_t)((u->q_head + 1u) % BM_FRAME_RX_QUEUE_LEN);
    return (next == u->q_tail) ? 1u : 0u;
}

static uint8_t q_is_empty(uart_framed_t *u)
{
    return (u->q_head == u->q_tail) ? 1u : 0u;
}

status_t UartFramed_Init(uart_framed_t *u, bm_link_uart_t *phy)
{
    if ((u == NULL) || (phy == NULL))
    {
        return kStatus_InvalidArgument;
    }

    u->phy = phy;

    u->rx_state = RX_WAIT_START;
    u->rx_len = 0u;
    u->rx_idx = 0u;
    u->rx_sum = 0u;

    u->q_head = 0u;
    u->q_tail = 0u;

    u->frames_rx = 0u;
    u->frames_tx = 0u;
    u->csum_err = 0u;
    u->len_err = 0u;
    u->rx_queue_overflow = 0u;
    u->start_sync_loss = 0u;

    u->fi_tx_corrupt_count = 0u;
    u->fi_rx_drop_count = 0u;

    return kStatus_Success;
}

void UartFramed_Poll(uart_framed_t *u)
{
    if ((u == NULL) || (u->phy == NULL))
    {
        return;
    }

    /* Bounded drain to keep Poll() runtime bounded. */
    uint8_t buf[64];
    size_t n = BM_LinkUart_Drain(u->phy, buf, sizeof(buf));

    for (size_t i = 0u; i < n; i++)
    {
        uint8_t b = buf[i];

#if (BM_FAULT_RX_DROP_BYTE_EVERY_N != 0u)
        static uint32_t drop_ctr = 0u;
        drop_ctr++;
        if ((drop_ctr % BM_FAULT_RX_DROP_BYTE_EVERY_N) == 0u)
        {
            u->fi_rx_drop_count++;
            continue;
        }
#endif

        switch (u->rx_state)
        {
            case RX_WAIT_START:
                if (b == BM_FRAME_START_BYTE)
                {
                    u->rx_state = RX_WAIT_LEN;
                }
                else
                {
                    /* Not a start byte; continue scanning. */
                    u->start_sync_loss++;
                }
                break;

            case RX_WAIT_LEN:
                u->rx_len = b;
                if (u->rx_len > BM_FRAME_MAX_PAYLOAD)
                {
                    u->len_err++;
                    u->rx_state = RX_WAIT_START;
                    break;
                }

                u->rx_idx = 0u;
                u->rx_sum = u->rx_len;

                u->rx_state = (u->rx_len == 0u) ? RX_WAIT_CSUM : RX_WAIT_PAYLOAD;
                break;

            case RX_WAIT_PAYLOAD:
                u->rx_buf[u->rx_idx++] = b;
                u->rx_sum = (uint8_t)(u->rx_sum + b);

                if (u->rx_idx >= u->rx_len)
                {
                    u->rx_state = RX_WAIT_CSUM;
                }
                break;

            case RX_WAIT_CSUM:
            {
                uint8_t total = (uint8_t)(u->rx_sum + b);
                if (total != 0u)
                {
                    u->csum_err++;
                    u->rx_state = RX_WAIT_START;
                    break;
                }

                if (q_is_full(u) != 0u)
                {
                    u->rx_queue_overflow++;
                    /* Policy: drop newest frame. */
                }
                else
                {
                    uart_frame_t *slot = &u->q[u->q_head];
                    slot->len = u->rx_len;
                    for (uint8_t k = 0u; k < u->rx_len; k++)
                    {
                        slot->payload[k] = u->rx_buf[k];
                    }
                    u->q_head = (uint8_t)((u->q_head + 1u) % BM_FRAME_RX_QUEUE_LEN);
                    u->frames_rx++;
                }

                u->rx_state = RX_WAIT_START;
            }
            break;

            default:
                u->rx_state = RX_WAIT_START;
                break;
        }
    }
}

status_t UartFramed_Recv(uart_framed_t *u, uart_frame_t *out)
{
    if ((u == NULL) || (out == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (q_is_empty(u) != 0u)
    {
        return kStatus_NoTransferInProgress;
    }

    const uart_frame_t *slot = &u->q[u->q_tail];
    out->len = slot->len;
    for (uint8_t i = 0u; i < slot->len; i++)
    {
        out->payload[i] = slot->payload[i];
    }

    u->q_tail = (uint8_t)((u->q_tail + 1u) % BM_FRAME_RX_QUEUE_LEN);
    return kStatus_Success;
}

status_t UartFramed_Send(uart_framed_t *u, const uint8_t *payload, uint8_t len)
{
    if ((u == NULL) || (u->phy == NULL) || (payload == NULL))
    {
        return kStatus_InvalidArgument;
    }

    if (len > BM_FRAME_MAX_PAYLOAD)
    {
        return kStatus_OutOfRange;
    }

    uint8_t csum = checksum_twos_complement(len, payload);

    u->tx_buf[0] = BM_FRAME_START_BYTE;
    u->tx_buf[1] = len;
    for (uint8_t i = 0u; i < len; i++)
    {
        u->tx_buf[2u + i] = payload[i];
    }
    u->tx_buf[2u + len] = csum;

#if (BM_FAULT_TX_CORRUPT_EVERY_N != 0u)
    /* Corrupt checksum to trigger receiver checksum errors. */
    if (((u->frames_tx + 1u) % BM_FAULT_TX_CORRUPT_EVERY_N) == 0u)
    {
        u->tx_buf[2u + len] ^= 0x5Au;
        u->fi_tx_corrupt_count++;
    }
#endif

    status_t st = BM_LinkUart_SendNonBlocking(u->phy, u->tx_buf, (size_t)(2u + len + 1u));
    if (st == kStatus_Success)
    {
        u->frames_tx++;
    }

    return st;
}
