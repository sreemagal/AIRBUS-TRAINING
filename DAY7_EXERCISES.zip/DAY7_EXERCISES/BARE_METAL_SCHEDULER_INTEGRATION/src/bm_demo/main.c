#include <stdint.h>

#include "board.h"
#include "fsl_debug_console.h"
#include "clock_config.h"
#include "pin_mux.h"
#include "project_config.h"
#include "fault_inject.h"

#include "dio_service.h"
#include "bm_sched.h"
#include "bm_tick_pit.h"
#include "bm_link_uart.h"
#include "uart_framed.h"
#include "arinc_bridge.h"
#include "diag_proto.h"
#include "airdata_app.h"

/* -------------------- Global modules -------------------- */
static dio_user_led_t g_led;

static bm_link_uart_t g_link_phy;
static uart_framed_t  g_link_framed;
static arinc_bridge_t g_arinc;
static airdata_state_t g_air;

static arinc_tx_entry_t g_tx_schedule[2];

/* -------------------- Tasks -------------------- */
static void TASK_LinkPoll(void)
{
    UartFramed_Poll(&g_link_framed);
}

static void TASK_Domain(void)
{
    ArincBridge_Poll(&g_arinc, BM_TimeMs());
}

#if (BM_NODE_ROLE == BM_ROLE_SENSOR_NODE)
static void TASK_SensorUpdateSchedule(void)
{
    /* Update scheduled words deterministically (content update only). */
    static uint32_t t = 0u;
    t++;

    uint32_t alt_ft = (t * 5u) % 50000u;
    uint32_t ias_centi = (t * 3u) % 30000u;

    g_tx_schedule[0].raw_word = Arinc_PackRaw(BM_LABEL_PRESS_ALT_OCTAL_203, 0u, alt_ft & 0x7FFFFu, 0u, 1u);
    g_tx_schedule[1].raw_word = Arinc_PackRaw(BM_LABEL_IAS_OCTAL_204,       0u, ias_centi & 0x7FFFFu, 0u, 1u);
}
#endif

#if (BM_FAULT_CPU_LOAD_US != 0u)
static void busy_wait_us(uint32_t us)
{
    uint32_t start = BM_TimeUs();
    while ((BM_TimeUs() - start) < us)
    {
        __NOP();
    }
}

static void TASK_LoadGen(void)
{
    busy_wait_us(BM_FAULT_CPU_LOAD_US);
}
#endif

static void TASK_Health(void)
{
#if (BM_NODE_ROLE == BM_ROLE_MISSION_COMPUTER)
    /* Toggle LED on each new valid update as activity indicator. */
    static uint32_t last_valid = 0u;
    if (g_air.valid_words != last_valid)
    {
        (void)DioUserLed_Toggle(&g_led);
        last_valid = g_air.valid_words;
    }
#endif
}

static void TASK_Log(void)
{
#if (BM_NODE_ROLE == BM_ROLE_SENSOR_NODE)
    PRINTF("[SENSOR] arinc(tx=%lu busy=%lu) framed(tx=%lu rx=%lu) csum=%lu len=%lu qovf=%lu fi_tx=%lu fi_drop=%lu",
           (unsigned long)g_arinc.tx_words,
           (unsigned long)g_arinc.tx_busy,
           (unsigned long)g_link_framed.frames_tx,
           (unsigned long)g_link_framed.frames_rx,
           (unsigned long)g_link_framed.csum_err,
           (unsigned long)g_link_framed.len_err,
           (unsigned long)g_link_framed.rx_queue_overflow,
           (unsigned long)g_link_framed.fi_tx_corrupt_count,
           (unsigned long)g_link_framed.fi_rx_drop_count);
#else
    PRINTF("[MC] IAS=%.2f kt ALT=%lu ft valid=%lu invalid=%lu ignored=%lu bad_par=%lu bad_ssm=%lu",
           (double)((float)g_air.ias_centi_kt / 100.0f),
           (unsigned long)g_air.pressure_alt_ft,
           (unsigned long)g_air.valid_words,
           (unsigned long)g_air.invalid_words,
           (unsigned long)g_air.ignored_words,
           (unsigned long)g_arinc.rx_bad_parity,
           (unsigned long)g_arinc.rx_bad_ssm);
#endif

    /* Optional: send compact binary diagnostics over the link. */
    (void)Diag_SendLink(&g_link_framed,
                        g_link_framed.frames_tx,
                        g_link_framed.frames_rx,
                        g_link_framed.csum_err,
                        g_link_framed.rx_queue_overflow);
}

/* -------------------- Task table -------------------- */
static bm_task_t g_tasks[] = {
    { "LINK_POLL",   TASK_LinkPoll,   BM_TASK_PERIOD_LINK_POLL_MS,  220u,  300u },
    { "DOMAIN",      TASK_Domain,     BM_TASK_PERIOD_DOMAIN_MS,     200u, 1000u },
#if (BM_NODE_ROLE == BM_ROLE_SENSOR_NODE)
    { "SENSOR_UPD",  TASK_SensorUpdateSchedule, BM_TASK_PERIOD_SENSOR_TX_MS, 180u,  400u },
#endif
#if (BM_FAULT_CPU_LOAD_US != 0u)
    { "LOADGEN",     TASK_LoadGen,    BM_TASK_PERIOD_LOADGEN_MS,    170u, 5000u },
#endif
    { "HEALTH",      TASK_Health,     BM_TASK_PERIOD_HEALTH_MS,     160u,  500u },
    { "LOG",         TASK_Log,        BM_TASK_PERIOD_LOG_MS,         50u, 4000u },
};

int main(void)
{
	        BOARD_ConfigMPU();
		    BOARD_InitBootPins();
		    BOARD_InitBootClocks();
		    BOARD_InitDebugConsole();
    (void)DioUserLed_Init(&g_led, LOGIC_LED_OFF);

    PRINTF("=== EVKB BM Scheduler + Framed UART + ARINC-Sim (Updated) ===");
#if (BM_NODE_ROLE == BM_ROLE_SENSOR_NODE)
    PRINTF("Role: SENSOR NODE");
#else
    PRINTF("Role: MISSION COMPUTER");
#endif

#if (BM_FAULT_TX_CORRUPT_EVERY_N != 0u)
    PRINTF("FaultInject: TX corrupt every %u frames", (unsigned)BM_FAULT_TX_CORRUPT_EVERY_N);
#endif
#if (BM_FAULT_RX_DROP_BYTE_EVERY_N != 0u)
    PRINTF("FaultInject: RX drop every %u bytes", (unsigned)BM_FAULT_RX_DROP_BYTE_EVERY_N);
#endif
#if (BM_FAULT_CPU_LOAD_US != 0u)
    PRINTF("FaultInject: CPU load %u us per LOADGEN", (unsigned)BM_FAULT_CPU_LOAD_US);
#endif

    /* Scheduler + PIT tick */
    BM_Sched_CoreInit();
    (void)BM_TickPIT_Init_1kHz();

    /* LINK UART init
     *
     * IMPORTANT: src clock depends on board clock mux/div settings.
     * EVKB examples provide BOARD_DebugConsoleSrcFreq() which returns UART root clock.
     */
    uint32_t uart_src_hz = BOARD_DebugConsoleSrcFreq();

    (void)BM_LinkUart_Init(&g_link_phy,
                          BM_LINK_LPUART_BASE,
                          BM_LINK_LPUART_IRQn,
                          BM_LINK_LPUART_CLOCK_IP,
                          BM_LINK_UART_BAUD,
                          uart_src_hz,
                          BM_NVIC_PRIO_LINK_UART);

    (void)UartFramed_Init(&g_link_framed, &g_link_phy);

    (void)ArincBridge_Init(&g_arinc, &g_link_framed);

    AirData_Init(&g_air);
    ArincBridge_SetRxCallback(&g_arinc, AirData_OnWord, &g_air);

#if (BM_NODE_ROLE == BM_ROLE_SENSOR_NODE)
    /* Install periodic schedule (period fixed, content updated by SENSOR task). */
    g_tx_schedule[0].raw_word = Arinc_PackRaw(BM_LABEL_PRESS_ALT_OCTAL_203, 0u, 1000u, 0u, 1u);
    g_tx_schedule[0].period_ms = BM_TASK_PERIOD_SENSOR_TX_MS;

    g_tx_schedule[1].raw_word = Arinc_PackRaw(BM_LABEL_IAS_OCTAL_204, 0u, 1234u, 0u, 1u);
    g_tx_schedule[1].period_ms = BM_TASK_PERIOD_SENSOR_TX_MS;

    (void)ArincBridge_SetTxSchedule(&g_arinc, g_tx_schedule, 2u, BM_TimeMs());
#endif

    (void)BM_Sched_Register(g_tasks, sizeof(g_tasks) / sizeof(g_tasks[0]));

    BM_Sched_Run();

    for (;;)
    {
    }
}
