#pragma once

/*
 * project_config.h
 *
 * Single point of configuration.
 *
 * Design notes:
 *  - Do NOT hide pin mux choices in services. Configure pins using MCUXpresso Config Tools.
 *  - Do NOT call PRINTF from ISR. Logs are handled by a low priority task.
 */

#include <stdint.h>
#include "fsl_common.h"
#include "fsl_device_registers.h"
#include "fsl_clock.h"

/* -------------------- Node role -------------------- */
#define BM_ROLE_SENSOR_NODE        1u
#define BM_ROLE_MISSION_COMPUTER   2u

#ifndef BM_NODE_ROLE
#define BM_NODE_ROLE BM_ROLE_SENSOR_NODE
#endif

/* -------------------- PIT tick -------------------- */
#define BM_TICK_HZ                (1000u) /* 1kHz => 1ms */

#define BM_TICK_PIT_BASE          PIT
#define BM_TICK_PIT_CHANNEL       kPIT_Chnl_0
#define BM_TICK_PIT_IRQn          PIT_IRQn

/* NVIC priorities (Cortex-M: smaller number = higher urgency) */
#define BM_NVIC_PRIO_LINK_UART    (5u)
#define BM_NVIC_PRIO_PIT_TICK     (7u)

/* PIT source clock (matches SDK PIT example for EVKB-IMXRT1050) */
#define BM_PIT_SOURCE_CLOCK_HZ    (CLOCK_GetFreq(kCLOCK_OscClk))

/* -------------------- LINK UART selection -------------------- */
/* Choose a UART NOT used by the debug console. */
#define BM_LINK_LPUART_BASE       LPUART2
#define BM_LINK_LPUART_IRQn       LPUART2_IRQn
#define BM_LINK_LPUART_CLOCK_IP   kCLOCK_Lpuart2

#define BM_LINK_UART_BAUD         (115200u)

/* Background RX ring buffer size (bytes). */
#define BM_LINK_UART_RX_RING_SIZE (1024u)

/* -------------------- Framed transport limits -------------------- */
#define BM_FRAME_START_BYTE       (0x55u)
#define BM_FRAME_MAX_PAYLOAD      (32u)
#define BM_FRAME_RX_QUEUE_LEN     (8u)

/* -------------------- Domain constants -------------------- */
/* Labels are in octal in many avionics texts; 203(oct) and 204(oct) */
#define BM_LABEL_PRESS_ALT_OCTAL_203   (0x83u)
#define BM_LABEL_IAS_OCTAL_204         (0x84u)

/* Payload message types */
#define BM_MSGTYPE_ARINC_WORD     (0xA4u)
#define BM_MSGTYPE_DIAG           (0xD1u)

/* -------------------- Task periods -------------------- */
#define BM_TASK_PERIOD_LINK_POLL_MS   (2u)
#define BM_TASK_PERIOD_DOMAIN_MS      (10u)
#define BM_TASK_PERIOD_SENSOR_TX_MS   (20u)
#define BM_TASK_PERIOD_HEALTH_MS      (100u)
#define BM_TASK_PERIOD_LOG_MS         (500u)

/* Optional load generator period (for overload testing) */
#define BM_TASK_PERIOD_LOADGEN_MS     (5u)

/* -------------------- LED defaults -------------------- */
/* Many EVKB examples define these; provide safe fallbacks if not. */
#ifndef LOGIC_LED_OFF
#define LOGIC_LED_OFF (0u)
#endif

#ifndef LOGIC_LED_ON
#define LOGIC_LED_ON (1u)
#endif

/* -------------------- Compile-time sanity -------------------- */
#if (BM_TICK_HZ != 1000u)
#warning "This demo assumes BM_TICK_HZ=1000 (1ms). Re-evaluate task periods if changed."
#endif
