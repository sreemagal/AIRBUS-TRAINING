#pragma once

/*
 * fault_inject.h
 *
 * Optional fault injection knobs to satisfy robustness tests in the exercise.
 * Keep them compile-time for determinism and simplicity.
 *
 *  - TX checksum corruption triggers checksum errors + resync on receiver.
 *  - RX byte dropping stresses parser robustness.
 *  - CPU load simulates overload and checks missed releases / WCET violations.
 */

/* Corrupt every Nth TX frame checksum (0 = disabled). */
#ifndef BM_FAULT_TX_CORRUPT_EVERY_N
#define BM_FAULT_TX_CORRUPT_EVERY_N (0u)
#endif

/* Drop every Nth received byte during framed Poll (0 = disabled). */
#ifndef BM_FAULT_RX_DROP_BYTE_EVERY_N
#define BM_FAULT_RX_DROP_BYTE_EVERY_N (0u)
#endif

/* Busy-wait this many microseconds in LOADGEN task (0 = disabled). */
#ifndef BM_FAULT_CPU_LOAD_US
#define BM_FAULT_CPU_LOAD_US (0u)
#endif
