#pragma once

#include <stddef.h>
#include <stdint.h>

#include "fsl_common.h"
#include "project_config.h"
#include "fault_inject.h"
#include "bm_link_uart.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * uart_framed.h — Deterministic framed UART transport
 *
 * Frame format:
 *   START(0x55) | LEN | PAYLOAD | CHECKSUM
 *
 * Checksum:
 *   checksum = two's complement of (LEN + sum(payload))
 *   => (LEN + sum(payload) + checksum) == 0 (mod 256)
 *
 * Determinism:
 *  - Parsing occurs only in Poll() (task context).
 *  - Poll() drains a bounded number of bytes.
 *  - RX queue has bounded length; overflow policy is explicit.
 */

typedef struct uart_frame
{
    uint8_t len;
    uint8_t payload[BM_FRAME_MAX_PAYLOAD];
} uart_frame_t;

typedef struct uart_framed
{
    bm_link_uart_t *phy;

    enum {
        RX_WAIT_START = 0,
        RX_WAIT_LEN,
        RX_WAIT_PAYLOAD,
        RX_WAIT_CSUM,
    } rx_state;

    uint8_t rx_len;
    uint8_t rx_idx;
    uint8_t rx_sum;
    uint8_t rx_buf[BM_FRAME_MAX_PAYLOAD];

    uart_frame_t q[BM_FRAME_RX_QUEUE_LEN];
    uint8_t q_head;
    uint8_t q_tail;

    uint8_t tx_buf[2u + BM_FRAME_MAX_PAYLOAD + 1u];

    /* Diagnostics */
    uint32_t frames_rx;
    uint32_t frames_tx;
    uint32_t csum_err;
    uint32_t len_err;
    uint32_t rx_queue_overflow;
    uint32_t start_sync_loss;

    /* Fault injection counters */
    uint32_t fi_tx_corrupt_count;
    uint32_t fi_rx_drop_count;
} uart_framed_t;

status_t UartFramed_Init(uart_framed_t *u, bm_link_uart_t *phy);
void     UartFramed_Poll(uart_framed_t *u);
status_t UartFramed_Recv(uart_framed_t *u, uart_frame_t *out);
status_t UartFramed_Send(uart_framed_t *u, const uint8_t *payload, uint8_t len);

#ifdef __cplusplus
}
#endif
