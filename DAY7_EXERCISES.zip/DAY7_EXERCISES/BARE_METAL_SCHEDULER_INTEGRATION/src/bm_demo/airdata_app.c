#include "airdata_app.h"
#include "project_config.h"
#include "bm_sched.h" /* for BM_TimeMs() */

void AirData_Init(airdata_state_t *s)
{
    if (s == NULL)
    {
        return;
    }

    s->ias_centi_kt = 0u;
    s->pressure_alt_ft = 0u;
    s->last_update_ms = 0u;
    s->valid_words = 0u;
    s->invalid_words = 0u;
    s->ignored_words = 0u;
}

void AirData_OnWord(const arinc_word_t *w, void *user)
{
    airdata_state_t *s = (airdata_state_t *)user;
    if ((w == NULL) || (s == NULL))
    {
        return;
    }

    /* Ignore invalid words explicitly (still counted). */
    if (w->validity != ARINC_VALID_OK)
    {
        s->invalid_words++;
        return;
    }

    if (w->label == BM_LABEL_PRESS_ALT_OCTAL_203)
    {
        s->pressure_alt_ft = (uint32_t)(w->data & 0x7FFFFu);
        s->valid_words++;
        s->last_update_ms = BM_TimeMs();
    }
    else if (w->label == BM_LABEL_IAS_OCTAL_204)
    {
        s->ias_centi_kt = (uint32_t)(w->data & 0x7FFFFu);
        s->valid_words++;
        s->last_update_ms = BM_TimeMs();
    }
    else
    {
        s->ignored_words++;
    }
}
