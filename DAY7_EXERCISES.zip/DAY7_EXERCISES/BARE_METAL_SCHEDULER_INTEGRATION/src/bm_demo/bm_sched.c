#include "bm_sched.h"
#include "fsl_device_registers.h"
#include "fsl_clock.h"

#ifndef BM_SCHED_MAX_TASKS
#define BM_SCHED_MAX_TASKS  16u
#endif

typedef struct bm_sched_state
{
    bm_task_t *tasks[BM_SCHED_MAX_TASKS];
    size_t count;

    volatile uint32_t tick_ms;

    volatile uint32_t dwt_at_last_tick;
    uint32_t cpu_hz;
} bm_sched_state_t;

static bm_sched_state_t g_sched;

static void BM_DwtInit(void)
{
    /* Cortex-M7 supports DWT CYCCNT. */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0u;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

void BM_Sched_CoreInit(void)
{
    g_sched.count = 0u;
    g_sched.tick_ms = 0u;
    g_sched.cpu_hz = CLOCK_GetFreq(kCLOCK_CpuClk);

    BM_DwtInit();
    g_sched.dwt_at_last_tick = DWT->CYCCNT;
}

status_t BM_Sched_Register(bm_task_t *tasks, size_t count)
{
    if ((tasks == NULL) || (count == 0u))
    {
        return kStatus_InvalidArgument;
    }

    if ((g_sched.count + count) > BM_SCHED_MAX_TASKS)
    {
        return kStatus_OutOfRange;
    }

    for (size_t i = 0u; i < count; i++)
    {
        bm_task_t *t = &tasks[i];
        if ((t->run == NULL) || (t->name == NULL))
        {
            return kStatus_InvalidArgument;
        }

        t->ready = 0u;
        t->missed_releases = 0u;
        t->last_start_us = 0u;
        t->last_finish_us = 0u;
        t->wcet_violations = 0u;

        if (t->period_ms != 0u)
        {
            t->next_release_ms = g_sched.tick_ms + t->period_ms;
        }
        else
        {
            t->next_release_ms = 0u;
        }

        g_sched.tasks[g_sched.count++] = t;
    }

    return kStatus_Success;
}

void BM_Sched_TickISR(void)
{
    g_sched.tick_ms++;
    g_sched.dwt_at_last_tick = DWT->CYCCNT;

    /* Release periodic tasks; "skip backlog" policy. */
    for (size_t i = 0u; i < g_sched.count; i++)
    {
        bm_task_t *t = g_sched.tasks[i];
        if (t->period_ms == 0u)
        {
            continue;
        }

        if ((int32_t)(g_sched.tick_ms - t->next_release_ms) >= 0)
        {
            t->ready = 1u;

            uint32_t behind = (uint32_t)(g_sched.tick_ms - t->next_release_ms);
            uint32_t missed = (behind / t->period_ms);
            if (missed > 0u)
            {
                t->missed_releases += missed;
            }

            t->next_release_ms = t->next_release_ms + ((missed + 1u) * t->period_ms);
        }
    }
}

uint32_t BM_TimeMs(void)
{
    return g_sched.tick_ms;
}

uint32_t BM_TimeUs(void)
{
    uint32_t ms;
    uint32_t cyc_base;
    uint32_t cyc_now;

    uint32_t primask = DisableGlobalIRQ();
    ms = g_sched.tick_ms;
    cyc_base = g_sched.dwt_at_last_tick;
    cyc_now = DWT->CYCCNT;
    EnableGlobalIRQ(primask);

    uint32_t cyc_delta = cyc_now - cyc_base;
    uint32_t us_in_tick = (uint32_t)(((uint64_t)cyc_delta * 1000000ULL) / (uint64_t)g_sched.cpu_hz);

    return (ms * 1000u) + us_in_tick;
}

void BM_Sched_Run(void)
{
    for (;;)
    {
        uint8_t ran_any = 0u;

        /* Scan priorities high->low. */
        for (int pr = 255; pr >= 0; pr--)
        {
            for (size_t i = 0u; i < g_sched.count; i++)
            {
                bm_task_t *t = g_sched.tasks[i];
                if ((t->ready != 0u) && (t->prio == (uint8_t)pr))
                {
                    t->ready = 0u;

                    t->last_start_us = BM_TimeUs();
                    t->run();
                    t->last_finish_us = BM_TimeUs();

                    if (t->wcet_us != 0u)
                    {
                        uint32_t dt = t->last_finish_us - t->last_start_us;
                        if (dt > t->wcet_us)
                        {
                            t->wcet_violations++;
                        }
                    }

                    ran_any = 1u;
                }
            }
        }

        if (ran_any == 0u)
        {
            __WFI();
        }
    }
}
