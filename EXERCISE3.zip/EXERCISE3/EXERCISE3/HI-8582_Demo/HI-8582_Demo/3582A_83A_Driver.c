/*! 
 *	3582A_83A_Driver.c
* Supports all: 3582A/3583A/8582/8583
 *	Low Level Driver
 *
 *			HOLT DISCLAIMER
 *
 *			THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *			EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *			OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *			NONINFRINGEMENT. 
 *			IN NO EVENT SHALL HOLT, INC BE LIABLE FOR ANY CLAIM, DAMAGES
 *			OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 *			OTHERWISE,ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 *			SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *			All Rights Reserved.
 *			Copyright (C) 2009 by  HOLT, Inc.
 */
#include <intrinsics.h>
#include <usart/usart.h>
#include <stdio.h>
#include "boardSupport.h"
#include "3582A_83A_Driver.h"
#include "common_init.h"


extern const H3582 pH3582; // in device.h

// Local function prototypes


/* Global Variables */

unsigned char LabelArray_R1[16] = {      // Receiver-1  
// --------------------------------------------------------------- 
//   [0]     [1]     [2]     [3]     [4]     [5]     [6]     [7]
// 000-007 008-015 016-023 024-031 032-039 040-047 048-055 056-063 
     0x01,   0x03,   0X05,   0X07,   0X09,   0X11,   0X13,   0X15,
// ---------------------------------------------------------------      
//   [8]     [9]     [10]    [11]    [12]    [13]    [14]    [15]  
// 064-071 072-079 080-087 088-095 096-103 104-111 112-119 120-127 
     0X17,   0X19,   0X21,   0X23,   0X25,   0X27,   0X29,   0X31,
// ---------------------------------------------------------------      
    
};

unsigned char LabelArray_R2[16] = {     // Receiver-2  
// --------------------------------------------------------------- 
//   [0]     [1]     [2]     [3]     [4]     [5]     [6]     [7]
// 000-007 008-015 016-023 024-031 032-039 040-047 048-055 056-063 
     0x00,   0x02,   0x04,   0X06,   0X08,   0X10,   0X12,   0X14,
// ---------------------------------------------------------------      
//   [8]     [9]     [10]    [11]    [12]    [13]    [14]    [15]  
// 064-071 072-079 080-087 088-095 096-103 104-111 112-119 120-127 
     0X16,   0X18,   0X20,   0X22,   0X24,   0X26,   0X28,   0X30,
// ---------------------------------------------------------------      
     
};

// Loads all 16 Receiver 1 labels
void loadReceiver_1_Labels(void)
{
  unsigned short controlWordM;
 
  
  controlWordM = readControlWord();     // read the CW
  controlWordM |= 0x0002;               // CR1
  writeControlWord(controlWordM);       // set CR1 high
  AT91C_BASE_PIOC->PIO_SODR = SEL;      // set SEL high
   printf("Receiver-1 Labels Loaded: \n\r");   
  for(unsigned short i=0; i<16; i++)
  {
    // user should review tLABEL parameter in AC electrical >=150ns for 3582.
    pH3582->PL1 = (unsigned char)LabelArray_R1[i];  
     printf("0x%.2X ",LabelArray_R1[i]);
  }
  printf("\n\r");
  
  controlWordM &= 0xFFFD;               // set CR1 low
  writeControlWord(controlWordM);       // set CR1 high
  AT91C_BASE_PIOC->PIO_CODR = SEL;      // set SEL high  
  
}
// Reads all 16 Receiver 1 labels and displays them
void readReceiver_1_Labels(void)
{
  unsigned short controlWordM;
  unsigned char readLabels[16];  
  
  controlWordM = readControlWord();     // read the CW
  controlWordM |= 0x0002;               // CR1
  writeControlWord(controlWordM);       // set CR1 high
  AT91C_BASE_PIOC->PIO_SODR = SEL;      // set SEL high
  printf("Receiver-1 Labels Read: \n\r");  
  for(unsigned short i=0; i<16; i++)
      {

        readLabels[i] = pH3582->EN1;     
        printf("0x%.2X ",readLabels[i]);
        
      }

  printf("\n\r");
  
  controlWordM &= 0xFFFD;               // set CR1 low
  writeControlWord(controlWordM);       // set CR1 low
  AT91C_BASE_PIOC->PIO_CODR = SEL;      // set SEL high  
  
}

// Loads all 16 Receiver 2 labels
void loadReceiver_2_Labels(void)
{
  unsigned short controlWordM;
 
  
  controlWordM = readControlWord();     // read the CW
  controlWordM |= 0x0002;               // CR1
  writeControlWord(controlWordM);       // set CR1 high
  AT91C_BASE_PIOC->PIO_SODR = SEL;      // set SEL high
  printf("\n\r");
   printf("Receiver-2 Labels Loaded: \n\r");   
  for(unsigned short i=0; i<16; i++)
  {
    pH3582->PL2 = (unsigned char)LabelArray_R2[i];  
     printf("0x%.2X ",LabelArray_R2[i]);
  }
  printf("\n\r");
  
  controlWordM &= 0xFFFD;               // set CR1 low
  writeControlWord(controlWordM);       // set CR1 high
  AT91C_BASE_PIOC->PIO_CODR = SEL;      // set SEL high  
  
}
// Reads all 16 Receiver 2 labelsand displays them
void readReceiver_2_Labels(void)
{
  unsigned short controlWordM;
  unsigned char readLabels[16];
  
  controlWordM = readControlWord();     // read the CW
  controlWordM |= 0x0002;               // CR1
  writeControlWord(controlWordM);       // set CR1 high
  AT91C_BASE_PIOC->PIO_SODR = SEL;      // set SEL high
  printf("Receiver-2 Labels Read: \n\r");  
  for(unsigned short i=0; i<16; i++)
      {

        readLabels[i] = pH3582->EN2;     
        printf("0x%.2X ",readLabels[i]);
        
      }

  printf("\n\r");
  
  controlWordM &= 0xFFFD;               // set CR1 low
  writeControlWord(controlWordM);       // set CR1 low
  AT91C_BASE_PIOC->PIO_CODR = SEL;      // set SEL high  
  
}

// Toggles Enable for Receiver-1 labels
void enableRec1_Labels(unsigned short Enable)
{
  unsigned short controlWordM;
  
  controlWordM = readControlWord();     // read the CW
  if(Enable)
    controlWordM |= CR2;                  // enable Rec-1 labels
  else
    controlWordM &= ~CR2;               // disable Rec-2 labels
  
   writeControlWord(controlWordM);      //  write the modified CW
  
}
// Toggles Enable for Receiver-2 labels
void enableRec2_Labels(unsigned short Enable)
{
  unsigned short controlWordM;
  
  controlWordM = readControlWord();     // read the CW
  if(Enable)
    controlWordM |= CR3;                  // enable Rec-1 labels
  else
    controlWordM &= ~CR3;               // disable Rec-2 labels
  
   writeControlWord(controlWordM);      //  write the modified CW
  
}

void toggleSelfTestMode(void)
{
  unsigned short controlWordM;
  
  controlWordM = readControlWord();     // read the CW  
  if(controlWordM & CR5)
  {
    controlWordM &= ~CR5;
    printf("Self-Test Mode\n\r");
    
  }
  else
  {
    controlWordM |= CR5;
    printf("Normal Operation\n\r");    
  }
  
   writeControlWord(controlWordM);      //  write the modified CW 
  
  
}
// Enables/Disables Receiver-1 Encoder with bits 9/10.
void setRec_1Bit_9Bit10encoder(unsigned short enable, unsigned short bit9, unsigned bit10)
{
  unsigned short controlWordM;

    controlWordM = readControlWord();     // read the CW 
    
    if(enable)
    {
    // Enable the Rec-1 Encoder bit9/bit10
      controlWordM &= ~(CR7 | CR8);     // mask off old bit9 and bit10
      controlWordM |= CR6;
      
      if(bit9)         
        controlWordM |= CR9;       // set the new bit9 
      if(bit10)
        controlWordM |= CR10;       // set the new bit10                  
    }
    else
    {
      // Disable the Rec-1 encoder bit9/bit10
        controlWordM &= ~CR6;    
    }
        writeControlWord(controlWordM);      //  write the modified CW 
}

// Enables/Disables Receiver-2 Encoder with bits 9/10.
void setRec_2Bit_9Bit10encoder(unsigned short enable, unsigned short bit9, unsigned bit10)
{
  unsigned short controlWordM;

    controlWordM = readControlWord();     // read the CW 
    
    if(enable)
    {
    // Enable the Rec-1 Encoder bit9/bit10
      controlWordM &= ~(CR10 | CR11);     // mask off old bit9 and bit10
      controlWordM |= CR9;
      
      if(bit9)         
        controlWordM |= CR10;       // set the new bit9 
      if(bit10)
        controlWordM |= CR11;       // set the new bit10                  
    }
    else
    {
      // Disable the Rec-1 encoder bit9/bit10
        controlWordM &= ~CR9;    
    }
        writeControlWord(controlWordM);      //  write the modified CW 
}

// Toggles ARINC bit32 between Parity and Data bit
void toggleParityBit32()
{
  unsigned short controlWordM;
  
  controlWordM = readControlWord();     // read the CW
  if(controlWordM&CR4)                  // check CR4 status for Parity?
  {
    controlWordM &= ~CR4;               // make bit32 as Data
    printf("Transmitter bit32 as Data\n\r");
    
  }
  else{
    controlWordM |= CR4;                // make bit32 as Parity
    printf("Transmitter bit32 as Parity\n\r");  
  }
   writeControlWord(controlWordM);      //  write the modified CW
  
}

//------------------------------------------------------------------------------
// This function generates an active low reset pulse for the HI-3582A/83A 
// Returns TRUE if the status register contains expected value after a reset
//------------------------------------------------------------------------------
unsigned short reset_3582(void) {  
 //   const Pin pinREADY = PIN_READY;  
    unsigned int i = 1;
    
    // active low pulse
    AT91C_BASE_PIOC->PIO_CODR = nMR;  // from power up this will already be low.
    while (i--);       
    AT91C_BASE_PIOC->PIO_SODR = nMR;  
    
    return readStatusRegister();      // should be 0x0040
  
//    while (!PIO_Get(&pinREADY));		
}


//------------------------------------------------------------------------------
// Write the Control Word
void writeControlWord(unsigned short controlWord)
{ 
     // write the Control Word
    pH3582->CWSTR = controlWord;     
  
}

//------------------------------------------------------------------------------
// Read the Control Word
// RST bits 8:0 are valid only
unsigned short readControlWord(void) 
{  
  unsigned short controlWord; // use local var for debugging
  
    // Set SEL=1 to read the Control Word
    AT91C_BASE_PIOC->PIO_SODR = SEL; 
    
    // read the Control Word
    controlWord = pH3582->RSR;   
    return controlWord;   
}

//------------------------------------------------------------------------------
// Read the Status Register
unsigned short readStatusRegister(void) 
{  
  unsigned short statusRegister; // use local var for debugging
  
    // Set SEL=0 to read the Control Word
    AT91C_BASE_PIOC->PIO_CODR = SEL;  
    statusRegister = pH3582->RSR; //RSR;    
     return (statusRegister & 0x01FF);   
}


//------------------------------------------------------------------------------
// Write a Transmitter FIFO word32 - unscrambled, CR15=1
// PL1 loads Byte1 DB16:L1, d15:d0
// PL2 loads Byte2 DB32(P):DB17, d31-d16
void writeTransmitterFIFO(unsigned int ArincWord)
{
    pH3582->PL1 = (unsigned short)(ArincWord&0xFFFF);  
    //small delay ~(262ns) to meet tLABEL parameter in AC electrical.
    for(unsigned int i=0; i<1;i++);     
    pH3582->PL2 = (unsigned short)(ArincWord>>16);       
}

// checks the Status Register and returns TRUE 
// if any data available in Receiver1's FIFO.
unsigned short receiver1DataAvailable(void)
{
  unsigned int temp;
  
    temp = readStatusRegister(); 
    if(temp&0x00000001)
       return TRUE;
    else return FALSE;
}


// checks the Status Register and returns TRUE 
// if any data available in Receiver2's FIFO.
unsigned short receiver2DataAvailable(void)
{
  unsigned int temp;
  
    temp = readStatusRegister(); 
    if(temp&0x00000008)
       return TRUE;
    else return FALSE;
}

//------------------------------------------------------------------------------
// Read the Receiver FIFO. 2 x 16 words to get 32 bits
// Returns 32bit value
unsigned int readReceiverFIFO_1(void)
{
  unsigned int data32, temp;        // use local var for debugging  
  
    // Set SEL=0 to read the byte 1
    AT91C_BASE_PIOC->PIO_CODR = SEL;  
     // read the FIFO
    data32 = pH3582->EN1;       // byte 1
    data32 &= 0xFFFF;
    data32 |= data32; 
    
     // Set SEL=1 to read the byte 2
    AT91C_BASE_PIOC->PIO_SODR = SEL;     
    temp =   pH3582->EN1;       // byte 2
    data32 |= (temp<<16);
    
    return data32;
}

//------------------------------------------------------------------------------
// Read the Receiver FIFO. 2 x 16 words to get 32 bits
// Returns 32bit value
unsigned int readReceiverFIFO_2(void)
{
  unsigned int data32, temp;        // use local var for debugging  
  
    // Set SEL=0 to read the byte 1
    AT91C_BASE_PIOC->PIO_CODR = SEL;  
     // read the FIFO
    data32 = pH3582->EN2;       // byte 1
    data32 &= 0xFFFF;
    
     // Set SEL=1 to read the byte 2
    AT91C_BASE_PIOC->PIO_SODR = SEL;     
    temp =   pH3582->EN2;       // byte 2
    data32 |=(temp<<16);
    
    return data32;
}
/*
void configureTransmitter(unsigned short parityMode,unsigned short normal, unsigned short evenOddParity, unsigned short txSpeed)
Input Parameters
parityMode:
    1 = Parity Mode for 32bit
    0 = Data 32bit 
normal:
    1= Normal Transmitter operation
    0= SelfTest
evenOddParity:
    1=Odd Parity
    0=Even Parity

txSpeed:
    1=High Speed
    0=Low Speed

*/
void configureTransmitter(unsigned short parityMode,unsigned short normal, unsigned short evenOddParity, unsigned short txSpeed)
{
 unsigned short controlRegisterM;
 
  controlRegisterM = readControlWord();  // read existing CR

  if(parityMode)
    controlRegisterM |= PARITY;         // set parity bit32
  else 
    controlRegisterM &= DATA;           // set data bit32  
  
  if(normal)
    controlRegisterM |= NORMAL;         // set normal mode
  else 
    controlRegisterM &= SELFTEST;       // set selftest mode   
   
  if(evenOddParity)
    controlRegisterM &= ODD;       // set selftest mode  
  else 
    controlRegisterM |= EVEN;         // set normal mode
  
  if(txSpeed)
    controlRegisterM &= HI;       // set selftest mode 
  else 
    controlRegisterM |= LO;         // set normal mode
  
  writeControlWord(controlRegisterM); // write the modified CR
  
}


void enableTransmission(void)
{
    AT91C_BASE_PIOC->PIO_SODR = ENTX; 
}

void disableTransmission(void)
{
    AT91C_BASE_PIOC->PIO_CODR = ENTX; 
}



// EOF











