/* ----------------------------------------------------------------------------
 *                            HOLT Integrated Circuits 
 * ----------------------------------------------------------------------------
 *
 *    file	boardSupport.c
 *    brief     This file contains functions applicable to all terminal modes
 *
 *	   	HOLT DISCLAIMER
 *      	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
 *      	KIND, EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 *      	WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 *      	PURPOSE AND NONINFRINGEMENT. 
 *      	IN NO EVENT SHALL HOLT, INC BE LIABLE FOR ANY CLAIM, DAMAGES
 *      	OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 *      	OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 *      	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
 *
 *              Copyright (C) 2009-2011 by  HOLT, Inc.
 *              All Rights Reserved
 */


// standard Atmel/IAR headers
#include <pio/pio.h>
#include <pmc/pmc.h>
#include <intrinsics.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
                   
#include "board_EBI.h"
#include "3582A_83A_Driver.h"   
   
extern const H3582 pH3582;

//------------------------------------------------------------------------------
/// Configure the PIO pins not used by ARM on-chip peripherals (USART, EBI, SPI).
/// This configures output pins used for HI-3582 control, LEDs, etc. and input
/// pins used for HI-3582 status, interrupts, DIP switches, pushbuttons, etc.
//------------------------------------------------------------------------------
void ConfigureGpio(void)
{
       const Pin pins[] = {
       PINS_BUTTON,     
       PINS_INPUTS,
       PINS_OUTPUTS,
     };
     
    PIO_Configure(pins, PIO_LISTSIZE(pins));
}



//------------------------------------------------------------------------------
// This function initializes Timer Counter 0 (TC0) for use in delay calls.
//------------------------------------------------------------------------------
void init_timer(void) {
    
    unsigned int i;
    
    // Enable TC0 peripheral clock
    PMC_EnablePeripheral(AT91C_ID_TC0);

    // INITIALIZE TIMER-COUNTER 0 FOR POLLED RC COMPARE OPERATION
    // ----------------------------------------------------------
    // Disable timer-counter clock and interrupts
    AT91C_BASE_TC0->TC_CCR = AT91C_TC_CLKDIS;
    AT91C_BASE_TC0->TC_IDR = 0xFFFFFFFF;
    
    // Clear timer0 status register by reading it
    i = AT91C_BASE_TC0->TC_SR;
    // suppress compiler warning: variable "i" was set, never used
    i = i;
    
    // Set Timer Counter mode. In TC_CMR, set the WAVE bit for waveform
    // operating mode and set the CPCSTOP bit so Register C match stops the
    // timer clock. The AT91C_TC_CLKS_TIMER_DIVx_CLOCK field selects clock 
    // prescaler (MCLK div-by-N).  Other bits are reset...
    AT91C_BASE_TC0->TC_CMR = AT91C_TC_WAVE | AT91C_TC_CPCSTOP 
                                           | AT91C_TC_CLKS_TIMER_DIV1_CLOCK; // for MCLK/2
    //                                     | AT91C_TC_CLKS_TIMER_DIV2_CLOCK; // for MCLK/8
    //                                     | AT91C_TC_CLKS_TIMER_DIV3_CLOCK; // for MCLK/32
    //                                     | AT91C_TC_CLKS_TIMER_DIV4_CLOCK; // for MCLK/128
    
    // Enable TC clock. Timer-counter will not start counting until triggered
    // outside this function
    AT91C_BASE_TC0->TC_CCR = AT91C_TC_CLKEN;
    
    // No AIC interrupt initialization used for timer0, its status reg is polled.
    //
    // To modify to use a timer0 "RC compare" interrupt, add these steps:
    //IRQ_ConfigureIT(AT91C_ID_TC0, 0, TC0_IrqHandler); // identify int svc function
    //AT91C_BASE_TC0->TC_IER = AT91C_TC_CPCS;
    //IRQ_EnableIT(AT91C_ID_TC0);

}   // end init_timer()

/*
//----------------------------------------------------------------------------
//  Function Name       : start_timer0(delay_count)
//  Object              : load register C with compare value then start timer0 
//  Input Parameters    : delay_count
//  Output Parameters   : none
// ----------------------------------------------------------------------------
// 
//  This function clears and starts timer0, then returns to calling program. Once
//  started, timer0 will stop counting and set the timer0 CPCS status flag when
//  count = <Register C>. Because the CPCS flag is polled by the calling program,
//  the timer0 interrrupt is not used.
// 
//  IMPORTANT valid range for delay_count: delay_count < 65,536 (decimal), 0x10000
//  See function "Delay_us()" below, for example using start_timer0()  

void start_timer0(unsigned short int delay_count) {
    
    unsigned short int i;
    // Operating mode already loaded for timer0
    // timer0 status is polled so we do not use interrupt
    
    // Load delay_count into the TC_RC register
    AT91C_BASE_TC0->TC_RC = delay_count;
    // Read timer0 status register to reset its CPCS flag
    i = AT91C_BASE_TC0->TC_SR;
    // Suppress warning: variable "i" was set, never used
    i = i;    
    // Start timer0: Clock Enable and software trigger, which clears the timer 
    // and up-count begins. Counting stops when Register C match occurs.
    AT91C_BASE_TC0->TC_CCR = AT91C_TC_CLKEN | AT91C_TC_SWTRG;
} 
*/

// --------------------------------------------------------------------------------------
//  Function Name       : Delay_us()
//  Object              : in-line delay
//  Input Parameters    : num_us = integer number of microseconds <  2731 
//  Output Parameters   : none
// ---------------------------------------------------------------------------------------
void Delay_us(unsigned short int num_us) {

//    const Pin pinLEDY = PIN_LEDY;
    unsigned short i;
    
//  Previous call for function "init_timer()" is assumed.
//  Use timer0 to generate an n_uS in-line delay. Can verify delay by pulse on LED4.
//  In this function, timer0 status is polled, okay for in-line delays.
//  While less overhead than using a vectored-interrupt delay, the pulse
//  generated is slightly longer than the set value because we poll timer0 status...
//    
//  TC0 Channel Mode Register prescaler selected, 48MHz    Load #     Max t (int)
//  ----------------------------------------------------   -------    -----------
//  AT91C_TC_CLKS_TIMER_DIV1_CLOCK for MCLK/2     48/2     24/1us     2,730us     <--- used
//  AT91C_TC_CLKS_TIMER_DIV2_CLOCK for MCLK/8     48/8     6/1us      10,922us
//  AT91C_TC_CLKS_TIMER_DIV3_CLOCK for MCLK/32    48K/32   1500/1ms   43ms
//  AT91C_TC_CLKS_TIMER_DIV4_CLOCK for MCLK/128   48K/128  375/1ms    174ms
   
    // using 48MHz MCLK and div-by-2 prescaler...
    AT91C_BASE_TC0->TC_CMR = AT91C_TC_WAVE | AT91C_TC_CPCSTOP 
                                           | AT91C_TC_CLKS_TIMER_DIV1_CLOCK; // for MCLK/2

    // Load delay_count into the TC_RC register
    AT91C_BASE_TC0->TC_RC = num_us * (BOARD_MCK / 2000000);
    
    // Read timer0 status register to reset its CPCS flag
    i = AT91C_BASE_TC0->TC_SR;
    // Suppress warning: variable "i" was set, never used
    i = i;    
    // Start timer0: Clock Enable and software trigger, which clears the timer 
    // and up-count begins. Counting stops when Register C match occurs.
    AT91C_BASE_TC0->TC_CCR = AT91C_TC_CLKEN | AT91C_TC_SWTRG;
    
   // Turn ON LED, logic-0 
 //   PIO_Clear(&pinLEDY);
    
    // poll timer0 register C compare status until 0 -> 1 transition
    while (!(AT91C_BASE_TC0->TC_SR & AT91C_TC_CPCS)) ;
    
    // time-out occurred, turn OFF LED, logic-01
//    PIO_Set(&pinLEDY);

}


// --------------------------------------------------------------------------------------
//  Function Name       : Delay_ms()
//  Object              : in-line delay
//  Input Parameters    : num_us = integer number of milliseconds < 175
//  Output Parameters   : none
// ---------------------------------------------------------------------------------------
void Delay_ms(unsigned short int num_ms) {

    unsigned short i;
    
//  Use timer0 to generate an n_uS in-line delay. Can verify delay by pulse on LED4.
//  In this example timer0 status is polled, okay for in-line delays.
//  While less overhead than using a vectored-interrupt delay (below), the pulse
//  generated is slightly longer than the set value because we poll timer0 status...
//    
//  TC0 Channel Mode Register prescaler selected, 48MHz    Load #     Max t (int)
//  ----------------------------------------------------   -------    -----------
//  AT91C_TC_CLKS_TIMER_DIV1_CLOCK for MCLK/2     48/2     24/1us     2,730us
//  AT91C_TC_CLKS_TIMER_DIV2_CLOCK for MCLK/8     48/8     6/1us      10,922us
//  AT91C_TC_CLKS_TIMER_DIV3_CLOCK for MCLK/32    48K/32   1500/1ms   43ms
//  AT91C_TC_CLKS_TIMER_DIV4_CLOCK for MCLK/128   48K/128  375/1ms    174ms     <--- used
   
    // using 48MHz MCLK and div-by-2 prescaler...
    AT91C_BASE_TC0->TC_CMR = AT91C_TC_WAVE | AT91C_TC_CPCSTOP 
                                           | AT91C_TC_CLKS_TIMER_DIV4_CLOCK; // for MCLK/128

    // Load delay_count into the TC_RC register
    AT91C_BASE_TC0->TC_RC = num_ms * (BOARD_MCK / 128000);	    
    
    // Read timer0 status register to reset its CPCS flag
    i = AT91C_BASE_TC0->TC_SR;
    // Suppress warning: variable "i" was set, never used
    i = i;    
    // Start timer0: Clock Enable and software trigger, which clears the timer 
    // and up-count begins. Counting stops when Register C match occurs.
    AT91C_BASE_TC0->TC_CCR = AT91C_TC_CLKEN | AT91C_TC_SWTRG;
    
   // Turn ON yellow LED, logic-0, measure pulse time to check delay time 
   // AT91C_BASE_PIOA->PIO_CODR = nLEDY; 
    
    // poll timer0 register C compare status until 0 -> 1 transition
    while (!(AT91C_BASE_TC0->TC_SR & AT91C_TC_CPCS)) ;
    
    // time-out occurred, turn OFF yellow LED, logic-01
 //   AT91C_BASE_PIOA->PIO_SODR = nLEDY; 

}

// ---------------------------------------------------------------------------------------
// multiple 100ms in-line delay
// ---------------------------------------------------------------------------------------
void Delay_x100ms(unsigned short num) {  
  for(; 0 < num ; num--) {
      Delay_ms(100);
  }
}

// ---------------------------------------------------------------------------------------
// multiple 10us in-line delay
// ---------------------------------------------------------------------------------------
void Delay_x10us(unsigned short num) {  
  for(; 0 < num ; num--) {
      Delay_us(100);
  }
}
// ---------------------------------------------------------------------------------------
// flash green LED for 400ms
// ---------------------------------------------------------------------------------------
void Flash_Green_LED(void) {
    AT91C_BASE_PIOA->PIO_CODR = nLEDG; 
    Delay_x100ms(4);
    AT91C_BASE_PIOA->PIO_SODR = nLEDG; 
}






   


// end of file

