#ifndef CLI_H_
#define CLI_H_

#ifdef __cplusplus
extern "C" {
#endif

void Cli_Init(void);
void Cli_Poll(void);

#ifdef __cplusplus
}
#endif

#endif /* CLI_H_ */
