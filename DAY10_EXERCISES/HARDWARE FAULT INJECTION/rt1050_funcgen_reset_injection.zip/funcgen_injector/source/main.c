/*
 * funcgen_injector: RT1050 EVKB used as a safe digital function/pulse generator
 * for reset fault-injection experiments.
 *
 * SDK: MCUXpresso SDK 25.06.00 for EVKB-IMXRT1050
 */

#include "board.h"
#include "fsl_common.h"
#include "fsl_debug_console.h"

#include "cli.h"
#include "funcgen_pit.h"

int main(void)
{
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();

    PRINTF("\r\n=== RT1050 Function Generator / Reset Pulse Injector ===\r\n");
    PRINTF("Output pin: J24[4] (GPIO_SD_B0_02 / GPIO3_IO14) open-drain\r\n");
    PRINTF("Type 'help' for commands.\r\n\r\n");

    FuncGenPit_Init();
    Cli_Init();

    while (1)
    {
        Cli_Poll();
        FuncGenPit_Background(); /* used for sweep automation */
    }
}
