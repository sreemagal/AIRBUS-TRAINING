#ifndef FUNCGEN_PIT_H_
#define FUNCGEN_PIT_H_

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum _funcgen_state
{
    kFuncGenStopped = 0,
    kFuncGenRunning = 1,
    kFuncGenBurst   = 2,
    kFuncGenSweep   = 3,
} funcgen_state_t;

typedef struct _funcgen_cfg
{
    uint32_t period_us;     /* full period */
    uint32_t pulse_us;      /* active-low time inside the period */
    bool     activeLow;     /* true = output low during pulse_us; otherwise high during pulse_us */
} funcgen_cfg_t;

typedef struct _funcgen_sweep_cfg
{
    bool     enabled;
    int32_t  start_us;
    int32_t  end_us;
    int32_t  step_us;         /* can be negative */
    uint32_t period_us;
    uint32_t count_each;      /* pulses per step */
} funcgen_sweep_cfg_t;

/* Init PIT + output pin. Must be called after BOARD_InitBootClocks(). */
void FuncGenPit_Init(void);

/* Stop output immediately and release line high (open-drain off). */
void FuncGenPit_Stop(void);

/* Configure waveform (does not start). Returns false on invalid parameters. */
bool FuncGenPit_Set(uint32_t period_us, uint32_t pulse_us, bool activeLow);

/* Start continuous waveform based on last configuration. */
void FuncGenPit_Start(void);

/* Start a burst of N pulses, then stop. */
void FuncGenPit_Burst(uint32_t pulse_count);

/* Blocking one-shot pulse (no PIT). */
void FuncGenPit_OneShot(uint32_t pulse_us);

/* Read current config/state (thread-safe for simple reads). */
funcgen_state_t FuncGenPit_GetState(void);
funcgen_cfg_t   FuncGenPit_GetConfig(void);

/* Sweep automation support */
bool FuncGenPit_SweepStart(const funcgen_sweep_cfg_t *cfg);
void FuncGenPit_SweepStop(void);
funcgen_sweep_cfg_t FuncGenPit_SweepGet(void);
void FuncGenPit_Background(void);

#ifdef __cplusplus
}
#endif

#endif /* FUNCGEN_PIT_H_ */
