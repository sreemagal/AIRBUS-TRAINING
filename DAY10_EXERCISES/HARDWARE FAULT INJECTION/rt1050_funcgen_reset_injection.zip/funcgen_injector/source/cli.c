/*
 * Simple UART CLI using fsl_debug_console (DbgConsole_TryGetchar).
 */

#include "cli.h"

#include <ctype.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "fsl_debug_console.h"
#include "funcgen_pit.h"

#define CLI_LINE_MAX 128

static char s_line[CLI_LINE_MAX];
static uint32_t s_len = 0;

static void print_help(void)
{
    PRINTF(
        "\r\nCommands:\r\n"
        "  help\r\n"
        "  status\r\n"
        "  set <period_us> <pulse_us>             (active-low pulses)\r\n"
        "  start                                  (continuous)\r\n"
        "  stop\r\n"
        "  burst <count>\r\n"
        "  oneshot <pulse_us>                     (blocking)\r\n"
        "  sweep <start_us> <end_us> <step_us> <period_us> <count_each>\r\n"
        "\r\nExamples:\r\n"
        "  set 5000000 10000\r\n"
        "  burst 3\r\n"
        "  sweep 10000 100 -100 5000000 1\r\n"
        "\r\n"
    );
}

static bool parse_u32(const char *s, uint32_t *out)
{
    if (!s || !out) return false;
    char *end = NULL;
    unsigned long v = strtoul(s, &end, 0);
    if (end == s || *end != '\0') return false;
    if (v > 0xFFFFFFFFUL) return false;
    *out = (uint32_t)v;
    return true;
}

static bool parse_i32(const char *s, int32_t *out)
{
    if (!s || !out) return false;
    char *end = NULL;
    long v = strtol(s, &end, 0);
    if (end == s || *end != '\0') return false;
    if (v < (long)INT32_MIN || v > (long)INT32_MAX) return false;
    *out = (int32_t)v;
    return true;
}

static void cmd_status(void)
{
    funcgen_cfg_t cfg = FuncGenPit_GetConfig();
    funcgen_state_t st = FuncGenPit_GetState();
    funcgen_sweep_cfg_t sw = FuncGenPit_SweepGet();

    const char *st_s = (st == kFuncGenStopped) ? "stopped" :
                       (st == kFuncGenRunning) ? "running" :
                       (st == kFuncGenBurst) ? "burst" :
                       (st == kFuncGenSweep) ? "sweep" : "unknown";

    PRINTF("State: %s\r\n", st_s);
    PRINTF("Cfg: period_us=%lu pulse_us=%lu activeLow=%u\r\n",
           (unsigned long)cfg.period_us, (unsigned long)cfg.pulse_us, (unsigned)cfg.activeLow);
    PRINTF("Sweep: enabled=%u start=%ld end=%ld step=%ld period=%lu count_each=%lu\r\n",
           (unsigned)sw.enabled, (long)sw.start_us, (long)sw.end_us, (long)sw.step_us,
           (unsigned long)sw.period_us, (unsigned long)sw.count_each);
}

static void process_line(char *line)
{
    /* Tokenize */
    char *argv[8] = {0};
    int argc = 0;

    for (char *tok = strtok(line, " \t"); tok && argc < 8; tok = strtok(NULL, " \t"))
    {
        argv[argc++] = tok;
    }
    if (argc == 0) return;

    if (strcmp(argv[0], "help") == 0)
    {
        print_help();
        return;
    }
    if (strcmp(argv[0], "status") == 0)
    {
        cmd_status();
        return;
    }
    if (strcmp(argv[0], "stop") == 0)
    {
        FuncGenPit_Stop();
        PRINTF("Stopped.\r\n");
        return;
    }
    if (strcmp(argv[0], "start") == 0)
    {
        FuncGenPit_SweepStop();
        FuncGenPit_Start();
        PRINTF("Started.\r\n");
        return;
    }
    if (strcmp(argv[0], "set") == 0)
    {
        if (argc < 3)
        {
            PRINTF("Usage: set <period_us> <pulse_us>\r\n");
            return;
        }
        uint32_t period_us = 0, pulse_us = 0;
        if (!parse_u32(argv[1], &period_us) || !parse_u32(argv[2], &pulse_us))
        {
            PRINTF("ERR: invalid number\r\n");
            return;
        }
        if (!FuncGenPit_Set(period_us, pulse_us, true))
        {
            PRINTF("ERR: invalid config (pulse must be >0 and < period)\r\n");
            return;
        }
        PRINTF("OK: period_us=%lu pulse_us=%lu\r\n", (unsigned long)period_us, (unsigned long)pulse_us);
        return;
    }
    if (strcmp(argv[0], "burst") == 0)
    {
        if (argc < 2)
        {
            PRINTF("Usage: burst <count>\r\n");
            return;
        }
        uint32_t n = 0;
        if (!parse_u32(argv[1], &n))
        {
            PRINTF("ERR: invalid number\r\n");
            return;
        }
        FuncGenPit_SweepStop();
        FuncGenPit_Burst(n);
        PRINTF("Burst started: %lu pulses\r\n", (unsigned long)n);
        return;
    }
    if (strcmp(argv[0], "oneshot") == 0)
    {
        if (argc < 2)
        {
            PRINTF("Usage: oneshot <pulse_us>\r\n");
            return;
        }
        uint32_t w = 0;
        if (!parse_u32(argv[1], &w))
        {
            PRINTF("ERR: invalid number\r\n");
            return;
        }
        FuncGenPit_SweepStop();
        FuncGenPit_OneShot(w);
        PRINTF("Oneshot complete.\r\n");
        return;
    }
    if (strcmp(argv[0], "sweep") == 0)
    {
        if (argc < 6)
        {
            PRINTF("Usage: sweep <start_us> <end_us> <step_us> <period_us> <count_each>\r\n");
            return;
        }
        funcgen_sweep_cfg_t sw = {0};
        if (!parse_i32(argv[1], &sw.start_us) ||
            !parse_i32(argv[2], &sw.end_us) ||
            !parse_i32(argv[3], &sw.step_us) ||
            !parse_u32(argv[4], &sw.period_us) ||
            !parse_u32(argv[5], &sw.count_each))
        {
            PRINTF("ERR: invalid number\r\n");
            return;
        }

        if (!FuncGenPit_SweepStart(&sw))
        {
            PRINTF("ERR: could not start sweep\r\n");
            return;
        }
        return;
    }

    PRINTF("Unknown command. Type 'help'.\r\n");
}

void Cli_Init(void)
{
    s_len = 0;
    memset(s_line, 0, sizeof(s_line));
}

void Cli_Poll(void)
{
    char ch;
    if (DbgConsole_TryGetchar(&ch) != kStatus_Success)
    {
        return;
    }

    /* Echo */
    PUTCHAR(ch);

    if (ch == '\r' || ch == '\n')
    {
        PUTCHAR('\n');
        s_line[s_len] = '\0';
        process_line(s_line);
        s_len = 0;
        memset(s_line, 0, sizeof(s_line));
        return;
    }

    if (ch == '\b' || ch == 127)
    {
        if (s_len > 0) s_len--;
        return;
    }

    if (isprint((unsigned char)ch))
    {
        if (s_len < (CLI_LINE_MAX - 1))
        {
            s_line[s_len++] = ch;
        }
    }
}
