/*
 * PIT-driven function generator / pulse train generator.
 *
 * Why PIT:
 * - 32-bit counter => can generate very low repetition rates (e.g., 0.2 Hz, 5 s period)
 * - We can generate extremely low duty ratios (e.g., 100 us low inside 5 s period)
 *
 * Output is configured as open-drain so it can safely pull an external reset net low.
 */

#include "funcgen_pit.h"

#include "fsl_common.h"
#include "fsl_clock.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"
#include "fsl_iomuxc.h"
#include "fsl_pit.h"

/* ---------------- Pin selection (Injector output) ----------------
 * EVKB Arduino SPI header J24 pin 4 (MOSI):
 *   Pad: GPIO_SD_B0_02
 *   GPIO function: GPIO3_IO14
 *
 * We configure the pad as OPEN-DRAIN; writing '1' releases the line (pulled up externally).
 */
#define FG_OUT_IOMUXC_MUX  IOMUXC_GPIO_SD_B0_02_GPIO3_IO14
#define FG_OUT_IOMUXC_PAD  IOMUXC_GPIO_SD_B0_02_GPIO3_IO14
#define FG_OUT_GPIO        GPIO3
#define FG_OUT_GPIO_PIN    14U

/* Base pad config used across SDK examples for 100MHz speed, keeper enabled, etc.
 * We OR in the ODE bit (0x800) to enable open-drain.
 *
 * If you want a stronger pull-up inside the MCU, you can generate a new config
 * using MCUXpresso Config Tools and replace this constant.
 */
#define FG_OUT_PAD_CONFIG  (0x10B0U | 0x800U) /* 0x10B0 from SDK-generated pinmux + ODE */

/* ---------------- PIT selection ---------------- */
#define FG_PIT_BASE     PIT
#define FG_PIT_CH       kPIT_Chnl_0
#define FG_PIT_IRQ      PIT_IRQn
#define FG_PIT_ISR      PIT_IRQHandler

/* Same as SDK PIT example for EVKB: */
#define FG_PIT_CLK_HZ   (CLOCK_GetFreq(kCLOCK_OscClk)) /* 24 MHz */

static volatile funcgen_state_t s_state = kFuncGenStopped;
static volatile funcgen_cfg_t   s_cfg   = { .period_us = 5000000U, .pulse_us = 10000U, .activeLow = true };

/* Derived timing in PIT ticks */
static volatile uint32_t s_ticks_low  = 0;
static volatile uint32_t s_ticks_high = 0;

static volatile bool     s_out_is_active = false; /* true means output is in "active" level per cfg */

static volatile uint32_t s_burst_remaining = 0;
static volatile bool     s_burst_last_pulse_armed = false;

/* Sweep support */
static funcgen_sweep_cfg_t s_sweep = {0};
static volatile int32_t s_sweep_current_us = 0;

static inline uint32_t us_to_ticks(uint32_t us)
{
    uint64_t ticks = ((uint64_t)FG_PIT_CLK_HZ * (uint64_t)us) / 1000000ULL;
    if (ticks == 0ULL)
        ticks = 1ULL;
    if (ticks > 0xFFFFFFFFULL)
        ticks = 0xFFFFFFFFULL;
    return (uint32_t)ticks;
}

static inline void out_release_high(void)
{
    /* Open-drain: write 1 = release line */
    GPIO_PinWrite(FG_OUT_GPIO, FG_OUT_GPIO_PIN, 1U);
}

static inline void out_drive_low(void)
{
    GPIO_PinWrite(FG_OUT_GPIO, FG_OUT_GPIO_PIN, 0U);
}

static inline void out_set_active(bool active)
{
    /* activeLow: active = low; else active = high */
    if (s_cfg.activeLow)
    {
        if (active) out_drive_low();
        else out_release_high();
    }
    else
    {
        if (active) out_release_high();
        else out_drive_low();
    }
    s_out_is_active = active;
}

static void pit_arm_oneshot(uint32_t ticks)
{
    PIT_StopTimer(FG_PIT_BASE, FG_PIT_CH);
    PIT_SetTimerPeriod(FG_PIT_BASE, FG_PIT_CH, ticks);
    PIT_StartTimer(FG_PIT_BASE, FG_PIT_CH);
}

static void output_pin_init(void)
{
    IOMUXC_SetPinMux(FG_OUT_IOMUXC_MUX, 0U);
    IOMUXC_SetPinConfig(FG_OUT_IOMUXC_PAD, FG_OUT_PAD_CONFIG);

    gpio_pin_config_t cfg = {
        .direction = kGPIO_DigitalOutput,
        .outputLogic = 1U, /* release line */
        .interruptMode = kGPIO_NoIntmode,
    };
    GPIO_PinInit(FG_OUT_GPIO, FG_OUT_GPIO_PIN, &cfg);

    out_release_high();
    s_out_is_active = false;
}

static void pit_init(void)
{
    pit_config_t pitConfig;
    PIT_GetDefaultConfig(&pitConfig);
    PIT_Init(FG_PIT_BASE, &pitConfig);

    PIT_SetTimerPeriod(FG_PIT_BASE, FG_PIT_CH, us_to_ticks(1000U)); /* placeholder */
    PIT_EnableInterrupts(FG_PIT_BASE, FG_PIT_CH, kPIT_TimerInterruptEnable);

    EnableIRQ(FG_PIT_IRQ);
}

static bool recalc_ticks(void)
{
    if (s_cfg.period_us == 0U) return false;
    if (s_cfg.pulse_us == 0U) return false;
    if (s_cfg.pulse_us >= s_cfg.period_us) return false;

    s_ticks_low  = us_to_ticks(s_cfg.pulse_us);
    s_ticks_high = us_to_ticks(s_cfg.period_us - s_cfg.pulse_us);
    return true;
}

void FuncGenPit_Init(void)
{
    output_pin_init();
    pit_init();

    if (!recalc_ticks())
    {
        /* Should not happen with defaults. */
        s_cfg.period_us = 5000000U;
        s_cfg.pulse_us  = 10000U;
        s_cfg.activeLow = true;
        (void)recalc_ticks();
    }

    FuncGenPit_Stop();
}

bool FuncGenPit_Set(uint32_t period_us, uint32_t pulse_us, bool activeLow)
{
    bool ok;
    __disable_irq();
    s_cfg.period_us = period_us;
    s_cfg.pulse_us  = pulse_us;
    s_cfg.activeLow = activeLow;
    ok = recalc_ticks();
    __enable_irq();

    return ok;
}

funcgen_cfg_t FuncGenPit_GetConfig(void)
{
    funcgen_cfg_t cfg;
    __disable_irq();
    cfg = s_cfg;
    __enable_irq();
    return cfg;
}

funcgen_state_t FuncGenPit_GetState(void)
{
    funcgen_state_t st;
    __disable_irq();
    st = s_state;
    __enable_irq();
    return st;
}

void FuncGenPit_Stop(void)
{
    __disable_irq();

    PIT_StopTimer(FG_PIT_BASE, FG_PIT_CH);
    PIT_ClearStatusFlags(FG_PIT_BASE, FG_PIT_CH, kPIT_TimerFlag);

    s_state = kFuncGenStopped;
    s_burst_remaining = 0;
    s_burst_last_pulse_armed = false;

    out_release_high();
    s_out_is_active = false;

    __enable_irq();
}

void FuncGenPit_Start(void)
{
    __disable_irq();

    if (!recalc_ticks())
    {
        __enable_irq();
        PRINTF("ERR: invalid config. Use: set <period_us> <pulse_us> (pulse < period)\r\n");
        return;
    }

    s_state = kFuncGenRunning;
    s_burst_remaining = 0;
    s_burst_last_pulse_armed = false;

    /* Start immediately with the active phase (pulse). */
    out_set_active(true);
    pit_arm_oneshot(s_ticks_low);

    __enable_irq();
}

void FuncGenPit_Burst(uint32_t pulse_count)
{
    __disable_irq();

    if (!recalc_ticks())
    {
        __enable_irq();
        PRINTF("ERR: invalid config. Use: set <period_us> <pulse_us> (pulse < period)\r\n");
        return;
    }
    if (pulse_count == 0U)
    {
        __enable_irq();
        PRINTF("ERR: burst count must be > 0\r\n");
        return;
    }

    s_state = kFuncGenBurst;
    s_burst_remaining = pulse_count;
    s_burst_last_pulse_armed = false;

    /* Start immediately with the active phase and count this pulse. */
    out_set_active(true);
    s_burst_remaining--;
    if (s_burst_remaining == 0U)
    {
        s_burst_last_pulse_armed = true;
    }

    pit_arm_oneshot(s_ticks_low);

    __enable_irq();
}

void FuncGenPit_OneShot(uint32_t pulse_us)
{
    /* Blocking one-shot. Good for quick manual tests. */
    FuncGenPit_Stop();

    if (pulse_us == 0U)
    {
        PRINTF("ERR: oneshot width must be > 0\r\n");
        return;
    }

    out_set_active(true);
    SDK_DelayAtLeastUs(pulse_us, CLOCK_GetFreq(kCLOCK_CpuClk));
    out_set_active(false);
}

static void isr_step(void)
{
    /* ISR toggles between active (pulse) and inactive (rest of period). */
    if (s_state == kFuncGenStopped)
    {
        return;
    }

    if (s_out_is_active)
    {
        /* active -> inactive */
        out_set_active(false);

        if (s_state == kFuncGenBurst && s_burst_last_pulse_armed)
        {
            /* last pulse completed: stop now, ensure released high */
            PIT_StopTimer(FG_PIT_BASE, FG_PIT_CH);
            s_state = kFuncGenStopped;
            s_burst_last_pulse_armed = false;
            return;
        }

        pit_arm_oneshot(s_ticks_high);
    }
    else
    {
        /* inactive -> active (new pulse) */
        out_set_active(true);

        if (s_state == kFuncGenBurst)
        {
            if (s_burst_remaining > 0U)
            {
                s_burst_remaining--;
                if (s_burst_remaining == 0U)
                {
                    s_burst_last_pulse_armed = true;
                }
            }
        }

        pit_arm_oneshot(s_ticks_low);
    }
}

void FG_PIT_ISR(void)
{
    if ((PIT_GetStatusFlags(FG_PIT_BASE, FG_PIT_CH) & kPIT_TimerFlag) != 0U)
    {
        PIT_ClearStatusFlags(FG_PIT_BASE, FG_PIT_CH, kPIT_TimerFlag);
        isr_step();
    }
}

/* ---------------- Sweep support (runs in main loop) ---------------- */

bool FuncGenPit_SweepStart(const funcgen_sweep_cfg_t *cfg)
{
    if (cfg == NULL) return false;
    if (cfg->count_each == 0U) return false;
    if (cfg->step_us == 0) return false;

    __disable_irq();
    s_sweep = *cfg;
    s_sweep.enabled = true;
    s_sweep_current_us = cfg->start_us;
    __enable_irq();

    PRINTF("Sweep armed: start=%ld us end=%ld us step=%ld us period=%lu us count_each=%lu\r\n",
           (long)cfg->start_us, (long)cfg->end_us, (long)cfg->step_us,
           (unsigned long)cfg->period_us, (unsigned long)cfg->count_each);

    /* Kick first step immediately */
    FuncGenPit_Stop();
    if (!FuncGenPit_Set(cfg->period_us, (uint32_t)((cfg->start_us > 0) ? cfg->start_us : 1), true))
    {
        PRINTF("ERR: sweep config invalid (period/pulse)\r\n");
        FuncGenPit_SweepStop();
        return false;
    }
    FuncGenPit_Burst(cfg->count_each);
    return true;
}

void FuncGenPit_SweepStop(void)
{
    __disable_irq();
    s_sweep.enabled = false;
    __enable_irq();
}

funcgen_sweep_cfg_t FuncGenPit_SweepGet(void)
{
    funcgen_sweep_cfg_t c;
    __disable_irq();
    c = s_sweep;
    __enable_irq();
    return c;
}

static bool sweep_done(int32_t cur, int32_t end, int32_t step)
{
    if (step > 0) return cur > end;
    else return cur < end;
}

void FuncGenPit_Background(void)
{
    /* Called from main loop to advance sweep when bursts complete. */
    funcgen_state_t st = FuncGenPit_GetState();
    funcgen_sweep_cfg_t sw = FuncGenPit_SweepGet();

    if (!sw.enabled) return;

    if (st != kFuncGenStopped)
    {
        return; /* wait for current burst */
    }

    /* advance */
    int32_t next = s_sweep_current_us + sw.step_us;
    if (sweep_done(next, sw.end_us, sw.step_us))
    {
        PRINTF("Sweep complete.\r\n");
        FuncGenPit_SweepStop();
        return;
    }

    s_sweep_current_us = next;
    uint32_t pulse_us = (next > 0) ? (uint32_t)next : 1U;

    if (!FuncGenPit_Set(sw.period_us, pulse_us, true))
    {
        PRINTF("ERR: sweep step invalid (pulse>=period?). Stopping.\r\n");
        FuncGenPit_SweepStop();
        return;
    }

    PRINTF("Sweep step: pulse=%lu us, period=%lu us, burst=%lu\r\n",
           (unsigned long)pulse_us, (unsigned long)sw.period_us, (unsigned long)sw.count_each);

    FuncGenPit_Burst(sw.count_each);
}
