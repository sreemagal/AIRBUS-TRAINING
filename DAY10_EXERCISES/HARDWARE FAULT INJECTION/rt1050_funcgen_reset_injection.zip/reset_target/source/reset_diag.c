/*
 * Reset diagnostics for i.MX RT1050 (SRC reset cause + GPR boot counter)
 *
 * Based directly on the approach described in your uploaded fault-injection notes.
 */

#include "reset_diag.h"

#include "fsl_src.h"
#include "fsl_debug_console.h"

static const char *flag_to_str(uint32_t f)
{
    switch (f)
    {
        case kSRC_Wdog3ResetFlag:             return "RTWDOG/WDOG3 timeout";
        case kSRC_WatchdogResetFlag:          return "WDOG1/WDOG2 timeout";
        case kSRC_IppResetPinFlag:            return "IPP_RESET_B (power-up sequence)";
        case kSRC_IppUserResetFlag:           return "IPP_USER_RESET_B (external reset pin)";
        case kSRC_JTAGSystemResetFlag:        return "JTAG system reset";
        case kSRC_JTAGSoftwareResetFlag:      return "JTAG software reset";
        case kSRC_JTAGGeneratedResetFlag:     return "JTAG generated reset (EXTEST/HIGHZ)";
        case kSRC_LockupSysResetFlag:         return "CPU lockup / SYSRESETREQ";
        case kSRC_TemperatureSensorResetFlag: return "On-chip temperature sensor reset";
        default:                              return "Unknown/Multiple";
    }
}

void ResetDiag_RunEarly(void)
{
    uint32_t flags = SRC_GetResetStatusFlags(SRC);

    /* Use SRC GPR1 (index 0) to persist a monotonic boot counter across warm resets. */
    uint32_t bootCount = SRC_GetGeneralPurposeRegister(SRC, 0);
    bootCount++;
    SRC_SetGeneralPurposeRegister(SRC, 0, bootCount);

    PRINTF("\r\n=== Reset diagnostic (SRC) ===\r\n");
    PRINTF("Boot count (SRC GPR1): %lu\r\n", (unsigned long)bootCount);

    if (flags == 0U)
    {
        PRINTF("Reset flags: none (cold power-up or flags already cleared)\r\n");
    }
    else
    {
        PRINTF("Reset flags raw: 0x%08lx\r\n", (unsigned long)flags);

        /* Print all flags that are set (may be more than one). */
        if (flags & kSRC_Wdog3ResetFlag)             PRINTF(" - %s\r\n", flag_to_str(kSRC_Wdog3ResetFlag));
        if (flags & kSRC_WatchdogResetFlag)          PRINTF(" - %s\r\n", flag_to_str(kSRC_WatchdogResetFlag));
        if (flags & kSRC_IppResetPinFlag)            PRINTF(" - %s\r\n", flag_to_str(kSRC_IppResetPinFlag));
        if (flags & kSRC_IppUserResetFlag)           PRINTF(" - %s\r\n", flag_to_str(kSRC_IppUserResetFlag));
        if (flags & kSRC_JTAGSystemResetFlag)        PRINTF(" - %s\r\n", flag_to_str(kSRC_JTAGSystemResetFlag));
        if (flags & kSRC_JTAGSoftwareResetFlag)      PRINTF(" - %s\r\n", flag_to_str(kSRC_JTAGSoftwareResetFlag));
        if (flags & kSRC_JTAGGeneratedResetFlag)     PRINTF(" - %s\r\n", flag_to_str(kSRC_JTAGGeneratedResetFlag));
        if (flags & kSRC_LockupSysResetFlag)         PRINTF(" - %s\r\n", flag_to_str(kSRC_LockupSysResetFlag));
        if (flags & kSRC_TemperatureSensorResetFlag) PRINTF(" - %s\r\n", flag_to_str(kSRC_TemperatureSensorResetFlag));
    }

    /* Clear all observed flags so the next reset cause is unambiguous. */
    SRC_ClearResetStatusFlags(SRC, flags);

    PRINTF("=== End reset diagnostic ===\r\n\r\n");
}
