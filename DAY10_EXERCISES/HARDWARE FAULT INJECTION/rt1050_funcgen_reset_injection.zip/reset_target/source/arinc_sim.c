/*
 * Avionics-use-case simulation (ARINC 429 continuity concept).
 *
 * Real HW: EVKB -> UART bridge -> Holt HI-8582/8583 -> ARINC 429 bus
 * In this lab we simulate the "bridge" and "labels" by printing framed lines on UART.
 *
 * Goal: demonstrate that after each reset, the system re-handshakes and resumes periodic frames
 * at deterministic boundaries, rather than immediately blasting partial frames.
 */

#include "arinc_sim.h"

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "fsl_common.h"
#include "fsl_debug_console.h"
#include "fsl_clock.h"
#include "fsl_pit.h"

/* Use PIT channel 1 for a 100 ms "label scheduler" tick. */
#define SIM_PIT_BASE PIT
#define SIM_PIT_CH   kPIT_Chnl_1
#define SIM_PIT_CLK_HZ (CLOCK_GetFreq(kCLOCK_OscClk))
#define SIM_TICK_MS  100U

static volatile bool s_tick = false;
static volatile uint32_t s_seq = 0;

static inline uint32_t ms_to_ticks(uint32_t ms)
{
    uint64_t ticks = ((uint64_t)SIM_PIT_CLK_HZ * (uint64_t)ms) / 1000ULL;
    if (ticks == 0ULL) ticks = 1ULL;
    if (ticks > 0xFFFFFFFFULL) ticks = 0xFFFFFFFFULL;
    return (uint32_t)ticks;
}

void PIT_IRQHandler(void)
{
    /* Channel 0 may be used by other apps; we only look at channel 1. */
    if ((PIT_GetStatusFlags(SIM_PIT_BASE, SIM_PIT_CH) & kPIT_TimerFlag) != 0U)
    {
        PIT_ClearStatusFlags(SIM_PIT_BASE, SIM_PIT_CH, kPIT_TimerFlag);
        s_tick = true;
    }
}

void ArincSim_Init(void)
{
    pit_config_t pitConfig;
    PIT_GetDefaultConfig(&pitConfig);
    PIT_Init(SIM_PIT_BASE, &pitConfig);

    PIT_SetTimerPeriod(SIM_PIT_BASE, SIM_PIT_CH, ms_to_ticks(SIM_TICK_MS));
    PIT_EnableInterrupts(SIM_PIT_BASE, SIM_PIT_CH, kPIT_TimerInterruptEnable);
    EnableIRQ(PIT_IRQn);
    PIT_StartTimer(SIM_PIT_BASE, SIM_PIT_CH);

    /* Simulated handshake: in a real setup this would be a UART exchange with the bridge. */
    PRINTF("RDC boot: sending HELLO to bridge...\r\n");
    PRINTF("HELLO <boot> <cause>\r\n");
    PRINTF("Assuming READY (simulation). Starting label schedule in 200ms.\r\n\r\n");

    SDK_DelayAtLeastUs(200000U, CLOCK_GetFreq(kCLOCK_CpuClk));
}

static void emit_label_frame(uint32_t seq)
{
    /* Simple framed format: TX:<LABEL>:<SDI>:<DATA>:<SCHED> */
    uint32_t label = 0x123U;
    uint32_t sdi = 0U;
    uint32_t data = (seq & 0xFFFFU);

    PRINTF("TX:%03lu:%lu:%04lu:%lums\r\n",
           (unsigned long)label, (unsigned long)sdi, (unsigned long)data, (unsigned long)SIM_TICK_MS);
}

void ArincSim_Run(void)
{
    PRINTF("RDC streaming (sim): one frame every %lu ms\r\n", (unsigned long)SIM_TICK_MS);
    while (1)
    {
        if (s_tick)
        {
            s_tick = false;
            emit_label_frame(s_seq++);
        }
        __WFI();
    }
}
