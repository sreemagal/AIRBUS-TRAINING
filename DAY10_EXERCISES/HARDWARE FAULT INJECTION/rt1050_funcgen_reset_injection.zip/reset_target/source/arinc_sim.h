#ifndef ARINC_SIM_H_
#define ARINC_SIM_H_

#ifdef __cplusplus
extern "C" {
#endif

void ArincSim_Init(void);
void ArincSim_Run(void);

#ifdef __cplusplus
}
#endif

#endif /* ARINC_SIM_H_ */
