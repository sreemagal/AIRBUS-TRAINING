/*
 * reset_target: firmware to validate reset injection.
 *
 * Prints SRC reset cause flags and boot counter, then runs a small "avionics-like" streaming loop.
 */

#include "board.h"
#include "fsl_common.h"
#include "fsl_debug_console.h"

#include "reset_diag.h"
#include "arinc_sim.h"

int main(void)
{
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();

    PRINTF("\r\n=== RT1050 Reset Target (Reset attribution + Avionics sim) ===\r\n");

    ResetDiag_RunEarly(); /* prints boot counter + reset cause and clears flags */

    ArincSim_Init();
    ArincSim_Run(); /* never returns */

    while (1)
    {
        __NOP();
    }
}
