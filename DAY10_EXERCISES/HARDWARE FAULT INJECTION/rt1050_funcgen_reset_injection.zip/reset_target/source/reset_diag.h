#ifndef RESET_DIAG_H_
#define RESET_DIAG_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Call early after clocks + debug console init. */
void ResetDiag_RunEarly(void);

#ifdef __cplusplus
}
#endif

#endif /* RESET_DIAG_H_ */
