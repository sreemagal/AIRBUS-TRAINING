# i.MX RT1050-EVKB “Function Generator” + Reset Fault-Injection Lab (MCUXpresso SDK 25.06.00)

This package contains **two firmware apps**:

1) **funcgen_injector** (Board A): a UART-controlled, safe **digital function generator / pulse generator**
   that drives an **open-drain** output pin. Intended use: generate controlled **active-low reset pulses**
   to inject resets into another i.MX RT1050 EVKB (“Target”) board.

2) **reset_target** (Board B): prints **SRC reset cause flags** and a **monotonic boot counter** (stored in SRC GPR)
   on every boot so you can verify that your injected pulses are being attributed as **external reset pin** events.

These apps are designed to be added to an **existing SDK example project** in MCUXpresso IDE.
They only add/replace files in the `source/` directory and do not modify NXP board support.

---

## Hardware wiring (2-board setup)

You have 4 boards; for the basic experiment you need **two**:

- **Board A** = Injector (runs `funcgen_injector`)
- **Board B** = Target (runs `reset_target`)

### Connections (SAFE DEFAULT)
1. Connect **GND(A) ↔ GND(B)** (any ground pins on the Arduino headers).
2. Connect **Board A output pin J24[4]** (SPI_MOSI / SD1_D0 / GPIO_SD_B0_02) **to**  
   **Board B Arduino RESET pin** (J25 “RESET”) **through a series resistor ≥ 10 kΩ**.

> Why series resistor? It limits current if you accidentally mis-wire or if the reset net is being driven/bounced.
> This follows the “safe lab pattern” in your fault-injection document.

Optional (recommended if you use the injector output standalone, not tied to reset):
- Add an **external pull-up 4.7 kΩ to 10 kΩ to 3.3 V** on the injector output, because we drive it as **open-drain**.

### IMPORTANT
- Inject into the **Reset** net (SW4 / external reset input), **NOT** the POR_B / power reset net (SW3).
- Never exceed **3.3 V** on any I/O, and never drive the reset net with a low-impedance source.

---

## What pin does the injector use?

**Injector output pin (Board A):**
- Header: **Arduino SPI header J24 pin 4** (labeled MOSI on Arduino)
- i.MX RT pad: **GPIO_SD_B0_02**  
- GPIO function: **GPIO3_IO14**  
- Electrical: configured as **open-drain output**.

This pin is also shared with SD-card signals on the EVKB. For this lab:
- Avoid using SD card features at the same time.
- Remove any SD card while doing reset-injection experiments.

---

## MCUXpresso IDE build instructions (quick path)

### Step 1 — Import two SDK example projects
Use your installed SDK: `SDK_25_06_00_EVKB-IMXRT1050`.

**Injector project base:**  
Import the SDK example: `boards/evkbimxrt1050/driver_examples/pit`  
(Any bare-metal example works; PIT is convenient because the clocks/IRQ are already validated.)

**Target project base:**  
Import the SDK example: `boards/evkbimxrt1050/demo_apps/hello_world` (or `new_project`)

In MCUXpresso IDE:
1. `File > Import... > MCUXpresso IDE > Import SDK example(s)`
2. Select the SDK location
3. Select the example and import it
4. Repeat for the second example

### Step 2 — Replace/add the provided source files
For each imported project:
- Copy the files from this package into the project’s `source/` folder
- If a file already exists (e.g., `main.c`), replace it.

**Injector project**: copy everything under `funcgen_injector/source/`  
**Target project**: copy everything under `reset_target/source/`

### Step 3 — Build and flash
- Build: `Project > Build Project`
- Flash/Debug: `Run > Debug` (DAP-Link CMSIS-DAP)

### Step 4 — Open UART terminals
Both boards use the standard EVKB debug console over OpenSDA VCOM:
- **115200, 8-N-1**
- Connect each board’s USB (OpenSDA) to your PC and open two terminals.

---

## Using the injector (commands)

Type `help` in the injector console.

Core commands:
- `set <period_us> <pulse_us>` : configure active-low pulse width within a period
- `start` : start continuous pulse train
- `stop` : stop output (releases line high)
- `burst <count>` : output <count> pulses and stop
- `oneshot <pulse_us>` : output exactly one pulse (blocking)
- `sweep <start_us> <end_us> <step_us> <period_us> <count_each>` : automated pulse-width sweep

Suggested reproduction of your lab method:
- Start with 0.2 Hz pulses (period = 5,000,000 us) and 10 ms low pulses:
  - `set 5000000 10000`
  - `burst 3`
- Then reduce the pulse width:
  - `sweep 10000 100  -100 5000000 1`  (example: 10 ms down to 100 us, 1 pulse each)

---

## Expected target output

On every reset, the target prints:
- boot counter (SRC GPR)
- SRC reset flags (including external reset pin)

When the injector pulses the target reset line you should see the external reset flag (IPP_USER_RESET_B)
and the boot counter increment.

---

## Files
- funcgen_injector/source/main.c
- funcgen_injector/source/funcgen_pit.c / funcgen_pit.h
- funcgen_injector/source/cli.c / cli.h
- reset_target/source/main.c
- reset_target/source/reset_diag.c / reset_diag.h
- reset_target/source/arinc_sim.c / arinc_sim.h

---

## License
Your NXP SDK governs the NXP-provided code. The files in this package are provided as-is for lab use.
