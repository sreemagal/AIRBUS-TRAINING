/*
 * Peripheral Register & Memory Inspection Lab (EVKB‑i.MXRT1050)
 * COMPLETE CODE-LEVEL SOLUTION
 *
 * Intended base project:
 *   SDK: boards/evkbimxrt1050/driver_examples/lpuart/interrupt_transfer
 *
 * Apply:
 *   1) Replace the example file:
 *        lpuart_interrupt_transfer.c
 *      with THIS file’s content.
 *   2) Keep the project’s existing:
 *        hardware_init.c  (calls BOARD_ConfigMPU/BootPins/BootClocks)
 *        pin_mux.c        (configures LPUART1 TX/RX pins + pads)
 *        clock_config.c
 *   3) Wire ADK‑8582 UART to EVKB LPUART1 pins (from the example pin mux):
 *        TXD: GPIO_AD_B0_12 (LPUART1_TXD)
 *        RXD: GPIO_AD_B0_13 (LPUART1_RXD)
 *        GND common
 *      UART: 115200-8-N-1
 *
 * What this solution provides for the lab stages:
 *   Stage 1: Register-ground-truth UART init and BAUD math readback (typed + MMIO)
 *   Stage 2: Pin mux + CCM clock gate readback snapshots (IOMUXC + CCGRx)
 *   Stage 3: Safe inspection helpers (no pop-on-read DATA reads in snapshots) + W1C clearing
 *   Stage 4: RX ring buffer with non-cacheable vs cacheable modes + cache clean controls
 *   Stage 5: “Avionics triage” counters and a computed fault-domain hint
 *   Stage 6: Watchpoint-friendly variables, sentinel/overflow tripwires
 *
 * IMPORTANT DEBUGGING NOTES (align with the doc’s cautions):
 *   - DO NOT read LPUARTx->DATA from the debugger while live traffic is running.
 *     DATA is pop-on-read; your inspection will consume FIFO bytes.
 *   - Status bits like OR/FE/NF are W1C (write-1-to-clear). Do not poke registers unless you
 *     understand the semantics; this code clears them safely after counting.
 *   - Cache coherency matters: in cacheable mode, the debugger’s Memory view can show stale RAM
 *     while new data sits only in D-cache. This lab demonstrates that and the remedy (clean).
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "board.h"
#include "app.h"

#include "fsl_common.h"
#include "fsl_common_arm.h"     // AT_NONCACHEABLE_SECTION* (toolchain-dependent)
#include "fsl_device_registers.h"
#include "fsl_lpuart.h"
#include "fsl_cache.h"          // DCACHE_*ByRange helpers

/*******************************************************************************
 * Lab configuration
 ******************************************************************************/
#define LAB_UART_BASE              (DEMO_LPUART)   // In the base example: LPUART1
#define LAB_UART_CLK_HZ            (DEMO_LPUART_CLK_FREQ)
#define LAB_UART_BAUD              (115200U)

// RX ring sizes
#define RX_RING_BYTES              (1024U)   // byte ring for “ground truth” capture
#define WORD_RING_WORDS            (128U)    // optional packed 32-bit words

// Build modes for Stage 4 cache/coherency demonstration
#define LAB_RUNMODE_NONCACHEABLE           (0)
#define LAB_RUNMODE_CACHEABLE_NO_MAINT     (1)
#define LAB_RUNMODE_CACHEABLE_CLEAN_ON_REQ (2)

#ifndef LAB_RUNMODE
// Default: the “trustworthy” mode recommended for inspection
#define LAB_RUNMODE LAB_RUNMODE_NONCACHEABLE
#endif

// Optional: pack incoming bytes into 32-bit words to inspect labels quickly.
// 0 = disabled, 1 = little-endian pack, 2 = big-endian pack (endianness confusion demo)
#ifndef ENABLE_WORD_PACKING
#define ENABLE_WORD_PACKING 1
#endif

/*******************************************************************************
 * Fixed addresses / offsets (for Memory view and direct MMIO checks)
 * (matches the doc’s “addresses you will actually use” section)
 ******************************************************************************/
#define REG32(addr) (*(volatile uint32_t *)(addr))

// LPUART1 base given in the doc (and in SDK headers)
#define LPUART1_BASE_ADDR          (0x40184000u)
#define LPUART_BAUD_OFFSET         (0x10u)
#define LPUART_STAT_OFFSET         (0x14u)
#define LPUART_CTRL_OFFSET         (0x18u)
#define LPUART_DATA_OFFSET         (0x1Cu)  // POP-ON-READ (do not inspect live)
#define LPUART_FIFO_OFFSET         (0x28u)
#define LPUART_WATER_OFFSET        (0x2Cu)

#define LPUART1_BAUD_ADDR          (LPUART1_BASE_ADDR + LPUART_BAUD_OFFSET)
#define LPUART1_STAT_ADDR          (LPUART1_BASE_ADDR + LPUART_STAT_OFFSET)
#define LPUART1_CTRL_ADDR          (LPUART1_BASE_ADDR + LPUART_CTRL_OFFSET)
#define LPUART1_FIFO_ADDR          (LPUART1_BASE_ADDR + LPUART_FIFO_OFFSET)
#define LPUART1_WATER_ADDR         (LPUART1_BASE_ADDR + LPUART_WATER_OFFSET)

/*******************************************************************************
 * Stage 4: RX ring buffer storage (non-cacheable vs cacheable)
 ******************************************************************************/
#if (LAB_RUNMODE == LAB_RUNMODE_NONCACHEABLE)
AT_NONCACHEABLE_SECTION_ALIGN(static uint8_t g_rxRing[RX_RING_BYTES], 32);
#else
static uint8_t g_rxRing[RX_RING_BYTES];
#endif

// Ring control variables (watchpoint-friendly)
volatile uint32_t g_rxHead = 0U;
volatile uint32_t g_rxTail = 0U;
volatile uint32_t g_rxHighWater = 0U;
volatile uint32_t g_rxOverflowCount = 0U;

// Sentinel after the ring (set a watchpoint here for overflow/corruption)
volatile uint32_t g_rxSentinel = 0xDEADBEEFu;

/*******************************************************************************
 * Optional: packed word ring for ARINC label inspection
 ******************************************************************************/
typedef struct
{
    uint32_t buf[WORD_RING_WORDS];
    volatile uint32_t head;
    volatile uint32_t tail;
    volatile uint32_t count;
    volatile uint32_t overflow;
} word_ring_t;

static word_ring_t g_wordRing;
volatile uint32_t g_lastWord = 0U;
volatile uint8_t  g_lastLabel = 0U;   // low byte of packed word
volatile uint32_t g_wordCount = 0U;

static inline void WordRing_Init(word_ring_t *r)
{
    for (uint32_t i = 0; i < WORD_RING_WORDS; i++) r->buf[i] = 0U;
    r->head = r->tail = r->count = r->overflow = 0U;
}

static inline void WordRing_Push(word_ring_t *r, uint32_t w)
{
    if (r->count >= WORD_RING_WORDS)
    {
        r->overflow++;
        return;
    }
    r->buf[r->head] = w;
    r->head = (r->head + 1U) % WORD_RING_WORDS;
    r->count++;
}

/*******************************************************************************
 * Stage 5: UART health counters (inspect instead of printf)
 ******************************************************************************/
volatile uint32_t g_rxByteCount = 0U;
volatile uint32_t g_statOrCount = 0U;  // overrun
volatile uint32_t g_statFeCount = 0U;  // framing
volatile uint32_t g_statNfCount = 0U;  // noise
volatile uint32_t g_statPfCount = 0U;  // parity

// Latest “snapshot-time” FIFO counts (for inspection)
volatile uint8_t g_rxFifoCount = 0U;
volatile uint8_t g_txFifoCount = 0U;

/*******************************************************************************
 * Stage 1: BAUD field decode + recomputed baud
 ******************************************************************************/
typedef struct
{
    uint32_t srcClockHz;

    uint32_t baud_reg_typed;
    uint32_t stat_reg_typed;
    uint32_t ctrl_reg_typed;
    uint32_t fifo_reg_typed;
    uint32_t water_reg_typed;

    uint32_t baud_reg_mmio;
    uint32_t stat_reg_mmio;
    uint32_t ctrl_reg_mmio;
    uint32_t fifo_reg_mmio;
    uint32_t water_reg_mmio;

    // Decoded BAUD fields
    uint32_t osr;
    uint32_t sbr;
    uint32_t bothEdge;

    // Calculated actual baud (integer math)
    uint32_t calcBaud;

    // Pin mux / pad readback for LPUART1 pins
    uint32_t mux_tx;
    uint32_t mux_rx;
    uint32_t pad_tx;
    uint32_t pad_rx;

    // CCM clock gate snapshot
    uint32_t ccgr[7];

    // GPIO LED sanity snapshot (GPIO1 pin 9 from board.h macros)
    uint32_t gpio1_gdir;
    uint32_t gpio1_dr;
    uint32_t gpio1_psr;

    // Ring state snapshot
    uint32_t rxHead;
    uint32_t rxTail;
    uint32_t rxDepth;
    uint32_t rxHighWater;
    uint32_t rxOverflow;
    uint32_t rxSentinel;

    // Triage hint (Stage 5)
    uint32_t triage_hint;

    // Marker for “snapshot complete”
    uint32_t snapshot_seq;
} lab_snapshot_t;

// Put snapshot in normal RAM; it’s read-only by debugger.
static volatile lab_snapshot_t g_snap;

// Debugger-controlled triggers
volatile uint32_t g_snapshot_request = 0U;     // set to 1 in debugger to capture snapshot
volatile uint32_t g_clear_counters_request = 0U; // set to 1 to clear counters/rings
volatile uint32_t g_clean_ring_on_snapshot = 0U; // cacheable mode: set 1 to DCACHE_CleanByRange on snapshot

/*******************************************************************************
 * Helpers
 ******************************************************************************/
static inline uint32_t Ring_Depth(uint32_t head, uint32_t tail)
{
    if (head >= tail) return (head - tail);
    return (RX_RING_BYTES - (tail - head));
}

static inline void Ring_PushByte(uint8_t b)
{
    uint32_t next = (g_rxHead + 1U) % RX_RING_BYTES;
    if (next == g_rxTail)
    {
        g_rxOverflowCount++;
        return;
    }

    g_rxRing[g_rxHead] = b;
    g_rxHead = next;

    uint32_t depth = Ring_Depth(g_rxHead, g_rxTail);
    if (depth > g_rxHighWater) g_rxHighWater = depth;
}

static inline void Ring_Clear(void)
{
    // Don’t memset in cacheable/no-maint mode: it will fill cache and make the “stale RAM” effect harder to see.
    // For a clean start between trials, clearing is still useful.
    for (uint32_t i = 0; i < RX_RING_BYTES; i++) g_rxRing[i] = 0U;
    g_rxHead = g_rxTail = g_rxHighWater = g_rxOverflowCount = 0U;
    g_rxSentinel = 0xDEADBEEFu;
}

static inline void Counters_Clear(void)
{
    g_rxByteCount = 0U;
    g_statOrCount = 0U;
    g_statFeCount = 0U;
    g_statNfCount = 0U;
    g_statPfCount = 0U;
    g_rxFifoCount = 0U;
    g_txFifoCount = 0U;
    g_lastWord = 0U;
    g_lastLabel = 0U;
    g_wordCount = 0U;
    WordRing_Init(&g_wordRing);
}

static inline void DecodeBaud(uint32_t baudReg, uint32_t *osr, uint32_t *sbr, uint32_t *bothEdge)
{
    // These masks come from PERI_LPUART.h via fsl_device_registers.h
    *osr = (baudReg & LPUART_BAUD_OSR_MASK) >> LPUART_BAUD_OSR_SHIFT;
    *sbr = (baudReg & LPUART_BAUD_SBR_MASK) >> LPUART_BAUD_SBR_SHIFT;
    *bothEdge = (baudReg & LPUART_BAUD_BOTHEDGE_MASK) ? 1U : 0U;
}

static inline uint32_t ComputeBaud(uint32_t srcClockHz, uint32_t osr, uint32_t sbr)
{
    // Common LPUART baud approximation: baud = srcClock / ((OSR+1) * SBR)
    // (This is what the lab asks you to recompute and compare.)
    uint32_t denom = (osr + 1U) * (sbr == 0U ? 1U : sbr);
    return (denom != 0U) ? (srcClockHz / denom) : 0U;
}

/*******************************************************************************
 * Stage 2: Pin mux + pad and CCM readback
 ******************************************************************************/
#include "fsl_iomuxc.h"
#include "PERI_IOMUXC.h"   // for kIOMUXC_* indices
#include "PERI_CCM.h"     // CCM register layout

static inline void Readback_IOMUXC_LPUART1(void)
{
    // LPUART1 pins used by this example are GPIO_AD_B0_12 (TXD) and GPIO_AD_B0_13 (RXD)
    g_snap.mux_tx = IOMUXC->SW_MUX_CTL_PAD[kIOMUXC_SW_MUX_CTL_PAD_GPIO_AD_B0_12];
    g_snap.mux_rx = IOMUXC->SW_MUX_CTL_PAD[kIOMUXC_SW_MUX_CTL_PAD_GPIO_AD_B0_13];

    g_snap.pad_tx = IOMUXC->SW_PAD_CTL_PAD[kIOMUXC_SW_PAD_CTL_PAD_GPIO_AD_B0_12];
    g_snap.pad_rx = IOMUXC->SW_PAD_CTL_PAD[kIOMUXC_SW_PAD_CTL_PAD_GPIO_AD_B0_13];
}

static inline void Snapshot_CCM_CCGRs(void)
{
    g_snap.ccgr[0] = CCM->CCGR0;
    g_snap.ccgr[1] = CCM->CCGR1;
    g_snap.ccgr[2] = CCM->CCGR2;
    g_snap.ccgr[3] = CCM->CCGR3;
    g_snap.ccgr[4] = CCM->CCGR4;
    g_snap.ccgr[5] = CCM->CCGR5;
    g_snap.ccgr[6] = CCM->CCGR6;
}

static inline void Snapshot_GPIO1_LED(void)
{
    // Board LED macro uses GPIO1 pin 9
    g_snap.gpio1_gdir = GPIO1->GDIR;
    g_snap.gpio1_dr   = GPIO1->DR;
    g_snap.gpio1_psr  = GPIO1->PSR;
}

/*******************************************************************************
 * Stage 3: “Safe snapshot” (avoid pop-on-read DATA)
 ******************************************************************************/
static void Snapshot_LPUART1_Safe(void)
{
    // Typed access
    g_snap.baud_reg_typed  = LAB_UART_BASE->BAUD;
    g_snap.stat_reg_typed  = LAB_UART_BASE->STAT;
    g_snap.ctrl_reg_typed  = LAB_UART_BASE->CTRL;
    g_snap.fifo_reg_typed  = LAB_UART_BASE->FIFO;
    g_snap.water_reg_typed = LAB_UART_BASE->WATER;

    // Direct MMIO (ground-truth cross-check)
    g_snap.baud_reg_mmio  = REG32(LPUART1_BAUD_ADDR);
    g_snap.stat_reg_mmio  = REG32(LPUART1_STAT_ADDR);
    g_snap.ctrl_reg_mmio  = REG32(LPUART1_CTRL_ADDR);
    g_snap.fifo_reg_mmio  = REG32(LPUART1_FIFO_ADDR);
    g_snap.water_reg_mmio = REG32(LPUART1_WATER_ADDR);

    DecodeBaud(g_snap.baud_reg_typed, &g_snap.osr, &g_snap.sbr, &g_snap.bothEdge);
    g_snap.calcBaud = ComputeBaud(g_snap.srcClockHz, g_snap.osr, g_snap.sbr);

    // FIFO counts (safe; reads WATER)
    g_rxFifoCount = LPUART_GetRxFifoCount(LAB_UART_BASE);
    g_txFifoCount = LPUART_GetTxFifoCount(LAB_UART_BASE);

    // Capture into snapshot too
    g_snap.rxHead = g_rxHead;
    g_snap.rxTail = g_rxTail;
    g_snap.rxDepth = Ring_Depth(g_rxHead, g_rxTail);
    g_snap.rxHighWater = g_rxHighWater;
    g_snap.rxOverflow = g_rxOverflowCount;
    g_snap.rxSentinel = g_rxSentinel;

    __DSB(); // ensure reads complete before return (matches the doc’s recommendation)
}

/*******************************************************************************
 * Stage 5: Triage hint computation (you still make the final call)
 ******************************************************************************/
enum
{
    TRIAGE_UNKNOWN = 0,
    TRIAGE_CONFIG_CLOCK_OR_BAUD = 1,
    TRIAGE_FIRMWARE_LATENCY_OR_BUFFER = 2,
    TRIAGE_SIGNAL_INTEGRITY_OR_FRAMING = 3,
    TRIAGE_CACHE_COHERENCY_SUSPECT = 4,
};

static uint32_t ComputeTriageHint(void)
{
    // Heuristic only. You confirm with register/memory evidence.
    const uint32_t depth = Ring_Depth(g_rxHead, g_rxTail);

    // 1) If UART overrun occurs, likely ISR latency/ring too small.
    if (g_statOrCount > 0U)
    {
        // If depth stays high, it’s likely buffering/latency.
        if (depth > (RX_RING_BYTES * 3U / 4U)) return TRIAGE_FIRMWARE_LATENCY_OR_BUFFER;
        return TRIAGE_FIRMWARE_LATENCY_OR_BUFFER;
    }

    // 2) Framing/noise errors suggest wiring/baud mismatch/signal integrity.
    if ((g_statFeCount > 0U) || (g_statNfCount > 0U))
        return TRIAGE_SIGNAL_INTEGRITY_OR_FRAMING;

    // 3) If computed baud wildly differs from requested, suspect clock tree/config.
    if (g_snap.calcBaud != 0U)
    {
        // Tolerate ~2% error.
        uint32_t diff = (g_snap.calcBaud > LAB_UART_BAUD) ? (g_snap.calcBaud - LAB_UART_BAUD) : (LAB_UART_BAUD - g_snap.calcBaud);
        if (diff > (LAB_UART_BAUD / 50U))
            return TRIAGE_CONFIG_CLOCK_OR_BAUD;
    }

#if (LAB_RUNMODE == LAB_RUNMODE_CACHEABLE_NO_MAINT)
    // Cacheable/no-maint is intentionally "untrustworthy" for Memory view.
    // If user reports “ring looks frozen in memory view” but counts rise, it’s cache.
    return TRIAGE_CACHE_COHERENCY_SUSPECT;
#endif

    return TRIAGE_UNKNOWN;
}

/*******************************************************************************
 * UART init and ISR
 ******************************************************************************/
void LPUART1_IRQHandler(void)
{
    uint32_t status = LPUART_GetStatusFlags(LAB_UART_BASE);

    // Error flags (W1C)
    if (status & kLPUART_RxOverrunFlag)
    {
        g_statOrCount++;
        (void)LPUART_ClearStatusFlags(LAB_UART_BASE, kLPUART_RxOverrunFlag);
    }
    if (status & kLPUART_FramingErrorFlag)
    {
        g_statFeCount++;
        (void)LPUART_ClearStatusFlags(LAB_UART_BASE, kLPUART_FramingErrorFlag);
    }
    if (status & kLPUART_NoiseErrorFlag)
    {
        g_statNfCount++;
        (void)LPUART_ClearStatusFlags(LAB_UART_BASE, kLPUART_NoiseErrorFlag);
    }
    if (status & kLPUART_ParityErrorFlag)
    {
        g_statPfCount++;
        (void)LPUART_ClearStatusFlags(LAB_UART_BASE, kLPUART_ParityErrorFlag);
    }

    // RX data ready
    if (status & kLPUART_RxDataRegFullFlag)
    {
        // DATA is pop-on-read. This is correct in ISR.
        uint8_t b = LPUART_ReadByte(LAB_UART_BASE);
        g_rxByteCount++;
        Ring_PushByte(b);

#if ENABLE_WORD_PACKING
        // Pack bytes into 32-bit words so you can inspect labels (low byte) quickly.
        static uint8_t pack[4];
        static uint8_t idx = 0;

        pack[idx++] = b;
        if (idx == 4U)
        {
            idx = 0U;
            uint32_t w;
#if (ENABLE_WORD_PACKING == 1)
            // little-endian: pack[0] is LSB
            w = ((uint32_t)pack[0]) | ((uint32_t)pack[1] << 8) | ((uint32_t)pack[2] << 16) | ((uint32_t)pack[3] << 24);
#elif (ENABLE_WORD_PACKING == 2)
            // big-endian: pack[0] is MSB
            w = ((uint32_t)pack[3]) | ((uint32_t)pack[2] << 8) | ((uint32_t)pack[1] << 16) | ((uint32_t)pack[0] << 24);
#else
            w = 0U;
#endif
            g_lastWord = w;
            g_lastLabel = (uint8_t)(w & 0xFFu);
            g_wordCount++;
            WordRing_Push(&g_wordRing, w);
        }
#endif
    }

    SDK_ISR_EXIT_BARRIER;
}

static void UART_Init_115200(void)
{
    lpuart_config_t cfg;
    LPUART_GetDefaultConfig(&cfg);

    cfg.baudRate_Bps = LAB_UART_BAUD;
    cfg.parityMode = kLPUART_ParityDisabled;
    cfg.stopBitCount = kLPUART_OneStopBit;
    cfg.enableTx = true;
    cfg.enableRx = true;

    // Stage 1: After this init, you will halt and inspect BAUD/CTRL/STAT/FIFO/WATER.
    (void)LPUART_Init(LAB_UART_BASE, &cfg, LAB_UART_CLK_HZ);

    // Enable FIFO (optional but recommended for stress tests)
    LAB_UART_BASE->FIFO |= (LPUART_FIFO_RXFE_MASK | LPUART_FIFO_TXFE_MASK);
    LPUART_SetRxFifoWatermark(LAB_UART_BASE, 1U);

    // Enable interrupts for RX + errors
    LPUART_EnableInterrupts(LAB_UART_BASE,
                            (uint32_t)kLPUART_RxDataRegFullInterruptEnable |
                            (uint32_t)kLPUART_RxOverrunInterruptEnable |
                            (uint32_t)kLPUART_FramingErrorInterruptEnable |
                            (uint32_t)kLPUART_NoiseErrorInterruptEnable |
                            (uint32_t)kLPUART_ParityErrorInterruptEnable);

    NVIC_SetPriority(LPUART1_IRQn, 3U);
    EnableIRQ(LPUART1_IRQn);
}

/*******************************************************************************
 * Stage 1/2/3/4 “pause points” via snapshot requests
 ******************************************************************************/
static void Snapshot_All(void)
{
#if (LAB_RUNMODE == LAB_RUNMODE_CACHEABLE_CLEAN_ON_REQ)
    if (g_clean_ring_on_snapshot)
    {
        // Make RAM reflect CPU-written cache lines for debugger Memory view.
        DCACHE_CleanByRange((uint32_t)g_rxRing, RX_RING_BYTES);
    }
#endif

    g_snap.srcClockHz = LAB_UART_CLK_HZ;

    Readback_IOMUXC_LPUART1();
    Snapshot_CCM_CCGRs();
    Snapshot_GPIO1_LED();
    Snapshot_LPUART1_Safe();

    g_snap.triage_hint = ComputeTriageHint();
    g_snap.snapshot_seq++;
}

static void Service_Requests(void)
{
    if (g_clear_counters_request)
    {
        __disable_irq();
        g_clear_counters_request = 0U;
        Ring_Clear();
        Counters_Clear();
        __enable_irq();
    }

    if (g_snapshot_request)
    {
        __disable_irq();
        g_snapshot_request = 0U;
        Snapshot_All();
        __enable_irq();
    }
}

/*******************************************************************************
 * Stage 1 support: LED sanity
 ******************************************************************************/
static void LED_Init(void)
{
    USER_LED_INIT(1);
    USER_LED_OFF();
}

static void LED_Heartbeat(void)
{
    static uint32_t t = 0U;
    t++;
    if ((t % 300000U) == 0U)
    {
        USER_LED_TOGGLE();
    }
}

/*******************************************************************************
 * MAIN
 ******************************************************************************/
int main(void)
{
    BOARD_InitHardware();

    LED_Init();
    WordRing_Init(&g_wordRing);

    // Recommended: start clean
    Ring_Clear();
    Counters_Clear();

    UART_Init_115200();

    // Stage 1 breakpoint location (optional):
    // Set a breakpoint on the next line to inspect BAUD/CTRL/STAT/FIFO/WATER immediately after init.
    Snapshot_All();

    // ====== MAIN LOOP ======
    while (1)
    {
        // Keep a visible heartbeat (doesn't affect UART semantics)
        LED_Heartbeat();

        // Stage 4/5/6: user triggers snapshots and clears via debugger variables:
        //   - set g_snapshot_request = 1 to capture all relevant registers into g_snap
        //   - set g_clear_counters_request = 1 to restart the experiment
        //   - in CACHEABLE_CLEAN_ON_REQ mode, set g_clean_ring_on_snapshot = 1 to force cache clean
        Service_Requests();

        // Tripwire: sentinel corruption indicates memory overwrite (set watchpoint on g_rxSentinel)
        if (g_rxSentinel != 0xDEADBEEFu)
        {
            __BKPT(0); // halt for investigation
            g_rxSentinel = 0xDEADBEEFu; // recover so it can trip again
        }

        __NOP();
    }
}

/*
 * ========= How to use this solution to complete the lab =========
 *
 * Stage 1 (UART config ground truth):
 *   - Halt at Snapshot_All() right after UART_Init_115200().
 *   - Inspect:
 *       g_snap.baud_reg_typed / stat_reg_typed / ctrl_reg_typed / fifo_reg_typed / water_reg_typed
 *       g_snap.baud_reg_mmio  / ... (cross-check typed vs MMIO)
 *       g_snap.osr, g_snap.sbr, g_snap.calcBaud
 *   - In GDB memory view, dump:
 *       x/8wx 0x40184010   (BAUD onward)
 *
 * Stage 2 (IOMUXC + clock gate):
 *   - Inspect:
 *       g_snap.mux_tx, g_snap.mux_rx, g_snap.pad_tx, g_snap.pad_rx
 *       g_snap.ccgr[0..6]
 *
 * Stage 3 (pop-on-read + W1C):
 *   - Confirm this code NEVER reads LAB_UART_BASE->DATA outside ISR.
 *   - Confirm W1C flags are cleared using LPUART_ClearStatusFlags after counting.
 *
 * Stage 4 (buffer visibility / cache effects):
 *   - Build 3 times (set LAB_RUNMODE):
 *       0: NONCACHEABLE (trustworthy Memory view)
 *       1: CACHEABLE_NO_MAINT (Memory view may look frozen while counters rise)
 *       2: CACHEABLE_CLEAN_ON_REQ (set g_clean_ring_on_snapshot=1 to force RAM update)
 *   - Use Memory view on &g_rxRing[0], and Expressions on g_rxHead/g_rxTail.
 *
 * Stage 5 (triage):
 *   - Inspect counters:
 *       g_statOrCount, g_statFeCount, g_statNfCount, g_rxOverflowCount, g_rxHighWater
 *   - Inspect LPUART STAT/FIFO/WATER via g_snap.
 *   - Use g_snap.triage_hint as a starting point, then justify with evidence.
 *
 * Stage 6 (watchpoints):
 *   - Set watchpoints on:
 *       g_rxHead, g_rxOverflowCount, g_rxSentinel
 *   - Stress with ADK-8582 stream and halt on events.
 */
