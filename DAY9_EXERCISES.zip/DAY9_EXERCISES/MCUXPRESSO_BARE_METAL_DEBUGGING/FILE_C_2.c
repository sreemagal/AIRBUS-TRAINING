#include "fsl_iomuxc.h"

// Add these inside BOARD_InitBootPins() with the rest of the mux calls:
IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_06_LPUART3_TXD, 0U);
IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_07_LPUART3_RXD, 0U);

// Optional pad config (recommended for RX pull-up):
IOMUXC_SetPinConfig(IOMUXC_GPIO_AD_B1_06_LPUART3_TXD,
                    IOMUXC_SW_PAD_CTL_PAD_SRE(0U) |
                    IOMUXC_SW_PAD_CTL_PAD_DSE(6U) |
                    IOMUXC_SW_PAD_CTL_PAD_SPEED(2U) |
                    IOMUXC_SW_PAD_CTL_PAD_ODE(0U) |
                    IOMUXC_SW_PAD_CTL_PAD_PKE(1U) |
                    IOMUXC_SW_PAD_CTL_PAD_PUE(0U) |
                    IOMUXC_SW_PAD_CTL_PAD_PUS(0U) |
                    IOMUXC_SW_PAD_CTL_PAD_HYS(0U));

IOMUXC_SetPinConfig(IOMUXC_GPIO_AD_B1_07_LPUART3_RXD,
                    IOMUXC_SW_PAD_CTL_PAD_SRE(0U) |
                    IOMUXC_SW_PAD_CTL_PAD_DSE(6U) |
                    IOMUXC_SW_PAD_CTL_PAD_SPEED(2U) |
                    IOMUXC_SW_PAD_CTL_PAD_ODE(0U) |
                    IOMUXC_SW_PAD_CTL_PAD_PKE(1U) |
                    IOMUXC_SW_PAD_CTL_PAD_PUE(1U) |
                    IOMUXC_SW_PAD_CTL_PAD_PUS(2U) |   // pull-up
                    IOMUXC_SW_PAD_CTL_PAD_HYS(0U));