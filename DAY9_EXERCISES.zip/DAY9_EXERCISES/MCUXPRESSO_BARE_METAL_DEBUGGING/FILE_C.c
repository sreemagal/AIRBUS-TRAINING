#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#include "board.h"
#include "app.h"

#include "fsl_lpuart.h"
#include "fsl_debug_console.h"
#include "fsl_common.h"

//------------------------------------------------------------------------------
// Stage controls
//------------------------------------------------------------------------------
#define ENABLE_STAGE3_WATCHPOINT_DEMO   (1)   // required by Stage 3
#define ENABLE_STAGE4_DWT_TIMING        (1)   // required by Stage 4

// Optional extension A: enable a deliberate fault + SCB capture
#define ENABLE_EXTENSION_FAULT_DEMO     (0)

// Data stream format: ASCII hex line: "XXXXXXXX\r\n"
#define ASCII_WORD_CHARS (8U)

//------------------------------------------------------------------------------
// SWO Debug Console init (copied from hello_world_swo/hardware_init.c)
//------------------------------------------------------------------------------
#include "fsl_clock.h"

static void BOARD_InitDebugConsoleSWO(uint32_t port, uint32_t baudrate)
{
    SystemCoreClockUpdate();
    CLOCK_EnableClock(kCLOCK_Trace);

    // RT1050 ETB FFCR initialization for non-debug mode SWO output
#define ETB_FFCR (*(volatile unsigned int *)0xE0040304)
    ETB_FFCR = 0x100;

    uint32_t clkSrcFreq = CLOCK_GetClockRootFreq(kCLOCK_TraceClkRoot);
    (void)DbgConsole_Init((uint8_t)port, baudrate, kSerialPort_Swo, clkSrcFreq);
}

//------------------------------------------------------------------------------
// DWT cycle counter (Stage 4)
//------------------------------------------------------------------------------
#if ENABLE_STAGE4_DWT_TIMING
static inline void DWT_EnableCycleCounter(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0U;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}
static inline uint32_t DWT_Cycles(void) { return DWT->CYCCNT; }

typedef struct {
    uint32_t min, max;
    uint64_t sum;
    uint32_t count;
} stats32_t;

static inline void Stats_Reset(stats32_t *s)
{
    s->min = 0xFFFFFFFFu; s->max = 0u; s->sum = 0u; s->count = 0u;
}
static inline void Stats_Add(stats32_t *s, uint32_t v)
{
    if (v < s->min) s->min = v;
    if (v > s->max) s->max = v;
    s->sum += v;
    s->count++;
}
#endif

//------------------------------------------------------------------------------
// ARINC-like decode structure (Stage 3)
//------------------------------------------------------------------------------
typedef struct
{
    uint32_t raw;
    uint8_t label;
    uint8_t sdi;
    uint32_t data;
    uint8_t ssm;
    bool parity_bit;
    bool odd_parity_ok;
} arinc_word_t;

volatile uint8_t g_lastLabel = 0U;      // Set watchpoint here (write)
volatile arinc_word_t g_lastRx;         // Inspect in Expressions view

static volatile uint32_t g_wordsDecoded = 0U;
static volatile uint32_t g_badLines = 0U;
static volatile uint32_t g_parseErrors = 0U;

#if ENABLE_STAGE4_DWT_TIMING
static volatile uint32_t g_isrEntryCycles = 0U; // ISR-to-store latency anchor
static stats32_t g_parseCycles;
static stats32_t g_isrToStoreCycles;
#endif

//------------------------------------------------------------------------------
// LPUART transfer plumbing
//------------------------------------------------------------------------------
static lpuart_handle_t g_lpuartHandle;
static uint8_t g_rxByte;
static lpuart_transfer_t g_rxXfer;
static volatile bool g_rxArmed = false;

// ASCII line accumulator
static char g_line[ASCII_WORD_CHARS + 3]; // allow CR/LF + NUL
static uint32_t g_lineLen = 0U;

static int HexNibble(char c)
{
    if (c >= '0' && c <= '9') return (c - '0');
    if (c >= 'A' && c <= 'F') return (10 + (c - 'A'));
    if (c >= 'a' && c <= 'f') return (10 + (c - 'a'));
    return -1;
}

static bool ParseHex32(const char *s, uint32_t *out)
{
    uint32_t v = 0U;
    for (uint32_t i = 0; i < ASCII_WORD_CHARS; i++)
    {
        int n = HexNibble(s[i]);
        if (n < 0) return false;
        v = (v << 4) | (uint32_t)n;
    }
    *out = v;
    return true;
}

static bool OddParity32(uint32_t w)
{
    // returns true when odd number of 1 bits
    w ^= w >> 16;
    w ^= w >> 8;
    w ^= w >> 4;
    w &= 0xFu;
    return ((0x6996u >> w) & 1u) != 0u;
}

static void DecodeArinc(uint32_t raw, arinc_word_t *o)
{
    // Generic ARINC-style extraction (common convention):
    //  - label: bits 0..7
    //  - SDI: bits 8..9
    //  - data: bits 10..28 (19 bits)
    //  - SSM: bits 29..30
    //  - parity: bit 31
    o->raw = raw;
    o->label = (uint8_t)(raw & 0xFFu);
    o->sdi = (uint8_t)((raw >> 8) & 0x3u);
    o->data = (raw >> 10) & 0x7FFFFu;
    o->ssm = (uint8_t)((raw >> 29) & 0x3u);
    o->parity_bit = ((raw >> 31) & 0x1u) != 0u;
    o->odd_parity_ok = OddParity32(raw);
}

static void ProcessCompletedLine(void)
{
#if ENABLE_STAGE4_DWT_TIMING
    uint32_t t0 = DWT_Cycles();
#endif

    // Expect exactly 8 hex chars
    if (g_lineLen < ASCII_WORD_CHARS)
    {
        g_badLines++;
        g_lineLen = 0U;
        return;
    }

    uint32_t raw;
    if (!ParseHex32(g_line, &raw))
    {
        g_parseErrors++;
        g_lineLen = 0U;
        return;
    }

    arinc_word_t decoded;
    DecodeArinc(raw, &decoded);

    // Update the volatile probe variables (watchpoint on g_lastLabel)
    g_lastRx = decoded;
    g_lastLabel = decoded.label;
    g_wordsDecoded++;

#if ENABLE_STAGE4_DWT_TIMING
    uint32_t t1 = DWT_Cycles();
    Stats_Add(&g_parseCycles, (uint32_t)(t1 - t0));
    Stats_Add(&g_isrToStoreCycles, (uint32_t)(t1 - g_isrEntryCycles));
#endif

    g_lineLen = 0U;
}

static void ConsumeByte(uint8_t b)
{
    // Ignore CR, treat LF as end of word line
    if (b == '\r')
        return;

    if (b == '\n')
    {
        // terminate for safety
        if (g_lineLen < sizeof(g_line)) g_line[g_lineLen] = '\0';
        ProcessCompletedLine();
        return;
    }

    // Accept only up to 8 hex chars; if too many, count as bad line and reset
    if (g_lineLen >= ASCII_WORD_CHARS)
    {
        g_badLines++;
        g_lineLen = 0U;
        return;
    }

    g_line[g_lineLen++] = (char)b;
}

// LPUART callback (called when the 1-byte nonblocking receive completes)
static void LPUART_UserCallback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    (void)base; (void)handle; (void)userData;

    if (status == kStatus_LPUART_RxIdle)
    {
        ConsumeByte(g_rxByte);
        g_rxArmed = false;
    }
    else
    {
        // Any error status is visible via debugger; keep counts
        g_parseErrors++;
        g_rxArmed = false;
    }
}

void LPUART3_IRQHandler(void)
{
#if ENABLE_STAGE4_DWT_TIMING
    g_isrEntryCycles = DWT_Cycles();
#endif
    LPUART_TransferHandleIRQ(DEMO_LPUART, &g_lpuartHandle);
    SDK_ISR_EXIT_BARRIER;
}

static void StartRxOneByte(void)
{
    g_rxXfer.data = &g_rxByte;
    g_rxXfer.dataSize = 1U;

    size_t rxCount = 0U;
    (void)LPUART_TransferReceiveNonBlocking(DEMO_LPUART, &g_lpuartHandle, &g_rxXfer, &rxCount);
    g_rxArmed = true;
}

//------------------------------------------------------------------------------
// Optional extension: deliberate fault + SCB inspection
//------------------------------------------------------------------------------
#if ENABLE_EXTENSION_FAULT_DEMO
static void DeliberateFault(void)
{
    // Example: write to invalid address
    volatile uint32_t *p = (uint32_t *)0x00000001u;
    *p = 0x12345678u;
}
#endif

int main(void)
{
    BOARD_InitHardware();

    // Use SWO for low-intrusion logs (Stage 4 requirement)
    BOARD_InitDebugConsoleSWO(DEMO_DEBUG_CONSOLE_SWO_PORT, DEMO_DEBUG_CONSOLE_SWO_BAUDRATE);

#if ENABLE_STAGE4_DWT_TIMING
    DWT_EnableCycleCounter();
    Stats_Reset(&g_parseCycles);
    Stats_Reset(&g_isrToStoreCycles);
#endif

    // Init LPUART3 @ 115200
    lpuart_config_t config;
    LPUART_GetDefaultConfig(&config);
    config.baudRate_Bps = 115200U;
    config.enableTx = true;
    config.enableRx = true;

    LPUART_Init(DEMO_LPUART, &config, DEMO_LPUART_CLK_FREQ);

    LPUART_TransferCreateHandle(DEMO_LPUART, &g_lpuartHandle, LPUART_UserCallback, NULL);

    // Enable the LPUART3 IRQ
    NVIC_SetPriority(LPUART3_IRQn, 3U);
    EnableIRQ(LPUART3_IRQn);

    PRINTF("SWO: stage3_4_start\r\n");
    PRINTF("SWO: data_uart=LPUART3 baud=115200 format=XXXXXXXX\\r\\n\r\n");
    PRINTF("SWO: stage3_watchpoint: set watchpoint on g_lastLabel (write)\r\n");
    PRINTF("SWO: target label 203(octal) == 0x83 low byte\r\n");

#if ENABLE_EXTENSION_FAULT_DEMO
    PRINTF("SWO: extension fault demo enabled\r\n");
#endif

    // Arm initial RX
    StartRxOneByte();

    while (1)
    {
        // Keep RX armed continuously
        if (!g_rxArmed)
        {
            StartRxOneByte();
        }

        // Stage 3: in the debugger, watchpoint breaks whenever g_lastLabel changes.
        // Specifically, when label 203(octal)/0x83 arrives, execution will break with g_lastLabel==0x83.

#if ENABLE_STAGE4_DWT_TIMING
        // Print timing stats every 1000 decoded words (via SWO, not UART)
        if ((g_wordsDecoded != 0U) && ((g_wordsDecoded % 1000U) == 0U))
        {
            uint32_t parseAvg = (g_parseCycles.count != 0U) ? (uint32_t)(g_parseCycles.sum / g_parseCycles.count) : 0U;
            uint32_t latAvg   = (g_isrToStoreCycles.count != 0U) ? (uint32_t)(g_isrToStoreCycles.sum / g_isrToStoreCycles.count) : 0U;

            // Convert cycles to microseconds using SystemCoreClock
            uint32_t coreHz = SystemCoreClock;
            uint32_t parseMaxUs = (coreHz != 0U) ? (uint32_t)((uint64_t)g_parseCycles.max * 1000000ULL / coreHz) : 0U;
            uint32_t latMaxUs   = (coreHz != 0U) ? (uint32_t)((uint64_t)g_isrToStoreCycles.max * 1000000ULL / coreHz) : 0U;

            PRINTF("SWO: words=%u badLines=%u parseErr=%u\r\n", g_wordsDecoded, g_badLines, g_parseErrors);
            PRINTF("SWO: parseCycles min=%u avg=%u max=%u (max~%u us)\r\n",
                   g_parseCycles.min, parseAvg, g_parseCycles.max, parseMaxUs);
            PRINTF("SWO: isrToStoreCycles min=%u avg=%u max=%u (max~%u us)\r\n",
                   g_isrToStoreCycles.min, latAvg, g_isrToStoreCycles.max, latMaxUs);
        }
#endif

#if ENABLE_EXTENSION_FAULT_DEMO
        // Use breakpoint before calling to inspect setup
        if (g_wordsDecoded == 5000U)
        {
            __BKPT(0);
            DeliberateFault();
        }
#endif

        __NOP();
    }
}