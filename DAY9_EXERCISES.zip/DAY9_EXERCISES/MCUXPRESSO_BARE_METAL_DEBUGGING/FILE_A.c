#include <stdbool.h>
#include <stdint.h>

#include "board.h"
#include "app.h"
#include "fsl_gpio.h"
#include "fsl_common.h"

// Simple SysTick delay (from NXP blinky)
static volatile uint32_t g_systickCounter;
static inline void SysTick_DelayTicks(uint32_t n)
{
    g_systickCounter = n;
    while (g_systickCounter != 0U) { __NOP(); }
}

void SysTick_Handler(void)
{
    if (g_systickCounter != 0U) g_systickCounter--;
}

// Stage 1 “decision gate”
static volatile bool g_gateEnable = false;

// Polling-based button edge detect with basic debounce
static bool Button_PressedEdge(void)
{
    static uint32_t stableCount = 0;
    static uint8_t last = 1U;

    // Most EVKB buttons are active-low; BOARD macros define port/pin.
    uint8_t now = (uint8_t)GPIO_PinRead(BOARD_USER_BUTTON_GPIO, BOARD_USER_BUTTON_GPIO_PIN);

    if (now == last)
    {
        if (stableCount < 5000U) stableCount++;
    }
    else
    {
        stableCount = 0U;
        last = now;
    }

    // Consider stable for a short time; trigger on high->low
    if (stableCount == 2000U && now == 0U)
    {
        return true;
    }
    return false;
}

int main(void)
{
    BOARD_InitHardware();

    // Init SysTick to 1ms tick
    SysTick_Config(SystemCoreClock / 1000U);

    // LED pin config is provided by SDK macros in app.h
    gpio_pin_config_t led_config = {kGPIO_DigitalOutput, 1U, kGPIO_NoIntmode};
    GPIO_PinInit(EXAMPLE_LED_GPIO, EXAMPLE_LED_GPIO_PIN, &led_config);

    bool ledOn = false;

    while (1)
    {
        // Toggle gate when user button is pressed (use breakpoint here to inspect GPIO regs)
        if (Button_PressedEdge())
        {
            g_gateEnable = !g_gateEnable;
        }

        // Only blink when gate is enabled
        if (g_gateEnable)
        {
            // BREAKPOINT TARGET: set your breakpoint on the GPIO_PinWrite line
            ledOn = !ledOn;
            GPIO_PinWrite(EXAMPLE_LED_GPIO, EXAMPLE_LED_GPIO_PIN, ledOn ? 0U : 1U);
        }
        else
        {
            // Force LED off when gate disabled
            GPIO_PinWrite(EXAMPLE_LED_GPIO, EXAMPLE_LED_GPIO_PIN, 1U);
        }

        // 1000 ms
        SysTick_DelayTicks(1000U);
    }
}