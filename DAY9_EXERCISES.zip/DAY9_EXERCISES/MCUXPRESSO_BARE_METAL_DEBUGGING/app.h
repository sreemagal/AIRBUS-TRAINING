#ifndef _APP_H_
#define _APP_H_

#include "board.h"

// Data UART = LPUART3 @ 115200 (ADK8582 bridge / burst source)
#define DEMO_LPUART          LPUART3
#define DEMO_LPUART_CLK_FREQ BOARD_DebugConsoleSrcFreq()

// SWO console parameters (same values as hello_world_swo demo)
#define DEMO_DEBUG_CONSOLE_SWO_PORT     (0U)
#define DEMO_DEBUG_CONSOLE_SWO_BAUDRATE (4000000U)

void BOARD_InitHardware(void);

#endif