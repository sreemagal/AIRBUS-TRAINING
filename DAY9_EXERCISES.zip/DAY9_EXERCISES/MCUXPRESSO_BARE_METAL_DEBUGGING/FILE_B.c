#include <stdbool.h>
#include <stdint.h>

#include "board.h"
#include "app.h"
#include "fsl_debug_console.h"
#include "fsl_common.h"

// These are already referenced in hardware_init.c in this demo.
volatile bool g_userPress = false;
static volatile bool g_timeOut = false;
static volatile uint32_t g_systickCounter = 0U;

void SysTick_Handler(void)
{
    if (g_systickCounter != 0U)
    {
        g_systickCounter--;
    }
    else
    {
        // 1-second heartbeat
        g_systickCounter = 1000U;
        g_timeOut = true;
    }
}

int main(void)
{
    BOARD_InitHardware();

    // Switch this demo’s console to SWO (ITM)
    BOARD_InitDebugConsoleSWO(DEMO_DEBUG_CONSOLE_SWO_PORT, DEMO_DEBUG_CONSOLE_SWO_BAUDRATE);

    SysTick_Config(SystemCoreClock / 1000U);
    g_systickCounter = 1000U;

    PRINTF("SWO: stage2_start\r\n");
    PRINTF("SWO: press button for event\r\n");

    uint32_t pressCount = 0;
    uint32_t heartbeatCount = 0;

    while (1)
    {
        // Button IRQ sets g_userPress in hardware_init.c
        if (g_userPress)
        {
            g_userPress = false;
            pressCount++;
            // Do NOT print from the ISR; print here to avoid perturbing interrupt timing.
            PRINTF("SWO: button_event count=%u\r\n", pressCount);
        }

        if (g_timeOut)
        {
            g_timeOut = false;
            heartbeatCount++;
            PRINTF("SWO: heartbeat count=%u\r\n", heartbeatCount);
        }

        // Optional: set a breakpoint here and observe PRIMASK/BASEPRI in Registers view.
        __NOP();
    }
}


