/*
 * IMXRT1050 EVKB – Debugging Capstone: COMPLETE SOLUTION (Stages 0–6)
 *
 * How to use this solution in MCUXpresso IDE (code-level steps):
 *  1) Import an SDK example as the base project:
 *     - boards/evkbimxrt1050/driver_examples/lpuart/edma_rb_transfer
 *       (this already brings in EDMA + idle-line ring-buffer mechanics)
 *  2) Replace the example’s app.h with the one below (sets DATA UART to LPUART3).
 *  3) Replace the example’s main source file (lpuart_edma_rb_transfer.c) with debug_capstone.c below.
 *  4) Replace pin_mux.c with the pin_mux.c below (enables LPUART3 TX/RX pins).
    5) Replace semihost_hardfault.c with the semihoast_hardfault.c below (wraps the hardfault handler within a conditional compilation)
    6) Set USE_CAPSTONE_HARDFAULT=1 in the preprocessor settings.
 *  7) Add the linker snippet (NOINIT section) to your project linker script.
 *  8) Build + Debug. Console uses LPUART1 (on-board USB). Data UART uses LPUART3 pins.
 *
 * Hardware wiring (data UART = LPUART3):
 *  - LPUART3 TX: GPIO_AD_B1_06 (board pin J12 in the SDK pin mux comments)
 *  - LPUART3 RX: GPIO_AD_B1_07 (board pin K10 in the SDK pin mux comments)
 *  - GND common between EVKB and your UART source.
 *  - Baud: 115200 8N1
 *
 * Data framing implemented here (robust for bursty streams):
 *  - Frame: 0xA5, <4 bytes little-endian ARINC-word>, <crc8 XOR of the 4 data bytes>
 *  - Burst ends when UART line goes idle (IDLE line interrupt).
 *
 * Stages mapped to code:
 *  - Stage 1: Correct LED GPIO init + pin mux (USER LED heartbeat)
 *  - Stage 2: HardFault handler capturing stacked regs + SCB fault regs
 *  - Stage 3: DWT cycle counter instrumentation with min/avg/max stats
 *  - Stage 4: Safe 32-bit ring buffer + sentinel guard for watchpoints
 *  - Stage 5: LPUART3 + EDMA + DMAMUX ring-buffer RX + IDLE line detect
 *  - Stage 6: Crash record persisted in .noinit across reset; printed next boot
 */

/*****************************
 * FILE: source/app.h
 *****************************/
/*
#ifndef _APP_H_
#define _APP_H_

#include "fsl_common.h"
#include "board.h"

// Data UART (from ADK8582 bridge / burst generator)
#define DATA_LPUART                 LPUART3
#define DATA_LPUART_CLK_FREQ        BOARD_DebugConsoleSrcFreq()
#define DATA_LPUART_IRQn            LPUART3_IRQn
#define DATA_LPUART_IRQHandler      LPUART3_IRQHandler

// EDMA/DMAMUX (RT1050 uses DMAMUX + EDMA)
#define DATA_LPUART_DMAMUX_BASEADDR DMAMUX
#define DATA_LPUART_DMA_BASEADDR    DMA0

// Pick DMA channels not used by other parts of your project
#define DATA_LPUART_TX_DMA_CHANNEL  2U
#define DATA_LPUART_RX_DMA_CHANNEL  3U

// DMAMUX requests for LPUART3
#define DATA_LPUART_TX_DMA_REQUEST  kDmaRequestMuxLPUART3Tx
#define DATA_LPUART_RX_DMA_REQUEST  kDmaRequestMuxLPUART3Rx

void BOARD_InitHardware(void);

#endif
*/

/*****************************
 * FILE: source/pin_mux.c
 *****************************/
/*
 * NOTE:
 *  - Keep the rest of the SDK-generated pin mux content as-is.
 *  - Ensure these two pins are configured for LPUART3:
 *      TX = GPIO_AD_B1_06, RX = GPIO_AD_B1_07
 *  - This snippet matches the SDK’s own pin list comments for EVKB i.MXRT1050.
 */

#include "fsl_iomuxc.h"
#include "fsl_clock.h"
#include "pin_mux.h"

void BOARD_InitPins(void)
{
    CLOCK_EnableClock(kCLOCK_Iomuxc);

    /* Existing debug console pins (from the SDK example) */
    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B0_12_LPUART1_TXD, 0U);
    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B0_13_LPUART1_RXD, 0U);
    IOMUXC_SetPinConfig(IOMUXC_GPIO_AD_B0_12_LPUART1_TXD, 0x10B0U);
    IOMUXC_SetPinConfig(IOMUXC_GPIO_AD_B0_13_LPUART1_RXD, 0x10B0U);

    /* Data UART pins: LPUART3 TX/RX */
    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_06_LPUART3_TXD, 0U);
    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_07_LPUART3_RXD, 0U);
    IOMUXC_SetPinConfig(IOMUXC_GPIO_AD_B1_06_LPUART3_TXD, 0x10B0U);
    IOMUXC_SetPinConfig(IOMUXC_GPIO_AD_B1_07_LPUART3_RXD, 0x10B0U);
}


void BOARD_InitBootPins(void)
{
    BOARD_InitPins();
}


/*****************************
 * FILE: linker script snippet
 *****************************/
/*
 * Add a NOINIT section to your project linker script (MCUXpresso GCC).
 * In your project’s .ld file (e.g., MIMXRT1052xxxxx_cm7.ld), add:
 *
 *   .noinit (NOLOAD) :
 *   {
 *       . = ALIGN(4);
 *       __noinit_start__ = .;
 *       *(.noinit*)
 *       . = ALIGN(4);
 *       __noinit_end__ = .;
 *   } > m_data
 *
 * Ensure it is NOT included in the .bss zeroing range.
 */
// ****************************************************************************
// semihost_hardfault.c
//                - Provides hard fault handler to allow semihosting code not
//                  to hang application when debugger not connected.
//
// ****************************************************************************
// Copyright 2017-2026 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
// ****************************************************************************
//
//                       ===== DESCRIPTION =====
//
// One of the issues with applications that make use of semihosting operations
// (such as printf calls) is that the code will not execute correctly when the
// debugger is not connected. Generally this will show up with the application
// appearing to just hang. This may include the application running from reset
// or powering up the board (with the application already in FLASH), and also
// as the application failing to continue to execute after a debug session is
// terminated.
//
// The problem here is that the "bottom layer" of the semihosted variants of
// the C library, semihosting is implemented by a "BKPT 0xAB" instruction.
// When the debug tools are not connected, this instruction triggers a hard
// fault - and the default hard fault handler within an application will
// typically just contains an infinite loop - causing the application to
// appear to have hang when no debugger is connected.
//
// The below code provides an example hard fault handler which instead looks
// to see what the instruction that caused the hard fault was - and if it
// was a "BKPT 0xAB", then it instead returns back to the user application.
//
// In most cases this will allow applications containing semihosting
// operations to execute (to some degree) when the debugger is not connected.
//
// == NOTE ==
//
// Correct execution of the application containing semihosted operations
// which are vectored onto this hard fault handler cannot be guaranteed. This
// is because the handler may not return data or return codes that the higher
// level C library code or application code expects. This hard fault handler
// is meant as a development aid, and it is not recommended to leave
// semihosted code in a production build of your application!
//
// ****************************************************************************

// Allow handler to be removed by setting a define (via command line)
#ifndef USE_CAPSTONE_HARDFAULT
#if !defined (__SEMIHOST_HARDFAULT_DISABLE)

__attribute__((naked))

void HardFault_Handler(void){
    __asm(  ".syntax unified\n"
        // Check which stack is in use
            "MOVS   R0, #4           \n"
            "MOV    R1, LR           \n"
            "TST    R0, R1           \n"
            "BEQ    _MSP             \n"
            "MRS    R0, PSP          \n"
            "B  _process             \n"
            "_MSP:                   \n"
            "MRS    R0, MSP          \n"
        // Load the instruction that triggered hard fault
        "_process:                   \n"
            "LDR    R1,[R0,#24]      \n"
            "LDRH   R2,[r1]          \n"
        // Semihosting instruction is "BKPT 0xAB" (0xBEAB)
            "LDR    R3,=0xBEAB       \n"
            "CMP    R2,R3            \n"
            "BEQ    _semihost_return \n"
        // Wasn't semihosting instruction so enter infinite loop
            "B .                     \n"
        // Was semihosting instruction, so adjust location to
        // return to by 1 instruction (2 bytes), then exit function
            "_semihost_return:       \n"
            "ADDS   R1,#2            \n"
            "STR    R1,[R0,#24]      \n"
        // Set a return value from semihosting operation.
        // 0 is slightly arbitrary, but appears to allow most
        // C Library IO functions sitting on top of semihosting to
        // continue to operate to some degree
        // Return a positive value (32) for SYS_OPEN only
            "LDR    R1,[ R0,#0 ]     \n"  // R0 is at location 0 on stack
            "CMP    R1, #1           \n"  // 0x01=SYS_OPEN
            "BEQ    _non_zero_ret    \n"
            "MOVS   R1,#0            \n"
            "B      _sys_ret         \n"
            "_non_zero_ret:          \n"
            "MOVS   R1,#32           \n"
            "_sys_ret:               \n"
            "STR    R1,[ R0,#0 ]     \n" // R0 is at location 0 on stack
        // Return from hard fault handler to application
            "BX     LR               \n"
        ".syntax divided\n") ;
}
#endif
#endif


/*****************************
 * FILE: source/debug_capstone.c
 *****************************/
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "board.h"
#include "app.h"
#include "clock_config.h"
#include "pin_mux.h"

#include "fsl_common.h"
#include "fsl_common_arm.h"      // AT_NONCACHEABLE_SECTION*
#include "fsl_debug_console.h"   // PRINTF
#include "fsl_gpio.h"            // USER LED
#include "fsl_lpuart.h"
#include "fsl_lpuart_edma.h"
#include "fsl_edma.h"
#if defined(FSL_FEATURE_SOC_DMAMUX_COUNT) && FSL_FEATURE_SOC_DMAMUX_COUNT
#include "fsl_dmamux.h"
#endif

/*******************************************************************************
 * Build-time options
 ******************************************************************************/
#define CAPSTONE_BAUDRATE_BPS        (115200U)
#define UART_RING_BYTES              (256U)      // EDMA byte ring buffer (power-of-2 not required)
#define BURST_MAX_BYTES              (256U)      // max burst we decode per idle event
#define WORD_RING_WORDS              (64U)       // decoded 32-bit words

#define FRAME_PREAMBLE               (0xA5U)

// Fault injection toggles (disabled by default in the “solution” build)
#define INJECT_NULL_FUNC_FAULT       (0)
#define INJECT_RING_OVERFLOW_BUG     (0)
#define INJECT_DMAMUX_MISCONFIG      (0)

/*******************************************************************************
 * Stage 3: DWT cycle counter + stats
 ******************************************************************************/
typedef struct
{
    uint32_t min;
    uint32_t max;
    uint64_t sum;
    uint32_t count;
} cycle_stats_t;

static inline void Stats_Reset(cycle_stats_t *s)
{
    s->min = 0xFFFFFFFFu;
    s->max = 0u;
    s->sum = 0u;
    s->count = 0u;
}

static inline void Stats_Add(cycle_stats_t *s, uint32_t cycles)
{
    if (cycles < s->min) s->min = cycles;
    if (cycles > s->max) s->max = cycles;
    s->sum += (uint64_t)cycles;
    s->count++;
}

static void DWT_Init(void)
{
    // Enable trace
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    // Reset and enable cycle counter
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

static inline uint32_t DWT_Cycles(void)
{
    return DWT->CYCCNT;
}

/*******************************************************************************
 * Stage 6: Crash record persisted in .noinit
 ******************************************************************************/
#define CRASH_MAGIC (0x43524153u) // 'CRAS'
#define CRASH_VER   (0x00010001u)

typedef struct
{
    uint32_t magic;
    uint32_t version;

    // stacked regs
    uint32_t r0, r1, r2, r3, r12;
    uint32_t lr, pc, psr;
    uint32_t sp;

    // SCB fault status
    uint32_t cfsr;
    uint32_t hfsr;
    uint32_t mmfar;
    uint32_t bfar;
    uint32_t afsr;

    // breadcrumbs
    uint32_t uptime_cycles;
    uint32_t last_event;

    uint32_t checksum;
} crash_record_t;

__attribute__((section(".noinit"))) static crash_record_t g_crash;

static uint32_t Crash_Checksum(const crash_record_t *r)
{
    const uint32_t *p = (const uint32_t *)r;
    uint32_t x = 0;
    // checksum over all words except checksum field itself
    for (size_t i = 0; i < (sizeof(*r) / sizeof(uint32_t)) - 1; i++)
    {
        x ^= p[i];
        x = (x << 1) | (x >> 31);
    }
    return x;
}

static void Crash_Clear(void)
{
    memset((void *)&g_crash, 0, sizeof(g_crash));
}

static bool Crash_IsValid(void)
{
    if (g_crash.magic != CRASH_MAGIC || g_crash.version != CRASH_VER)
        return false;
    return (g_crash.checksum == Crash_Checksum(&g_crash));
}

static void Crash_PrintAndClear(void)
{
    if (!Crash_IsValid())
        return;

    PRINTF("\r\n===== CRASH RECORD (persisted) =====\r\n");
    PRINTF("PC=0x%08X LR=0x%08X PSR=0x%08X SP=0x%08X\r\n", g_crash.pc, g_crash.lr, g_crash.psr, g_crash.sp);
    PRINTF("R0=0x%08X R1=0x%08X R2=0x%08X R3=0x%08X R12=0x%08X\r\n",
           g_crash.r0, g_crash.r1, g_crash.r2, g_crash.r3, g_crash.r12);
    PRINTF("CFSR=0x%08X HFSR=0x%08X MMFAR=0x%08X BFAR=0x%08X AFSR=0x%08X\r\n",
           g_crash.cfsr, g_crash.hfsr, g_crash.mmfar, g_crash.bfar, g_crash.afsr);
    PRINTF("UptimeCycles=%u LastEvent=0x%08X\r\n", g_crash.uptime_cycles, g_crash.last_event);
    PRINTF("===================================\r\n\r\n");

    Crash_Clear();
}

/*******************************************************************************
 * Stage 4: Safe 32-bit ring buffer + sentinel guard (watchpoint-friendly)
 ******************************************************************************/
typedef struct
{
    uint32_t buf[WORD_RING_WORDS];
    volatile uint32_t sentinel; // put a watchpoint here to catch overwrites
} ring32_storage_t;

typedef struct
{
    ring32_storage_t storage;
    volatile uint32_t head;
    volatile uint32_t tail;
    volatile uint32_t count;
    volatile uint32_t overflow_count;
} ring32_t;

static ring32_t g_wordRing;

static void Ring32_Init(ring32_t *r)
{
    memset((void *)r->storage.buf, 0, sizeof(r->storage.buf));
    r->storage.sentinel = 0xDEADBEEFu;
    r->head = 0;
    r->tail = 0;
    r->count = 0;
    r->overflow_count = 0;
}

static bool Ring32_Push(ring32_t *r, uint32_t v)
{
#if INJECT_RING_OVERFLOW_BUG
    // BUGGY: forget bounds check (for the lab’s “catch it with watchpoint” stage)
    r->storage.buf[r->head] = v;
    r->head = (r->head + 1U) % WORD_RING_WORDS;
    r->count++;
    return true;
#else
    if (r->count >= WORD_RING_WORDS)
    {
        r->overflow_count++;
        return false;
    }

    r->storage.buf[r->head] = v;
    r->head = (r->head + 1U) % WORD_RING_WORDS;
    r->count++;
    return true;
#endif
}

static bool Ring32_Pop(ring32_t *r, uint32_t *out)
{
    if (r->count == 0)
        return false;

    *out = r->storage.buf[r->tail];
    r->tail = (r->tail + 1U) % WORD_RING_WORDS;
    r->count--;
    return true;
}

/*******************************************************************************
 * “ARINC-like” word decode + processing (Stage 3 target)
 ******************************************************************************/
typedef struct
{
    uint32_t total_words;
    uint32_t parity_errors;
    uint32_t crc_errors;
    uint32_t label203_count;
    cycle_stats_t proc_cycles;
} pipeline_stats_t;

static pipeline_stats_t g_stats;

static bool ParityOdd32(uint32_t w)
{
    // Odd parity over all 32 bits: returns true if odd number of 1s.
    w ^= w >> 16;
    w ^= w >> 8;
    w ^= w >> 4;
    w &= 0xFu;
    // 0x6996 parity LUT for 4-bit
    bool parity = (0x6996u >> w) & 1u;
    return parity;
}

static void ProcessWord_ARINC(uint32_t w)
{
    // Example “work”: extract label (LSB 8), do parity check, update counters.
    // Typical ARINC 429: parity is bit 31 (odd parity overall). Here we check overall odd parity.
    uint8_t label = (uint8_t)(w & 0xFFu);

    if (!ParityOdd32(w))
    {
        g_stats.parity_errors++;
    }

    // Example label tracking (0xCB == decimal 203)
    if (label == 0xCBu)
    {
        g_stats.label203_count++;
    }

    // Add any realistic “decode” work here to stress timing (scale/BCD, etc.)
    // This is intentionally lightweight but deterministic.
}

static void Pipeline_ProcessOneWord(uint32_t w)
{
    uint32_t t0 = DWT_Cycles();
    ProcessWord_ARINC(w);
    uint32_t t1 = DWT_Cycles();
    Stats_Add(&g_stats.proc_cycles, (uint32_t)(t1 - t0));
    g_stats.total_words++;
}

/*******************************************************************************
 * Stage 5: LPUART3 + EDMA ring-buffer RX + IDLE line detect
 ******************************************************************************/
static lpuart_edma_handle_t g_lpuartEdmaHandle;
static edma_handle_t g_lpuartTxEdmaHandle;
static edma_handle_t g_lpuartRxEdmaHandle;

// Non-cacheable buffers used by EDMA
AT_NONCACHEABLE_SECTION(static uint8_t g_uartRing[UART_RING_BYTES]);
AT_NONCACHEABLE_SECTION(static uint8_t g_burstBuf[BURST_MAX_BYTES]);

// TCD memory pool (one TCD, self-linked for circular buffer)
AT_NONCACHEABLE_SECTION_ALIGN(static edma_tcd_t g_rxTcdPool[1], sizeof(edma_tcd_t));

static volatile bool g_burstReady = false;
static volatile uint32_t g_burstBytes = 0;
static volatile uint32_t g_uartRingWraps = 0;
static volatile uint32_t g_uartRingReadIndex = 0;

// A simple breadcrumb/event code for crash context
static volatile uint32_t g_lastEvent = 0;

enum
{
    EVT_BOOT = 0xB0010001u,
    EVT_UART_INIT = 0xB0010002u,
    EVT_EDMA_INIT = 0xB0010003u,
    EVT_EDMA_START = 0xB0010004u,
    EVT_IDLE_ISR = 0xB0010005u,
    EVT_PARSE_BURST = 0xB0010006u,
    EVT_PROCESS_WORD = 0xB0010007u,
};

static uint8_t Crc8Xor4(const uint8_t d[4])
{
    return (uint8_t)(d[0] ^ d[1] ^ d[2] ^ d[3]);
}

static void DataUart_Init(void)
{
    lpuart_config_t cfg;
    LPUART_GetDefaultConfig(&cfg);

    cfg.baudRate_Bps = CAPSTONE_BAUDRATE_BPS;
    cfg.parityMode = kLPUART_ParityDisabled;
    cfg.stopBitCount = kLPUART_OneStopBit;
    cfg.enableTx = true;
    cfg.enableRx = true;

    // Idle detection: matches the SDK EDMA ring buffer example pattern
    cfg.rxIdleType = kLPUART_IdleTypeStopBit;
    cfg.rxIdleConfig = kLPUART_IdleCharacter2;

    LPUART_Init(DATA_LPUART, &cfg, DATA_LPUART_CLK_FREQ);
}

static void DataEdma_RxMajorCallback(edma_handle_t *handle, void *param, bool transferDone, uint32_t tcds)
{
    (void)handle; (void)param; (void)tcds;
    if (transferDone)
    {
        // Ring buffer wrapped
        g_uartRingWraps++;
    }
}

static void DataUartEdma_Init(void)
{
    edma_config_t edmaCfg;

#if defined(FSL_FEATURE_SOC_DMAMUX_COUNT) && FSL_FEATURE_SOC_DMAMUX_COUNT
    DMAMUX_Init(DATA_LPUART_DMAMUX_BASEADDR);

#if INJECT_DMAMUX_MISCONFIG
    // BUG: wrong request or channel disabled (kept here for lab replication). Disabled by default.
    DMAMUX_SetSource(DATA_LPUART_DMAMUX_BASEADDR, DATA_LPUART_RX_DMA_CHANNEL, kDmaRequestMuxLPUART1Rx);
    // DMAMUX_EnableChannel intentionally omitted
#else
    DMAMUX_SetSource(DATA_LPUART_DMAMUX_BASEADDR, DATA_LPUART_TX_DMA_CHANNEL, DATA_LPUART_TX_DMA_REQUEST);
    DMAMUX_SetSource(DATA_LPUART_DMAMUX_BASEADDR, DATA_LPUART_RX_DMA_CHANNEL, DATA_LPUART_RX_DMA_REQUEST);
    DMAMUX_EnableChannel(DATA_LPUART_DMAMUX_BASEADDR, DATA_LPUART_TX_DMA_CHANNEL);
    DMAMUX_EnableChannel(DATA_LPUART_DMAMUX_BASEADDR, DATA_LPUART_RX_DMA_CHANNEL);
#endif
#endif

    EDMA_GetDefaultConfig(&edmaCfg);
    EDMA_Init(DATA_LPUART_DMA_BASEADDR, &edmaCfg);

    EDMA_CreateHandle(&g_lpuartTxEdmaHandle, DATA_LPUART_DMA_BASEADDR, DATA_LPUART_TX_DMA_CHANNEL);
    EDMA_CreateHandle(&g_lpuartRxEdmaHandle, DATA_LPUART_DMA_BASEADDR, DATA_LPUART_RX_DMA_CHANNEL);

    // Create LPUART EDMA handle (TX callback not required for this lab)
    LPUART_TransferCreateHandleEDMA(DATA_LPUART, &g_lpuartEdmaHandle,
                                    NULL, NULL, &g_lpuartTxEdmaHandle, &g_lpuartRxEdmaHandle);
}

static void DataUartEdma_StartRxRing(void)
{
    edma_transfer_config_t xfer;

    // Clear ring buffer and state
    memset((void *)g_uartRing, 0, sizeof(g_uartRing));
    g_uartRingWraps = 0;
    g_uartRingReadIndex = 0;

    // Use one TCD (self-linked scatter/gather) to create a circular ring
    EDMA_InstallTCDMemory(&g_lpuartRxEdmaHandle, (edma_tcd_t *)&g_rxTcdPool[0], 1U);

    EDMA_PrepareTransfer(&xfer,
                         (void *)(uint32_t *)LPUART_GetDataRegisterAddress(DATA_LPUART),
                         sizeof(uint8_t),
                         (void *)g_uartRing,
                         sizeof(uint8_t),
                         sizeof(uint8_t),
                         UART_RING_BYTES,
                         kEDMA_PeripheralToMemory);

    // Submit transfer config into TCD pool[0], and link-to-self using last parameter
    g_lpuartRxEdmaHandle.tcdUsed = 1U;
    g_lpuartRxEdmaHandle.tail = 0U;

#if defined(FSL_EDMA_DRIVER_EDMA4) && FSL_EDMA_DRIVER_EDMA4
    EDMA_TcdResetExt(g_lpuartRxEdmaHandle.base, &g_lpuartRxEdmaHandle.tcdPool[0U]);
    EDMA_TcdSetTransferConfigExt(g_lpuartRxEdmaHandle.base, &g_lpuartRxEdmaHandle.tcdPool[0U], &xfer, &g_rxTcdPool[0]);
    EDMA_TcdEnableInterruptsExt(g_lpuartRxEdmaHandle.base, &g_lpuartRxEdmaHandle.tcdPool[0U], kEDMA_MajorInterruptEnable);
#else
    EDMA_TcdReset(&g_lpuartRxEdmaHandle.tcdPool[0U]);
    EDMA_TcdSetTransferConfig(&g_lpuartRxEdmaHandle.tcdPool[0U], &xfer, &g_rxTcdPool[0]);
    EDMA_TcdEnableInterrupts(&g_lpuartRxEdmaHandle.tcdPool[0U], kEDMA_MajorInterruptEnable);
#endif

    EDMA_InstallTCD(g_lpuartRxEdmaHandle.base, g_lpuartRxEdmaHandle.channel, &g_lpuartRxEdmaHandle.tcdPool[0U]);
    EDMA_SetCallback(&g_lpuartRxEdmaHandle, DataEdma_RxMajorCallback, NULL);
    EDMA_StartTransfer(&g_lpuartRxEdmaHandle);

    // Enable RX DMA requests from LPUART
    LPUART_EnableRxDMA(DATA_LPUART, true);

    // Enable IDLE line interrupt to mark burst end
    LPUART_EnableInterrupts(DATA_LPUART, kLPUART_IdleLineInterruptEnable);

    NVIC_SetPriority(DATA_LPUART_IRQn, 3U);
    EnableIRQ(DATA_LPUART_IRQn);
}

// Read out bytes from the EDMA ring buffer (same algorithm as SDK example)
static uint32_t DataUart_ReadRing(uint8_t *out, uint32_t length)
{
    // If length > ring, treat as overflow and only return last ring-size bytes
    uint32_t idx = length;
    if (length > UART_RING_BYTES)
    {
        g_uartRingReadIndex = (g_uartRingReadIndex + length) % UART_RING_BYTES;
        idx = UART_RING_BYTES;
    }

    uint32_t n = idx;
    while (n)
    {
        *(out++) = g_uartRing[g_uartRingReadIndex++];
        if (g_uartRingReadIndex == UART_RING_BYTES)
        {
            g_uartRingReadIndex = 0U;
            // consumption reduced the wrap counter as we pass the boundary
            if (g_uartRingWraps) g_uartRingWraps--;
        }
        n--;
    }
    return idx;
}

void DATA_LPUART_IRQHandler(void)
{
    uint32_t status = LPUART_GetStatusFlags(DATA_LPUART);
    uint32_t en = LPUART_GetEnabledInterrupts(DATA_LPUART);

    if (((uint32_t)kLPUART_IdleLineFlag & status) && ((uint32_t)kLPUART_IdleLineInterruptEnable & en))
    {
        g_lastEvent = EVT_IDLE_ISR;

        // Clear IDLE flag
        (void)LPUART_ClearStatusFlags(DATA_LPUART, kLPUART_IdleLineFlag);

        // Compute how many bytes are currently in ring since last consumption
        uint32_t remaining = EDMA_GetRemainingMajorLoopCount(DATA_LPUART_DMA_BASEADDR, DATA_LPUART_RX_DMA_CHANNEL);
        uint32_t receivedInThisLoop = UART_RING_BYTES - remaining;
        uint32_t total = receivedInThisLoop + (UART_RING_BYTES * g_uartRingWraps) - g_uartRingReadIndex;

        if (total > BURST_MAX_BYTES)
            total = BURST_MAX_BYTES;

        g_burstBytes = total;
        g_burstReady = true;
    }

    SDK_ISR_EXIT_BARRIER;
}

/*******************************************************************************
 * Stage 2: HardFault handler capturing stacked regs + fault status
 ******************************************************************************/
static void HardFault_Capture(uint32_t *stacked_sp)
{
    // stacked_sp points to r0,r1,r2,r3,r12,lr,pc,psr
    g_crash.magic = CRASH_MAGIC;
    g_crash.version = CRASH_VER;

    g_crash.r0 = stacked_sp[0];
    g_crash.r1 = stacked_sp[1];
    g_crash.r2 = stacked_sp[2];
    g_crash.r3 = stacked_sp[3];
    g_crash.r12 = stacked_sp[4];
    g_crash.lr = stacked_sp[5];
    g_crash.pc = stacked_sp[6];
    g_crash.psr = stacked_sp[7];
    g_crash.sp = (uint32_t)stacked_sp;

    g_crash.cfsr = SCB->CFSR;
    g_crash.hfsr = SCB->HFSR;
    g_crash.mmfar = SCB->MMFAR;
    g_crash.bfar = SCB->BFAR;
    g_crash.afsr = SCB->AFSR;

    g_crash.uptime_cycles = DWT_Cycles();
    g_crash.last_event = g_lastEvent;

    g_crash.checksum = Crash_Checksum(&g_crash);
}

__attribute__((naked)) void HardFault_Handler(void)
{
    __asm volatile(
        "tst lr, #4 \n"           // Which stack? MSP/PSP
        "ite eq \n"
        "mrseq r0, msp \n"        // r0 = MSP if EQ
        "mrsne r0, psp \n"        // r0 = PSP if NE
        "b HardFault_HandlerC \n"
    );
}

void HardFault_HandlerC(uint32_t *stacked_sp)
{
    __disable_irq();
    HardFault_Capture(stacked_sp);

    // Try to reset so record is printed on next boot.
    NVIC_SystemReset();

    while (1) {}
}

/*******************************************************************************
 * Stage 1: LED heartbeat
 ******************************************************************************/
static void Led_Init(void)
{
    // USER_LED_INIT expects 0/1 output param; examples typically use output=1
    USER_LED_INIT(1);
    USER_LED_OFF();
}

static void Led_Tick(void)
{
    static uint32_t ctr = 0;
    ctr++;
    if ((ctr % 500000U) == 0U) // rough loop-based blink (no RTOS)
    {
        USER_LED_TOGGLE();
    }
}

/*******************************************************************************
 * Burst parser: 0xA5 + 4 bytes + crc8 XOR
 ******************************************************************************/
typedef enum
{
    ST_WAIT_PREAMBLE = 0,
    ST_DATA0,
    ST_DATA1,
    ST_DATA2,
    ST_DATA3,
    ST_CRC,
} frame_state_t;

static frame_state_t g_fsm = ST_WAIT_PREAMBLE;
static uint8_t g_data4[4];

static void Parser_Reset(void)
{
    g_fsm = ST_WAIT_PREAMBLE;
    memset(g_data4, 0, sizeof(g_data4));
}

static void Parser_ConsumeByte(uint8_t b)
{
    switch (g_fsm)
    {
        case ST_WAIT_PREAMBLE:
            if (b == FRAME_PREAMBLE)
                g_fsm = ST_DATA0;
            break;

        case ST_DATA0:
            g_data4[0] = b;
            g_fsm = ST_DATA1;
            break;
        case ST_DATA1:
            g_data4[1] = b;
            g_fsm = ST_DATA2;
            break;
        case ST_DATA2:
            g_data4[2] = b;
            g_fsm = ST_DATA3;
            break;
        case ST_DATA3:
            g_data4[3] = b;
            g_fsm = ST_CRC;
            break;

        case ST_CRC:
        {
            uint8_t crc = Crc8Xor4(g_data4);
            if (crc == b)
            {
                uint32_t w = ((uint32_t)g_data4[0]) |
                             ((uint32_t)g_data4[1] << 8) |
                             ((uint32_t)g_data4[2] << 16) |
                             ((uint32_t)g_data4[3] << 24);

                (void)Ring32_Push(&g_wordRing, w);
            }
            else
            {
                g_stats.crc_errors++;
            }
            g_fsm = ST_WAIT_PREAMBLE;
            break;
        }

        default:
            g_fsm = ST_WAIT_PREAMBLE;
            break;
    }
}

static void Pipeline_DrainWordRing(void)
{
    uint32_t w;
    while (Ring32_Pop(&g_wordRing, &w))
    {
        g_lastEvent = EVT_PROCESS_WORD;
        Pipeline_ProcessOneWord(w);
    }
}

/*******************************************************************************
 * Optional injected crash (Stage 2 demonstration)
 ******************************************************************************/
static void Maybe_InjectNullFuncFault(void)
{
#if INJECT_NULL_FUNC_FAULT
    void (*fn)(void) = (void (*)(void))0x00000000u;
    fn();
#endif
}

/*******************************************************************************
 * Main
 ******************************************************************************/
int main(void)
{
    g_lastEvent = EVT_BOOT;

    BOARD_InitHardware();

    // Stage 6: If we crashed last run, show record now
    DWT_Init();
    Crash_PrintAndClear();

    Led_Init();

    // Stats init
    memset(&g_stats, 0, sizeof(g_stats));
    Stats_Reset(&g_stats.proc_cycles);

    // Stage 4 ring init
    Ring32_Init(&g_wordRing);

    PRINTF("\r\n[Capstone] IMXRT1050 Debugging Exercise – SOLUTION BUILD\r\n");
    PRINTF("Console: LPUART1 (DebugConsole). Data: LPUART3 @ %u bps\r\n", CAPSTONE_BAUDRATE_BPS);

    // Stage 5 init: UART3 + EDMA ring RX
    g_lastEvent = EVT_UART_INIT;
    DataUart_Init();

    g_lastEvent = EVT_EDMA_INIT;
    DataUartEdma_Init();

    g_lastEvent = EVT_EDMA_START;
    DataUartEdma_StartRxRing();

    Parser_Reset();

    Maybe_InjectNullFuncFault();

    while (1)
    {
        Led_Tick();

        if (g_burstReady)
        {
            __disable_irq();
            uint32_t n = g_burstBytes;
            g_burstReady = false;
            __enable_irq();

            g_lastEvent = EVT_PARSE_BURST;

            if (n > 0)
            {
                uint32_t got = DataUart_ReadRing((uint8_t *)g_burstBuf, n);

                for (uint32_t i = 0; i < got; i++)
                {
                    Parser_ConsumeByte(g_burstBuf[i]);
                }

                Pipeline_DrainWordRing();

                // Print summary per burst (keep printing here, not in ISR)
                if (g_stats.proc_cycles.count)
                {
                    uint32_t avg = (uint32_t)(g_stats.proc_cycles.sum / g_stats.proc_cycles.count);
                    PRINTF("BurstBytes=%u Words=%u Label203=%u CRCerr=%u ParityErr=%u\r\n",
                           got, g_stats.total_words, g_stats.label203_count, g_stats.crc_errors, g_stats.parity_errors);
                    PRINTF("ProcCycles: min=%u avg=%u max=%u (count=%u)\r\n",
                           g_stats.proc_cycles.min, avg, g_stats.proc_cycles.max, g_stats.proc_cycles.count);
                }
            }
        }

        // If sentinel changed, you can set a watchpoint on g_wordRing.storage.sentinel
        // This check also gives you an in-code tripwire.
        if (g_wordRing.storage.sentinel != 0xDEADBEEFu)
        {
            PRINTF("[WARN] Word ring sentinel corrupted! 0x%08X\r\n", g_wordRing.storage.sentinel);
            __BKPT(0);
        }
    }
}

/*******************************************************************************
 * END
 ******************************************************************************/
