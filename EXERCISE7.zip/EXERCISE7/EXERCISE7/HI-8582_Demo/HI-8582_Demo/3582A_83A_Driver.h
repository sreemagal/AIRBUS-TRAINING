/*!
 *	3582A_83A_Driver.h
 * Supports all: 3582A/3583A/8582/8583				
 *	   	HOLT DISCLAIMER
 *      	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
 *      	KIND,EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 *      	WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 *      	PURPOSE AND NONINFRINGEMENT. 
 *      	IN NO EVENT SHALL HOLT, INC BE LIABLE FOR ANY CLAIM, DAMAGES
 *      	OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 *      	OTHERWISE,ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 *      	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
 *
 *        Copyright (C) 2009 by  HOLT, Inc.
 *        All Rights Reserved
 */



typedef unsigned short int U16BIT;
typedef unsigned int U32BIT;
typedef volatile unsigned short HI3582_REG ; // (16-bits)

// TESTCONFIGURATION IS A DEFAULT used for initial test.
// This will select unscrambled, hi speed, odd parity, normal mode and no label
// detection
#define DEFAULTCONFG 0x8030 // 
#define TXEMPTY (1<<6)
#define TXNFULL (1<<7)
#define SR_VALID_FROM_RESET 0x0040

// Transmitter Configuration Constants
#define PARITY 0x0010
#define DATA ~PARITY

#define NORMAL 0x20
#define SELFTEST !NORMAL

#define EVEN 0x1000
#define ODD !EVEN

#define LO 0x2000
#define HI !LO



#define ENABLE 1
#define DISABLE 0
#define CR0 1
#define CR1 (1<<1)
#define CR2 (1<<2)
#define CR3 (1<<3)
#define CR4 (1<<4)
#define CR5 (1<<5)
#define CR6 (1<<6)
#define CR7 (1<<7)
#define CR8 (1<<8)
#define CR9 (1<<9)
#define CR10 (1<<10)
#define CR11 (1<<11)
#define CR12 (1<<12)
#define CR13 (1<<13)
#define CR14 (1<<14)
#define CR15 (1<<15)


typedef struct H3582_REGS {	          // EBI Bus Addresses 
	HI3582_REG EN1;        
        HI3582_REG EN2;      
        HI3582_REG CWSTR;           
        HI3582_REG RSR; 
        HI3582_REG PL2; 
        HI3582_REG PL1; 
       
} HI3582, *H3582 ;		
#define HI3582_BASE	((H3582) 0x60000000) 	// using EBI chip select NCS0 CM3
// -----------------------------------------------------------------------------

void setRec_1Bit_9Bit10encoder(unsigned short enable, unsigned short d9, unsigned d10);
void setRec_2Bit_9Bit10encoder(unsigned short enable, unsigned short d9, unsigned d10);
void toggleParityBit32();
void loadReceiver_1_Labels();
void readReceiver_1_Labels();
void loadReceiver_2_Labels();
void readReceiver_2_Labels();
void enableRec1_Labels(unsigned short Enable);
void enableRec2_Labels(unsigned short Enable);
unsigned short receiver1DataAvailable(void);
unsigned short receiver2DataAvailable(void);
void configureTransmitter(unsigned short parityMode,unsigned short selfTest, unsigned short oddEvenParity, unsigned short txSpeed);
void enableTransmission(void);
void disableTransmission(void);
unsigned short reset_3582(void);
void writeControlWord(unsigned short controlWord);
unsigned short readControlWord(void);
unsigned short readStatusRegister(void);
void writeTransmitterFIFO(unsigned int ArincWord);
unsigned int readReceiverFIFO_1(void);
unsigned int readReceiverFIFO_2(void);
void toggleSelfTestMode(void);


