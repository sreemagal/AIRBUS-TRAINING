/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 10 – Capstone ARINC Front-End over UART
 *
 * Goal:
 *   Turn ADK8582+HI-8582 into a UART-controlled ARINC front-end that:
 *     1) streams RX1/RX2 ARINC words to UART (for IMXRT1050/PC),
 *     2) generates ARINC TX words under UART control,
 *     3) rate-limits UART output to protect 115200 baud links,
 *     4) reports basic stats for diagnostics.
 *
 * UART: 115200 8N1
 *
 * Output lines (ASCII, easy parse):
 *   R1,<label_hex>,<sdi>,<word_hex>
 *   R2,<label_hex>,<sdi>,<word_hex>
 * Example:
 *   R1,01,0,01001234
 *
 * UART commands (single-character):
 *   h/H : help
 *   p/P : print status page (stats + current config)
 *
 *   Logging control:
 *   r/R : resume RX logging
 *   s/S : stop   RX logging
 *   a/A : log ALL labels (disable label filter)
 *   1   : filter label = 0x01
 *   2   : filter label = 0x02
 *   3   : filter label = 0x03
 *   4   : filter label = 0x04
 *
 *   Throttle control (UART output rate):
 *   t   : set throttle LOW  (fewer log lines / second)
 *   T   : set throttle HIGH (more log lines / second)
 *
 *   TX generator control:
 *   e/E : enable  ARINC TX generator
 *   d/D : disable ARINC TX generator
 *   f/F : TX rate FAST  (100 ms)
 *   w/W : TX rate SLOW  (500 ms)
 *   (Label uses same 1/2/3/4 keys as above)
 *
 * Notes:
 *  - This code assumes DEFAULTCONFG configures:
 *      * Unscrambled ARINC
 *      * 32nd bit parity
 *      * High-speed 100 kbps, odd parity
 *  - RX logging is throttled to avoid UART saturation (115200).
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>
#include <usart/usart.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables & macros
//------------------------------------------------------------------------------
#define VER "1.0"

// required by console.c in this codebase (even if not used)
unsigned short EmptyOrFull = 0;

// Holt driver base pointer
const H3582 pH3582 = HI3582_BASE;

// reset-valid status
#ifndef SR_VALID_FROM_RESET
#define SR_VALID_FROM_RESET 0x0040
#endif

// TX status bits (already used in earlier exercises)
#ifndef TXNFULL
#define TXNFULL (1u << 7)
#endif

//------------------------------------------------------------------------------
// Logger / filter state
//------------------------------------------------------------------------------
static unsigned char g_logEnabled   = 1;     // RX log output enabled
static unsigned char g_filterEn     = 0;     // label filter enabled
static unsigned char g_filterLabel  = 0x00;  // label when filter enabled

//------------------------------------------------------------------------------
// TX generator state
//------------------------------------------------------------------------------
static unsigned char  g_txEnabled     = 0;      // TX generator enable
static unsigned char  g_txLabel       = 0x01;   // TX label
static unsigned short g_txDelayTicks  = 1;      // 1 tick = 100ms

//------------------------------------------------------------------------------
// Throttle (token bucket) for UART RX logging lines
//   We allow N log lines per second approx.
//   Each 100ms tick replenishes tokens.
//------------------------------------------------------------------------------
static unsigned short g_tokens        = 0;
static unsigned short g_tokensMax     = 20;  // capacity
static unsigned short g_tokensAdd100ms= 4;   // tokens added per 100ms

//------------------------------------------------------------------------------
// Stats
//------------------------------------------------------------------------------
static unsigned long g_rx1Words       = 0;
static unsigned long g_rx2Words       = 0;
static unsigned long g_loggedLines    = 0;
static unsigned long g_droppedLines   = 0;
static unsigned long g_cmdCount       = 0;

//------------------------------------------------------------------------------
// Helpers: label & SDI extraction
//------------------------------------------------------------------------------
static unsigned char GetLabelFromWord(unsigned int word)
{
    return (unsigned char)(word & 0xFFu);
}

static unsigned char GetSDIFromWord(unsigned int word)
{
    return (unsigned char)((word >> 8) & 0x03u); // bits 8..9
}

//------------------------------------------------------------------------------
// Help and status printing
//------------------------------------------------------------------------------
static void PrintHelp(void)
{
    printf("\r\nExercise 10 – Capstone ARINC Front-End (UART controlled)\r\n");
    printf("Commands:\r\n");
    printf("  h/H : help\r\n");
    printf("  p/P : print status page\r\n");
    printf("\r\nLogging:\r\n");
    printf("  r/R : resume RX logging\r\n");
    printf("  s/S : stop   RX logging\r\n");
    printf("  a/A : log ALL labels (disable filter)\r\n");
    printf("  1   : filter label 0x01\r\n");
    printf("  2   : filter label 0x02\r\n");
    printf("  3   : filter label 0x03\r\n");
    printf("  4   : filter label 0x04\r\n");
    printf("\r\nThrottle:\r\n");
    printf("  t   : throttle LOW  (fewer lines/sec)\r\n");
    printf("  T   : throttle HIGH (more lines/sec)\r\n");
    printf("\r\nTX generator:\r\n");
    printf("  e/E : enable  TX generator\r\n");
    printf("  d/D : disable TX generator\r\n");
    printf("  f/F : TX rate FAST (100ms)\r\n");
    printf("  w/W : TX rate SLOW (500ms)\r\n");
    printf("  (1/2/3/4 also set TX label)\r\n");
    printf("\r\nOutput:\r\n");
    printf("  R1,<label_hex>,<sdi>,<word_hex>\r\n");
    printf("  R2,<label_hex>,<sdi>,<word_hex>\r\n\r\n");
}

static void PrintStatusPage(void)
{
    printf("\r\n===== Exercise 10 STATUS =====\r\n");
    printf("Logging      : %s\r\n", g_logEnabled ? "ENABLED" : "PAUSED");
    if (g_filterEn) {
        printf("Label filter : ENABLED (0x%02X)\r\n", g_filterLabel);
    } else {
        printf("Label filter : DISABLED (ALL)\r\n");
    }

    printf("Throttle     : tokens=%u/%u, add_per_100ms=%u\r\n",
           (unsigned int)g_tokens, (unsigned int)g_tokensMax, (unsigned int)g_tokensAdd100ms);

    printf("TX generator : %s\r\n", g_txEnabled ? "ENABLED" : "DISABLED");
    printf("TX label     : 0x%02X\r\n", g_txLabel);
    printf("TX interval  : %u x 100ms\r\n", (unsigned int)g_txDelayTicks);

    printf("\r\nStats:\r\n");
    printf("  RX1 words       : %lu\r\n", g_rx1Words);
    printf("  RX2 words       : %lu\r\n", g_rx2Words);
    printf("  Logged lines    : %lu\r\n", g_loggedLines);
    printf("  Dropped lines   : %lu\r\n", g_droppedLines);
    printf("  UART commands   : %lu\r\n", g_cmdCount);
    printf("=============================\r\n\r\n");
}

//------------------------------------------------------------------------------
// Command processing
//------------------------------------------------------------------------------
static void SetFilterAll(void)
{
    g_filterEn = 0;
    printf("CMD: filter DISABLED (log ALL labels)\r\n");
}

static void SetFilterLabel(unsigned char label)
{
    g_filterEn = 1;
    g_filterLabel = label;
    printf("CMD: filter ENABLED (label=0x%02X)\r\n", label);
}

static void SetThrottleLow(void)
{
    // conservative: ~ (tokensAdd100ms*10) lines/sec ~ 10 lines/sec
    g_tokensMax      = 10;
    g_tokensAdd100ms = 1;
    if (g_tokens > g_tokensMax) g_tokens = g_tokensMax;
    printf("CMD: throttle LOW (max=%u, add/100ms=%u)\r\n",
           (unsigned int)g_tokensMax, (unsigned int)g_tokensAdd100ms);
}

static void SetThrottleHigh(void)
{
    // more aggressive: ~ (tokensAdd100ms*10) lines/sec ~ 40 lines/sec
    g_tokensMax      = 40;
    g_tokensAdd100ms = 4;
    if (g_tokens > g_tokensMax) g_tokens = g_tokensMax;
    printf("CMD: throttle HIGH (max=%u, add/100ms=%u)\r\n",
           (unsigned int)g_tokensMax, (unsigned int)g_tokensAdd100ms);
}

static void ProcessCmd(char c)
{
    if (c == '\r' || c == '\n') return;

    g_cmdCount++;

    switch (c) {
        case 'h':
        case 'H':
            PrintHelp();
            break;

        case 'p':
        case 'P':
            PrintStatusPage();
            break;

        // logging control
        case 'r':
        case 'R':
            g_logEnabled = 1;
            printf("CMD: logging RESUMED\r\n");
            break;

        case 's':
        case 'S':
            g_logEnabled = 0;
            printf("CMD: logging PAUSED\r\n");
            break;

        case 'a':
        case 'A':
            SetFilterAll();
            break;

        // throttle
        case 't':
            SetThrottleLow();
            break;

        case 'T':
            SetThrottleHigh();
            break;

        // TX generator
        case 'e':
        case 'E':
            g_txEnabled = 1;
            printf("CMD: TX generator ENABLED\r\n");
            break;

        case 'd':
        case 'D':
            g_txEnabled = 0;
            printf("CMD: TX generator DISABLED\r\n");
            break;

        case 'f':
        case 'F':
            g_txDelayTicks = 1; // 100ms
            printf("CMD: TX interval FAST (100ms)\r\n");
            break;

        case 'w':
        case 'W':
            g_txDelayTicks = 5; // 500ms
            printf("CMD: TX interval SLOW (500ms)\r\n");
            break;

        // label select (also sets TX label)
        case '1':
            g_txLabel = 0x01;
            SetFilterLabel(0x01);
            break;

        case '2':
            g_txLabel = 0x02;
            SetFilterLabel(0x02);
            break;

        case '3':
            g_txLabel = 0x03;
            SetFilterLabel(0x03);
            break;

        case '4':
            g_txLabel = 0x04;
            SetFilterLabel(0x04);
            break;

        default:
            printf("CMD: unknown '%c' (press 'h')\r\n", c);
            break;
    }
}

//------------------------------------------------------------------------------
// Logging decision + throttled print
//------------------------------------------------------------------------------
static void MaybeLogWord(const char *prefix, unsigned int word)
{
    unsigned char label = GetLabelFromWord(word);
    unsigned char sdi   = GetSDIFromWord(word);

    // Filter check
    if (g_filterEn && (label != g_filterLabel)) {
        return;
    }

    // Logging enabled?
    if (!g_logEnabled) {
        return;
    }

    // Throttle check
    if (g_tokens == 0) {
        g_droppedLines++;
        return;
    }

    g_tokens--;
    g_loggedLines++;

    // Print the CSV line
    printf("%s,%02X,%u,%08X\r\n",
           prefix,
           (unsigned int)label,
           (unsigned int)sdi,
           (unsigned int)word);
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // TX word builder (same union pattern as earlier exercises)
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };
    union arincBuffer32 ArincTX;

    const Pin pinNMR  = PIN_NMR;
    const Pin pinNSW1 = PIN_NSW1;  // unused
    const Pin pinNSW2 = PIN_NSW2;  // unused
    (void)pinNSW1;
    (void)pinNSW2;

    // init TX buffer
    ArincTX.arincTXWord  = 0x00000000;
    ArincTX.arincByte[0] = 0x0000;
    ArincTX.arincByte[1] = 0x0000;  // counter
    ArincTX.arincLable   = g_txLabel;

    __disable_interrupt();

    // ---------------- Board init (matches Holt demo style) -------------------
    AT91C_BASE_PIOC->PIO_CODR = nMR;      // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();
#endif

    init_timer();

    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01; // enable external reset

    Configure_ARM_MCU_ExtBus();

    // blink LEDs
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;
    Delay_x100ms(3);
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;

    // USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // ---------------- HI-8582 reset / detect -------------------
    statusReg = reset_3582();

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG; // LED ON
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%04X\r\n", statusReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG; // LED OFF
        printf("*** Part Not Detected, Status Reg Invalid = 0x%04X ***\r\n", statusReg);
        controlReg = readControlWord();
        printf("Control Word = 0x%04X\r\n", controlReg);
        printf("Check +10V/-10V supplies. Status should be 0x0040.\r\n");
        for (;;) { }
    }

    // ---------------- Device configuration -------------------
    writeControlWord(DEFAULTCONFG);

    // For capstone: accept all RX (chip-side filters off)
    enableRec1_Labels(DISABLE);
    enableRec2_Labels(DISABLE);
    setRec_1Bit_9Bit10encoder(0, 0, 0); // disable SDI filtering on RX1

    enableTransmission();
    __enable_interrupt();

    // initial throttle: HIGH by default, with some initial tokens
    SetThrottleHigh();
    g_tokens = g_tokensMax;

    printf("Exercise 10: Capstone ARINC front-end over UART.\r\n");
    printf("Feed ARINC into RX1/RX2 to see R1/R2 lines.\r\n");
    printf("Use UART commands (press 'h') to control logging/filter/TX.\r\n\r\n");
    PrintHelp();
    PrintStatusPage();

    // ---------------- Main loop -------------------
    while (1) {
        unsigned short sr;

        // 1) Handle UART commands (non-blocking)
        while (USART_IsRxReady(BOARD_USART_BASE)) {
            char c = USART_GetChar(BOARD_USART_BASE);
            ProcessCmd(c);
        }

        // 2) RX streaming (read all available; log with throttle)
        while (receiver1DataAvailable()) {
            unsigned int w = readReceiverFIFO_1();
            g_rx1Words++;
            MaybeLogWord("R1", w);
        }

        while (receiver2DataAvailable()) {
            unsigned int w = readReceiverFIFO_2();
            g_rx2Words++;
            MaybeLogWord("R2", w);
        }

        // 3) TX generator (paced by g_txDelayTicks)
        //    We do a lightweight scheduler by using Delay_x100ms(1) ticks
        //    and a down-counter.
        static unsigned short txTick = 0;
        txTick++;

        if (g_txEnabled && (txTick >= g_txDelayTicks)) {
            txTick = 0;
            sr = readStatusRegister();

            if ((sr & TXNFULL) == 0) {
                disableTransmission();

                ArincTX.arincTXWord = 0x00000000;
                ArincTX.arincLable  = g_txLabel;
                ArincTX.arincByte[1]++; // increment counter

                writeTransmitterFIFO(ArincTX.arincTXWord);
                enableTransmission();
                // (We intentionally do NOT print every TX word to avoid UART flooding.
                //  Use 'p' to check TX settings, and analyzer to view TX.)
            }
        }

        // 4) Replenish throttle tokens every 100ms (token bucket)
        //    Also gives the CPU a predictable cadence.
        Delay_x100ms(1);

        if (g_tokens < g_tokensMax) {
            unsigned short newTokens = (unsigned short)(g_tokens + g_tokensAdd100ms);
            g_tokens = (newTokens > g_tokensMax) ? g_tokensMax : newTokens;
        }
    }
}
