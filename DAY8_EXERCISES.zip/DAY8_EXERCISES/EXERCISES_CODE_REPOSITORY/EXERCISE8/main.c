/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 8 – ARINC429 Logger with UART Command Filter
 *
 * This variant of the HI-8582 demo:
 *  - Configures HI-8582 as a pure ARINC429 receiver/logger (like Exercise 7).
 *  - Streams every received word from RX1 and RX2 over USART1.
 *  - Adds a simple UART command interface so an external host (PC or IMXRT1050)
 *    can enable/disable logging and select a label filter.
 *
 * UART settings: 115200 baud, 8 data bits, 1 stop bit, no parity.
 *
 * UART command summary (single-character commands):
 *   'h' or 'H' : show help
 *   'a' or 'A' : disable label filter (log ALL labels)
 *   '1'        : log ONLY label 0x01
 *   '2'        : log ONLY label 0x02
 *   '3'        : log ONLY label 0x03
 *   '4'        : log ONLY label 0x04
 *   's' or 'S' : stop logging (pause output)
 *   'r' or 'R' : resume logging
 *
 * UART output format (same as Exercise 7, but now subject to filter/logging):
 *   R1,<label_hex>,<sdi>,<word_hex>\r\n
 *   R2,<label_hex>,<sdi>,<word_hex>\r\n
 *
 * Where:
 *   <label_hex> = low 8 bits of the word (ARINC label, in hex)
 *   <sdi>       = bits 9..10 interpreted as SDI (0..3)
 *   <word_hex>  = full 32-bit internal ARINC word (hex)
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
// standard Atmel/IAR headers
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>
#include <usart/usart.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"  // also supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables & macros
//------------------------------------------------------------------------------
#define VER "1.0"

// Required by console.c (even though we do not use FIFO "full" mode here)
unsigned short EmptyOrFull = 0;

// Holt driver base pointer (from 3582A_83A_Driver.h)
const H3582 pH3582 = HI3582_BASE;

// From driver header (status after reset)
#ifndef SR_VALID_FROM_RESET
#define SR_VALID_FROM_RESET 0x0040
#endif

// Simple logging/filter state controlled by UART commands
static unsigned char g_loggingEnabled = 1;   // 1 = log RX words, 0 = pause
static unsigned char g_filterEnabled  = 0;   // 1 = only log selected label
static unsigned char g_filterLabel    = 0x00; // label to match when filter enabled

//------------------------------------------------------------------------------
//  Helper: extract label (low 8 bits) and SDI (bits 9/10) from internal word
//------------------------------------------------------------------------------
// Assumes DEFAULTCONFG uses UNSCRAMBLED ARINC format, so the internal
// 32-bit mapping is:
//   bits  0..7  : ARINC label (bits 1..8)
//   bits  8..9  : ARINC SDI   (bits 9..10)
//   bits 10..28 : ARINC data
//   bit  31     : parity
//------------------------------------------------------------------------------
static unsigned char GetLabelFromWord(unsigned int word)
{
    return (unsigned char)(word & 0xFFu);
}

static unsigned char GetSDIFromWord(unsigned int word)
{
    return (unsigned char)((word >> 8) & 0x03u);  // bits 8..9
}

//------------------------------------------------------------------------------
//  Helper: brief status/control dump at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("Receiver FIFO Status bits:\r\n");
    printf("  SR0 (0x0001) RX1 data ready     : %s\r\n",
           (statusReg & 0x0001) ? "YES (RX1 FIFO has data)" : "no (RX1 empty)");
    printf("  SR3 (0x0008) RX2 data ready     : %s\r\n",
           (statusReg & 0x0008) ? "YES (RX2 FIFO has data)" : "no (RX2 empty)");

    printf("\r\nDefault RX/TX config (from Control Reg):\r\n");
    printf("  CR4 (0x0010) bit 32 function    : %s\r\n",
           (controlReg & 0x0010) ? "Parity bit (ARINC 32nd bit is parity)"
                                 : "Data bit (no parity bit)");
    printf("  CR12(0x1000) TX parity mode     : %s\r\n",
           (controlReg & 0x1000) ? "Even parity on bit 32"
                                 : "Odd parity on bit 32");
    printf("  CR13(0x2000) TX data rate       : %s\r\n",
           (controlReg & 0x2000) ? "LOW speed (CLK/80 ≈ 12.5 kbps)"
                                 : "HIGH speed (CLK/10 ≈ 100 kbps)");
    printf("  CR15(0x8000) data format        : %s\r\n",
           (controlReg & 0x8000) ? "Unscrambled ARINC (standard label/data layout)"
                                 : "Scrambled data\r\n");

    printf("\r\n");
}

//------------------------------------------------------------------------------
//  Helper: print UART command help
//------------------------------------------------------------------------------
static void PrintCommandHelp(void)
{
    printf("\r\nUART command interface (Exercise 8):\r\n");
    printf("  h/H : show this help\r\n");
    printf("  a/A : log ALL labels (disable filter)\r\n");
    printf("  1   : log ONLY label 0x01\r\n");
    printf("  2   : log ONLY label 0x02\r\n");
    printf("  3   : log ONLY label 0x03\r\n");
    printf("  4   : log ONLY label 0x04\r\n");
    printf("  s/S : stop logging (pause output)\r\n");
    printf("  r/R : resume logging\r\n\r\n");
    printf("Current state:\r\n");
    printf("  Logging      : %s\r\n", g_loggingEnabled ? "ENABLED" : "PAUSED");
    if (g_filterEnabled) {
        printf("  Label filter : ENABLED (Label = 0x%02X)\r\n", g_filterLabel);
    } else {
        printf("  Label filter : DISABLED (all labels logged)\r\n");
    }
    printf("\r\n");
}

//------------------------------------------------------------------------------
//  Helper: process a single UART command character
//------------------------------------------------------------------------------
static void ProcessUartCommand(char c)
{
    if (c == '\r' || c == '\n') {
        return; // ignore line endings
    }

    switch (c) {
        case 'h':
        case 'H':
            PrintCommandHelp();
            break;

        case 'a':
        case 'A':
            g_filterEnabled = 0;
            printf("CMD: filter DISABLED – logging all labels.\r\n");
            break;

        case '1':
            g_filterEnabled = 1;
            g_filterLabel   = 0x01;
            printf("CMD: filter ENABLED – logging only Label 0x01.\r\n");
            break;

        case '2':
            g_filterEnabled = 1;
            g_filterLabel   = 0x02;
            printf("CMD: filter ENABLED – logging only Label 0x02.\r\n");
            break;

        case '3':
            g_filterEnabled = 1;
            g_filterLabel   = 0x03;
            printf("CMD: filter ENABLED – logging only Label 0x03.\r\n");
            break;

        case '4':
            g_filterEnabled = 1;
            g_filterLabel   = 0x04;
            printf("CMD: filter ENABLED – logging only Label 0x04.\r\n");
            break;

        case 's':
        case 'S':
            g_loggingEnabled = 0;
            printf("CMD: logging PAUSED.\r\n");
            break;

        case 'r':
        case 'R':
            g_loggingEnabled = 1;
            printf("CMD: logging RESUMED.\r\n");
            break;

        default:
            printf("CMD: unknown key '%c' (press 'h' for help).\r\n", c);
            break;
    }
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;
    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings (unused)
    (void)pinNSW2;

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (as in original Holt demo)
    // -------------------------------------------------------------------------

    // first priority: reset pin to 0 for nMR, then configure that MCU pin as output
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure ARM's other general purpose I/O pins and timer(s)
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure the message interrupt pin
#endif

    init_timer();

    // enable the MCU nRST external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize processor for selected interface to HI-8582 device
    Configure_ARM_MCU_ExtBus();

    // flash both green LEDs to signify initialization complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // Configure USART1 for console / UART logging
    ConfigureUsart1();
    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();                  // reset the 8582/8583
    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON  RSR is good
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%04X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF RSR is bad
        printf("*** Part Not Detected, Status Reg Invalid = 0x%04X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%04X\r\n", controlReg);
        printf("Check for +10V and -10V connected on the board.\r\n");
        printf("+10V enables the 5V power supply for the 8582.\r\n");
        printf("Status should be 0x0040. Try again and press Reset.\r\n");

        for (;;);                        // dead loop
    }

    // -------------------------------------------------------------------------
    // Apply default configuration for RX-only logger with UART command filter
    // -------------------------------------------------------------------------
    // DEFAULTCONFG (from driver header) typically selects:
    //  - Unscrambled ARINC
    //  - 32nd bit = parity
    //  - High-speed ARINC (100 kbps)
    //  - Odd parity
    //  - Normal mode (CR5=1)
    writeControlWord(DEFAULTCONFG);

    // Disable label tables on both RX1 and RX2 (log ALL labels)
    enableRec1_Labels(DISABLE);
    enableRec2_Labels(DISABLE);

    // Disable SDI decoder on RX1 (no SDI filtering)
    setRec_1Bit_9Bit10encoder(0, 0, 0);

    enableTransmission();      // keep TX block enabled (no explicit TX used here)
    __enable_interrupt();

    printf("Exercise 8: ARINC429 RX Logger with UART command filter.\r\n");
    printf("All RX1 and RX2 words will be streamed as CSV lines when logging is enabled:\r\n");
    printf("  R1,<label_hex>,<sdi>,<word_hex>\\r\\n\r\n");
    printf("  R2,<label_hex>,<sdi>,<word_hex>\\r\\n\r\n\r\n");
    printf("Use UART commands to control logging and label filter (press 'h' for help).\r\n\r\n");

    // Show initial help and state
    PrintCommandHelp();

    // -------------------------------------------------------------------------
    // Main loop:
    //   - Poll UART for commands (non-blocking).
    //   - Poll RX1 and RX2 FIFOs and log words according to current settings.
    // -------------------------------------------------------------------------
    while (1) {
        // 1) Check for incoming UART command characters (non-blocking)
        if (USART_IsRxReady(BOARD_USART_BASE)) {
            char c = USART_GetChar(BOARD_USART_BASE);
            ProcessUartCommand(c);
        }

        // 2) RX1: dump all available words (subject to logging/filter)
        while (receiver1DataAvailable()) {
            arincReceiver1Buffer = readReceiverFIFO_1();

            unsigned char label = GetLabelFromWord(arincReceiver1Buffer);
            unsigned char sdi   = GetSDIFromWord(arincReceiver1Buffer);

            if (g_loggingEnabled) {
                if (!g_filterEnabled || (label == g_filterLabel)) {
                    printf("R1,%02X,%u,%08X\r\n",
                           (unsigned int)label,
                           (unsigned int)sdi,
                           (unsigned int)arincReceiver1Buffer);
                }
            }
        }

        // 3) RX2: dump all available words (subject to logging/filter)
        while (receiver2DataAvailable()) {
            arincReceiver2Buffer = readReceiverFIFO_2();

            unsigned char label = GetLabelFromWord(arincReceiver2Buffer);
            unsigned char sdi   = GetSDIFromWord(arincReceiver2Buffer);

            if (g_loggingEnabled) {
                if (!g_filterEnabled || (label == g_filterLabel)) {
                    printf("R2,%02X,%u,%08X\r\n",
                           (unsigned int)label,
                           (unsigned int)sdi,
                           (unsigned int)arincReceiver2Buffer);
                }
            }
        }

        // No explicit delay: loop is tight to keep up with RX traffic.
        // If UART flooding becomes an issue, you may add a small Delay_x100ms(1)
        // here for training, at the cost of possibly missing some RX words.
    } // end while(1)
}
