/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 2 – Bit-rate & Parity Demo
 *
 * This version is derived from the Holt HI-8582 demo:
 *  - No menu / pushbutton logic
 *  - Continuous ARINC429 TX stream with RX1/RX2 loopback prints
 *  - Periodically changes TX/RX bit-rate and parity:
 *
 *      MODE 0: High-speed (100 kbps), 32nd bit = parity, ODD parity
 *      MODE 1: High-speed (100 kbps), 32nd bit = parity, EVEN parity
 *      MODE 2: Low-speed  (12.5 kbps), 32nd bit = parity, ODD parity
 *      MODE 3: Low-speed  (12.5 kbps), 32nd bit = parity, EVEN parity
 *
 * Trainee observations:
 *  - UART console (115200 8N1, ADK USART1):
 *      You will see:
 *        [MODE X ...] banners whenever config changes, and
 *        TX : 0xXXXXXXXX  Label: 0x01
 *        RX1: 0xXXXXXXXX  Label: 0x01
 *        RX2: 0xXXXXXXXX  Label: 0x01
 *      with the upper 16 bits in TX incrementing as a counter.
 *
 *  - ARINC analyzer (on HI-8582 TX A/B):
 *      Watch the bus as modes change every few seconds:
 *        - Bit rate toggles between 100 kbps and 12.5 kbps
 *        - Parity toggles Odd/Even (32nd bit)
 *
 * Hardware requirement:
 *  - HI-8582 TX output wired to RX1 and RX2 (loopback) so that RX1/RX2
 *    see the transmitted words.
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"    // supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables
//------------------------------------------------------------------------------
#define VER "1.0"

// From driver header (for RX speed bits)
#define CR0   (1u << 0)     // RX1 speed bit: 0 = high, 1 = low
#define CR14  (1u << 14)    // RX2 speed bit: 0 = high, 1 = low

// TX status bits (from driver header)
#define TXEMPTY  (1u << 6)
#define TXNFULL  (1u << 7)

// Not used in this minimal example but kept for compatibility
const H3582 pH3582 = HI3582_BASE;

//------------------------------------------------------------------------------
//  Helper: interpret bits we care about in Control register
//------------------------------------------------------------------------------
static void PrintParityAndSpeedFromControl(unsigned short controlReg)
{
    // CR4: 32nd bit parity/data
    printf("  CR4  (0x0010) bit 32 function : %s\r\n",
           (controlReg & 0x0010) ? "Parity bit (ARINC 32nd bit is parity)"
                                  : "Data bit (no parity bit)");

    // CR12: parity mode (0 = odd, 1 = even)
    printf("  CR12 (0x1000) TX parity       : %s\r\n",
           (controlReg & 0x1000) ? "EVEN parity on bit 32"
                                  : "ODD parity on bit 32");

    // CR13: TX speed (0 = high, 1 = low)
    printf("  CR13 (0x2000) TX data rate    : %s\r\n",
           (controlReg & 0x2000) ? "LOW speed (CLK/80 ≈ 12.5 kbps)"
                                  : "HIGH speed (CLK/10 ≈ 100 kbps)");

    // CR0/CR14: RX speeds (0 = high, 1 = low)
    printf("  CR0  (0x0001) RX1 data rate   : %s\r\n",
           (controlReg & CR0) ? "LOW speed (CLK/80 ≈ 12.5 kbps)"
                               : "HIGH speed (CLK/10 ≈ 100 kbps)");
    printf("  CR14 (0x4000) RX2 data rate   : %s\r\n",
           (controlReg & CR14) ? "LOW speed (CLK/80 ≈ 12.5 kbps)"
                                : "HIGH speed (CLK/10 ≈ 100 kbps)");
    printf("\r\n");
}

//------------------------------------------------------------------------------
//  Helper: one-time status/control print at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("Initial Control Register (DEFAULTCONFG) summary:\r\n");
    PrintParityAndSpeedFromControl(controlReg);
}

//------------------------------------------------------------------------------
//  Helper: configure TX/RX speed and parity via driver + manual CR bits
//
//  parityBit32   : 1 = bit 32 is parity, 0 = bit 32 is data
//  oddParity     : 1 = odd parity, 0 = even parity
//  highSpeed     : 1 = high-speed ARINC (100 kbps), 0 = low-speed (12.5 kbps)
//
//  This uses Holt's configureTransmitter() for TX bits and then explicitly
//  sets RX1/RX2 rate bits CR0/CR14 to match, so TX and RX operate at the
//  same data rate.
//------------------------------------------------------------------------------
static void SetTxRxConfig(unsigned short parityBit32,
                          unsigned short oddParity,
                          unsigned short highSpeed)
{
    unsigned short controlReg;

    // normal = 1 (normal operation, not self-test)
    // evenOddParity parameter: 1 = ODD, 0 = EVEN
    // txSpeed parameter      : 1 = HIGH, 0 = LOW
    configureTransmitter(parityBit32,       /* parityMode: 1 = parity, 0 = data */
                         1,                 /* normal operation */
                         oddParity,         /* 1 = odd parity, 0 = even */
                         highSpeed);        /* 1 = high speed, 0 = low */

    // Now adjust RX1/RX2 speed bits to match TX
    controlReg = readControlWord();

    if (highSpeed) {
        // Clear RX speed bits for high-speed
        controlReg &= (unsigned short)~CR0;    // RX1 high speed
        controlReg &= (unsigned short)~CR14;   // RX2 high speed
    } else {
        // Set RX speed bits for low-speed
        controlReg |= CR0;                     // RX1 low speed
        controlReg |= CR14;                    // RX2 low speed
    }

    writeControlWord(controlReg);

    // Print a short human-readable summary
    printf("\r\n===== NEW ARINC CONFIG =====\r\n");
    PrintParityAndSpeedFromControl(controlReg);
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // Simple ARINC word buffer as in Holt demo:
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };

    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;
    union arincBuffer32 ArincBuffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings (unused)
    (void)pinNSW2;

    // Mode variables for Exercise 2
    unsigned int modeIndex      = 0;    // 0..3
    unsigned int modeTick       = 0;    // counts 100ms ticks
    const unsigned int MODE_TICKS = 50; // ~5 seconds per mode (50 * 100ms)

    // -------------------------------------------------------------------------
    // Initial ARINC buffer contents
    // -------------------------------------------------------------------------
    // We will send a continuous stream of words with:
    //  - Label = 0x01
    //  - Upper 16 bits counting upwards (data field changes every word)
    //
    // Trainee: On the ARINC analyzer, you should see the label 0x01 and
    //          the data field increment for each word.
    //          On the UART console, the printed TX words should match.
    // -------------------------------------------------------------------------
    ArincBuffer.arincTXWord  = 0x87654300;
    ArincBuffer.arincByte[0] = 0x4311;  // arbitrary low 16-bit pattern
    ArincBuffer.arincByte[1] = 0x0000;  // we increment upper 16 bits only
    ArincBuffer.arincLable   = 0x01;    // set label last so it overwrites low byte

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (unchanged from Holt demo)
    // -------------------------------------------------------------------------

    // Assert nMR low to reset HI-8582, then configure the pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure MCU GPIOs and timers
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure message interrupt pin (if used)
#endif

    init_timer();

    // Enable MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize external bus to talk to HI-8582
    Configure_ARM_MCU_ExtBus();

    // Flash both green LEDs to indicate init complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // UART console on USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset HI-8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LED ON (device detected)
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%.4X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LED OFF (device NOT detected)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%.4X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\r\n", controlReg);
        printf("Check for +10V and -10V on the board.\r\n");
        printf("These enable the 5V supply for the 8582.\r\n");
        printf("Status should be 0x0040. Press Reset after fixing power.\r\n");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default configuration then override with Exercise 2 mode 0
    // -------------------------------------------------------------------------
    writeControlWord(DEFAULTCONFG);  // baseline config from Holt demo

    enableTransmission();
    __enable_interrupt();

    // Exercise 2 starts in MODE 0:
    //   High-speed, bit 32 = parity, ODD parity
    //   RX1/RX2 speeds are set to match TX
    SetTxRxConfig(1, 1, 1);          // parityBit32=1, odd=1, highSpeed=1

    printf("Exercise 2: Bit-rate & Parity demo (modes rotate every ~5 seconds).\r\n");
    printf("HI-8582 TX must be wired to RX1/RX2 and ARINC analyzer.\r\n\r\n");

    // -------------------------------------------------------------------------
    // Main loop:
    //   1) Continuously load TX FIFO when not full.
    //   2) Continuously drain RX1/RX2 FIFOs and print any received words.
    //   3) Every MODE_TICKS (~5s), switch to the next mode:
    //        0: High-speed,  ODD parity
    //        1: High-speed,  EVEN parity
    //        2: Low-speed,   ODD parity
    //        3: Low-speed,   EVEN parity
    //
    // Trainee:
    //   - Watch UART banners when mode changes and match them to analyzer
    //     readings: data rate and parity changes on TX bus.
    // -------------------------------------------------------------------------
    while (1) {
        // 1) Transmit path: load TX FIFO whenever it is not full
        if ((readStatusRegister() & TXNFULL) == 0) {
            disableTransmission();

            // Queue current word
            writeTransmitterFIFO(ArincBuffer.arincTXWord);

            // Print what we just queued
            printf("TX : 0x%.8X  Label: 0x%.2X\r\n",
                   ArincBuffer.arincTXWord,
                   ArincBuffer.arincTXWord & 0xFF);

            // Increment upper 16 bits (data field) for next word
            ArincBuffer.arincByte[1]++;

            enableTransmission();
        }

        // 2) Receiver 1: dump all received words
        while (receiver1DataAvailable()) {
            arincReceiver1Buffer = readReceiverFIFO_1();
            printf("RX1: 0x%.8X  Label: 0x%.2X\r\n",
                   arincReceiver1Buffer,
                   arincReceiver1Buffer & 0xFF);
        }

        // 3) Receiver 2: dump all received words
        while (receiver2DataAvailable()) {
            arincReceiver2Buffer = readReceiverFIFO_2();
            printf("RX2: 0x%.8X  Label: 0x%.2X\r\n",
                   arincReceiver2Buffer,
                   arincReceiver2Buffer & 0xFF);
        }

        // 4) Mode timing: every MODE_TICKS * 100ms, rotate configuration
        Delay_x100ms(1);   // ~100 ms
        modeTick++;

        if (modeTick >= MODE_TICKS) {
            modeTick = 0;
            modeIndex = (modeIndex + 1) & 0x3;  // 0..3 cyclic

            switch (modeIndex) {
                case 0:
                    printf("\r\n*** MODE 0: HIGH speed, bit32=PARITY, ODD parity ***\r\n");
                    SetTxRxConfig(1, 1, 1);
                    break;
                case 1:
                    printf("\r\n*** MODE 1: HIGH speed, bit32=PARITY, EVEN parity ***\r\n");
                    SetTxRxConfig(1, 0, 1);
                    break;
                case 2:
                    printf("\r\n*** MODE 2: LOW speed, bit32=PARITY, ODD parity ***\r\n");
                    SetTxRxConfig(1, 1, 0);
                    break;
                case 3:
                default:
                    printf("\r\n*** MODE 3: LOW speed, bit32=PARITY, EVEN parity ***\r\n");
                    SetTxRxConfig(1, 0, 0);
                    break;
            }
        }
    } // end while(1)
}
