/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 3 – Label Recognition Demo
 *
 * This version is derived from the Holt HI-8582 demo:
 *  - No menu / pushbutton logic
 *  - Continuous ARINC429 TX stream with RX1/RX2 loopback prints
 *  - Uses HI-8582 label tables so RX1 and RX2 see different subsets of labels
 *
 * Transmit pattern:
 *   TX labels cycle: 0x01 -> 0x02 -> 0x03 -> 0x04 -> repeat...
 *
 * Label filter configuration:
 *   RX1 Label Table:
 *     - Accepts labels 0x01 and 0x03
 *   RX2 Label Table:
 *     - Accepts labels 0x02 and 0x04
 *
 * Trainee observations:
 *  - ARINC Analyzer (on HI-8582 TX A/B):
 *      You should see ALL labels 0x01, 0x02, 0x03, 0x04 on the bus,
 *      at high-speed ARINC (100 kbps, odd parity, 32nd bit = parity).
 *
 *  - UART console (115200 8N1, ADK USART1):
 *      TX : 0xXXXXXXXX  Label: 0x01
 *      RX1: 0xXXXXXXXX  Label: 0x01   <-- RX1 sees only 0x01 and 0x03
 *      RX2: 0xXXXXXXXX  Label: 0x02   <-- RX2 sees only 0x02 and 0x04
 *      ...
 *
 * This clearly demonstrates that HI-8582 LABEL RECOGNITION filters which
 * ARINC words reach each receiver FIFO, even though the bus carries all labels.
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"    // supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables
//------------------------------------------------------------------------------
#define VER "1.0"

// External label tables defined in 3582A_83A_Driver.c
extern unsigned char LabelArray_R1[16];    // Receiver-1 label table
extern unsigned char LabelArray_R2[16];    // Receiver-2 label table

// Not used in this minimal example but kept for compatibility
const H3582 pH3582 = HI3582_BASE;

//------------------------------------------------------------------------------
// Helper: interpret subset of Control register bits
//------------------------------------------------------------------------------
static void PrintControlLabelBits(unsigned short controlReg)
{
    // CR2 & CR3 – Label recognition enables
    printf("  CR2 (0x0004) RX1 label filter : %s\r\n",
           (controlReg & CR2) ? "ENABLED (uses 16-label table)" :
                                "disabled (accepts all labels)");
    printf("  CR3 (0x0008) RX2 label filter : %s\r\n",
           (controlReg & CR3) ? "ENABLED (uses 16-label table)" :
                                "disabled (accepts all labels)");

    // CR4 – 32nd bit parity vs data
    printf("  CR4 (0x0010) bit 32 function  : %s\r\n",
           (controlReg & CR4) ? "Parity bit (ARINC 32nd bit is parity)" :
                                "Data bit (no parity bit)");

    // CR12 – parity odd/even
    printf("  CR12(0x1000) TX parity mode   : %s\r\n",
           (controlReg & CR12) ? "EVEN parity on bit 32" :
                                 "ODD parity on bit 32");

    // CR13 – TX data rate
    printf("  CR13(0x2000) TX data rate     : %s\r\n",
           (controlReg & CR13) ? "LOW speed (CLK/80 ≈ 12.5 kbps)" :
                                 "HIGH speed (CLK/10 ≈ 100 kbps)");

    // CR15 – data format scrambling
    printf("  CR15(0x8000) data format      : %s\r\n",
           (controlReg & CR15) ? "Unscrambled ARINC (standard label/data layout)" :
                                 "Scrambled data\r\n");

    printf("\r\n");
}

//------------------------------------------------------------------------------
// Helper: one-time status/control print at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("Initial Control Register (DEFAULTCONFG) summary:\r\n");
    PrintControlLabelBits(controlReg);
}

//------------------------------------------------------------------------------
// Helper: configure label tables for Exercise 3
//
// RX1: accepts labels 0x01 and 0x03
// RX2: accepts labels 0x02 and 0x04
//
// All other entries are set to 0x00 so they do not match our test labels.
//------------------------------------------------------------------------------
static void ConfigureLabelTables_Exercise3(void)
{
    int i;

    // Clear both tables first
    for (i = 0; i < 16; i++) {
        LabelArray_R1[i] = 0x00;
        LabelArray_R2[i] = 0x00;
    }

    // RX1 label table: allow 0x01 and 0x03
    LabelArray_R1[0] = 0x01;
    LabelArray_R1[1] = 0x03;

    // RX2 label table: allow 0x02 and 0x04
    LabelArray_R2[0] = 0x02;
    LabelArray_R2[1] = 0x04;

    // Load into HI-8582 internal label RAMs
    loadReceiver_1_Labels();
    loadReceiver_2_Labels();

    // Enable label recognition for both receivers
    enableRec1_Labels(ENABLE);
    enableRec2_Labels(ENABLE);

    // Print tables for trainees
    printf("Receiver-1 Label Table (R1 accepts ONLY these labels):\r\n");
    for (i = 0; i < 16; i++) {
        printf("  R1[%2d] = 0x%02X\r\n", i, LabelArray_R1[i]);
    }
    printf("\r\n");

    printf("Receiver-2 Label Table (R2 accepts ONLY these labels):\r\n");
    for (i = 0; i < 16; i++) {
        printf("  R2[%2d] = 0x%02X\r\n", i, LabelArray_R2[i]);
    }
    printf("\r\n");

    printf("=> EXPECTATION:\r\n");
    printf("   - RX1 will only output labels 0x01 and 0x03.\r\n");
    printf("   - RX2 will only output labels 0x02 and 0x04.\r\n");
    printf("   - ARINC bus (analyzer) will see ALL labels 0x01..0x04.\r\n\r\n");
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // Simple ARINC word buffer as in Holt demo:
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };

    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;
    union arincBuffer32 ArincBuffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    // Labels to cycle on TX: 0x01, 0x02, 0x03, 0x04
    const unsigned char txLabels[4] = { 0x01, 0x02, 0x03, 0x04 };
    unsigned int        txLabelIndex = 0;

    (void)pinNSW1; // avoid compiler warnings (unused)
    (void)pinNSW2;

    // -------------------------------------------------------------------------
    // Initial ARINC buffer contents
    // -------------------------------------------------------------------------
    // We will send a continuous stream of words with:
    //  - Label cycling through 0x01,0x02,0x03,0x04
    //  - Upper 16 bits counting upwards (data field changes every word)
    //
    // Trainee:
    //  - On ARINC analyzer: you should see all four labels on the bus.
    //  - On UART: you see TX of all labels, but RX1 only for 0x01/0x03 and
    //             RX2 only for 0x02/0x04.
    // -------------------------------------------------------------------------
    ArincBuffer.arincTXWord  = 0x00000000;
    ArincBuffer.arincByte[0] = 0x0000;
    ArincBuffer.arincByte[1] = 0x0000;  // upper 16 bits as counter
    ArincBuffer.arincLable   = txLabels[0];

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (unchanged from Holt demo)
    // -------------------------------------------------------------------------

    // Assert nMR low to reset HI-8582, then configure the pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure MCU GPIOs and timers
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure message interrupt pin (if used)
#endif

    init_timer();

    // Enable MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize external bus to talk to HI-8582
    Configure_ARM_MCU_ExtBus();

    // Flash both green LEDs to indicate init complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // UART console on USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset HI-8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LED ON (device detected)
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%.4X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LED OFF (device NOT detected)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%.4X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\r\n", controlReg);
        printf("Check for +10V and -10V on the board.\r\n");
        printf("These enable the 5V supply for the 8582.\r\n");
        printf("Status should be 0x0040. Press Reset after fixing power.\r\n");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default configuration and enable label recognition
    // -------------------------------------------------------------------------
    writeControlWord(DEFAULTCONFG);  // baseline config: high-speed, odd parity, unscrambled
    enableTransmission();
    __enable_interrupt();

    // Configure label tables and enable label filters
    ConfigureLabelTables_Exercise3();

    printf("Exercise 3: Label Recognition demo.\r\n");
    printf("TX labels: 0x01, 0x02, 0x03, 0x04 (cycling).\r\n");
    printf("RX1 accepts labels 0x01 and 0x03 only.\r\n");
    printf("RX2 accepts labels 0x02 and 0x04 only.\r\n\r\n");
    printf("Connect HI-8582 TX A/B to RX1 A/B and RX2 A/B and ARINC analyzer.\r\n\r\n");

    // -------------------------------------------------------------------------
    // Main loop:
    //   1) Whenever TX FIFO is not full, transmit next label in the sequence.
    //   2) Continuously read RX1/RX2 FIFOs and print any received words.
    //
    // Trainee:
    //   - On UART:
    //       TX : shows ALL labels 0x01..0x04.
    //       RX1: shows ONLY labels 0x01 and 0x03.
    //       RX2: shows ONLY labels 0x02 and 0x04.
    //   - On analyzer: see all four labels on the bus.
    // -------------------------------------------------------------------------
    while (1) {
        // 1) Transmit path: load TX FIFO when not full
        if ((readStatusRegister() & TXNFULL) == 0) {
            // Build the next ARINC word:
            //  - label from txLabels[]
            //  - upper 16 bits as an incrementing counter
            ArincBuffer.arincTXWord = 0x00000000;
            ArincBuffer.arincLable  = txLabels[txLabelIndex];
            ArincBuffer.arincByte[1]++;   // increment data counter

            // Cycle label index 0..3
            txLabelIndex = (txLabelIndex + 1) & 0x3;

            disableTransmission();
            writeTransmitterFIFO(ArincBuffer.arincTXWord);

            printf("TX : 0x%.8X  Label: 0x%.2X\r\n",
                   ArincBuffer.arincTXWord,
                   ArincBuffer.arincTXWord & 0xFF);

            enableTransmission();
        }

        // 2) Receiver 1: dump all received words (only labels in its table)
        while (receiver1DataAvailable()) {
            arincReceiver1Buffer = readReceiverFIFO_1();
            printf("RX1: 0x%.8X  Label: 0x%.2X\r\n",
                   arincReceiver1Buffer,
                   arincReceiver1Buffer & 0xFF);
        }

        // 3) Receiver 2: dump all received words (only labels in its table)
        while (receiver2DataAvailable()) {
            arincReceiver2Buffer = readReceiverFIFO_2();
            printf("RX2: 0x%.8X  Label: 0x%.2X\r\n",
                   arincReceiver2Buffer,
                   arincReceiver2Buffer & 0xFF);
        }

        // Small delay so console is readable and not flooded
        Delay_x100ms(1);   // ~100 ms
    } // end while(1)
}
