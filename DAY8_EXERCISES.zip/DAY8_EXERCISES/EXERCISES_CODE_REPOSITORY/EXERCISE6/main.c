/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 6 – Self-Test Mode & Simple BITE
 *
 * This exercise demonstrates:
 *  - NORMAL mode (CR5 = 1): TX → external ARINC bus → RX1/RX2
 *  - SELF-TEST mode (CR5 = 0): TX digital data internally looped to RX1/RX2
 *
 * Behaviour:
 *  - Transmits a continuous ARINC429 stream:
 *      Label = 0x01
 *      Data  = 16-bit counter (upper 16 bits)
 *  - Every ~5 seconds, toggles:
 *      NORMAL  → SELF-TEST → NORMAL → ...
 *  - For each mode it:
 *      * Counts RX1 and RX2 words
 *      * Counts simple “errors” (label != 0x01)
 *      * Prints a summary when the mode changes (simple BITE result)
 *
 * Trainee observations:
 *  - UART (115200 8N1, ADK USART1):
 *      Shows mode banners, TX words and RX1/RX2 words tagged with (NORM) or (SELF).
 *      At each mode switch, prints a summary:
 *        >>> Mode NORMAL summary: RX1=..., RX2=..., Errors=...
 *        >>> Mode SELF-TEST summary: RX1=..., RX2=..., Errors=...
 *
 *  - ARINC analyzer (HI-8582 TX A/B):
 *      Sees a continuous stream of label 0x01 in both modes.
 *      If you disconnect TX from RX1/RX2:
 *        - In NORMAL mode: RX1/RX2 see nothing.
 *        - In SELF-TEST mode: RX1/RX2 still see data (internal loopback).
 *
 * Hardware requirement:
 *  - HI-8582 TX output wired to RX1 and RX2 (for NORMAL mode demo).
 *    For SELF-TEST, wiring is optional (digital loopback is internal).
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"    // supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables & macros
//------------------------------------------------------------------------------
#define VER "1.0"

// From 3582A_83A_Driver.h:
#define MODE_NORMAL    0
#define MODE_SELFTEST  1

// TX status bits (from 3582A_83A_Driver.h)
#ifndef TXEMPTY
#define TXEMPTY (1u << 6)
#endif

#ifndef TXNFULL
#define TXNFULL (1u << 7)
#endif

// Control register bit for self-test/normal (from driver header)
#ifndef CR5
#define CR5 (1u << 5)
#endif

// From driver header (status after reset)
#ifndef SR_VALID_FROM_RESET
#define SR_VALID_FROM_RESET 0x0040
#endif

// Holt driver base pointer
const H3582 pH3582 = HI3582_BASE;

// Current operating mode
static unsigned short g_currentMode = MODE_NORMAL;

// Per-mode counters (reset when entering each mode)
static unsigned long g_rx1Count = 0;
static unsigned long g_rx2Count = 0;
static unsigned long g_errCount = 0;

// Mode timing: toggle between NORMAL / SELF-TEST every ~5 seconds
static unsigned int g_modeTick       = 0;
static const unsigned int MODE_TICKS = 50;   // 50 * 100ms ≈ 5 s

//------------------------------------------------------------------------------
//  Helper: brief status/control dump at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("TX-related Status bits:\r\n");
    printf("  SR6 (0x0040) TX FIFO empty      : %s\r\n",
           (statusReg & 0x0040) ? "YES (no words pending)" : "no");
    printf("  SR7 (0x0080) TX FIFO not full   : %s\r\n",
           (statusReg & 0x0080) ? "YES (space available)"  : "no (TX FIFO full)");
    printf("  SR8 (0x0100) TX FIFO half-full  : %s\r\n",
           (statusReg & 0x0100) ? "YES (>=16 words loaded)" : "no (<16 words)");

    printf("\r\nSelf-Test / Normal Control bit (CR5):\r\n");
    printf("  CR5 (0x0020) self-test/normal   : %s\r\n",
           (controlReg & CR5) ? "Normal operation (RX1/RX2 use external ARINC bus)"
                              : "Self-test (TX digital data internally looped to RX1/RX2)");
    printf("\r\n");
}

//------------------------------------------------------------------------------
//  Helper: print a short status line each loop (optional but nice for training)
//------------------------------------------------------------------------------
static void PrintStatusShort(unsigned short statusReg)
{
    printf("SR=0x%04X  [RX1:%s%s%s RX2:%s%s%s TX:%s%s%s]\r\n",
           statusReg,
           (statusReg & 0x0001) ? "D" : "-",
           (statusReg & 0x0002) ? "H" : "-",
           (statusReg & 0x0004) ? "F" : "-",
           (statusReg & 0x0008) ? "D" : "-",
           (statusReg & 0x0010) ? "H" : "-",
           (statusReg & 0x0020) ? "F" : "-",
           (statusReg & 0x0040) ? "E" : "-",
           (statusReg & 0x0080) ? "N" : "-",
           (statusReg & 0x0100) ? "H" : "-");
    // Legend:
    //   RX1: D = Data, H = Half-full, F = Full
    //   RX2: D = Data, H = Half-full, F = Full
    //   TX : E = Empty, N = Not full, H = Half-full
}

//------------------------------------------------------------------------------
//  Helper: set HI-8582 into NORMAL or SELF-TEST mode by manipulating CR5
//------------------------------------------------------------------------------
static void EnterMode(unsigned short newMode)
{
    unsigned short controlReg = readControlWord();

    if (newMode == MODE_SELFTEST) {
        // Clear CR5 → self-test mode
        controlReg &= (unsigned short)~CR5;
        writeControlWord(controlReg);

        printf("\r\n=== ENTERING SELF-TEST MODE (CR5=0) ===\r\n");
        printf("TX digital data is internally looped into RX1/RX2.\r\n");
        printf("External ARINC wiring is no longer required for RX traffic.\r\n\r\n");
    } else {
        // Set CR5 → normal operation
        controlReg |= CR5;
        writeControlWord(controlReg);

        printf("\r\n=== ENTERING NORMAL MODE (CR5=1) ===\r\n");
        printf("RX1/RX2 now use the external ARINC bus.\r\n");
        printf("Ensure HI-8582 TX A/B are wired to RX1/RX2 and analyzer.\r\n\r\n");
    }

    g_currentMode = newMode;
    g_modeTick    = 0;

    // Reset per-mode counters (fresh BITE run each time)
    g_rx1Count = 0;
    g_rx2Count = 0;
    g_errCount = 0;
}

//------------------------------------------------------------------------------
//  Helper: simple BITE-style summary for the mode we are leaving
//------------------------------------------------------------------------------
static void PrintModeSummary(unsigned short mode)
{
    const char *modeName = (mode == MODE_SELFTEST) ? "SELF-TEST" : "NORMAL";

    printf("\r\n>>> Mode %s summary: RX1=%lu, RX2=%lu, Errors=%lu\r\n",
           modeName,
           g_rx1Count,
           g_rx2Count,
           g_errCount);

    if (g_errCount == 0 && (g_rx1Count + g_rx2Count) > 0) {
        printf(">>> Mode %s BITE RESULT: PASS\r\n", modeName);
    } else if ((g_rx1Count + g_rx2Count) == 0) {
        printf(">>> Mode %s BITE RESULT: NO DATA (check wiring / analyzer)\r\n",
               modeName);
    } else {
        printf(">>> Mode %s BITE RESULT: FAIL (non-0x01 labels or anomalies seen)\r\n",
               modeName);
    }
    printf("\r\n");
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // Simple ARINC word buffer as in other exercises:
    //  - arincTXWord : full 32-bit word
    //  - arincByte[0]: low 16 bits
    //  - arincByte[1]: high 16 bits (we use this as a counter)
    //  - arincLable  : alias for low 8 bits (label)
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };

    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;
    union arincBuffer32 ArincBuffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings
    (void)pinNSW2;

    // -------------------------------------------------------------------------
    // Initial ARINC buffer contents
    // -------------------------------------------------------------------------
    // We will send a continuous stream of words with:
    //  - Label fixed at 0x01
    //  - Upper 16 bits counting upwards (data field)
    //
    // Trainee:
    //  - ARINC analyzer: label 0x01, data field increments each word.
    //  - UART:
    //      TX(NORM) / TX(SELF) lines show the pattern.
    //      RX1/2 show whether self-test or external bus is feeding data.
    // -------------------------------------------------------------------------
    ArincBuffer.arincTXWord  = 0x00000000;
    ArincBuffer.arincByte[0] = 0x0000;
    ArincBuffer.arincByte[1] = 0x0000;  // upper 16 bits as counter
    ArincBuffer.arincLable   = 0x01;    // label in low byte

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (as in original Holt demo)
    // -------------------------------------------------------------------------

    // Assert nMR low to reset HI-8582, then configure that pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure MCU GPIOs and timers
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure message interrupt pin (if used)
#endif

    init_timer();

    // Enable MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize external bus to talk to HI-8582
    Configure_ARM_MCU_ExtBus();

    // Flash both green LEDs to indicate init complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300 ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // UART console on USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset HI-8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LED ON (device detected)
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%.4X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LED OFF (device NOT detected)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%.4X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\r\n", controlReg);
        printf("Check for +10V and -10V on the board.\r\n");
        printf("These enable the 5V supply for the 8582.\r\n");
        printf("Status should be 0x0040. Press Reset after fixing power.\r\n");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default configuration and enable TX
    // -------------------------------------------------------------------------
    // DEFAULTCONFG (from driver header) typically selects:
    //  - Unscrambled ARINC
    //  - 32nd bit = parity
    //  - High-speed ARINC (100 kbps)
    //  - Odd parity
    //  - CR5 = 1 → NORMAL mode initially
    writeControlWord(DEFAULTCONFG);

    enableTransmission();
    __enable_interrupt();

    printf("Exercise 6: Self-Test Mode & Simple BITE.\r\n");
    printf("TX label fixed at 0x01, data = incrementing counter.\r\n");
    printf("Modes alternate every ~5 seconds:\r\n");
    printf("  NORMAL   : RX1/RX2 use external ARINC bus (CR5=1).\r\n");
    printf("  SELF-TEST: TX digital data internally looped to RX1/RX2 (CR5=0).\r\n\r\n");
    printf("Use the ARINC analyzer and UART console together to see the effect.\r\n\r\n");

    // Start in NORMAL mode explicitly (even though DEFAULTCONFG already set CR5=1)
    EnterMode(MODE_NORMAL);

    // -------------------------------------------------------------------------
    // Main loop:
    //   - Transmit whenever TX FIFO is not full.
    //   - Continuously read RX1/RX2, classify by current mode, check label.
    //   - After MODE_TICKS (~5 s), print summary and toggle mode.
    // -------------------------------------------------------------------------
    while (1) {
        unsigned short sr;

        // 1) Read & print status register (helps visualize FIFO usage)
        sr = readStatusRegister();
        PrintStatusShort(sr);

        // 2) Transmit path: load TX FIFO whenever it is not full
        if ((sr & TXNFULL) == 0) {
            disableTransmission();

            // Build next ARINC word:
            //  - label fixed at 0x01
            //  - upper 16 bits as incrementing counter
            ArincBuffer.arincTXWord = 0x00000000;
            ArincBuffer.arincLable  = 0x01;       // label in low 8 bits
            ArincBuffer.arincByte[1]++;           // increment data counter

            writeTransmitterFIFO(ArincBuffer.arincTXWord);

            if (g_currentMode == MODE_NORMAL) {
                printf("TX(NORM) : 0x%.8X  Label: 0x%.2X\r\n",
                       ArincBuffer.arincTXWord,
                       ArincBuffer.arincTXWord & 0xFF);
            } else {
                printf("TX(SELF) : 0x%.8X  Label: 0x%.2X\r\n",
                       ArincBuffer.arincTXWord,
                       ArincBuffer.arincTXWord & 0xFF);
            }

            enableTransmission();
        }

        // 3) Receiver 1: dump all received words and check label
        while (receiver1DataAvailable()) {
            unsigned int rxWord = readReceiverFIFO_1();
            unsigned char rxLabel = (unsigned char)(rxWord & 0xFFu);

            g_rx1Count++;
            if (rxLabel != 0x01u) {
                g_errCount++;
            }

            if (g_currentMode == MODE_NORMAL) {
                printf("RX1(NORM): 0x%.8X  Label: 0x%.2X\r\n",
                       rxWord, rxLabel);
            } else {
                printf("RX1(SELF): 0x%.8X  Label: 0x%.2X\r\n",
                       rxWord, rxLabel);
            }
        }

        // 4) Receiver 2: dump all received words and check label
        while (receiver2DataAvailable()) {
            unsigned int rxWord = readReceiverFIFO_2();
            unsigned char rxLabel = (unsigned char)(rxWord & 0xFFu);

            g_rx2Count++;
            if (rxLabel != 0x01u) {
                g_errCount++;
            }

            if (g_currentMode == MODE_NORMAL) {
                printf("RX2(NORM): 0x%.8X  Label: 0x%.2X\r\n",
                       rxWord, rxLabel);
            } else {
                printf("RX2(SELF): 0x%.8X  Label: 0x%.2X\r\n",
                       rxWord, rxLabel);
            }
        }

        // 5) Delay so console is readable and allow FIFOs to evolve a bit
        Delay_x100ms(1);   // ~100 ms
        g_modeTick++;

        // 6) Periodically print summary and toggle mode
        if (g_modeTick >= MODE_TICKS) {
            // Print summary for the mode we are leaving
            PrintModeSummary(g_currentMode);

            // Toggle to the other mode
            if (g_currentMode == MODE_NORMAL) {
                EnterMode(MODE_SELFTEST);
            } else {
                EnterMode(MODE_NORMAL);
            }
        }
    } // end while(1)
}
