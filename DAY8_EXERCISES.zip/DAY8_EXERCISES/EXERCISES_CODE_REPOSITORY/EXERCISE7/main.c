/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 7 – ARINC429 Receiver Logger to UART
 *
 * This exercise turns the ADK8582 + HI-8582 into a simple ARINC429 sniffer:
 *
 *  - HI-8582 receives ARINC words on RX1 and RX2.
 *  - The firmware reads RX1/RX2 FIFOs and streams every word out over UART.
 *
 * UART output format (115200 8N1, ADK USART1):
 *   R1,<label_hex>,<sdi>,<word_hex>\r\n
 *   R2,<label_hex>,<sdi>,<word_hex>\r\n
 *
 * Where:
 *   <label_hex> = low 8 bits of the word (ARINC label, in hex)
 *   <sdi>       = bits 9..10 interpreted as SDI (0..3)
 *   <word_hex>  = full 32-bit internal ARINC word (hex)
 *
 * Trainee observations:
 *   - On the ARINC bus (via analyzer):
 *       Observe labels and data from an external ARINC source (or another board).
 *   - On UART:
 *       See R1/R2 lines corresponding to every word received by HI-8582.
 *       These lines can be captured/parsed by an IMXRT1050 or PC.
 *
 * Note:
 *   - This example does NOT transmit ARINC words; it acts as a pure receiver/
 *     logger. You should feed ARINC traffic into RX1/RX2 from an external
 *     source or another evaluation board.
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"    // supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables & macros
//------------------------------------------------------------------------------
#define VER "1.0"

// Holt driver base pointer (from 3582A_83A_Driver.h)
const H3582 pH3582 = HI3582_BASE;

// From driver header (status after reset)
#ifndef SR_VALID_FROM_RESET
#define SR_VALID_FROM_RESET 0x0040
#endif

// Convenience macros for RX status bits (for comments/debug)
#ifndef RX1_DATA_READY
#define RX1_DATA_READY  (1u << 0)
#endif
#ifndef RX2_DATA_READY
#define RX2_DATA_READY  (1u << 3)
#endif

//------------------------------------------------------------------------------
//  Helper: extract label (low 8 bits) and SDI (bits 9/10) from internal word
//------------------------------------------------------------------------------
// Assumes DEFAULTCONFG uses UNSCRAMBLED ARINC format, so the internal
// 32-bit mapping is:
//   bits  0..7  : ARINC label (bits 1..8)
//   bits  8..9  : ARINC SDI   (bits 9..10)
//   bits 10..28 : ARINC data
//   bit  31     : parity
//------------------------------------------------------------------------------
static unsigned char GetLabelFromWord(unsigned int word)
{
    return (unsigned char)(word & 0xFFu);
}

static unsigned char GetSDIFromWord(unsigned int word)
{
    return (unsigned char)((word >> 8) & 0x03u);  // bits 8..9
}

//------------------------------------------------------------------------------
//  Helper: brief status/control dump at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("Receiver FIFO Status bits:\r\n");
    printf("  SR0 (0x0001) RX1 data ready     : %s\r\n",
           (statusReg & 0x0001) ? "YES (RX1 FIFO has data)" : "no (RX1 empty)");
    printf("  SR3 (0x0008) RX2 data ready     : %s\r\n",
           (statusReg & 0x0008) ? "YES (RX2 FIFO has data)" : "no (RX2 empty)");

    printf("\r\nDefault RX/TX config (from Control Reg):\r\n");
    printf("  CR4 (0x0010) bit 32 function    : %s\r\n",
           (controlReg & 0x0010) ? "Parity bit (ARINC 32nd bit is parity)"
                                  : "Data bit (no parity bit)");
    printf("  CR12(0x1000) TX parity mode     : %s\r\n",
           (controlReg & 0x1000) ? "Even parity on bit 32"
                                  : "Odd parity on bit 32");
    printf("  CR13(0x2000) TX data rate       : %s\r\n",
           (controlReg & 0x2000) ? "LOW speed (CLK/80 ≈ 12.5 kbps)"
                                  : "HIGH speed (CLK/10 ≈ 100 kbps)");
    printf("  CR15(0x8000) data format        : %s\r\n",
           (controlReg & 0x8000) ? "Unscrambled ARINC (standard label/data layout)"
                                  : "Scrambled data\r\n");

    printf("\r\n");
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings (unused)
    (void)pinNSW2;

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (as in original Holt demo)
    // -------------------------------------------------------------------------

    // Assert nMR low to reset HI-8582, then configure that pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure MCU GPIOs and timers
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure message interrupt pin (if used)
#endif

    init_timer();

    // Enable MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize external bus to talk to HI-8582
    Configure_ARM_MCU_ExtBus();

    // Flash both green LEDs to indicate init complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // UART console on USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset HI-8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LED ON (device detected)
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%04X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LED OFF (device NOT detected)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%04X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%04X\r\n", controlReg);
        printf("Check for +10V and -10V on the board.\r\n");
        printf("These enable the 5V supply for the 8582.\r\n");
        printf("Status should be 0x0040. Press Reset after fixing power.\r\n");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default configuration for RX-only logger
    // -------------------------------------------------------------------------
    // DEFAULTCONFG (from driver header) typically selects:
    //  - Unscrambled ARINC
    //  - 32nd bit = parity
    //  - High-speed ARINC (100 kbps)
    //  - Odd parity
    //  - Normal mode (CR5=1)
    //
    // We explicitly:
    //  - Disable label recognition on RX1/RX2 (log ALL labels).
    //  - Disable SDI filtering on RX1 (accept all SDI values).
    // -------------------------------------------------------------------------
    writeControlWord(DEFAULTCONFG);

    // Disable label tables on both RX1 and RX2
    enableRec1_Labels(DISABLE);
    enableRec2_Labels(DISABLE);

    // Disable SDI decoder on RX1 (no SDI filtering)
    setRec_1Bit_9Bit10encoder(0, 0, 0);

    enableTransmission();      // TX block remains enabled (no explicit TX used here)
    __enable_interrupt();

    printf("Exercise 7: ARINC429 RX Logger to UART.\r\n");
    printf("All RX1 and RX2 words will be streamed as CSV lines:\r\n");
    printf("  R1,<label_hex>,<sdi>,<word_hex>\\r\\n\r\n");
    printf("  R2,<label_hex>,<sdi>,<word_hex>\\r\\n\r\n\r\n");
    printf("Feed ARINC traffic into RX1/RX2 (e.g., from external generator or another board).\r\n");
    printf("Connect USART1 to PC or IMXRT1050 LPUART to capture the log.\r\n\r\n");

    // -------------------------------------------------------------------------
    // Main loop:
    //   - Poll RX1 and RX2 FIFOs continuously.
    //   - For each received word:
    //       * Decode label and SDI.
    //       * Print a single CSV-style line over UART.
    //
    //   There is deliberately no delay so we can keep up with RX traffic as
    //   much as possible. In heavy bursts, RX FIFO may still overflow.
    // -------------------------------------------------------------------------
    while (1) {
        // RX1: dump all available words
        while (receiver1DataAvailable()) {
            arincReceiver1Buffer = readReceiverFIFO_1();

            unsigned char label = GetLabelFromWord(arincReceiver1Buffer);
            unsigned char sdi   = GetSDIFromWord(arincReceiver1Buffer);

            printf("R1,%02X,%u,%08X\r\n",
                   (unsigned int)label,
                   (unsigned int)sdi,
                   (unsigned int)arincReceiver1Buffer);
        }

        // RX2: dump all available words
        while (receiver2DataAvailable()) {
            arincReceiver2Buffer = readReceiverFIFO_2();

            unsigned char label = GetLabelFromWord(arincReceiver2Buffer);
            unsigned char sdi   = GetSDIFromWord(arincReceiver2Buffer);

            printf("R2,%02X,%u,%08X\r\n",
                   (unsigned int)label,
                   (unsigned int)sdi,
                   (unsigned int)arincReceiver2Buffer);
        }

        // Optional: you could add a small Delay_x100ms(1) here to reduce
        // UART flooding, at the risk of missing some RX words if traffic
        // is very heavy. For pure logging, we keep the loop tight.
    } // end while(1)
}
