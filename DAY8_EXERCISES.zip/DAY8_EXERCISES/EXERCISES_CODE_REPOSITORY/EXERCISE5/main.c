/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 5 – FIFO Behavior Demo
 *
 * This version is derived from the Holt HI-8582 demo:
 *  - No menu / pushbutton logic
 *  - Uses TX FIFO and RX1/RX2 FIFOs to illustrate:
 *      * "FULL FIFO" mode: fill TX FIFO, then drain all RX words
 *      * "EMPTY FIFO" mode: send one word when TX FIFO is empty, read one RX word
 *  - Automatically alternates between these two modes every ~5 seconds
 *
 * Transmit pattern:
 *   - Label fixed at 0x01
 *   - Upper 16 bits increment every word (data field)
 *
 * Modes:
 *   - FULL FIFO mode:
 *       - Continuously load TX FIFO while it is NOT full
 *       - Then read ALL available RX1/RX2 words
 *   - EMPTY FIFO mode:
 *       - Wait until TX FIFO is EMPTY
 *       - Load exactly ONE TX word
 *       - Read at most ONE word from RX1 and ONE from RX2
 *
 * Trainee observations:
 *  - UART console (115200 8N1, ADK USART1):
 *      [MODE] FULL FIFO ...
 *      TX(FULL) : 0xXXXXXXXX  Label: 0x01
 *      RX1(FULL): 0xXXXXXXXX  Label: 0x01
 *      RX2(FULL): 0xXXXXXXXX  Label: 0x01
 *      ...
 *      [MODE] EMPTY FIFO ...
 *      TX(EMPTY) : 0xXXXXXXXX  Label: 0x01
 *      RX1(EMPTY): 0xXXXXXXXX  Label: 0x01
 *      RX2(EMPTY): 0xXXXXXXXX  Label: 0x01
 *
 *  - ARINC analyzer (HI-8582 TX A/B):
 *      Continuous ARINC429 stream with label 0x01, high-speed, odd parity.
 *      The difference between modes is how the FIFOs are used, visible on UART.
 *
 * Hardware requirement:
 *  - HI-8582 TX output wired to RX1 and RX2 (loopback) so that the transmitted
 *    words appear on both receivers.
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"    // supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables
//------------------------------------------------------------------------------
#define VER "1.0"

// Global flag reused from original demo:
//   0 = "EMPTY FIFO" mode
//   1 = "FULL FIFO" mode
unsigned short EmptyOrFull = 0;

// Not used directly in this example but kept for compatibility
const H3582 pH3582 = HI3582_BASE;

// Mode timing: toggle between FULL / EMPTY every ~5 seconds
static unsigned int g_modeTick      = 0;
static const unsigned int MODE_TICKS = 50;   // 50 * 100ms = ~5s

//------------------------------------------------------------------------------
//  Helper: brief status/control dump at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("TX-related Status bits:\r\n");
    printf("  SR6 (0x0040) TX FIFO empty      : %s\r\n",
           (statusReg & 0x0040) ? "YES (no words pending)" : "no");
    printf("  SR7 (0x0080) TX FIFO not full   : %s\r\n",
           (statusReg & 0x0080) ? "YES (space available)"  : "no (TX FIFO full)");
    printf("  SR8 (0x0100) TX FIFO half-full  : %s\r\n",
           (statusReg & 0x0100) ? "YES (>=16 words loaded)" : "no (<16 words)");

    printf("\r\nRX1 FIFO-related Status bits:\r\n");
    printf("  SR0 (0x0001) RX1 data ready     : %s\r\n",
           (statusReg & 0x0001) ? "YES (RX1 FIFO has data)" : "no (RX1 empty)");
    printf("  SR1 (0x0002) RX1 half-full      : %s\r\n",
           (statusReg & 0x0002) ? "YES (>=16 words in RX1 FIFO)" : "no (<16 words)");
    printf("  SR2 (0x0004) RX1 full           : %s\r\n",
           (statusReg & 0x0004) ? "YES (RX1 FIFO full, possible overwrite)" : "no");

    printf("\r\nRX2 FIFO-related Status bits:\r\n");
    printf("  SR3 (0x0008) RX2 data ready     : %s\r\n",
           (statusReg & 0x0008) ? "YES (RX2 FIFO has data)" : "no (RX2 empty)");
    printf("  SR4 (0x0010) RX2 half-full      : %s\r\n",
           (statusReg & 0x0010) ? "YES (>=16 words in RX2 FIFO)" : "no (<16 words)");
    printf("  SR5 (0x0020) RX2 full           : %s\r\n",
           (statusReg & 0x0020) ? "YES (RX2 FIFO full, possible overwrite)" : "no");

    printf("\r\n");
}

//------------------------------------------------------------------------------
//  Helper: print a concise status line each loop (for training)
//------------------------------------------------------------------------------
static void PrintStatusShort(unsigned short statusReg)
{
    printf("SR=0x%04X  [RX1:%s%s%s RX2:%s%s%s TX:%s%s%s]\r\n",
           statusReg,
           (statusReg & 0x0001) ? "D" : "-",
           (statusReg & 0x0002) ? "H" : "-",
           (statusReg & 0x0004) ? "F" : "-",
           (statusReg & 0x0008) ? "D" : "-",
           (statusReg & 0x0010) ? "H" : "-",
           (statusReg & 0x0020) ? "F" : "-",
           (statusReg & 0x0040) ? "E" : "-",
           (statusReg & 0x0080) ? "N" : "-",
           (statusReg & 0x0100) ? "H" : "-");
    // Legend:
    //   RX1: D = Data, H = Half-full, F = Full
    //   RX2: D = Data, H = Half-full, F = Full
    //   TX : E = Empty, N = Not full, H = Half-full
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // Simple ARINC word buffer as in Holt demo:
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };

    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;
    union arincBuffer32 ArincBuffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings
    (void)pinNSW2;

    // -------------------------------------------------------------------------
    // Initial ARINC buffer contents
    // -------------------------------------------------------------------------
    // We will send a continuous stream of words with:
    //  - Label fixed at 0x01
    //  - Upper 16 bits counting upwards (data field)
    //
    // Trainee:
    //  - On ARINC analyzer: label 0x01, data field increments each word.
    //  - On UART: "TX(FULL)" / "TX(EMPTY)" lines show the pattern.
    // -------------------------------------------------------------------------
    ArincBuffer.arincTXWord  = 0x00000000;
    ArincBuffer.arincByte[0] = 0x0000;
    ArincBuffer.arincByte[1] = 0x0000;  // upper 16 bits as counter
    ArincBuffer.arincLable   = 0x01;    // label in low byte

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (as in original Holt demo)
    // -------------------------------------------------------------------------

    // Assert nMR low to reset HI-8582, then configure that pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure MCU GPIOs and timers
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure message interrupt pin (if used)
#endif

    init_timer();

    // Enable MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize external bus to talk to HI-8582
    Configure_ARM_MCU_ExtBus();

    // Flash both green LEDs to indicate init complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // UART console on USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset HI-8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LED ON (device detected)
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%.4X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LED OFF (device NOT detected)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%.4X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\r\n", controlReg);
        printf("Check for +10V and -10V on the board.\r\n");
        printf("These enable the 5V supply for the 8582.\r\n");
        printf("Status should be 0x0040. Press Reset after fixing power.\r\n");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default HI-8582 configuration and enable TX
    // -------------------------------------------------------------------------
    // DEFAULTCONFG: high-speed ARINC, odd parity, bit 32 = parity, unscrambled.
    writeControlWord(DEFAULTCONFG);

    enableTransmission();
    __enable_interrupt();

    printf("Exercise 5: FIFO behavior demo.\r\n");
    printf("Modes alternate every ~5 seconds:\r\n");
    printf("  FULL FIFO  : fill TX FIFO, then drain ALL RX1/RX2 words.\r\n");
    printf("  EMPTY FIFO : send ONE word when TX FIFO empty, read ONE RX word.\r\n\r\n");
    printf("Connect HI-8582 TX A/B to RX1 A/B and RX2 A/B and ARINC analyzer.\r\n\r\n");

    printf("[MODE] Starting in EMPTY FIFO mode (EmptyOrFull = 0).\r\n\r\n");

    EmptyOrFull  = 0;   // start in EMPTY mode
    g_modeTick   = 0;

    // -------------------------------------------------------------------------
    // Main loop:
    //   - Use TX FIFO and RX1/RX2 FIFOs differently in each mode.
    //   - Print a concise status line each loop so trainees can relate
    //     SR bits to FIFO depths.
    // -------------------------------------------------------------------------
    while (1) {
        unsigned short sr;

        // Read status register once per loop for printing & decisions
        sr = readStatusRegister();
        PrintStatusShort(sr);

        if (EmptyOrFull) {
            // =========================================================
            // FULL FIFO mode
            //   - Continuously load TX FIFO while TXNFULL == 0 (not full)
            //   - Then drain ALL RX1 and RX2 words
            // =========================================================
            printf("[MODE] FULL FIFO: load until TX FIFO full, then read ALL RX.\r\n");

            // Load TX FIFO until it's full
            while ((readStatusRegister() & TXNFULL) == 0) {
                disableTransmission();

                // Build next ARINC word:
                //  - label fixed at 0x01
                //  - upper 16 bits as incrementing counter
                ArincBuffer.arincTXWord = 0x00000000;
                ArincBuffer.arincLable  = 0x01;
                ArincBuffer.arincByte[1]++;

                writeTransmitterFIFO(ArincBuffer.arincTXWord);

                printf("TX(FULL) : 0x%.8X  Label: 0x%.2X\r\n",
                       ArincBuffer.arincTXWord,
                       ArincBuffer.arincTXWord & 0xFF);

                enableTransmission();
            }

            // Drain ALL RX1 words
            while (receiver1DataAvailable()) {
                arincReceiver1Buffer = readReceiverFIFO_1();
                printf("RX1(FULL): 0x%.8X  Label: 0x%.2X\r\n",
                       arincReceiver1Buffer,
                       arincReceiver1Buffer & 0xFF);
            }

            // Drain ALL RX2 words
            while (receiver2DataAvailable()) {
                arincReceiver2Buffer = readReceiverFIFO_2();
                printf("RX2(FULL): 0x%.8X  Label: 0x%.2X\r\n",
                       arincReceiver2Buffer,
                       arincReceiver2Buffer & 0xFF);
            }
        } else {
            // =========================================================
            // EMPTY FIFO mode
            //   - Wait until TX FIFO empty
            //   - Load exactly ONE word
            //   - Read at most ONE word from each RX FIFO
            // =========================================================
            printf("[MODE] EMPTY FIFO: send ONE word when TX empty, read ONE RX.\r\n");

            // When TX FIFO is empty, load a single word
            if (sr & TXEMPTY) {
                disableTransmission();

                ArincBuffer.arincTXWord = 0x00000000;
                ArincBuffer.arincLable  = 0x01;
                ArincBuffer.arincByte[1]++;

                writeTransmitterFIFO(ArincBuffer.arincTXWord);

                printf("TX(EMPTY) : 0x%.8X  Label: 0x%.2X\r\n",
                       ArincBuffer.arincTXWord,
                       ArincBuffer.arincTXWord & 0xFF);

                enableTransmission();
            }

            // Read at most one word from RX1
            if (receiver1DataAvailable()) {
                arincReceiver1Buffer = readReceiverFIFO_1();
                printf("RX1(EMPTY): 0x%.8X  Label: 0x%.2X\r\n",
                       arincReceiver1Buffer,
                       arincReceiver1Buffer & 0xFF);
            }

            // Read at most one word from RX2
            if (receiver2DataAvailable()) {
                arincReceiver2Buffer = readReceiverFIFO_2();
                printf("RX2(EMPTY): 0x%.8X  Label: 0x%.2X\r\n",
                       arincReceiver2Buffer,
                       arincReceiver2Buffer & 0xFF);
            }
        }

        // Delay so console is readable and give FIFOs time to evolve
        Delay_x100ms(1);   // ~100 ms
        g_modeTick++;

        // Toggle mode every MODE_TICKS intervals
        if (g_modeTick >= MODE_TICKS) {
            g_modeTick  = 0;
            EmptyOrFull = (EmptyOrFull ? 0 : 1);

            if (EmptyOrFull) {
                printf("\r\n=== SWITCHING TO FULL FIFO MODE (EmptyOrFull = 1) ===\r\n\r\n");
            } else {
                printf("\r\n=== SWITCHING TO EMPTY FIFO MODE (EmptyOrFull = 0) ===\r\n\r\n");
            }
        }
    } // end while(1)
}
