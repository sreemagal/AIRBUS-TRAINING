/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 1 � Minimal ARINC429 TX/RX demo
 *
 * This version is trimmed down from the full Holt demo:
 *  - No menu
 *  - No pushbutton handling
 *  - Just a continuous ARINC429 transmit stream plus RX1/RX2 prints.
 *
 * What the trainee should observe:
 *  - On the UART terminal (115200 8N1, connected to ADK USART1):
 *      TX : 0xXXXXXXXX  Label: 0x01
 *      RX1: 0xXXXXXXXX  Label: 0x01
 *      RX2: 0xXXXXXXXX  Label: 0x01
 *    The TX counter (upper 16 bits) increments each word.
 *
 *  - On the ARINC429 analyzer (connected to HI-8582 TX A/B):
 *      A continuous stream of words with:
 *        - Label = 0x01
 *        - High-speed ARINC (100 kbps, odd parity, 32nd bit = parity)
 *        - Data field increasing every word.
 *
 * Hardware requirement:
 *  - HI-8582 TX output must be wired to RX1 and RX2 (loopback) so that
 *    the transmitted words appear on both receivers.
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"    // also supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables
//------------------------------------------------------------------------------
#define VER "1.0"

// Not used in this minimal example but kept for compatibility
const H3582 pH3582 = HI3582_BASE;

//------------------------------------------------------------------------------
//  Helper: interpret Status & Control registers once at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n", controlReg);

    printf("\r\nStatus Register bit meanings:\r\n");

    // SR0..SR2 � Receiver 1 FIFO status
    printf("  SR0 (0x0001) RX1 data ready     : %s\r\n",
           (statusReg & 0x0001) ? "YES (RX1 FIFO has data)" : "no (RX1 empty)");
    printf("  SR1 (0x0002) RX1 half-full      : %s\r\n",
           (statusReg & 0x0002) ? "YES (>=16 words in RX1 FIFO)" : "no (<16 words)");
    printf("  SR2 (0x0004) RX1 full           : %s\r\n",
           (statusReg & 0x0004) ? "YES (RX1 FIFO full, risk overwrite)" : "no");

    // SR3..SR5 � Receiver 2 FIFO status
    printf("  SR3 (0x0008) RX2 data ready     : %s\r\n",
           (statusReg & 0x0008) ? "YES (RX2 FIFO has data)" : "no (RX2 empty)");
    printf("  SR4 (0x0010) RX2 half-full      : %s\r\n",
           (statusReg & 0x0010) ? "YES (>=16 words in RX2 FIFO)" : "no (<16 words)");
    printf("  SR5 (0x0020) RX2 full           : %s\r\n",
           (statusReg & 0x0020) ? "YES (RX2 FIFO full, risk overwrite)" : "no");

    // SR6..SR8 � Transmitter status
    printf("  SR6 (0x0040) TX FIFO empty      : %s\r\n",
           (statusReg & 0x0040) ? "YES (no words pending)" : "no");
    printf("  SR7 (0x0080) TX FIFO not full   : %s\r\n",
           (statusReg & 0x0080) ? "YES (space available)" : "no (TX FIFO full)");
    printf("  SR8 (0x0100) TX FIFO half-full  : %s\r\n",
           (statusReg & 0x0100) ? "YES (>=16 words loaded)" : "no (<16 words)");

    printf("\r\nControl Register bit meanings (initial config):\r\n");

    // CR0 & CR14 � Receiver data rates
    printf("  CR0 (0x0001) RX1 data rate      : %s\r\n",
           (controlReg & 0x0001) ? "LOW speed (CLK/80 � 12.5 kbps)"
                                  : "HIGH speed (CLK/10 � 100 kbps)");
    printf("  CR14(0x4000) RX2 data rate      : %s\r\n",
           (controlReg & 0x4000) ? "LOW speed (CLK/80 � 12.5 kbps)"
                                  : "HIGH speed (CLK/10 � 100 kbps)");

    // CR2 & CR3 � Label recognition
    printf("  CR2 (0x0004) RX1 label filter   : %s\r\n",
           (controlReg & 0x0004) ? "ENABLED (uses 16-label table)" : "disabled (accepts all labels)");
    printf("  CR3 (0x0008) RX2 label filter   : %s\r\n",
           (controlReg & 0x0008) ? "ENABLED (uses 16-label table)" : "disabled (accepts all labels)");

    // CR4 � 32nd bit parity vs data
    printf("  CR4 (0x0010) bit 32 function    : %s\r\n",
           (controlReg & 0x0010) ? "Parity bit (ARINC 32nd bit is parity)"
                                  : "Data bit (no parity bit)");

    // CR5 � Self-test vs normal mode
    printf("  CR5 (0x0020) self-test/normal   : %s\r\n",
           (controlReg & 0x0020) ? "Normal operation (receivers use external ARINC bus)"
                                  : "Self-test (TX digital loopback into RX1/RX2)");

    // CR6 & CR7/8 � RX1 SDI decoder
    printf("  CR6 (0x0040) RX1 SDI decoder    : %s\r\n",
           (controlReg & 0x0040) ? "ENABLED (bits 9/10 must match CR7/CR8)"
                                  : "disabled (no SDI filtering)");
    printf("  CR7 (0x0080) RX1 bit 9 match    : %s\r\n",
           (controlReg & 0x0080) ? "expects bit 9 = 1" : "expects bit 9 = 0");
    printf("  CR8 (0x0100) RX1 bit 10 match   : %s\r\n",
           (controlReg & 0x0100) ? "expects bit 10 = 1" : "expects bit 10 = 0");

    // CR9 & CR10/11 � RX2 SDI decoder
    printf("  CR9 (0x0200) RX2 SDI decoder    : %s\r\n",
           (controlReg & 0x0200) ? "ENABLED (bits 9/10 must match CR10/CR11)"
                                  : "disabled (no SDI filtering)");

    // CR12 � parity odd/even
    printf("  CR12(0x1000) TX parity mode     : %s\r\n",
           (controlReg & 0x1000) ? "Even parity on bit 32"
                                  : "Odd parity on bit 32");

    // CR13 � TX data rate
    printf("  CR13(0x2000) TX data rate       : %s\r\n",
           (controlReg & 0x2000) ? "LOW speed (CLK/80 � 12.5 kbps, ~10�s slope)"
                                  : "HIGH speed (CLK/10 � 100 kbps, ~1.5�s slope)");

    // CR15 � data format scrambling
    printf("  CR15(0x8000) data format        : %s\r\n",
           (controlReg & 0x8000) ? "Unscrambled ARINC (standard label/data layout)"
                                  : "Scrambled data (for special modes)\r\n");

    printf("\r\n");
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // Simple ARINC word buffer as in Holt demo:
    // - arincTXWord : full 32-bit word
    // - arincByte[0]: low 16 bits (includes label in low byte)
    // - arincByte[1]: high 16 bits (we use this as a counter)
    // - arincLable  : alias for low 8 bits (label)
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };

    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;
    union arincBuffer32 ArincBuffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings (unused)
    (void)pinNSW2;

    // -------------------------------------------------------------------------
    // Initial ARINC buffer contents
    // -------------------------------------------------------------------------
    // We will send a continuous stream of words with:
    //  - Label = 0x01
    //  - Upper 16 bits counting upwards (data field changes every word)
    //
    // Trainee: On the ARINC analyzer, you should see the label 0x01 and
    //          the data field incrementing for each word.
    //          On the UART console, the printed TX words should match.
    // -------------------------------------------------------------------------
    ArincBuffer.arincTXWord  = 0x87654300;
    ArincBuffer.arincByte[0] = 0x4311;  // includes some arbitrary low 16-bit pattern
    ArincBuffer.arincByte[1] = 0x0000;  // this demo will increment the upper 16 bits only
    ArincBuffer.arincLable   = 0x01;    // set label last so it overwrites lower byte

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (unchanged from Holt demo)
    // -------------------------------------------------------------------------

    // First priority: drive nMR low for the HI-8582, then configure that pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure MCU GPIOs and timers
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure the message interrupt pin (if used)
#endif

    init_timer();

    // Enable the MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize processor external bus to talk to HI-8582
    Configure_ARM_MCU_ExtBus();

    // Flash both green bus LEDs to indicate init complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // UART console on USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\n\r", VER);
    printf("Compiled: %s %s\n\n\r", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    // Trainee: At this point, if the HI-8582 has proper �10V and 5V supplies,
    //          the status register should read as 0x0040 and the LED will be ON.
    //          If status is invalid, the program stops and prints a message.
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset HI-8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON  (device detected)
        printf("*** Part Detected ***\n\rStatus Reg Valid = 0x%.4X\n\r", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\n\r", controlReg);

        // New: interpret Status & Control registers bit-by-bit once at startup
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF (device NOT detected)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%.4X ***\n\n\r", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\n\r", controlReg);
        printf("Check for +10V and -10V connected on the board.\n\r");
        printf("These enable the 5V power supply for the 8582.\n\r");
        printf("Status should be 0x0040. Press Reset after fixing power.\n\r");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default HI-8582 configuration
    // -------------------------------------------------------------------------
    // DEFAULTCONFG (from driver) typically configures:
    //  - Unscrambled ARINC format
    //  - 32nd bit = parity
    //  - High-speed ARINC (100 kbps)
    //  - Odd parity
    //
    // Trainee: Set your ARINC analyzer to:
    //    Bit rate  : 100 kbps
    //    Word size : 32 bits + parity
    //    Parity    : Odd
    // -------------------------------------------------------------------------
    writeControlWord(DEFAULTCONFG);  // default config to enable TX/RX, high-speed, odd parity

    // Enable transmitter and global interrupts
    enableTransmission();
    __enable_interrupt();

    // Make sure our upper 16-bit counter starts from 0
    ArincBuffer.arincByte[1] = 0x0000;
    ArincBuffer.arincLable   = 0x01;  // default label for Exercise 1

    printf("Exercise 1: Continuous ARINC429 TX with label 0x01; RX1/RX2 loopback.\n\r");
    printf("Connect HI-8582 TX A/B to RX1 A/B and RX2 A/B and attach ARINC analyzer.\n\r\n\r");

    // -------------------------------------------------------------------------
    // Main loop:
    //  1) Whenever TX FIFO is not full, load the next word.
    //  2) Continuously read RX1 and RX2 and print any received words.
    //
    // Trainee:
    //  - On UART: you should see a steady stream of lines like:
    //      TX : 0x01000001  Label: 0x01
    //      RX1: 0x01000001  Label: 0x01
    //      RX2: 0x01000001  Label: 0x01
    //
    //    The hex values will differ, but the LABEL should be 0x01 and RX1/RX2
    //    words should match the TX word (apart from parity bit).
    //
    //  - On ARINC analyzer: the bus should show the same label 0x01 and
    //    an incrementing data field at high-speed ARINC.
    // -------------------------------------------------------------------------
    while (1) {
        // 1) Transmit path: load TX FIFO whenever it is not full
        if ((readStatusRegister() & TXNFULL) == 0) {
            // Disable transmission while loading FIFO (as in Holt demo)
            disableTransmission();

            // Queue current ARINC word into the TX FIFO
            writeTransmitterFIFO(ArincBuffer.arincTXWord);

            // Print what we just queued
            printf("TX : 0x%.8X  Label: 0x%.2X\n\r",
                   ArincBuffer.arincTXWord,
                   ArincBuffer.arincTXWord & 0xFF);

            // Increment upper 16 bits (data field) for next word
            ArincBuffer.arincByte[1]++;

            // Re-enable transmitter
            enableTransmission();
        }

        // 2) Receiver 1: dump all received words
        while (receiver1DataAvailable()) {
            arincReceiver1Buffer = readReceiverFIFO_1();
            printf("RX1: 0x%.8X  Label: 0x%.2X\n\r",
                   arincReceiver1Buffer,
                   arincReceiver1Buffer & 0xFF);
        }

        // 3) Receiver 2: dump all received words
        while (receiver2DataAvailable()) {
            arincReceiver2Buffer = readReceiverFIFO_2();
            printf("RX2: 0x%.8X  Label: 0x%.2X\n\r",
                   arincReceiver2Buffer,
                   arincReceiver2Buffer & 0xFF);
        }

        // Small delay so the UART console is readable and not flooded.
        // Trainee: if you reduce this delay, you will see more frequent
        //          TX/RX lines and higher apparent ARINC throughput.
        Delay_x100ms(1);   // ~100 ms
    } // end while(1)
}
