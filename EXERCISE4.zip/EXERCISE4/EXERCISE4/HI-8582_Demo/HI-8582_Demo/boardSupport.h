/* ----------------------------------------------------------------------------
 *                            HOLT Integrated Circuits 
 * ----------------------------------------------------------------------------
 *
 *    file	board_613x.h
 *    brief     This file contains definitions applicable to all terminal modes
 *
 *              IMPORTANT: Because register addressing differs for Bus and 
 *              SPI interface, files "device_6130.h" and "device_6131.h" 
 *              contain the definitions needed for register addressing.
 *
 *	   	HOLT DISCLAIMER
 *      	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
 *      	KIND, EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 *      	WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 *      	PURPOSE AND NONINFRINGEMENT. 
 *      	IN NO EVENT SHALL HOLT, INC BE LIABLE FOR ANY CLAIM, DAMAGES
 *      	OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 *      	OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 *      	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
 *
 *              Copyright (C) 2009-2011 by  HOLT, Inc.
 *              All Rights Reserved
 */


// standard Atmel/IAR headers

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
/// The constants are named using the following convention: * for a constant 
/// that defines a single Pin instance, and PINS_* for a list of Pin instances.

//------------------------------------------------------------
// used for direct addressing
#define ENTX      1<<14 
#define SEL       1<<15 
#define nLEDG     1 << 16 // on PIOC
#define nMR       1 << 25 // on PIOC

/// Push button input on main board 
#define PIN_NSW1    {1 << 17, AT91C_BASE_PIOB, AT91C_ID_PIOB, PIO_INPUT, PIO_DEGLITCH}
#define PIN_NSW2    {1 << 18, AT91C_BASE_PIOB, AT91C_ID_PIOB, PIO_INPUT, PIO_DEGLITCH}
#define PINS_BUTTON PIN_NSW1, PIN_NSW2

//---------------------------------------------------------------
//  3582A_83A INPUTS definitions
#define PIN_NIRQ  {1 << 1, AT91C_BASE_PIOB, AT91C_ID_PIOB, PIO_INPUT}
#define PIN_TXR  {1 << 22, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_FFT  {1 << 23, AT91C_BASE_PIOB, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_HFT  {1 << 24, AT91C_BASE_PIOB, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_MR   {1 << 25, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_DR1  {1 << 26, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_HF1  {1 << 27, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_FF1  {1 << 28, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_DR2  {1 << 29, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_HF2  {1 << 30, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PIN_FF2  {1 << 31, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_INPUT}
#define PINS_INPUTS   PIN_NIRQ,PIN_TXR, PIN_FFT,  \
                      PIN_HFT, PIN_MR, PIN_DR1, PIN_HF1, \
                      PIN_FF1, PIN_DR2, PIN_HF2, PIN_FF2
                                            
//-------------------------------------------------------------
#define PIN_ENTX  {1 << 14, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_OUTPUT_0, PIO_DEFAULT}                        
#define PIN_SEL   {1 << 15, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_OUTPUT_0, PIO_DEFAULT}
#define PIN_LED   {1 << 16, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_OUTPUT_0, PIO_DEFAULT}
#define PIN_NMR   {1 << 25, AT91C_BASE_PIOC, AT91C_ID_PIOC, PIO_OUTPUT_1, PIO_DEFAULT}
#define PINS_OUTPUTS PIN_ENTX, PIN_SEL, PIN_LED, PIN_NMR

/// USART1 used for console I/O
#define PIN_USART_RXD    {0x1 << 21, AT91C_BASE_PIOA, AT91C_ID_PIOA, PIO_PERIPH_A, PIO_DEFAULT}
#define PIN_USART_TXD    {0x1 << 20, AT91C_BASE_PIOA, AT91C_ID_PIOA, PIO_PERIPH_A, PIO_DEFAULT}
#define PIN_USART_CTS    {0x1 << 23, AT91C_BASE_PIOA, AT91C_ID_PIOA, PIO_PERIPH_B, PIO_DEFAULT}
#define PIN_USART_RTS    {0x1 << 22, AT91C_BASE_PIOA, AT91C_ID_PIOA, PIO_PERIPH_B, PIO_DEFAULT}
#define PINS_USART       PIN_USART_RXD, PIN_USART_TXD, PIN_USART_CTS, PIN_USART_RTS

//------------------------------------------------------------------------------
//      Global Function Prototypes
//------------------------------------------------------------------------------
 
void ConfigureGpio(void);
void init_timer(void);
void Delay_us(unsigned short int num_us);
void Delay_ms(unsigned short int num_ms);
void Delay_x100ms(unsigned short num);
void Delay_x10us(unsigned short num);
void Flash_Green_LED(void);


// end of file

