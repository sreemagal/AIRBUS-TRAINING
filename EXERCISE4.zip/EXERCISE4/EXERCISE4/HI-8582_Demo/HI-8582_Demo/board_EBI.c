/* ----------------------------------------------------------------------------
 *                            HOLT Integrated Circuits 
 * ----------------------------------------------------------------------------
 *
 *    file	board_ebi.h
 *    brief     This file contains ARM Cortex M3 hardware initialization for
 *              the processor's External Bus Interface (EBI) for Holt HI-3582/83 
 *
 *	   	HOLT DISCLAIMER
 *      	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
 *      	KIND, EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 *      	WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 *      	PURPOSE AND NONINFRINGEMENT. 
 *      	IN NO EVENT SHALL HOLT, INC BE LIABLE FOR ANY CLAIM, DAMAGES
 *      	OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
 *      	OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 *      	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
 *
 *              Copyright (C) 2009-2011 by  HOLT, Inc.
 *              All Rights Reserved
 */


// standard Atmel/IAR headers
#include <pio/pio.h>
#include <pmc/pmc.h>

// Holt project headers
#include "board_EBI.h"
#include "3582A_83A_Driver.h"

//const H3582 pH3582;


//------------------------------------------------------------------------------
// This function initializes and configures the HI-3582/83 External Bus Interface
//------------------------------------------------------------------------------
// based on Atmel function BOARD_ConfigurePsram(), this function sets up the
// external bus interface (EBI) and the characteristic for the /CS0 chip select
// Changes to Atmel version: [a] Output address range was 
// reduced to 64K bytes (32K words) to free-up upper address output pins for use
// as ordinary GPIO, [b] header file definition deletes output pin connection for
// byte-select outputs used for 8-bit external bus or byte-addressed (e.g flash) 
// memories (still used for internal flash access), and [c] enabled the NWAIT input...
void Configure_ARM_MCU_ExtBus(void) 
{
    const Pin pin3582[] = {PINS_EBI_3582};
    unsigned int tmp;

    // Open EBI clock
    AT91C_BASE_PMC->PMC_PCER = (1<< AT91C_ID_HSMC4);

    // Configure I/O
    PIO_Configure(pin3582, PIO_LISTSIZE(pin3582));

#if 1   //3582_83 slower device. Default so either part can be demoed.    
    
    // Setup the bus (HSMC4_EBI.CS0, 0x60000000 ~ 0x6000FFFF)
    AT91C_BASE_HSMC4_CS0->HSMC4_SETUP = 0
                        | ((2 <<  0) & AT91C_HSMC4_NWE_SETUP)    //   min [A]
                        | ((2 <<  8) & AT91C_HSMC4_NCS_WR_SETUP) //   min 
                        | ((2 << 16) & AT91C_HSMC4_NRD_SETUP)    //   min 
                        | ((2 << 24) & AT91C_HSMC4_NCS_RD_SETUP) //   min 
                        ;
    AT91C_BASE_HSMC4_CS0->HSMC4_PULSE = 0
                        | ((14 <<  0) & AT91C_HSMC4_NWE_PULSE)    // 14 x 1/48M = 292ns [B]
                        | ((14 <<  8) & AT91C_HSMC4_NCS_WR_PULSE) // 14 x 1/48M = 292ns
                        | ((14 << 16) & AT91C_HSMC4_NRD_PULSE)    // 14 x 1/48M = 292ns
                        | ((14 << 24) & AT91C_HSMC4_NCS_RD_PULSE)
                        ;
    AT91C_BASE_HSMC4_CS0->HSMC4_CYCLE = 0
                        | ((16 <<  0) & AT91C_HSMC4_NWE_CYCLE)    // [A]+[B]
                        | ((16 << 16) & AT91C_HSMC4_NRD_CYCLE)
                        ;

#else // 3582A_83A is a faster device can use faster timings
    
    // Setup the bus (HSMC4_EBI.CS0, 0x60000000 ~ 0x6000FFFF)
    AT91C_BASE_HSMC4_CS0->HSMC4_SETUP = 0
                        | ((1 <<  0) & AT91C_HSMC4_NWE_SETUP)    // 0ns min [A]
                        | ((1 <<  8) & AT91C_HSMC4_NCS_WR_SETUP) // 0ns min 
                        | ((1 << 16) & AT91C_HSMC4_NRD_SETUP)    // 0ns min 
                        | ((1 << 24) & AT91C_HSMC4_NCS_RD_SETUP) //  0ns min 
                        ;
    AT91C_BASE_HSMC4_CS0->HSMC4_PULSE = 0
                        | ((5 <<  0) & AT91C_HSMC4_NWE_PULSE)    //  55ns min [B]
                        | ((5 <<  8) & AT91C_HSMC4_NCS_WR_PULSE) //  55ns min
                        | ((6 << 16) & AT91C_HSMC4_NRD_PULSE)    //  65ns min
                        | ((6 << 24) & AT91C_HSMC4_NCS_RD_PULSE)
                        ;
    AT91C_BASE_HSMC4_CS0->HSMC4_CYCLE = 0
                        | ((6 <<  0) & AT91C_HSMC4_NWE_CYCLE)    // [A]+[B]
                        | ((7 << 16) & AT91C_HSMC4_NRD_CYCLE)
                        ;    


#endif    
    
    tmp = AT91C_BASE_HSMC4_CS0->HSMC4_MODE & ~(AT91C_HSMC4_DBW);
    AT91C_BASE_HSMC4_CS0->HSMC4_MODE = tmp
                        | (AT91C_HSMC4_READ_MODE)  // read cycle controlled by NRD, not NCSx
                        | (AT91C_HSMC4_WRITE_MODE) // write cycle controlled by NWE, not NCSx
                        | (AT91C_HSMC4_BAT_BYTE_SELECT)
                        | (AT91C_HSMC4_DBW_WIDTH_SIXTEEN_BITS)
                        ;
                    //  | ((1 << 16) & AT91C_HSMC4_TDF_MODE) // 1 cycle data float enabled
                    //  | (AT91C_HSMC4_EXNW_MODE_NWAIT_ENABLE_READY) // NWAIT enabled
                    //  ;
}


// end of file

