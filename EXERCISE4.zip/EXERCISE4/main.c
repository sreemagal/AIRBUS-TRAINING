/* ----------------------------------------------------------------------------
 *            HOLT INTEGRATED CIRCUITS Applications Engineering
 * ----------------------------------------------------------------------------
 * HI-8582 / HI-8583 Exercise 4 – SDI (bits 9/10) Filtering Demo
 *
 * This version is derived from the Holt HI-8582 demo and Exercises 1–3:
 *  - No menu / pushbutton logic
 *  - Continuous ARINC429 TX stream with RX1/RX2 loopback prints
 *  - TX words cycle through SDI values 0..3 (bits 9/10) while label is fixed
 *  - RX1 uses the HI-8582 SDI decoder so it only accepts words whose SDI
 *    matches the currently selected filter value.
 *
 * Transmit pattern:
 *   - Label is fixed at 0x01 for all words.
 *   - SDI bits (bits 9 and 10) cycle: 0,1,2,3,0,1,2,3, ...
 *   - Upper 16 bits (data field) increment every word.
 *
 * SDI filter configuration (Receiver 1 only):
 *   - The RX1 SDI decoder is enabled using setRec_1Bit_9Bit10encoder().
 *   - Every ~5 seconds, the firmware changes RX1 SDI filter to one of:
 *       SDI = 0  (bits 9..10 = 00b)
 *       SDI = 1  (bits 9..10 = 01b)
 *       SDI = 2  (bits 9..10 = 10b)
 *       SDI = 3  (bits 9..10 = 11b)
 *
 * Trainee observations:
 *  - ARINC Analyzer (on HI-8582 TX A/B):
 *      You should see label 0x01 on the bus with SDI cycling 0..3 in order.
 *
 *  - UART console (115200 8N1, ADK USART1):
 *      TX : 0xXXXXXXXX  Label: 0x01  SDI: N
 *      RX1: 0xXXXXXXXX  Label: 0x01  SDI: N
 *      RX2: 0xXXXXXXXX  Label: 0x01  SDI: N
 *
 *    For RX1:
 *      - At any time, RX1 prints only those words whose SDI equals the
 *        current SDI filter value (shown in the mode banner).
 *      - RX2 does not use SDI filtering (all SDIs appear).
 *
 *    This demonstrates that HI-8582 SDI decoding uses bits 9/10 to
 *    further filter accepted labels, in addition to label recognition.
 * --------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
//         Headers
//------------------------------------------------------------------------------
#include <board.h>
#include <pio/pio.h>
#include <pio/pio_it.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

// Holt project headers
#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"    // supports HI-8582/8583
#include "Interrupts.h"
#include "console.h"

//------------------------------------------------------------------------------
//         Global variables
//------------------------------------------------------------------------------
#define VER "1.0"

// Not used directly in this example but kept for compatibility
const H3582 pH3582 = HI3582_BASE;

//------------------------------------------------------------------------------
//  Helper: extract SDI bits (bits 9 and 10) from an ARINC word
//------------------------------------------------------------------------------
// Assumes DEFAULTCONFG uses UNSCRAMBLED ARINC format, so the internal
// 32-bit word mapping is:
//   bits  0..7  : ARINC label bits 1..8
//   bits  8..9  : ARINC SDI bits 9..10
//   bits 10..28 : data
//   bit  31     : parity
//------------------------------------------------------------------------------
static unsigned char GetSDIFromWord(unsigned int word)
{
    return (unsigned char)((word >> 8) & 0x03u);  // bits 8..9
}

//------------------------------------------------------------------------------
// Helper: print a short explanation of SDI decoder configuration
//------------------------------------------------------------------------------
static void PrintSdiDecoderSummary(unsigned short controlReg)
{
    printf("  CR6 (0x0040) RX1 SDI decoder   : %s\r\n",
           (controlReg & CR6) ? "ENABLED (bits 9/10 must match CR7/CR8)"
                               : "disabled (no SDI filtering)");

    printf("  CR7 (0x0080) RX1 bit 9 match   : %s\r\n",
           (controlReg & CR7) ? "expects bit 9 = 1" : "expects bit 9 = 0");
    printf("  CR8 (0x0100) RX1 bit 10 match  : %s\r\n",
           (controlReg & CR8) ? "expects bit 10 = 1" : "expects bit 10 = 0");
    printf("\r\n");
}

//------------------------------------------------------------------------------
// Helper: one-time status/control print at startup
//------------------------------------------------------------------------------
static void PrintStatusAndControlDetails(unsigned short statusReg,
                                         unsigned short controlReg)
{
    printf("Raw Status Reg  = 0x%04X\r\n", statusReg);
    printf("Raw Control Reg = 0x%04X\r\n\r\n", controlReg);

    printf("Initial SDI-related Control bits:\r\n");
    PrintSdiDecoderSummary(controlReg);
}

//------------------------------------------------------------------------------
// Helper: configure RX1 SDI decoder for a desired SDI value (0..3)
//------------------------------------------------------------------------------
static void ConfigureRx1SdiFilter(unsigned char sdi)
{
    unsigned short bit9  = (unsigned short)(sdi & 0x1u);
    unsigned short bit10 = (unsigned short)((sdi >> 1) & 0x1u);

    // Enable SDI decoder on Receiver 1 with selected bits 9/10.
    // setRec_1Bit_9Bit10encoder(enable, bit9, bit10) is provided
    // in 3582A_83A_Driver.c.
    setRec_1Bit_9Bit10encoder(1, bit9, bit10);

    // Show configuration to trainee
    {
        unsigned short controlReg = readControlWord();
        printf("\r\n=== RX1 SDI filter changed: SDI = %u (bits9..10 = %u%u) ===\r\n",
               (unsigned int)sdi, (unsigned int)bit10, (unsigned int)bit9);
        PrintSdiDecoderSummary(controlReg);
    }
}

//------------------------------------------------------------------------------
//         main
//------------------------------------------------------------------------------
void main(void)
{
    unsigned short statusReg, controlReg;

    // Simple ARINC word buffer as in Holt demo:
    union arincBuffer32 {
        unsigned int   arincTXWord;
        unsigned short arincByte[2];
        unsigned char  arincLable;
    };

    unsigned int arincReceiver1Buffer;
    unsigned int arincReceiver2Buffer;
    union arincBuffer32 ArincBuffer;

    const Pin pinNMR  = PIN_NMR;   // Reset pin to HI-8582
    const Pin pinNSW1 = PIN_NSW1;  // Not used in this exercise
    const Pin pinNSW2 = PIN_NSW2;  // Not used in this exercise

    (void)pinNSW1; // avoid compiler warnings (unused)
    (void)pinNSW2;

    // SDI pattern for TX: 0,1,2,3 repeated
    unsigned char txSdiValues[4] = { 0, 1, 2, 3 };
    unsigned int  txSdiIndex     = 0;

    // Current SDI filter used by RX1 (starts at 0)
    unsigned char rx1SdiFilter = 0;
    unsigned int  filterTick   = 0;
    const unsigned int FILTER_TICKS = 50; // ~5 seconds per SDI (50 * 100ms)

    // -------------------------------------------------------------------------
    // Initial ARINC buffer contents
    // -------------------------------------------------------------------------
    // We will send a continuous stream of words with:
    //  - Label fixed at 0x01
    //  - SDI bits (9..10) cycling 0..3
    //  - Upper 16 bits as a counter that increments every word
    //
    // Trainee:
    //  - On ARINC analyzer: watch SDI field cycle 0,1,2,3 at label 0x01.
    //  - On UART:
    //      TX : shows SDI for every word.
    //      RX1: shows only words whose SDI equals current filter.
    //      RX2: shows all SDI values (no SDI filter).
    // -------------------------------------------------------------------------
    ArincBuffer.arincTXWord  = 0x00000000;
    ArincBuffer.arincByte[0] = 0x0000;
    ArincBuffer.arincByte[1] = 0x0000;
    ArincBuffer.arincLable   = 0x01;    // set label last so it overwrites low byte

    __disable_interrupt();              // until initialization is complete

    // -------------------------------------------------------------------------
    // Board-level initialization (as in original Holt demo)
    // -------------------------------------------------------------------------

    // Assert nMR low to reset HI-8582, then configure the pin
    AT91C_BASE_PIOC->PIO_CODR = nMR;    // assert reset (active low)
    PIO_Configure(&pinNMR, 1);

    // Configure MCU GPIOs and timers
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       // configure message interrupt pin (if used)
#endif

    init_timer();

    // Enable MCU external reset
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    // Initialize external bus to talk to HI-8582
    Configure_ARM_MCU_ExtBus();

    // Flash both green LEDs to indicate init complete
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LEDs ON
    Delay_x100ms(3);                    // 300ms
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LEDs OFF

    // UART console on USART1
    ConfigureUsart1();

    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Demo Board Ver: %s\r\n", VER);
    printf("Compiled: %s %s\r\n\r\n", __DATE__, __TIME__);

    // -------------------------------------------------------------------------
    // Reset and basic configuration of HI-8582
    // -------------------------------------------------------------------------
    statusReg = reset_3582();        // reset HI-8582/8583

    if (statusReg == SR_VALID_FROM_RESET) {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  // LED ON (device detected)
        printf("*** Part Detected ***\r\nStatus Reg Valid = 0x%.4X\r\n", statusReg);

        controlReg = readControlWord();
        PrintStatusAndControlDetails(statusReg, controlReg);
    } else {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  // LED OFF (device NOT detected)
        printf("*** Part Not Detected, Status Reg Invalid = 0x%.4X ***\r\n\r\n", statusReg);

        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\r\n", controlReg);
        printf("Check for +10V and -10V on the board.\r\n");
        printf("These enable the 5V supply for the 8582.\r\n");
        printf("Status should be 0x0040. Press Reset after fixing power.\r\n");

        for (;;) {
            // dead loop if HI-8582 not detected
        }
    }

    // -------------------------------------------------------------------------
    // Apply default configuration and enable SDI filtering on RX1
    // -------------------------------------------------------------------------
    // DEFAULTCONFG typically selects:
    //  - Unscrambled ARINC
    //  - 32nd bit = parity
    //  - High-speed ARINC (100 kbps)
    //  - Odd parity
    writeControlWord(DEFAULTCONFG);

    enableTransmission();
    __enable_interrupt();

    // Disable label recognition for both RX1 and RX2 so only SDI filtering
    // is in effect (label is fixed at 0x01 anyway).
    enableRec1_Labels(DISABLE);
    enableRec2_Labels(DISABLE);

    // Configure initial RX1 SDI filter (SDI = 0)
    ConfigureRx1SdiFilter(rx1SdiFilter);

    printf("Exercise 4: SDI (bits 9/10) filtering demo.\r\n");
    printf("TX label fixed at 0x01, SDI cycles 0->1->2->3 on each word.\r\n");
    printf("RX1 SDI filter changes every ~5 seconds to match SDI = 0,1,2,3.\r\n");
    printf("RX2 has SDI decoding disabled (no SDI filter).\r\n\r\n");
    printf("Connect HI-8582 TX A/B to RX1 A/B and RX2 A/B and ARINC analyzer.\r\n\r\n");

    // -------------------------------------------------------------------------
    // Main loop:
    //   1) Build and transmit ARINC words with SDI cycling 0..3.
    //   2) Continuously read RX1/RX2 FIFOs and print received words + SDI.
    //   3) Every FILTER_TICKS (~5s), change RX1 SDI filter to next value.
    //
    // Trainee:
    //   - On analyzer: SDI field cycles 0..3 for label 0x01.
    //   - On UART:
    //       TX : label 0x01, SDI cycles 0..3.
    //       RX1: only SDIs matching current filter appear.
    //       RX2: all SDIs appear (no filter).
    // -------------------------------------------------------------------------
    while (1) {
        // 1) Transmit path: load TX FIFO whenever it is not full
        if ((readStatusRegister() & TXNFULL) == 0) {
            unsigned char sdi = txSdiValues[txSdiIndex];

            // Build ARINC word:
            //  - Start from zero
            //  - Set label = 0x01 (low 8 bits)
            //  - Set SDI bits (9..10) to 'sdi'
            //  - Increment upper 16-bit data counter
            ArincBuffer.arincTXWord = 0x00000000;
            ArincBuffer.arincLable  = 0x01;       // label in low 8 bits

            // Set SDI in bits 8..9
            ArincBuffer.arincTXWord &= ~(0x03u << 8);
            ArincBuffer.arincTXWord |= ((unsigned int)(sdi & 0x03u) << 8);

            // Increment upper 16-bit data field
            ArincBuffer.arincByte[1]++;

            // Cycle SDI index
            txSdiIndex = (txSdiIndex + 1) & 0x3u;

            disableTransmission();
            writeTransmitterFIFO(ArincBuffer.arincTXWord);

            printf("TX : 0x%.8X  Label: 0x%.2X  SDI: %u\r\n",
                   ArincBuffer.arincTXWord,
                   ArincBuffer.arincTXWord & 0xFF,
                   (unsigned int)sdi);

            enableTransmission();
        }

        // 2) Receiver 1: dump all received words and show SDI
        while (receiver1DataAvailable()) {
            arincReceiver1Buffer = readReceiverFIFO_1();
            printf("RX1: 0x%.8X  Label: 0x%.2X  SDI: %u\r\n",
                   arincReceiver1Buffer,
                   arincReceiver1Buffer & 0xFF,
                   (unsigned int)GetSDIFromWord(arincReceiver1Buffer));
        }

        // 3) Receiver 2: dump all received words and show SDI
        while (receiver2DataAvailable()) {
            arincReceiver2Buffer = readReceiverFIFO_2();
            printf("RX2: 0x%.8X  Label: 0x%.2X  SDI: %u\r\n",
                   arincReceiver2Buffer,
                   arincReceiver2Buffer & 0xFF,
                   (unsigned int)GetSDIFromWord(arincReceiver2Buffer));
        }

        // 4) Periodically change RX1 SDI filter
        Delay_x100ms(1);   // ~100 ms
        filterTick++;

        if (filterTick >= FILTER_TICKS) {
            filterTick = 0;

            // Advance SDI filter 0..3
            rx1SdiFilter = (unsigned char)((rx1SdiFilter + 1u) & 0x3u);
            ConfigureRx1SdiFilter(rx1SdiFilter);
        }
    } // end while(1)
}
