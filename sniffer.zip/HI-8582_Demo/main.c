/* ----------------------------------------------------------------------------
 *  HI-8582 / HI-8583 ARINC 429 Sniffer Firmware (Board C, LOW SPEED)
 *  Based on Holt "_HI-8582 Demo" main.c
 *
 *  - Initializes HI-8582 exactly like the Holt demo
 *  - Configures for LOW-SPEED, normal mode, odd parity, unscrambled
 *  - Disables TX on this board (RX-only sniffer)
 *  - Continuously reads RX1/RX2 and prints decoded ARINC words on USART1
 * ----------------------------------------------------------------------------
 */

#include <board.h>
#include <pio/pio.h>
#include <tc/tc.h>
#include <irq/irq.h>
#include <utility/trace.h>
#include <intrinsics.h>
#include <stdio.h>

#include "boardSupport.h"
#include "common_init.h"
#include "board_EBI.h"
#include "3582A_83A_Driver.h"
#include "Interrupts.h"
#include "console.h"

#define VER "Sniffer LS 1.0"

/* These globals are used by Holt driver and support code */
unsigned short EmptyOrFull = 0;      /* FIFO handling: 0 = Empty mode, 1 = Full mode */
const H3582    pH3582      = HI3582_BASE;

/* ------------------------------------------------------------------------- */
/* Utility: print one received ARINC word                                   */
/* ------------------------------------------------------------------------- */

static void Sniffer_PrintWord(unsigned int channel, unsigned int word)
{
    /* HI-8582 host word format:
       bits 0..7   : LABEL
       bits 8..9   : SDI
       bits 10..28 : DATA (19 bits)
       bits 29..30 : SSM
       bit  31     : PARITY
     */
    unsigned char  label  = (unsigned char)(word & 0xFFu);
    unsigned char  sdi    = (unsigned char)((word >> 8) & 0x03u);
    unsigned long  data   = (word >> 10) & 0x7FFFFu;
    unsigned char  ssm    = (unsigned char)((word >> 29) & 0x03u);
    unsigned char  parity = (unsigned char)((word >> 31) & 0x01u);

    printf("CH%u LBL=%02X SDI=%u DATA=%05lX SSM=%u P=%u\r\n",
           (unsigned int)channel,
           (unsigned int)label,
           (unsigned int)sdi,
           data,
           (unsigned int)ssm,
           (unsigned int)parity);
}

/* ------------------------------------------------------------------------- */
/* Main � Holt init + LOW-SPEED sniffer loop                                */
/* ------------------------------------------------------------------------- */

void main(void)
{
    unsigned short statusReg, controlReg;
    const Pin pinNMR  = PIN_NMR;

    __disable_interrupt();              /* Match Holt demo: no interrupts during init */

    /* First priority: reset pin to 0 for nMR, then configure that MCU pin as output */
    AT91C_BASE_PIOC->PIO_CODR = nMR;    /* drive /NMR low */
    PIO_Configure(&pinNMR, 1);

    /* Configure ARM's GPIO pins and timer(s) */
    ConfigureGpio();

#if INT
    ConfigureHostInterruptPins();       /* message interrupt pin */
#endif

    init_timer();

    /* Enable external reset for MCU (same as demo) */
    AT91C_BASE_RSTC->RSTC_RMR = 0xA5000F01;

    /* Initialize processor External Bus Interface for HI-8582 */
    Configure_ARM_MCU_ExtBus();

    /* Flash green LEDs to indicate initialization complete */
    AT91C_BASE_PIOC->PIO_CODR = nLEDG;  /* LEDs ON  */
    Delay_x100ms(3);                    /* 300ms    */
    AT91C_BASE_PIOC->PIO_SODR = nLEDG;  /* LEDs OFF */

    /* Initialize USART1 at 115200 8-N-1 (Holt console) */
    ConfigureUsart1();
    printf("\n\n\n\n\n\n\rHolt Integrated Circuits HI-8582/8583 Sniffer Ver: %s\n\r", VER);
    printf("Compiled: %s %s\n\n\r", __DATE__, __TIME__);

    /* --------------------------------------------------------------------- */
    /* HI-8582 reset and basic configuration                                */
    /* --------------------------------------------------------------------- */

    statusReg = reset_3582();    /* active-low pulse on nMR, then readStatusRegister() */
    printf("Status  = 0x%04X\r\n", statusReg);

    if (statusReg == SR_VALID_FROM_RESET)
    {
        AT91C_BASE_PIOC->PIO_CODR = nLEDG;  /* LED ON = part detected */
        printf("*** HI-8582 Detected ***\n\rStatus Reg Valid = 0x%.4X\n\r", statusReg);
        controlReg = readControlWord();
        printf("Initial Control Word = 0x%.4X\n\n\r", controlReg);
    }
    else
    {
        AT91C_BASE_PIOC->PIO_SODR = nLEDG;  /* LED OFF = part not detected */
        printf("*** Part Not Detected, Status Reg Invalid = 0x%.4X ***\n\n\r", statusReg);
        controlReg = readControlWord();
        printf("Control Word = 0x%.4X\n\r", controlReg);
        printf("Check +10V/-10V supplies and +5V enable on ADK-8582.\n\r");
        for (;;);   /* dead loop if part not detected */
    }

    /* Set control word explicitly for HIGH-SPEED, normal mode, odd parity, unscrambled:
       0x8030 = 0x8000 (Holt test config / unscrambled)
              + 0x0000 (HI speed)
              + 0x0020 (NORMAL mode)
              + 0x0010 (PARITY enabled; bit 32 is parity)
     */
    writeControlWord(0x8030);

    /* Make this board RX-only: disable TX output driver */
    disableTransmission();               /* ENTX low; control word unchanged */

    controlReg = readControlWord();
    printf("Sniffer Control = 0x%04X\r\n", controlReg);

    /* Configure receiver label tables (demo defaults).
       Receiver-1: 0x01,0x03,...,0x31
       Receiver-2: 0x00,0x02,...,0x30
     */
    //loadReceiver_1_Labels();
    //loadReceiver_2_Labels();

    printf("Receivers configured, sniffer running...\r\n");

    __enable_interrupt();

    /* --------------------------------------------------------------------- */
    /* Sniffer main loop � RX1 & RX2 only, no TX                             */
    /* --------------------------------------------------------------------- */

    for (;;)
    {
        /* Receiver channel 1 */
        while (receiver1DataAvailable())
        {
            unsigned int word = readReceiverFIFO_1();
            Sniffer_PrintWord(1u, word);
        }

        /* Receiver channel 2 */
        while (receiver2DataAvailable())
        {
            unsigned int word = readReceiverFIFO_2();
            Sniffer_PrintWord(2u, word);
        }

        /* Pure polling sniffer � no delays so we don't miss fast bursts */
    }
}
